# 렌더 리뷰 루프 (S6 fit + 점진 검토) — 단독 S6·결합 파이프라인 공용 단일 출처

S6가 슬라이드를 **슬라이드 단위로 fit하고 유저가 점진 검토**하는 공통 절차. 두 경로가 이 문서를 그대로 따른다:

- **단독 S6**(`render/SKILL.md`) — 완성된 `slide_plan.json`으로 돈다. 각 슬라이드를 `assemble_slide.py --plan "$PLAN" --slide <n>`로 seed(전량 미리 or 필요 시), PLAN 풀 없음.
- **S5↔S6 결합**(`pipeline/references/pipeline-render.md`) — S5를 슬라이드별로 교차하며 돈다. 각 슬라이드를 `--plan-slide <레코드>`로 seed, PLAN 풀이 동시에 앞 슬라이드를 설계.

**seed 방법·plan 소스는 호출자가 정하고, 경로 공통분은 이 문서가 소유한다** — FIT 디스패치·연속 top-up·동시 예산·refit 슬롯·finalize 게이트·재개 reconcile, 그리고 일시정지·질문·피드백·패널(= 유저 리뷰 UX). 호출자는 경로 고유분만 더한다(결합: PLAN 풀 교차 · 단독: `--plan` seed). 그래서 두 경로의 리뷰 질문·동작이 문자 그대로 동일하다.

## N (리뷰 배치 크기)
`N = 10` (기본값). 일시정지 카운트·질문 라벨·진단 패널 배치 섹션 크기가 모두 이 `N`을 쓴다. 유저가 진입 질문(아래)에서 다른 크기를 요청하면(예: "5장씩 보여줘") 그 값이 런 내내 유효 N이 되고, 이 문서의 이후 모든 `N`은 그 유효값을 가리킨다.

## 진입 모드 선택 (시작 질문, 1회)
S6 진입 시 **딱 한 번** 리뷰 방식을 묻는다(AskUserQuestion, 사용자 표시 문장 규칙 준수):

**"어떤 방식으로 진행할까요?"**
- **슬라이드 1–N 렌더 후 리뷰하기** — 점진 리뷰 모드. N장마다 일시정지해 검토·수정한다(아래 일시정지 질문).
- **슬라이드 전체 렌더 후 마지막에 리뷰하기** — 일괄 모드. 중간 일시정지 없이 끝까지 렌더하고, 마지막에 `--expand-all`로 패널을 다시 그려 전 구간을 한 번에 리뷰한다(아래 "마지막 옵션" 참고).

모드는 런 동안 유지되되, 점진 모드의 일시정지에서 일괄 모드로 전환할 수 있다(일시정지 질문 옵션 3).

## FIT 디스패치 (슬라이드당 서브에이전트 1개, 연속 top-up)
`seeded` 슬라이드를 **slide_number 오름차순**으로 FIT 풀에 띄우되 **연속 top-up**한다: FIT 풀을 동시 상한(≤4 — `render_slide.py`가 로컬 soffice를 호출, soffice가 CPU 상한)까지 채워 두고 **하나가 끝나는 즉시 다음 `seeded`를 띄운다.** 절대 '한 웨이브(4장)가 다 끝나길 기다렸다가 다음 웨이브'가 아니다 — fit은 슬라이드당 라운드 편차가 커서(1회~`fit.md`의 캡까지) 웨이브 배리어를 두면 매 웨이브가 **가장 느린 슬라이드**에 묶여 빠른 슬롯이 논다(벽시계가 `Σ웨이브별-최장`으로 늘어난다). 연속 top-up이면 `총 fit 작업량 / 상한`에 수렴한다. 그러려면 fit 서브에이전트를 **백그라운드로** 띄워 **개별 완료**를 관찰하고(배치 전체를 await하지 않는다) 완료 알림마다 풀을 상한까지 되채운다. 유일한 동기화 지점은 아래 **N장 일시정지**뿐이다. `render` 스킬 Stage 3을 **슬라이드당 1개**로 디스패치한다(`{SLIDE_DIRS}` = 그 슬라이드 dir 하나; `fit.md`는 grouping-agnostic이라 프롬프트·스크립트 변경 없음). 입력:
- `{FEEDBACK_GUIDANCE}` — 이 슬라이드에 적용할 누적 일반 규칙: `feedback_store.py active {name} --root <abs> --run {run_label} --slide <n> --format text`. 비어 있으면 생략.
- `{FEEDBACK}` — 일반 진행 중엔 없음. 일시정지 재핏에서만 그 슬라이드에 직접 지시로 붙인다.

**재수정(refit)도 FIT 디스패치다.** 기존 `slides/<n>/` dir에 `{FEEDBACK}`를 붙여 같은 FIT 풀·연속 top-up으로 띄운다(슬롯 하나 점유, **별도 refit 상한 없음** — soffice 동시성이 초과되지 않게 예산 하나를 공유한다). 일반 진행 중엔 없고 일시정지에서 확인된 수정 지시로만 띄운다. 슬롯이 하나 비고 대기 중 refit과 forward fit이 둘 다 있으면 **대기 refit 먼저(요청 순 FIFO)**, 그다음 forward top-up이다.

**타이밍 기록(메트릭).** FIT(fit·refit 공통)을 띄우기 **직전** `record_round.py start <slide_dir> --kind fit|refit [--note "<지시 요지>"]`, **완료를 관찰한 시점** `record_round.py stop <slide_dir>` 를 실행한다(kind 판별 = `{FEEDBACK}` 유무 — refit은 `--kind refit`, `--note`에 지시 요지). 스크립트가 wall-clock을 스스로 재 `slides/<n>/rounds.jsonl`에 append하므로(덮어쓰지 않음 — `status.json`과 달리 fit과 이후 refit이 라인별로 남는다) 시간을 옮겨 적지 않는다. 기록 실패는 렌더를 막지 않는다(경고만).

완료 마커 = `slides/<n>/status.json`. 슬라이드가 `fit_done` 될 때마다 `slide_diagnostics.py … --run "$RUN" --batch-size N` 로 패널을 갱신한다(라이브 스트리밍, `N` = 위 §N의 유효값). 진단 패널은 슬라이드를 `slide_number` 기준 N-슬라이드 배치 섹션으로 묶어 보여주고(최신 배치만 펼침, 이전 배치는 접혀 재방문 가능), plan 조각은 plan이 생기는 대로 먼저 뜨며 render는 완료되는 슬라이드부터 채워진다. `render` fit 계약(인용·이미지 보존·acceptance check·`status.json` 스키마)은 그대로.

## N장 일시정지 + 점진 검토
`slide_diagnostics.py`가 그린 `outputs/render/slide_diagnostics.html` 패널이 검토 표면이다 — 각 슬라이드 render 썸네일을 overview 그리드로 펼치고(상태 색으로 floor/fallback 강조, `slide_number` 순), 클릭하면 그 render를 plan 결정(catalog 조각)과 나란히 놓는 focused overlay가 열려 결함을 S5/S6로 localize한다.

- **카운트:** `fit_done`가 N의 배수에 닿거나(중간 정지) 마지막 슬라이드가 fit_done 되면(마지막 정지) 일시정지한다(`N` = 위 §N). FIT은 slide_number 오름차순으로만 디스패치하고 정지 시 진행 중 FIT을 **await**(취소 아님)하므로 정지 시점 배치 a–b는 항상 연속이다. 마지막 배치가 N 미만이어도 마무리 전 반드시 한 번 검토한다. **N 카운트는 forward fit의 최초 `fit_done`만 센다**(= `rounds.jsonl`의 `kind=fit` 라인) — refit이 이미 센 슬라이드의 `status.json`을 다시 써도 N을 올리지 않고 일시정지를 재발동하지 않는다.
- **정지 행동:** 새 forward FIT을 멈추고 진행 중 forward FIT을 await로 비운 뒤, `slide_diagnostics.py … --run "$RUN" --batch-size N`로 패널 갱신하고 아래 **일시정지 질문**. (결합 모드는 이때 PLAN을 계속 돌린다 — 단독 S6엔 PLAN이 없다.) **백그라운드 refit은 drain 대상이 아니다** — 이미 검토된 앞 배치 슬라이드라 정지를 가로질러 계속 돌고, 완료 시 아래 "완료 알림"으로 보고된다.
- **재개:** "렌더 후 리뷰" 류 옵션이면 다음 `seeded`부터 FIT 재개. 상태가 디스크에 있어 정지는 세션을 넘겨도 된다.

**일시정지 질문 (점진 모드):** AskUserQuestion — **"어떤 방식으로 진행할까요?"** (a–b = 방금 배치, c = 다음 시작 번호, M = 총 슬라이드 수). **잔여량에 따라 옵션이 달라진다:**
- **잔여 > N:** ① 슬라이드 a–b 중에 수정하기 · ② 슬라이드 c–(c+N−1) 렌더 후 리뷰(점진 유지) · ③ 남은 c–M 전체 렌더 후 마지막 리뷰(일괄 전환).
- **잔여 ≤ N:** ②·③가 같은 잔여를 가리키므로 합쳐 2옵션 — ① 수정하기 · ② 남은 c–M 렌더 후 **마지막 리뷰**.
- **잔여 0 (마지막 정지 — 전체 렌더됨):** 다음 배치가 없으므로 2옵션 — ① 수정하기 · ② **마무리하기**(→ package→verify→출력).

**① 수정하기(모든 변형 공통):** 고르면 orchestrator가 **곧바로 후속 자유 입력**으로 수정 내용을 받는다("어떤 점을 수정할까요? 슬라이드 번호와 함께 구체적으로 적어주세요"). AskUserQuestion은 옵션에 입력창을 못 넣고 자동 'Other'만 붙으므로, 입력창을 옵션으로 분리하지 말고 **선택 → 후속 질문** 2단계로 받는다(자동 'Other'는 피드백 채널로 쓰지 않음). 받은 피드백은 아래 "일시정지 중 피드백"으로 처리한다. 일괄 모드(시작 옵션 2)의 끝 리뷰도 = **마지막 정지**(① 수정 · ② 마무리).

**마지막 옵션(시작 질문 옵션 2 · 일시정지 질문 옵션 3 공통):** 끝까지 렌더한 뒤 `slide_diagnostics.py … --run "$RUN" --batch-size N --expand-all --total-slides M` 로 패널을 다시 그린다 — `--expand-all`이 모든 배치 섹션을 펼쳐서 이번 런에서 렌더된 **모든 슬라이드**를 한 번에 검토하게 되고, `--total-slides`가 마지막 배치 라벨을 실제 끝 번호(M)로 자른다.

## 일시정지 중 피드백 (자연어 → 해석 → 확인 → 백그라운드 적용)
유저가 미리보기를 보고 자연어로 수정을 요청하면(패널의 `slide_number`로 지칭, 예: *"슬라이드 1에서 'X' 헤더가 아래 내용을 가리고 있어. 수정해줘"*), orchestrator가 일시정지에서 대화 루프로 처리한다(입력은 채팅). **재수정은 블로킹하지 않는다**(절차·타이밍은 아래 4 — forward fit의 N장 일시정지는 그대로 유지된다).

1. **신중히 해석(피드백은 종종 모호).** 어떤 슬라이드인지, 무엇이 문제인지, **구체적 고치는 법**을 도출한다.
2. **고치는 법을 유저에게 확인(포그라운드).** 해석한 수정안을 되읽어주고 확인을 받는다 — 추측으로 적용하지 않는다. 디스패치 전 유일한 동기 단계다. 수정안 텍스트는 **AskUserQuestion 옵션의 `preview`에 담는다** — 툴 호출 직전에 쓴 채팅 텍스트는 유저에게 렌더되지 않을 수 있다.
3. **조용히 분류 + 지금 적재(유저에게 노출 안 함).** 일반화 가능한 규칙인지 그 슬라이드 한정인지 스스로 판단한다 — 유저에게 묻지 않는다. **디스패치·재개 전에 먼저 적재한다:** 일반화 가능이면 `feedback_store.py add {name} --root <abs> --run {run_label} --source-slide <n> --raw "<원문>" --interpreted "<적용 규칙>" --scope general`(뒤 forward fit이 `{FEEDBACK_GUIDANCE}`로 선반영하려면 **재개 전에** 있어야 한다). 그리고 확인된 지시는 **항상** `--scope slide_only`로도 적재한다(provenance + 크래시 복구용 재-offer 근거). **적재 호출들과 아래 4의 `record_round.py start`는 `&&`로 묶어 한 번의 셸 호출로 실행한다** — 확인→질문 재등장 사이의 턴 지연을 줄인다. (더블-플래그로 즉시 디스패치가 안 되는 분기에서도 **적재는 확인 즉시**, `start`는 실제 디스패치 시점에 — 크래시 재-offer가 적재분에 걸려 있다.)
4. **백그라운드로 그 슬라이드를 고친다.** 슬라이드별 refit lock(`slides/<n>/.round_start.json` `kind=refit` 존재 — 같은 slide dir를 두 에이전트가 동시에 편집해 XML을 깨뜨리지 않도록, 슬라이드당 refit은 동시에 1개)을 확인한다:
   - **lock이 비어 있으면:** `record_round.py start <slide_dir> --kind refit --note "<지시 요지>"`(위 3과 한 셸 호출) → fit 서브에이전트를 그 dir에 `{FEEDBACK}`=확인된 지시로 **백그라운드 디스패치(await 안 함)** → **바로 다음 행동으로 같은 일시정지 질문을 다시 던진다 — 디스패치와 질문 사이에 패널 갱신·상태 확인 등 다른 작업을 끼워넣지 않는다**(패널은 완료 알림 때 갱신된다). 유저는 다른 슬라이드를 또 지목(또 다른 백그라운드 refit, 공유 예산까지)하거나 재개("다음 N"/"남은 전체")할 수 있다.
   - **이미 refit 진행 중이면(더블-플래그):** 멈춰 묻는다 — "슬라이드 <n> 재수정이 '<현재 지시 요지>'로 이미 진행 중입니다. 어떻게 할까요?": ① 끝날 때까지 기다렸다 적용(현재 것 완료 후 새 지시 디스패치) · ② 현재 것을 취소하고 새 지시 적용(`TaskStop`으로 진행 중 에이전트 중단 → `record_round.py reconcile <slide_dir>`로 마커 정리 → 새 refit 디스패치) · ③ 직접 입력.

**일반 규칙 캐시(위 3의 general 적재분).** 이후 **아직 fit 안 한 슬라이드**의 FIT 디스패치가 `feedback_store.py active`로 이를 `{FEEDBACK_GUIDANCE}`로 받아 선반영한다. 슬라이드 한정(`slide_only`)은 forward로 흘리지 않고 provenance로만 남는다.

**캐시 범위 — 프로젝트 단위.** `projects/{name}/render_feedback.json`. 같은 덱의 재렌더에도 유지되고, 프로젝트를 넘지 않는다. 활성 판정(원런은 피드백 슬라이드 이후, 이후 런은 전 슬라이드)은 `feedback_store.py`가 소유한다.

## 백그라운드 재수정 완료 알림
refit 서브에이전트 완료를 **관찰할 때마다**(백그라운드 완료 통지):
1. `record_round.py stop <slide_dir>` (kind=refit, `--note`는 마커에서 승계) — lock 해제 + ledger 기록.
2. `slide_diagnostics.py … --run "$RUN" --batch-size N` 재실행으로 패널을 갱신한다(그 슬라이드의 새 render가 뜬다).
3. **채팅으로만 알린다**(패널 배지·이미지 첨부·push 없음): 예) `슬라이드 <n> 재생성이 완료되었습니다. 우측 패널에서 확인해보세요.` 결과는 `status.json`으로 판정해 문장에 싣는다 — `passed && !needs_attention` → 완료 / `needs_attention` → `완료(확인 필요: <residual>)` / 백그라운드 태스크 오류, 또는 `status.json` mtime이 `rounds.jsonl` 마지막 refit 라인의 `started_at`보다 오래됨(= 재수정이 결과를 못 씀; 마커는 1의 stop이 이미 지웠으므로 그 라인이 start 시각의 유일한 출처다) → `재수정 실패 — 원본 유지, 다시 시도할까요?`(재-offer). AskUserQuestion 모달로 막지 않는다.
4. 거의 동시에 여러 refit이 끝나면 한 메시지로 묶어 각 슬라이드 결과를 적는다(debounce).
5. 그 슬라이드에 **대기 중인 더블-플래그 지시**(위 4-①)가 있으면 지금 위 4의 "lock이 비어 있으면" 절차 그대로(`record_round.py start --kind refit --note` → 백그라운드 디스패치) 디스패치한다. 대기 지시는 위 3에서 이미 `slide_only`로 적재돼 있어 세션이 죽어도 재-offer로 살아남는다.

## 재개 (크래시·세션 중단 후)
런을 재개할 때 forward 재디스패치보다 먼저 `record_round.py reconcile "$RUN/slides"`를 1회 돌린다. 살아남은 `.round_start.json`은 중단된 라운드다 — reconcile이 `duration_s=null` 라인으로 마감하고(다운타임이 시간에 부풀지 않게) 마커를 지운다. 이 선행 단계가 필요한 이유: refit된 슬라이드는 이미 `status.json`이 있어서, '`status.json` 없는 슬라이드만 재디스패치'하는 forward resume 규칙만으로는 dangling refit 마커를 영영 보지 못한다. 이어서 재-offer 두 갈래 — ① 마커가 `kind=refit`이었으면 저장된 지시로 그 슬라이드 재수정을 다시 실행할지 유저에게 제안한다. ② `feedback_store`에 `slide_only`로만 남고 완료 refit 라인이 없는 지시(대기 중이던 더블-플래그 지시 포함)도 같은 재-offer 대상이다.

## 리뷰 표면 + 셋업
- **패널 seed:** 런 시작 시 `slide_diagnostics.py {name} --root <abs> --batch-size N` 를 `--run` 없이 1회 실행해 패널(`outputs/render/slide_diagnostics.html`)을 깐다(plan 레코드가 있으면 plan 먼저 채워지고, 없으면 빈 상태로 그려진다). `--run` 없는 seed 호출은 **no-clobber**다 — 패널이 이미 있으면 덮지 않고 skip해, 재개 시 셋업 재실행이 진행 중 패널을 지우지 않는다.
- **표시(둘 다 셸의 S6 탭 · 라이브 스트리밍):** 결합·단독 **둘 다 진행 셸(`outputs/index.html`)을 `outputs/` 루트로 정적 서빙해 preview에 띄우고, 셸의 S6 탭 iframe(`render/slide_diagnostics.html`)으로 패널을 보여준다** — 셸 12초 reload가 fit_done마다 다시 그려진 패널을 끌어와 슬라이드가 완료되는 대로 뜬다(N배치로 몰리지 않는다). 결합은 파이프라인이 셸을 seed·서빙하고, **단독 S6는 셸이 없으면 자기가 seed한다**(`render/SKILL.md` Stage 0 — `contrl-shell.html`→`outputs/index.html`, 이후 `outputs/`를 루트로 서빙). `render/` 하위폴더를 직접 서빙하지 않는다. 패널 자체는 self-contained라, 셸 없이 직접 열렸을 때(`window.parent===window`)만 **스스로 주기 reload하는 fallback**을 갖는다(셸 안에선 셸 reload가 대신 — 이중 reload 없음; postMessage는 `window.parent` 가드).
- **최종 산출물 + refit finalize 게이트:** 끝단 `package_deck`가 `deck.pptx`를 만든다(전체 덱 딜리버러블). 패널은 렌더 중 **점진 리뷰 표면**, `deck.pptx`는 최종 결과물이다. 덱 마무리(package/verify)는 마지막 forward 슬라이드 `fit_done` 후 **진행 중·대기 중 refit이 하나도 없을 때만** 돈다 — 그래야 `deck.pptx`가 최신 재수정을 담는다. 검사는 `record_round.py reconcile "$RUN/slides" --check` 출력에 refit 라인이 없음을 확인하는 것이다(정확한 커맨드·출력 형식·grep 패턴은 `record_round.py --help`가 소유).