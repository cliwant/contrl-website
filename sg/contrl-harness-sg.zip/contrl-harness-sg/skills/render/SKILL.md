---
name: render
description: >-
  CONTRL pipeline S6 — Render. Takes slide_plan.json plus the design-system catalog, assembles slides, runs fit-and-polish, packages, verifies, and copies deck.pptx plus slide PNG outputs.
  Use when the user asks to render the deck, create deck.pptx, generate slide PNGs, run S6, or produce the final proposal deck.
---

# render

## Customer Delivery Defaults

Render English deck content and English progress/diagnostic panels. Preserve the English language tags and do not introduce Korean UI labels or Korean slide text unless an official proper noun has no reliable English equivalent.

Turn a **confirmed design-system catalog** + a **Slide Content plan** into a **finished PPTX**. This is
the *render* stage: the plan already decided *what goes where* (intents, layouts, components, slot
values); this skill **draws** it — fills the chosen components, fits them onto their layout, and
packages every slide into one deck that inherits the original template's frame (master/layout/theme).

You (Claude) are the **orchestrator**: you read this file and drive the pipeline. Mechanical steps are
scripts; the one judgment step (per-slide fit) is a **subagent** dispatched with `prompts/fit.md`.
Hold the model in §Mental model and prefer understanding *why* each stage exists over running commands
by rote — when a slide breaks an assumption, reason about it.

> **Stage discipline (load-bearing).** This is *render-stage* code: it must work for **any** plan and
> **any** catalog. Never let a script or prompt branch on a specific variant_id, slide number, section
> string, or sample literal. "Works on the sample plan" is **not** success — generalizing is.

## Requirements

Runs **inside Claude Code / the Agent SDK** — mechanical steps are scripts, the fit step is a
**subagent (the Agent tool)**. Runtime deps:

- **LibreOffice** — `soffice` on `PATH` (renders PPTX → PNG for the fit loop and previews).
- **Fonts** covering the deck's language (e.g. a Korean font) so renders aren't tofu.
- **Python 3** + `requirements.txt` (lxml, Pillow). Self-contained: the skill carries `scripts/_lib/`,
  no cross-skill imports. Venv at `$SK/scripts/.venv/`; created in Stage 0 if absent.

## Inputs

1. **A confirmed design system** — `$DS/`: `catalog.json` (the
   selection index this skill reads), `frame/` (the master/layout/theme/media inheritance bundle),
   and per-entity `variants/<id>/`, `adornments/<id>/`, `layouts/<id>/` artifacts (`shapes.xml` +
   previews). Produced by the design-system extraction step.
2. **A Slide Content plan** — `$PLAN`: `master_fills`, and per slide
   `{ slide_number, layout_id, intent_id, layout_fills[], blocks[] }`, where each block is
   `{ heading, adornment_id, adornment_fills[], components[{ variant_id, fills[], repeating_fills[] }] }`.

## What it produces

Under a fresh run dir (`$RUN/`; every script takes `--run`):

- **`deck.pptx`** — the finished multi-slide proposal, inheriting the template frame. The deliverable.
- **`slides/<n>/`** — per slide: `adjusted.xml` (the final block), `after.png` (its render),
  `before.png` (the mechanical seed), `status.json` (the fit result), and context files.
- `_work/` — build-time intermediates (not a deliverable).

Final artifacts are copied to `projects/{name}/artifacts/render/` in Stage 6.

## Mental model

The plan is already decided; rendering reassembles five separable pieces per slide:

- **Layout** — the fixed page frame (Master + Layout): header band, chapter marker, footer, and the
  empty **content_box** where the body goes. Inherited from `frame/`, never redrawn.
- **Adornment** — a fluid block decoration (a header/label band) — exactly one per block.
- **Variant** — an atomic body component (card row, table, diagram…) chosen by the plan.
- **Slot** — a fillable region inside a Variant/Adornment (text, repeating rows, or an **image**), or
  a Layout placeholder.
- **Block** — one Adornment + its Component(s); blocks stack top→bottom inside content_box.

The fit judgment rules live in **`prompts/fit.md`** — read it when you dispatch that step, not before.
The mechanical contracts (slot fill, cardinality, image preservation, frame inheritance, media
resolution) live in each script's own docstring — there is no separate spec doc to read.

## Code does the mechanical bulk; the agent does the visual judgment

Direct XML authoring by an agent fails on cost and fidelity (it silently drifts colors and runs into
millions of tokens per deck). So **deterministic code does all the mechanical transformation** — fill
text, resize repeating rows, place, package (each runs in seconds) — and **the agent does only the
visual judgment the code can't**: does it fit, does a chart encode its real numbers, is the composition
clean, are theme colors intact. This is a split of **responsibility, not effort or time**: the per-slide
fit loop is by far the **slowest and most complex stage** — it dominates wall-clock and tokens (order of
minutes and ~10⁵ tokens *per slide*, vs seconds for every script combined). The point isn't that the
agent does "little"; it's that it **never hand-authors the deterministic part** — that's what would blow
up cost and drift colors. The agent **recreates every block fresh** — authoring clean OOXML from the
*original component's* shapes (never the seed's tangled geometry), re-sized to fill the slide — while
**quoting the original paint verbatim** so it never free-hands a color. There is **no in-place-edit
path**: recreation is the method, not a fallback.

## How it runs

```
Stage 0 env → Stage 1 prep & validate → Stage 2 assemble (per slide) →
Stage 3 fit & review (per slide; 점진/일괄 질문 + N장 일시정지 + 리뷰 패널) → Stage 4 package → Stage 5 verify →
Stage 6 artifact copy
```

Every mechanical script is **idempotent** (skips slides whose output exists), so a stopped/partial run resumes
by re-running from where it left off. **Review UX:** Stage 3 asks the same initial (점진/일괄) and N-slide pause
questions as the combined pipeline and shows the **Slide diagnostics panel** — the single source is
`references/review-loop.md` (shared with the combined pipeline). `deck.pptx` is the final whole-deck
deliverable; the panel is the *incremental* review surface.

### Variables
```bash
SK=<CLAUDE_PLUGIN_ROOT>/skills/render          # this skill's folder
DS=design-system                               # confirmed design system (CWD, projects/와 나란함)
PLAN=projects/{name}/artifacts/slides/slide_plan.json
RUN=projects/{name}/outputs/render/{run_label} # build workspace
PYTHON=$SK/scripts/.venv/bin/python3
VALIDATE=<CLAUDE_PLUGIN_ROOT>/skills/pipeline/scripts/validate-artifacts.mjs
```

`run_label` is `YYYY-MM-DD_<label>` format. If the user doesn't specify one, generate date+timestamp.

---

### Stage 0 · env setup  *(orchestrator, inline)*

1. **venv check/create:**
```bash
if [ ! -f "$PYTHON" ]; then
  python3 -m venv "$SK/scripts/.venv"
  "$SK/scripts/.venv/bin/pip" install -r "$SK/requirements.txt" --quiet
fi
```
2. **LibreOffice check:** `which soffice` — if missing, **stop immediately**. Install: `brew install --cask libreoffice`
3. **Catalog SHA-256 check:** compare `slide_plan.json._meta.catalog_sha256` against current `$DS/catalog.json` SHA-256. Mismatch → stop; tell user to re-run S5.
4. **S6 before gate:** `node "$VALIDATE" gate {name} S6 before`
5. **Progress shell (preview surface).** Standalone S6 previews through the **same `outputs/index.html` shell the pipeline uses** — its `STAGES` array already carries the S6 render tab — so the built-in preview shows it at the served root with **no separate server**. This is the same mechanism every stage's panel is shown by; S6 must not self-serve its own subfolder (that path needs a hand-rolled `http.server`). Seed the shell if absent:
```bash
SHELL=<CLAUDE_PLUGIN_ROOT>/skills/pipeline/templates/contrl-shell.html
[ -f "projects/{name}/outputs/index.html" ] || cp "$SHELL" "projects/{name}/outputs/index.html"
```
Then ask to serve `projects/{name}/outputs/` as the **static root** and open `http://localhost:PORT/` in preview. Panel/streaming semantics — the S6 tab, reload cadence, never serving the `render/` subfolder directly — are owned by `review-loop.md` (its review-surface section). (S1–S4 tabs populate if those panels already exist from an earlier run; otherwise they sit empty — harmless for a render-only run.)

---

### Stage 1 · prep & validate  *(orchestrator, inline)*

There is **no `prep_deck.py`** — you (the orchestrator) do this inline before Stage 2:

> **Inputs first (hard guard).** `$DS` (design system) and `$PLAN` (slide plan) are **required and have
> no default**. If the request didn't provide one or both, **stop and ask the user for the path** — never
> default to a repo example or a sample/leftover plan, and never guess from what
> happens to be in the tree. The mechanical scripts enforce this too (`assemble_slide.py --ds/--plan` are
> `required`), but don't reach that error by guessing — confirm both paths up front.

1. **Scaffold** `$RUN/` and `$RUN/slides/`.
2. **Resolve layouts** — for each plan slide, confirm its `layout_id` maps to a real `slideLayout`
   in `$DS/frame/` (the inheritance bundle).
3. **Validate every plan reference** against `$DS/catalog.json` — `layout_id` / `variant_id` /
   `adornment_id`, and every slot name a `fills` / `repeating_fills` / `layout_fills` entry targets.
   **Report missing refs; do not silently skip them** — fix the plan or catalog before continuing.

---

### Stage 2 · assemble each slide  *(mechanical, per slide)*
```bash
$PYTHON "$SK/scripts/assemble_slide.py" --ds "$DS" --plan "$PLAN" --run "$RUN" --slide <n>
```
> **Pipelined entry (per-record).** When S6 is interleaved with S5 per-slide (the orchestrator drives this
> via `pipeline/references/pipeline-render.md`), a slide can be seeded from its S5 DECISION record **before**
> the whole `slide_plan.json` exists, with `--plan-slide <.plan/slide_{index}.json> --slide-number <absolute>`.
> It reuses the same compose path (the seed is byte-identical to `--plan --slide <n>` for the same record) and
> runs per-slide admission validation — **no empty slide** (≥1 component with a `variant_id`), **allowed-list**,
> and **referential integrity** of every id/slot — the moved-forward, one-slide equivalent of Stage 1 and the
> deck gate's per-slide guarantees. Standalone S6 keeps using `--plan`.

Per slide, deterministically, in this order:
1. **Cardinality resize** — clone/delete each repeating component's occurrences to the plan's row
   count **first**, so content is never truncated to the asset's base count.
2. **Slot fill** — inject `fills` / `repeating_fills` text by shape-id; blank leftover runs so no
   template sample text leaks through.
3. **Preserve image placeholders** — where a slot is an image (catalog `kind: image`, or a
   `{description, convention}` value), **keep the `<p:pic>` region as-is**; never fill it with text.
4. **Wrap + pre-place** — wrap each unit (adornment + each component) into its own group and stack
   blocks top→bottom inside the layout's **safe_box**. This placement is only a **seed**; the fit
   agent re-places freely in Stage 3. (Vertical-center + shrink-to-fit is a known-acceptable heuristic.)
5. **Inject layout placeholders into the seed** — append the layout's editable text placeholders (page
   title / chapter / breadcrumb / intro / any others the layout declares) from `layout_fills` straight
   into the seed `spTree`, so the fit agent owns their **text** alongside the body (one editable surface;
   the agent fits each placeholder's text to its fixed visual). No-op for layouts that declare no
   placeholders. The packager **dedupes** against these at render/package time, so they're never
   double-injected. (Master fills — footer / page-number auto-field — stay packager-injected.)

Writes `slides/<n>/{ filled.xml, adjusted.xml(seed), before.png, safe_box.json, layout.json,
block_meta.json, palette.json, original_*.png, original_*.shapes.xml }`.

Slides whose seed completed (`before.png` — the last-written seed artifact — exists) are skipped, so a
resume never reverts fit work while a half-seeded dir still gets healed. Report skipped and newly
assembled slides separately.

---

### Stage 3 · fit & review  *(judgment subagent, per slide — same review UX as the combined pipeline)*

Dispatch **one fit subagent per slide** and drive the whole loop from **`references/review-loop.md`** — the
single source shared with the combined S5↔S6 pipeline. It owns both the review UX (the initial
incremental/batch review question, N-slide pauses, pause questions, feedback loop, Slide diagnostics panel)
and the FIT dispatch mechanics (continuous top-up, the soffice concurrency budget, background dispatch with
per-completion observation, the N-pause as the only sync point). Standalone deltas only: feed the loop from
the **complete `slide_plan.json`**, seeding each slide via `assemble_slide.py --plan "$PLAN" --slide <n>`
(Stage 2) in `slide_number` order — there is **no PLAN pool and no per-record seed**. Each slide's fit
judgment is per `prompts/fit.md`.

**Pause-time refits run in the background**, entirely per `review-loop.md` — dispatch mechanism, shared
budget, slot priority, completion notification, and the `record_round.py` timing bracket are all owned there.
Standalone S6 adds no delta beyond the absent PLAN pool.

**Recreation** (the method for every block) **quotes the original paint** (theme colors + gradients, verbatim)
and **preserves image placeholders** — it never drops an image region or recolors. It **re-sizes to the slide's
free space**: the original is a tone/form reference, not a size reference, so blocks scale and re-space to fill
the `content_box`. Each slide carries its own `layout.json` / `safe_box.json`; a slide passing all `fit.md`
checks is the objective (the render-round cap and the flag-don't-loop rule live in `fit.md`).

On finishing each slide the agent writes `slides/<n>/{ adjusted.xml(final), after.png, status.json }` — the
completion marker + human-triage signal (schema and the self-report-is-not-the-source-of-truth rule:
`fit.md` §Per-slide output; Stage 5 verification is what's authoritative).

**Resume:** run the shared resume procedure first (`review-loop.md` — reconcile, then the two re-offer
branches), then re-dispatch only slides with no `status.json`. (`fit.md`'s `{FEEDBACK}` / `{FEEDBACK_GUIDANCE}`
inputs carry the review-loop's user corrections; inert when absent, so a no-review render is unchanged.)

---

### Stage 4 · package the deck  *(mechanical)*
```bash
$PYTHON "$SK/scripts/package_deck.py" --run "$RUN" --out "$RUN/deck.pptx"
```
Assembles **all** `adjusted.xml` slides into **one** multi-slide PPTX that inherits `frame/`
(master/layout/theme/media), in plan order. **Resolves real media** from the frame bundle and **keeps
template furniture** (logos, marks) whose media is present — no blanket `<p:pic>` deletion, no grey
placeholder. Injects layout/master placeholder fills + the page-number auto-field. Renders the full-deck
preview.

**PowerPoint-safe by construction:** it emits the OOXML that soffice tolerates but PowerPoint repairs
already correct — `cNvPr` ids renumbered unique per slide, slide `rId`s numbered clear of the frame's
master/theme rels (no `presentation.xml.rels` collision, so the master reference stays intact), and one
group header per slide (a header a source-quoted `spTree` carried is dropped). Stage 5 backstops these.

**Refit finalize gate:** package runs only after the all-slides barrier **and** the refit finalize gate
passes — the rule is owned by `review-loop.md` (its final-deliverable bullet), the check command and output
form by `record_round.py --help`. If a background refit is still running, wait for it to drain first, so
`deck.pptx` carries the latest re-rendered slide rather than a pre-refit one.

---

### Stage 5 · verify  *(mechanical check, must PASS)*
```bash
$PYTHON "$SK/scripts/verify_deck.py" --run "$RUN"
```
Conformance audit: every plan slide present and in order; each slide's content inside its safe_box;
the deck opens as valid OOXML; no leftover template sample text; no broken/missing media. It also
gates the defects soffice tolerates but PowerPoint repairs — no duplicate `cNvPr` id within a slide,
no duplicate `rId` within a `.rels`, every presentation reference resolving to the right part-type
(`sldMasterId`→slideMaster, `sldId`→slide), and one group header per `spTree`. Prints concrete
PASS/FAIL checks. A run isn't shippable until this passes.

**If FAIL, do not proceed to Stage 6.** Report the failing items and stop.

---

### Stage 6 · artifact copy  *(orchestrator, inline)*

After verify PASS:

```bash
mkdir -p "projects/{name}/artifacts/render/slides"
cp "$RUN/deck.pptx" "projects/{name}/artifacts/render/deck.pptx"
for slide_dir in "$RUN/slides/"/*/; do
  n=$(basename "$slide_dir")
  cp "$slide_dir/after.png" "projects/{name}/artifacts/render/slides/${n}.png"
done
node "$VALIDATE" gate {name} S6 after
```

Declare completion after S6 after gate passes.

---

## Return

Report back to the pipeline orchestrator:
- Total slide count, passed / needs_attention tallies
- `needs_attention` slide list (if any)
- `artifacts/render/deck.pptx` path
- Total render rounds
- Token cost note: the fit loop runs ~10⁵ tokens per slide

## Files

```
skills/render/
  SKILL.md                      this orchestration spec
  prompts/fit.md                the per-slide fit & perfect judgment prompt (acceptance checks)
  references/review-loop.md     the S6 review UX (initial/pause questions, N-pauses, feedback, panel) — shared with the combined pipeline
  templates/slide-diagnostics.html  the Slide diagnostics panel (N-slide batch sections + focused overlay + distribution)
  requirements.txt              pip deps (lxml, Pillow)
  scripts/
    assemble_slide.py           stage 2 — --plan / --plan-slide / --front-matter seed (+ per-slide validate)
    render_slide.py             agent render tool (render→look→fix)
    slide_diagnostics.py        renders the Slide diagnostics panel (plan + render + distribution)
    feedback_store.py           project-scoped render-feedback cache (review-loop)
    record_round.py             per-slide round state: refit lock marker + rounds.jsonl ledger + crash reconcile (review-loop)
    package_deck.py             stage 4 — multi-slide assembly + frame inheritance + media resolution
    verify_deck.py              stage 5 — conformance audit (PASS/FAIL)
    check_text.py               text-fidelity helper (filled.xml ↔ adjusted.xml)
    _lib/                       this skill's own helpers (no cross-skill imports; incl. plan_record.py)
    .venv/                      Python venv (created in Stage 0, .gitignore)
```
