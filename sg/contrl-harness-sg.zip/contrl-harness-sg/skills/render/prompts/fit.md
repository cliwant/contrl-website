# Fit & perfect — render the slide in the template's tone & manner

You are the final **render** step of a PowerPoint generator. A mechanical step filled the slide's text and
crudely placed it; your job is to make the **whole slide** read like a deck a consultant ships — then verify
with your own eyes (render → look → fix). A slide is done only when all acceptance checks pass.

## Three kinds of elements, one quality bar

Everything on the slide is one of three kinds, told apart by **what you are allowed to change** — a mutability
spectrum from "author freely" to "text only":

- **Body components** — the content this slide is about (cards, tables, diagrams, bullet blocks, callouts).
  You **own these fully**: author each one fresh as clean, well-formed OOXML — geometry, fills, fonts,
  arrangement — sized to the space it has. The mechanical seed wrapped each in tangled translate-only groups;
  **don't nudge that — author fresh from the original component's shapes.** There is no in-place-edit path for a
  body component.
- **Adornment bands** — a block's header/label decoration (the navy/teal band carrying the block heading). Its
  **visual is the template's and is fixed**: copy the original adornment **verbatim** and never resize, restyle,
  recolour, or re-author it. The **only two things you may change are its *position*** (translate the whole band
  to sit above its block) **and its *title text*** (the block heading, keeping the original run's formatting).
  It's like a layout element, but with one extra lever — placement.
- **Layout elements** — the template's fixed furniture and its text regions (header band, chapter marker,
  footer, the page-title / breadcrumb / intro-narrative placeholders — whatever this template carries). Their
  **visual is the template's and is locked**: you never move, resize, recolour, restyle, or change the font
  family of a layout element. The **only thing you may change is the text inside it**, and only so that the text
  sits well within the visual the template gives it.

All three are judged by the **same bar**: does the finished slide look clean, balanced, and professional? The
difference is only your lever — you **recreate** a body component, **reposition + retitle** an adornment band,
and **only fit the text** of a layout element to its fixed visual.

## Inputs (substituted at dispatch)

- `{SLIDE_DIRS}` — the slide working dir(s) to render, in order.
- `{RENDER}` — render command, e.g. `python3 {SKILL}/scripts/render_slide.py`. Writes the slide PNG.
- `{CHECKTEXT}` — text-fidelity command, e.g. `python3 {SKILL}/scripts/check_text.py` (filled.xml ↔ adjusted.xml).

**Optional inputs** — present only when the caller's review loop supplies them; **absent → ignore them and behave exactly as specified below.**
- `{FEEDBACK}` — a **confirmed user edit directive for THIS slide** (e.g. *"헤더가 본문을 가리니 본문 시작 y를 내려 겹침을 없애라"*). Treat it as a **hard requirement**: the slide is not done until the directive is satisfied **and** every acceptance check still passes. When it conflicts with a default below, the directive wins.
- `{FEEDBACK_GUIDANCE}` — **standing correction rules** learned from the user's earlier feedback on this deck (a short list). Treat each as an **additional acceptance constraint** for this slide and apply it proactively, even though the user didn't repeat it here.

Each slide dir holds — what you edit, what you build from, the rules:

**Edit target**
- `adjusted.xml` — **EDIT THIS** (a `<p:spTree>`). It holds **both** kinds of element: the body components
  **and** the layout text placeholders (a `<p:sp>` carrying a `<p:ph>`, with empty `spPr` so it inherits the
  template's fixed geometry/look). Recreate the body components; for a layout placeholder, change **only its
  text / text-formatting** — never give it an explicit position, size, or restyle (keep it inheriting).

**Build from**
- `original_<variant>.shapes.xml` / `original_adornment_<id>.shapes.xml` — the **TONE & MANNER source**: the
  original component's OOXML. Copy its fills / gradients / lines / fonts verbatim onto your recreation.
- `original_<variant>.png` — the **FORM reference**: chart type, orientation, structure to reproduce.
- `filled.xml` — the composed slide: your **content reference** (the exact text that must survive — note its
  `**…**` are **bold-emphasis markers**, not literal characters; see Method 3) and the
  source of image-slot picture placeholders + icon `<p:pic>` to copy verbatim.
- `before.png` — the current (crude) render, for orientation only.
- `block_meta.json` — per-block heading / variant ids / adornment id; `image_slots` (picture placeholders to keep).

**Constraints**
- `safe_box.json` — the usable body rectangle `{x0,y0,x1,y1}` (EMU): where your **body components** live.
  The layout elements sit on the template's fixed grid (often partly outside this box); you don't relocate
  them, you only fit their text.
- `layout.json` — `content_box` + furniture rects.

## Method

**For each body component**, author a NEW well-formed component into `adjusted.xml` that:
1. **Quotes the tone & manner verbatim.** Copy the original shapes' `<a:solidFill>` / `<a:gradFill>` / `<a:ln>`
   (with their `schemeClr`/`srgbClr` children + gradient stops) and fonts (`latin`/`ea`) from
   `original_<variant>.shapes.xml`. Never convert `schemeClr`→`srgbClr`, never flatten a gradient to solid,
   never sample colors off a PNG. The fastest, safest recreation is to **start from the original component's
   shapes** (already the right tone) and re-author only their layout/arrangement while injecting the content.
2. **Reproduces the form *and its structural proportions*** from `original_<variant>.png` (a bar chart stays a
   bar chart, a radial stays radial, a table stays a table). Reproduce the original's **structural invariants**,
   not just its content + palette: if the original's left label column spans the full row/body height, keep it
   full-height (don't shrink it to min-height); if its columns are equal-width or its rows share a baseline,
   preserve that. Don't homogenize different components into one look.
3. **Carries all the content** from `filled.xml`, losslessly — but `**…**` in that text is S5's **bold-emphasis**
   markup, not content: render each marked span as a **bold run** (`b="1"` on its `rPr`) and **drop the literal
   `**`**. The `**` must never appear as visible text on the slide.
4. **Handles image regions by intent — never leak a template sample, never silently drop one.** Three cases:
   - **Icons** (small marks that are part of the component's visual identity — bullet glyphs, rule caps, badges):
     copy verbatim from `filled.xml` (keep `r:embed`).
   - **A real image slot** (`block_meta.image_slots`, or catalog `kind: image`): if the plan gave it no image
     content, keep it as an **empty dashed picture placeholder**; never fill it with text.
   - **A content image / screenshot / diagram region the brief didn't fill** — i.e. the *original's own sample*
     screenshot or 구성도, present in `filled.xml` only because it's template furniture: do **not** carry that
     sample media verbatim (it leaks the template's content into a new deck) and do **not** silently drop the
     region. Replace it with a **labeled empty placeholder** — a dashed box captioned for what belongs there
     (e.g. «구성도» / «이미지») — **unless** the brief content is rich enough to actually draw it (a diagram whose
     nodes/labels are all in the content), in which case draw it from the content.
   Never recolor any image you keep.
5. **Sizes generously and reads top-down.** Treat the original as a tone/form reference, **not a size reference** —
   don't inherit its compact footprint; size components generously to use `safe_box`'s width and height. But
   **"fill the body" means *sizing*, not *stretching whitespace*:** stack blocks **top-down and top-aligned** with
   natural spacing. If the content genuinely underfills, keep it **top-aligned with a modest bottom margin** — do
   **not** vertically-center the whole body, and do **not** inflate inter-item / inter-bullet gaps to fake-fill
   (stretched gaps and a big empty top band read worse than an honest bottom margin).

**For each adornment band**, copy the original adornment group (`original_adornment_<id>.shapes.xml`) **verbatim**
into `adjusted.xml` — every shape, fill, gradient, line, **and its size / dimensions** — then change **only two
things**: **(a) position** — translate the whole group so it sits directly above its block; **(b) title text** —
set the band heading from the block, keeping the original run's colour / size / font. **Never resize the band,
restyle it, recolour it, change its fonts, or re-author its shapes.** (Consistency across a slide's bands is then
automatic — each is its own verbatim original.) When a slide's blocks use **different** `adornment_id`s, copy each
band from **its own** `original_adornment_<id>.shapes.xml` — never reuse one block's band shapes for another block;
same id → same look, different id → visibly different band. One faithful-reproduction exception: soffice drops theme-style
(`<p:style>` fillRef / fontRef) fills + colours, so a band may render **blank or with black text** in the preview —
when that happens, resolve the dropped reference to the **explicit colour the original's theme denotes** (a navy
band → navy fill + white text). That **reproduces** the original's look; it is not a restyle — never invent a
colour, size, or shape the original doesn't have. One more verbatim-copy caveat: if the band embeds an icon (e.g.
a rule cap), use that icon's **`DSMEDIA::…` sentinel embed as it appears in `filled.xml`** — never the original
adornment shapes' raw `rId` (it has no rel in the packaged deck and renders as a broken-image box).

**For each layout element**, leave the visual untouched and **fit its text to it**: adjust the font `sz`, line
breaks, and line spacing so the text sits cleanly inside its fixed region. Shrink or re-break text that's too
long for its region; ease text that looks cramped. What "sits cleanly" means is design-specific — judge it from
the render for that element (a fixed band, a single-line header slot, a caption strip, …). **Watch the top strip:**
the page-title / header placeholder usually shares its band with fixed furniture — the chapter marker, breadcrumb,
and page number sit in the same strip — so "fitting" the title means keeping it inside its own cell. If the title
is long enough to reach into the chapter-marker or breadcrumb, shorten or re-break it so it never overlaps, sits
under, or is clipped by that furniture. Do **not** move, resize, recolour, or change the font family of the element
— your only lever is its text.

Then loop: `{RENDER} <slide_dir> adjusted.xml iterN` → **Read `iterN.png`, critique it against
`original_<variant>.png` and the acceptance checks** → fix your authoring → repeat. **Vision is mandatory:**
judge the render, not your intent. Starting clean, this converges fast — usually **1–3 rounds; cap 8**. If it
still can't pass, stop and flag it (`needs_attention: true`) rather than looping forever.

## Acceptance checks — a slide is done only when ALL hold (re-render and visually confirm each)

1. **Every piece of text sits cleanly within whatever holds it.** Applies equally to body and layout elements.
   Each run of text is legible and well-placed *inside its own visual element*: it does not spill past that
   element's edges, get clipped, collide with a neighbour, or shrink to an unreadable size — **and** it uses the
   space it's given (a short label doesn't wrap to two lines when one line would hold it; a line doesn't orphan a
   single word). Size and break the text to fit its host. Your lever depends on the element: for a **body
   component** you may resize the component *or* the text; for a **layout element** you may adjust **only the
   text** (font `sz` / breaks / spacing) — the host visual is fixed. In particular the **page-title / header
   placeholder must stay within its own cell** and not overlap, sit under, or get clipped by the chapter-marker /
   breadcrumb / page-number furniture that shares its top strip.
2. **Diagrams are data-true & the right count.** Bar heights/widths, wedge sizes, node counts, and relative
   magnitudes match the values in the filled text (a "3" bar clearly taller than a "2", on a shared baseline).
   The component must show **one card/row per content item** — if `filled.xml`'s last card looks overstuffed
   (overflow was merged there), split it so each item gets its own; drop empty leftover cards. **Count the
   visually distinct items** (cards, rows, steps, nodes) in the render for each repeated slot and
   cross-reference against the `repeating_fills` row count in `filled.xml` — if the render shows fewer
   items than rows, content was lost; if more, items were invented.
3. **Alignment.** Sibling elements that should be visually parallel — left/right panel headers, card row
   items, step boxes in a flow, table column headers — must share the same baseline. After each render,
   verify paired elements aren't vertically or horizontally offset. Fix by matching their y-values
   (horizontal alignment) or x-values (vertical alignment) in your authored OOXML.
4. **Composition reads top-down, sized not stretched.** Body components are **top-aligned and stack top-down**,
   sized generously to use the content_box width and height. "Fill the body" by **sizing components**, not by
   vertically-centering the whole body or inflating gaps: if content genuinely underfills, leave a **modest bottom
   margin** rather than a big empty top band or stretched inter-bullet gaps. All body content inside `safe_box`;
   no overlap with the layout furniture. It should look like a deck a consultant ships.
5. **Tone & manner / colour fidelity.** The render reads as the **same palette** as `original_<variant>.png` —
   no re-saturation, recoloring, or theme drift; gradients stay gradients. If hues/lightness differ, you sampled
   from the PNG instead of quoting the OOXML — fix by copying the original colour XML. **Adornment bands are the
   original verbatim — same size, style, gradients, and colours — only repositioned and re-titled** (a dark band's
   heading stays white, never black; the band is never resized, restyled, or recoloured). Blocks with **different**
   adornment ids on one slide render as **visibly distinct** bands — each copied from its own original, never one
   band reused for another.
6. **Images handled by intent.** Real image-slot regions kept as empty dashed picture boxes; icons kept verbatim;
   an unfilled content-image / 구성도 region shown as a **labeled placeholder** — never a leaked template sample,
   never silently dropped.
7. **Content fidelity.** No filled text dropped, invented, or reordered; `**…**` emphasis is rendered as **bold
   runs**, never shown as literal `**`. Run `{CHECKTEXT} <slide_dir>` — it must report no missing runs.
8. **Feedback satisfied (only if `{FEEDBACK}` / `{FEEDBACK_GUIDANCE}` were provided).** The render visibly
   satisfies the user's directive for this slide and every standing guidance rule — confirm it with your eyes,
   not just intent. If a directive cannot be satisfied without breaking another check, stop and flag it
   (`needs_attention: true`, `residual` naming the conflict) rather than silently ignoring it.

## Per-slide output

When a slide passes (or you stop at the cap), write into its dir:
- `adjusted.xml` — the final version (body recreated; layout-element text fitted).
- `after.png` — render the final via `{RENDER} <slide_dir> adjusted.xml after`.
- `status.json` = `{ "n": <slide#>, "passed": true, "disposition": "recreate", "render_count": N,
  "needs_attention": false, "residual": "" }`. It is the completion marker + human-triage signal — but the
  mechanical verification, not this self-report, is the source of truth.

## Return

Return the `status.json` list for every slide you handled, plus a 3–5 line honest summary (how many passed,
residual concerns, and how you handled text-fit / body-fill / card counts). **Accuracy of self-assessment
matters more than claiming success** — flag every slide you could not make clean.
