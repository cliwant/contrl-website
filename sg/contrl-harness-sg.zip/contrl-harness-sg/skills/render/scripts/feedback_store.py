#!/usr/bin/env python3
"""Project-scoped render-feedback cache (S6 incremental-review feedback).

At an N-slide pause the orchestrator interprets the user's natural-language edit
feedback into a structured rule and persists generalizable rules here so every
SUBSEQUENT fit subagent applies them (the per-slide `{FEEDBACK_GUIDANCE}` input).
The cache is **project-scoped** — `projects/<project>/render_feedback.json` — so
corrections persist across re-renders of the same deck, and **never cross
projects**.

A rule = {id, source_run, source_slide, raw, interpreted, scope, added_after_slide}:
  - scope "general"    → fed forward to later fit subagents.
  - scope "slide_only" → recorded for provenance only; never fed forward (it just
    triggered the one re-fit at review time).

Activation of a `general` rule for a fit subagent rendering slide `S` in run `R`:
  - in the ORIGINATING run (rule.source_run == R): active iff S > added_after_slide
    (don't retroactively re-fit slides already done earlier in that run).
  - in any LATER run (rule.source_run != R): active for ALL slides (the correction
    is now a known property of the deck).

CLI:
    feedback_store.py add    <project> --root <abs> --run <label> --source-slide <n>
        --raw <text> --interpreted <text> --scope general|slide_only
        [--added-after <n>]
    feedback_store.py active <project> --root <abs> --run <label> --slide <n>
        [--format json|text]      # the active general rules for this slide+run
    feedback_store.py list   <project> --root <abs>
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def _cache_path(root: Path, project: str) -> Path:
    return root / "projects" / project / "render_feedback.json"


def _load(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {"rules": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"render_feedback.json invalid JSON at {path}: {exc}")
    data.setdefault("rules", [])
    return data


def _next_id(rules: list[dict]) -> str:
    return f"fb_{len(rules) + 1:03d}"


def is_active(rule: dict, run: str, slide: int) -> bool:
    """Whether a general rule applies to slide `slide` in run `run` (see module doc)."""
    if rule.get("scope") != "general":
        return False
    if rule.get("source_run") == run:
        return slide > int(rule.get("added_after_slide") or 0)
    return True


def cmd_add(args: argparse.Namespace) -> None:
    path = _cache_path(Path(args.root).resolve(), args.project)
    data = _load(path)
    rule = {
        "id": _next_id(data["rules"]),
        "source_run": args.run,
        "source_slide": int(args.source_slide),
        "raw": args.raw,
        "interpreted": args.interpreted,
        "scope": args.scope,
        # for general rules, default the cutoff to the slide the feedback came from,
        # so it applies to everything rendered after it in the originating run.
        "added_after_slide": int(args.added_after) if args.added_after is not None else int(args.source_slide),
    }
    data["rules"].append(rule)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{rule['id']} ({rule['scope']}) → {path}")


def cmd_active(args: argparse.Namespace) -> None:
    path = _cache_path(Path(args.root).resolve(), args.project)
    data = _load(path)
    active = [r for r in data["rules"] if is_active(r, args.run, int(args.slide))]
    if args.format == "json":
        print(json.dumps([{"id": r["id"], "interpreted": r["interpreted"]} for r in active],
                         ensure_ascii=False, indent=2))
    else:
        for r in active:
            print(f"- {r['interpreted']}")


def cmd_list(args: argparse.Namespace) -> None:
    path = _cache_path(Path(args.root).resolve(), args.project)
    data = _load(path)
    print(json.dumps(data, ensure_ascii=False, indent=2))


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="Project-scoped render-feedback cache")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("add")
    a.add_argument("project")
    a.add_argument("--root", required=True)
    a.add_argument("--run", required=True)
    a.add_argument("--source-slide", dest="source_slide", required=True, type=int)
    a.add_argument("--raw", required=True)
    a.add_argument("--interpreted", required=True)
    a.add_argument("--scope", required=True, choices=["general", "slide_only"])
    a.add_argument("--added-after", dest="added_after", type=int, default=None)
    a.set_defaults(func=cmd_add)

    ac = sub.add_parser("active")
    ac.add_argument("project")
    ac.add_argument("--root", required=True)
    ac.add_argument("--run", required=True)
    ac.add_argument("--slide", required=True, type=int)
    ac.add_argument("--format", choices=["json", "text"], default="text")
    ac.set_defaults(func=cmd_active)

    ls = sub.add_parser("list")
    ls.add_argument("project")
    ls.add_argument("--root", required=True)
    ls.set_defaults(func=cmd_list)

    args = p.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()