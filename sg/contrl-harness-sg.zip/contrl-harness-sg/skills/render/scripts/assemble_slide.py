#!/usr/bin/env python3
"""Stage 2 — assemble each plan slide into a working dir the fit agent edits.

Runs the vendored `compose_deck` on one plan slide (which may yield several composed slides
via overflow pagination), serialises each composed spTree to `filled.xml` + `adjusted.xml`(seed),
writes the fit context (layout.json, safe_box.json, block_meta.json with `image_slots`, the
`original_*` colour/form references), and renders `before.png`.

Render-stage code: no per-slide or sample-specific literals — works for any plan + catalog.

Usage: assemble_slide.py --ds <design_system> --plan <plan.json> --run <run> [--slide N | all]
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

import lxml.etree as ET

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from _lib.catalog import Catalog
from _lib.slide_composer import compose_deck
from _lib.ooxml import _max_cnvpr_id
from _lib.pptx_writer import _inject_layout_fills
from _lib.plan_record import record_to_slide, validate_admission
import render_slide


def _xml_bytes(el: ET._Element) -> bytes:
    return ET.tostring(el, xml_declaration=True, encoding="UTF-8", standalone=True)


def _safe_box(layout: dict) -> dict:
    cb = layout.get("content_box") or {"x": 0, "y": 0, "w": 0, "h": 0}
    x, y, w, h = cb.get("x", 0), cb.get("y", 0), cb.get("w", 0), cb.get("h", 0)
    return {"x0": x, "y0": y, "x1": x + w, "y1": y + h, "w": w, "h": h}


def _compose(ds: Path, cat: Catalog, plan: dict, run: str | Path, which: str = "all") -> list[dict]:
    """Shared per-slide compose/seed loop — drives both the whole-plan entry
    (`assemble`) and the per-record pipeline entry (`assemble_plan_slide`). `plan`
    is `{master_fills, slides:[...]}`; `ds` must already be resolved (so the
    `ds_root`/`frame_dir` strings stamped into block_meta match across entries)."""
    frame_dir = str(ds / "frame")
    master_fills = plan.get("master_fills") or []
    if which == "all":
        targets = plan["slides"]
    else:
        want = {int(x) for x in str(which).split(",") if x.strip()}
        targets = [s for s in plan["slides"] if s.get("slide_number") in want]

    gn, summary, skipped = 0, [], []
    for ps in targets:
        sub = {"master_fills": master_fills, "slides": [ps]}
        composed = compose_deck(sub, cat).slides            # 1 plan slide → 1..N composed (pagination)
        variants = [c["variant_id"] for b in ps.get("blocks", []) for c in b.get("components", [])]
        adornments = [b.get("adornment_id") for b in ps.get("blocks", []) if b.get("adornment_id")]
        for j, cs in enumerate(composed):
            gn += 1
            pn = ps.get("slide_number") or gn
            label = f"{pn:02d}" + (chr(ord("a") + j) if len(composed) > 1 else "")
            d = Path(run) / "slides" / label
            if (d / "before.png").exists():
                # Resume no-op (the documented idempotence). before.png is the LAST seed artifact
                # written (after adjusted.xml/block_meta/originals), so its presence means the seed
                # completed — re-writing would silently revert completed fit work in adjusted.xml
                # while status.json still marks the slide fit_done (the deck would package the crude
                # seed). Keying on the last artifact (not adjusted.xml, written 2nd) also means a
                # HALF-seeded dir (crash/soffice failure mid-seed) is re-seeded and healed instead
                # of being skipped forever. A deliberate re-seed still needs a fresh run dir or a
                # deleted slide dir (cascade-rules.md owns that on replan).
                skipped.append(f"slides/{label}")
                continue
            d.mkdir(parents=True, exist_ok=True)
            layout = cat.layouts.get(cs.layout_id, {})
            # Inject the layout's editable text placeholders straight into the seed spTree, so the fit
            # agent owns their text alongside the body (one editable surface). No-op for design systems
            # whose layouts declare no placeholders (e.g. they render nothing). The packager dedupes
            # against these at render/package time, so they're never double-injected.
            for sp in _inject_layout_fills(cs.layout_fills, layout,
                                           max(9100, _max_cnvpr_id(cs.sptree) + 1))[0]:
                cs.sptree.append(sp)
            xb = _xml_bytes(cs.sptree)
            (d / "filled.xml").write_bytes(xb)
            (d / "adjusted.xml").write_bytes(xb)              # seed = filled; the fit agent edits this
            (d / "layout.json").write_text(json.dumps(
                {"layout_id": cs.layout_id, "content_box": layout.get("content_box"),
                 "furniture": layout.get("furniture", [])}, ensure_ascii=False, indent=2))
            (d / "safe_box.json").write_text(json.dumps(_safe_box(layout), ensure_ascii=False, indent=2))
            (d / "block_meta.json").write_text(json.dumps({
                # Ordering identity MUST be the plan slide number (stable across per-slide invocations),
                # not the per-call counter gn — package_deck orders the deck by this. Using gn breaks
                # ordering when assemble is run one slide at a time (the documented resumable path),
                # since gn resets to 1 each invocation. (Pagination is 1:1 today, so pn is unique.)
                "slide_number": pn, "plan_slide": ps.get("slide_number"),
                "intent_id": ps.get("intent_id"), "layout_id": cs.layout_id,
                "layout_fills": cs.layout_fills, "master_fills": master_fills,
                "ds_root": str(ds), "frame_dir": frame_dir,
                "blocks": [{"heading": b.get("heading"), "adornment_id": b.get("adornment_id"),
                            "variants": [c["variant_id"] for c in b.get("components", [])]}
                           for b in ps.get("blocks", [])],
                "image_slots": cs.image_placeholders}, ensure_ascii=False, indent=2))
            for vid in dict.fromkeys(variants):               # colour source (+ form preview if present)
                if (src := ds / "variants" / vid / "shapes.xml").exists():
                    shutil.copy(src, d / f"original_{vid}.shapes.xml")
                if (prev := ds / "variants" / vid / "preview.png").exists():
                    shutil.copy(prev, d / f"original_{vid}.png")
            for aid in dict.fromkeys(adornments):
                if (asrc := ds / "adornments" / aid / "shapes.xml").exists():
                    shutil.copy(asrc, d / f"original_adornment_{aid}.shapes.xml")
            render_slide.render(d, "filled.xml", "before")    # mechanical seed render
            summary.append({"dir": f"slides/{label}", "plan_slide": ps.get("slide_number"),
                            "intent_id": ps.get("intent_id"), "layout_id": cs.layout_id,
                            "placed": len(cs.placed), "image_slots": len(cs.image_placeholders)})
    for s in summary:
        print(f"{s['dir']}: plan#{s['plan_slide']} layout={s['layout_id']} "
              f"placed={s['placed']} imgPH={s['image_slots']}")
    for lbl in skipped:
        print(f"{lbl}: skipped (before.png exists — seed complete / possibly fit)")
    print(f"assembled {len(summary)} composed slide(s), skipped {len(skipped)} → {Path(run) / 'slides'}")
    return summary


def assemble(ds: str | Path, plan_path: str | Path, run: str | Path, which: str = "all") -> list[dict]:
    """Whole-plan entry: seed one/all slides from an assembled slide_plan.json."""
    ds = Path(ds).resolve()
    cat = Catalog.load(ds)
    plan = json.loads(Path(plan_path).read_text())
    return _compose(ds, cat, plan, run, which)


def assemble_plan_slide(
    ds: str | Path,
    record_path: str | Path,
    run: str | Path,
    slide_number: int,
    master_fills: list | None = None,
) -> list[dict]:
    """Pipeline entry: seed ONE slide directly from its S5 DECISION record
    (`.plan/slide_{index}.json`) — no assembled slide_plan.json needed, so S6 can
    start the instant S5 finishes a slide. Reuses the vendored `record_to_slide`
    so the seed is byte-identical to the whole-plan path for the same record; the
    orchestrator supplies the absolute `slide_number` (front_matter_count + flatten
    index + 1) and `master_fills` (run-constant). Validates per-slide at admission
    (`validate_admission`, the moved-forward Stage-1 check) before composing.

    Floor/failed records are NOT handled here (no input-slide context to floor
    from) — that stays the end-of-run assemble.py's job; the coordinator only
    feeds ok/fallback records to this entry."""
    ds = Path(ds).resolve()
    cat = Catalog.load(ds)
    rec = json.loads(Path(record_path).read_text())
    slide = record_to_slide(rec)
    slide["slide_number"] = int(slide_number)
    validate_admission(slide, cat.data)
    plan = {"master_fills": list(master_fills or []), "slides": [slide]}
    return _compose(ds, cat, plan, run, which="all")


def assemble_front_matter(
    ds: str | Path,
    cover_toc_path: str | Path,
    run: str | Path,
    master_fills: list | None = None,
) -> list[dict]:
    """Pipeline entry: seed the front-matter (cover / TOC) slides up front from
    `cover_toc.py`'s output. Those entries are real plan Slide dicts (intent
    `cover` / `table-of-contents`) but carry `slide_number: null` and have no
    `.plan` DECISION record, so they take neither the `--plan` nor `--plan-slide`
    path. This stamps the absolute `slide_number` by position (1..front_matter_count)
    and composes/seeds them — so `slides/01`/`slides/02` exist before the fit pool
    and the deck-level package/verify find them.

    Handles ANY count (cover-only, TOC-only, both, or neither) — `front_matter_count`
    is simply the number of entries `cover_toc.py` emitted; no count is hard-coded.
    Done by a provided script (not a hand-edited mini-plan), keeping the
    "records are passed to scripts verbatim, never hand-authored" discipline."""
    ds = Path(ds).resolve()
    cat = Catalog.load(ds)
    fm = json.loads(Path(cover_toc_path).read_text())
    slides = fm.get("slides") if isinstance(fm, dict) else list(fm)
    for n, s in enumerate(slides or [], 1):
        s["slide_number"] = n
        validate_admission(s, cat.data)   # same per-slide gate as body slides
    plan = {"master_fills": list(master_fills or []), "slides": slides or []}
    return _compose(ds, cat, plan, run, which="all")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--run", required=True)
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--plan", help="assembled slide_plan.json (whole-plan entry)")
    src.add_argument("--plan-slide", dest="plan_slide",
                     help="one S5 DECISION record .plan/slide_{index}.json (pipeline entry)")
    src.add_argument("--front-matter", dest="front_matter",
                     help="cover_toc.py output JSON — seed all front-matter (cover/TOC) slides up front")
    ap.add_argument("--slide", default="all", help="[--plan] plan slide_number, or 'all'")
    ap.add_argument("--slide-number", dest="slide_number", type=int,
                    help="[--plan-slide] absolute slide_number = front_matter_count + flatten index + 1")
    ap.add_argument("--master-fills", dest="master_fills",
                    help="optional JSON file with the run's master_fills (default: []; see pipeline-render.md)")
    a = ap.parse_args()
    mf = json.loads(Path(a.master_fills).read_text()) if a.master_fills else None
    if a.plan_slide:
        if a.slide_number is None:
            ap.error("--plan-slide requires --slide-number")
        assemble_plan_slide(a.ds, a.plan_slide, a.run, a.slide_number, mf)
    elif a.front_matter:
        assemble_front_matter(a.ds, a.front_matter, a.run, mf)
    else:
        assemble(a.ds, a.plan, a.run, a.slide)
