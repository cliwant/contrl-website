#!/usr/bin/env python3
"""Text-fidelity helper for the fit loop (acceptance check 6).

Compares a slide dir's `filled.xml` (the composed text, before fit) against `adjusted.xml`
(after the agent's edits / recreation) and reports any **missing** text — a string that was in
the filled block but no longer appears. Containment-based (whitespace-normalised substring), so
run splits/merges from reflow don't false-alarm; only genuinely dropped content is flagged.

Usage: check_text.py <slide_dir> [filled=filled.xml] [adjusted=adjusted.xml]
Prints a PASS/FAIL line + the missing strings. Exit 0 always (informational; the agent decides).
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import lxml.etree as ET

A_T = "{http://schemas.openxmlformats.org/drawingml/2006/main}t"


def _runs(path: Path) -> list[str]:
    root = ET.parse(str(path)).getroot()
    return [(t.text or "").strip() for t in root.iter(A_T) if (t.text or "").strip()]


def _norm(s: str) -> str:
    # Strip S5's `**bold**` emphasis markers before comparing — the fit agent renders them
    # as bold runs and drops the literal `**` (per fit.md Method 3), so they are markup, not
    # content; ignoring them avoids false "missing" flags on correctly-bolded text.
    return re.sub(r"\s+", " ", s.replace("**", "")).strip()


def check(slide_dir: str | Path, filled: str = "filled.xml", adjusted: str = "adjusted.xml"):
    d = Path(slide_dir)
    f_runs, a_runs = _runs(d / filled), _runs(d / adjusted)
    a_blob = _norm(" ".join(a_runs))
    f_blob = _norm(" ".join(f_runs))
    missing = [s for s in f_runs if _norm(s) and _norm(s) not in a_blob]
    extra = [s for s in a_runs if _norm(s) and _norm(s) not in f_blob]
    status = "PASS" if not missing else "FAIL"
    print(f"[{status}] {d.name}: filled_runs={len(f_runs)} adjusted_runs={len(a_runs)} "
          f"missing={len(missing)} extra={len(extra)}")
    for s in missing:
        print(f"  MISSING: {s[:80]}")
    for s in extra[:8]:
        print(f"  extra:   {s[:80]}")
    return missing


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("usage: check_text.py <slide_dir> [filled] [adjusted]")
    check(sys.argv[1], *(sys.argv[2:4] or []))
