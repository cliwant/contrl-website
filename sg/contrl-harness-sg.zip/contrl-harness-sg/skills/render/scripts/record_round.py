#!/usr/bin/env python3
"""Per-slide FIT round state for S6: the refit lock marker, the round ledger, and
crash reconciliation (timing capture comes along for free).

The marker this tool manages (`.round_start.json`) doubles as the per-slide refit
LOCK: review-loop.md's double-flag check, the finalize gate (`reconcile --check`),
and resume recovery (`reconcile`) all key on it. The ORCHESTRATOR brackets each FIT
dispatch (fit or refit) with two calls — `start` just before spawning the fit
subagent, `stop` when it observes the completion (the subagent itself never calls
this; see review-loop.md "타이밍 기록"):

    record_round.py start <slide_dir> --kind fit                     # or --kind refit
    record_round.py start <slide_dir> --kind refit --note "<directive>"   # refit carries its directive
    ... render -> look -> fix loop, then write status.json ...
    record_round.py stop  <slide_dir>                 # render_count + note auto-read from marker/status.json

On resume after a crash, clear interrupted rounds without inflating durations:

    record_round.py reconcile <run>/slides            # append duration_s=null lines, drop dangling markers
    record_round.py reconcile <run>/slides --check     # dry-run: list in-flight rounds (finalize gate)

`start` drops `<slide_dir>/.round_start.json` (kind + epoch t0 + optional note/directive). `stop` reads it,
computes the wall-clock duration itself (so no LLM ever transcribes a number),
and APPENDS one line to `<slide_dir>/rounds.jsonl`:

    {"n":3,"kind":"fit","started_at":"…","ended_at":"…","duration_s":92.4,
     "render_count":6,"note":"","ts":"…"}

Append-only by design: `status.json` is last-write-wins (a refit clobbers it), but
this ledger keeps the slide's initial fit AND every later refit as separate lines.
`kind` is the fit/refit discriminator — a normal fit dispatch is `fit`; a re-dispatch
carrying a `{FEEDBACK}` directive at an N-slide pause is `refit`. The refit-completion
failure check reads the last refit line's `started_at` (the marker is gone by then),
and the durations remain available for any offline run comparison.

Robust by intent — a metrics helper must never fail a render: `stop` without a
matching `start` still appends a line (duration null) rather than crashing.
"""
from __future__ import annotations

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path

MARKER = ".round_start.json"
LEDGER = "rounds.jsonl"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _read_status(slide_dir: Path) -> dict:
    sp = slide_dir / "status.json"
    if sp.is_file():
        try:
            return json.loads(sp.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _slide_number(slide_dir: Path) -> int | None:
    """Best-effort slide_number for the ledger line: status.json `n` first, else
    the numeric prefix of the dir label (e.g. '03a' -> 3)."""
    try:
        return int(_read_status(slide_dir).get("n"))
    except (TypeError, ValueError):
        pass
    digits = "".join(c for c in slide_dir.name if c.isdigit())
    return int(digits) if digits else None


def cmd_start(slide_dir: Path, kind: str, note: str) -> None:
    slide_dir.mkdir(parents=True, exist_ok=True)
    # note doubles as the confirmed refit directive — kept so `stop`/notification carry it
    # without transcription, and so a crashed refit can be re-offered on resume (reconcile).
    marker = {"kind": kind, "started_at": _now_iso(), "t0": time.time(), "note": note or ""}
    (slide_dir / MARKER).write_text(json.dumps(marker, ensure_ascii=False), encoding="utf-8")
    print(f"{slide_dir}/{MARKER} start kind={kind}" + (f" note={note!r}" if note else ""))


def cmd_stop(slide_dir: Path, render_count: int | None, note: str, kind_override: str | None) -> None:
    marker_path = slide_dir / MARKER
    started_at = None
    duration_s = None
    kind = kind_override or "unknown"
    marker_note = ""
    if marker_path.is_file():
        try:
            m = json.loads(marker_path.read_text(encoding="utf-8"))
            kind = kind_override or m.get("kind", "unknown")
            started_at = m.get("started_at")
            marker_note = m.get("note") or ""
            t0 = m.get("t0")
            if isinstance(t0, (int, float)):
                duration_s = round(time.time() - float(t0), 1)
        except (json.JSONDecodeError, OSError):
            pass
        marker_path.unlink(missing_ok=True)

    note = note or marker_note      # explicit --note wins; else carry the directive from the marker

    if render_count is None:
        rc = _read_status(slide_dir).get("render_count")
        render_count = rc if isinstance(rc, int) else None

    line = {
        "n": _slide_number(slide_dir),
        "kind": kind,
        "started_at": started_at,
        "ended_at": _now_iso(),
        "duration_s": duration_s,
        "render_count": render_count,
        "note": note or "",
        "ts": _now_iso(),
    }
    with (slide_dir / LEDGER).open("a", encoding="utf-8") as f:
        f.write(json.dumps(line, ensure_ascii=False) + "\n")
    dur = f"{duration_s}s" if duration_s is not None else "?"
    warn = "" if started_at else "  (no start marker — duration unknown)"
    print(f"{slide_dir}/{LEDGER} += kind={kind} duration={dur}{warn}")


def cmd_reconcile(run_slides_dir: Path, check: bool) -> None:
    """Interrupted-round recovery. A surviving `.round_start.json` means a fit/refit round was
    in flight when the process died. With --check (dry-run) just LIST the in-flight rounds — the
    finalize gate greps this for `"kind": "refit"` to decide whether a refit is still outstanding.
    Otherwise, for each: append a ledger line with `duration_s=null` (NEVER `time.time()-t0`, which
    would inflate a killed round's duration by the downtime), print `{slide, kind, directive}` so
    the orchestrator can re-offer the refit, then delete the marker."""
    if not run_slides_dir.is_dir():
        print(f"reconcile: {run_slides_dir} not a dir — nothing to do")
        return
    found = 0
    # The arg may be the run's slides/ dir (scan children) OR a single slide dir (its own
    # marker — the double-flag cancel path passes one slide dir). Check both levels.
    for d in [run_slides_dir, *sorted(run_slides_dir.iterdir())]:
        marker_path = d / MARKER
        if not d.is_dir() or not marker_path.is_file():
            continue
        found += 1
        kind, started_at, note = "unknown", None, ""
        try:
            m = json.loads(marker_path.read_text(encoding="utf-8"))
            kind = m.get("kind", "unknown")
            started_at = m.get("started_at")
            note = m.get("note") or ""
        except (json.JSONDecodeError, OSError):
            pass
        info = {"slide": _slide_number(d), "kind": kind, "directive": note, "dir": str(d)}
        if check:
            print("active " + json.dumps(info, ensure_ascii=False))
            continue
        line = {
            "n": _slide_number(d), "kind": kind, "started_at": started_at,
            "ended_at": _now_iso(), "duration_s": None, "render_count": None,
            "note": f"reconciled: interrupted {kind}", "ts": _now_iso(),
        }
        with (d / LEDGER).open("a", encoding="utf-8") as f:
            f.write(json.dumps(line, ensure_ascii=False) + "\n")
        marker_path.unlink(missing_ok=True)
        print("reconciled " + json.dumps(info, ensure_ascii=False))
    if found == 0:
        print("reconcile: no interrupted rounds")


def main() -> None:
    p = argparse.ArgumentParser(description="Record per-slide fit/refit timing.")
    sub = p.add_subparsers(dest="cmd", required=True)

    ps = sub.add_parser("start", help="Mark the start of a fit/refit round for a slide dir.")
    ps.add_argument("slide_dir")
    ps.add_argument("--kind", required=True, choices=["fit", "refit"],
                    help="fit = normal dispatch; refit = re-dispatch with a {FEEDBACK} directive.")
    ps.add_argument("--note", default="",
                    help="Confirmed refit directive (carried to stop/notification + reconcile re-offer).")

    pt = sub.add_parser("stop", help="Close the round: append duration + render_count to rounds.jsonl.")
    pt.add_argument("slide_dir")
    pt.add_argument("--render-count", dest="render_count", type=int, default=None,
                    help="Soffice render iterations. Default: auto-read from the slide's status.json.")
    pt.add_argument("--kind", choices=["fit", "refit"], default=None,
                    help="Fallback kind if the start marker is missing.")
    pt.add_argument("--note", default="",
                    help="Ledger note. Default: carried from the start marker (the refit directive).")

    pr = sub.add_parser("reconcile", help="Clear interrupted (crashed) rounds without inflating durations.")
    pr.add_argument("run_slides_dir",
                    help="The run's slides/ dir (…/render/<label>/slides) to scan, OR one slide dir "
                         "(…/slides/<n>) to reconcile just that slide's marker (cancel path).")
    pr.add_argument("--check", action="store_true",
                    help='Dry-run: list in-flight rounds without mutating. Output lines are '
                         '`active {"slide": ..., "kind": "refit", ...}` — the finalize gate greps '
                         'the exact JSON form: grep -F \'"kind": "refit"\'.')

    args = p.parse_args()
    if args.cmd == "start":
        cmd_start(Path(args.slide_dir).resolve(), args.kind, args.note)
    elif args.cmd == "stop":
        cmd_stop(Path(args.slide_dir).resolve(), args.render_count, args.note, args.kind)
    else:
        cmd_reconcile(Path(args.run_slides_dir).resolve(), args.check)


if __name__ == "__main__":
    main()