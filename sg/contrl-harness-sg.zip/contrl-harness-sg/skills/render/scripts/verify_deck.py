#!/usr/bin/env python3
"""Stage 5 — conformance audit of the packaged deck (PASS/FAIL).

Verifies the finished `deck.pptx` against the run's own assembled slides — no plan or catalog
needed at verify time (the run is self-describing via `slides/<n>/block_meta.json`). Checks:

  1. valid OOXML — deck opens as a zip; every `ppt/slides/slideN.xml` parses.
  2. cNvPr id uniqueness — no slide has two shapes sharing a `<p:cNvPr id>` (a PowerPoint
     repair trigger soffice silently tolerates).
  3. rId uniqueness — no `.rels` part has two relationships sharing an `Id` (an OPC violation;
     PowerPoint repairs and can drop the slide whose reference became ambiguous).
  4. presentation refs resolve by type — every `sldMasterId` r:id resolves to a `/slideMaster`
     and every `sldId` r:id to a `/slide` (a re-id that points a reference at the wrong part-type
     stays "present" and slips existence checks).
  5. spTree structure — every slide's `<p:spTree>` is exactly one `nvGrpSpPr` + one `grpSpPr`
     then shape children; a second top-level group header is invalid OOXML (a PowerPoint repair
     trigger from an `adjusted.xml` that quoted a raw spTree).
  6. slide count & order — deck has exactly one slide per assembled `slides/<n>/` dir, and
     `presentation.xml`'s `sldId` order matches the run's slide-number order.
  7. media resolves — every `r:embed` / `r:link` in each slide + slideLayout + slideMaster has a
     matching rel whose Target part exists in the package (no dangling picture → grey box).
  8. body in-bounds — each slide's drawn shapes (sp/pic/graphicFrame) sit within the slide canvas
     (no shape pushed off the page); reported per slide, soft-fail only if a body shape overflows.
  9. no leftover sample text (soft) — flags body text runs that also appear verbatim in a variant's
     original `shapes.xml` but in NONE of that slide's `filled.xml` (i.e. template placeholder text
     that survived instead of being replaced). Heuristic + advisory: printed, not a hard FAIL.

Render-stage code: no plan/sample literals; works for any packaged run.

Usage: verify_deck.py --run <run> [--deck <deck.pptx>] [--render]   (--render also soffice-checks it opens)
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

import lxml.etree as ET

NS = {
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
}
R_EMBED = f"{{{NS['r']}}}embed"
R_LINK = f"{{{NS['r']}}}link"
A_T = f"{{{NS['a']}}}t"


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()


class Audit:
    def __init__(self) -> None:
        self.checks: list[tuple[str, bool, str]] = []
        self.notes: list[str] = []

    def check(self, name: str, ok: bool, detail: str = "") -> None:
        self.checks.append((name, ok, detail))

    def note(self, msg: str) -> None:
        self.notes.append(msg)

    @property
    def passed(self) -> bool:
        return all(ok for _, ok, _ in self.checks)


def _slide_canvas(zf: zipfile.ZipFile) -> tuple[int, int]:
    pres = ET.fromstring(zf.read("ppt/presentation.xml"))
    sz = pres.find("p:sldSz", NS)
    return (int(sz.get("cx")), int(sz.get("cy"))) if sz is not None else (0, 0)


def _slide_order(zf: zipfile.ZipFile) -> list[str]:
    """slide part names in presentation order (resolve sldId r:id → rels → target)."""
    pres = ET.fromstring(zf.read("ppt/presentation.xml"))
    rels = ET.fromstring(zf.read("ppt/_rels/presentation.xml.rels"))
    rid2tgt = {r.get("Id"): r.get("Target") for r in rels}
    order = []
    for sid in pres.findall("p:sldIdLst/p:sldId", NS):
        rid = sid.get(f"{{{NS['r']}}}id")
        tgt = rid2tgt.get(rid, "")
        order.append("ppt/" + tgt.lstrip("/").replace("../", ""))
    return order


def _rels_for(part: str, names: set[str]) -> str | None:
    p = Path(part)
    rp = f"{p.parent.as_posix()}/_rels/{p.name}.rels"
    return rp if rp in names else None


def audit(run: str | Path, deck: str | Path | None = None, do_render: bool = False) -> Audit:
    run = Path(run)
    deck = Path(deck) if deck else run / "deck.pptx"
    a = Audit()

    slide_dirs = sorted([d for d in (run / "slides").iterdir() if d.is_dir() and (d / "block_meta.json").exists()],
                        key=lambda d: int(re.sub(r"\D", "", d.name) or 0))
    n_expected = len(slide_dirs)

    if not deck.exists():
        a.check("deck exists", False, str(deck))
        return a
    a.check("deck exists", True, str(deck))

    try:
        zf = zipfile.ZipFile(deck)
    except zipfile.BadZipFile as e:
        a.check("valid zip", False, str(e))
        return a
    names = set(zf.namelist())
    a.check("valid zip", True, f"{len(names)} parts")

    # 1. every slide XML parses
    slide_parts = sorted([n for n in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)],
                         key=lambda n: int(re.sub(r"\D", "", n)))
    bad = []
    for sp in slide_parts:
        try:
            ET.fromstring(zf.read(sp))
        except ET.XMLSyntaxError as e:
            bad.append(f"{sp}: {e}")
    a.check("all slide XML well-formed", not bad, "; ".join(bad[:3]))

    # 2. cNvPr id uniqueness per slide — duplicate/zero ids trigger PowerPoint's repair dialog
    #     (soffice tolerates them). The packager renumbers to guarantee this; the gate turns any
    #     regression into a build failure instead of a customer-side repair.
    dup_cnvpr = []
    for sp in slide_parts:
        ids = [c.get("id") for c in ET.fromstring(zf.read(sp)).iter(f"{{{NS['p']}}}cNvPr")]
        seen, dup = set(), set()
        for i in ids:
            if i in seen:
                dup.add(i)
            else:
                seen.add(i)
        if dup or "0" in ids:
            dup_cnvpr.append(f"{Path(sp).name}: {sorted(dup, key=str) or ['id 0']}")
    a.check("no duplicate cNvPr id per slide", not dup_cnvpr,
            "; ".join(dup_cnvpr[:5]) + (f" (+{len(dup_cnvpr) - 5})" if len(dup_cnvpr) > 5 else ""))

    # 3. rId uniqueness per .rels — a duplicate relationship Id violates OPC; PowerPoint repairs
    #     and can drop the slide whose sldId reference is ambiguous. soffice + the dict-based
    #     resolver in _slide_order silently collapse dups, so check every .rels part explicitly.
    dup_rid = []
    for rf in sorted(n for n in names if n.endswith(".rels")):
        rids = re.findall(r'Id="(rId\w+)"', zf.read(rf).decode())
        seen, dup = set(), set()
        for r in rids:
            if r in seen:
                dup.add(r)
            else:
                seen.add(r)
        if dup:
            dup_rid.append(f"{rf.split('/')[-1]}: {sorted(dup)}")
    a.check("no duplicate rId per .rels", not dup_rid,
            "; ".join(dup_rid[:5]) + (f" (+{len(dup_rid) - 5})" if len(dup_rid) > 5 else ""))

    # 4. presentation refs resolve by TYPE — every <p:sldMasterId r:id> must resolve (via
    #     presentation.xml.rels) to a /slideMaster and every <p:sldId r:id> to a /slide. A re-id
    #     that leaves a reference pointing at the wrong part-type (e.g. master → a slide) keeps the
    #     id "present", so it slips existence checks while still triggering a PowerPoint repair.
    pres_el = ET.fromstring(zf.read("ppt/presentation.xml"))
    prels_el = ET.fromstring(zf.read("ppt/_rels/presentation.xml.rels"))
    rid_type = {r.get("Id"): (r.get("Type") or "") for r in prels_el}
    ref_bad = []
    for path, want in (("p:sldMasterIdLst/p:sldMasterId", "slideMaster"), ("p:sldIdLst/p:sldId", "slide")):
        for el in pres_el.findall(path, NS):
            rid = el.get(f"{{{NS['r']}}}id")
            if not rid_type.get(rid, "").endswith(f"/{want}"):
                ref_bad.append(f"{want} r:id={rid}→{(rid_type.get(rid) or 'MISSING').rsplit('/', 1)[-1]}")
    a.check("presentation refs resolve by type", not ref_bad,
            "; ".join(ref_bad[:5]) + (f" (+{len(ref_bad) - 5})" if len(ref_bad) > 5 else ""))

    # 5. spTree structure — every slide's <p:spTree> = one nvGrpSpPr + one grpSpPr then shape
    #     children; a doubled top-level group header (adjusted.xml quoting a raw spTree) is invalid
    #     OOXML and a PowerPoint repair trigger. The packager drops smuggled headers; gate backstops.
    legal_child = {f"{{{NS['p']}}}{t}" for t in ("sp", "pic", "graphicFrame", "grpSp", "cxnSp", "contentPart", "extLst")}
    bad_tree = []
    for sp in slide_parts:
        st = ET.fromstring(zf.read(sp)).find(".//p:cSld/p:spTree", NS)
        if st is None:
            bad_tree.append(f"{Path(sp).name}: no spTree"); continue
        tags = [e.tag for e in st if isinstance(e.tag, str)]
        if tags[:2] != [f"{{{NS['p']}}}nvGrpSpPr", f"{{{NS['p']}}}grpSpPr"]:
            bad_tree.append(f"{Path(sp).name}: head={[t.rsplit('}', 1)[-1] for t in tags[:3]]}"); continue
        illegal = [t.rsplit('}', 1)[-1] for t in tags[2:] if t not in legal_child]
        if illegal:
            bad_tree.append(f"{Path(sp).name}: illegal {illegal[:3]} (double group header?)")
    a.check("spTree structure (single group header)", not bad_tree,
            "; ".join(bad_tree[:5]) + (f" (+{len(bad_tree) - 5})" if len(bad_tree) > 5 else ""))

    # 6. slide count & order
    a.check("slide count == assembled", len(slide_parts) == n_expected,
            f"deck={len(slide_parts)} expected={n_expected}")
    try:
        order = _slide_order(zf)
        ordered_ok = [p for p in order if p in names] == order and len(order) == len(slide_parts)
        a.check("presentation sldId order resolves", ordered_ok,
                f"{len(order)} sldIds")
    except Exception as e:
        a.check("presentation sldId order resolves", False, str(e))

    # 7. media resolves (slides + layouts + masters)
    dangling = []
    parts_to_check = [n for n in names if re.fullmatch(
        r"ppt/(slides|slideLayouts|slideMasters)/[^/]+\.xml", n)]
    for part in parts_to_check:
        root = ET.fromstring(zf.read(part))
        embeds = {el.get(R_EMBED) or el.get(R_LINK)
                  for el in root.iter() if el.get(R_EMBED) or el.get(R_LINK)}
        embeds.discard(None)
        if not embeds:
            continue
        rp = _rels_for(part, names)
        rid2tgt = {}
        if rp:
            for r in ET.fromstring(zf.read(rp)):
                rid2tgt[r.get("Id")] = r.get("Target")
        for rid in embeds:
            tgt = rid2tgt.get(rid)
            if not tgt:
                dangling.append(f"{Path(part).name}:{rid} (no rel)")
                continue
            # resolve relative target to a package part
            abs_part = os.path.normpath(os.path.join(str(Path(part).parent), tgt)).replace("\\", "/")
            if abs_part not in names:
                dangling.append(f"{Path(part).name}:{rid}->{tgt} (missing part)")
    a.check("no dangling/broken media refs", not dangling, "; ".join(dangling[:5]) + (
        f" (+{len(dangling)-5} more)" if len(dangling) > 5 else ""))

    # 8. body shapes in-bounds (within the slide canvas)
    cw, ch = _slide_canvas(zf)
    overflow = []
    tol = 9525 * 4  # ~4px slack
    for sp in slide_parts:
        root = ET.fromstring(zf.read(sp))
        spTree = root.find(".//p:cSld/p:spTree", NS)
        if spTree is None:
            continue
        for el in spTree:
            if not isinstance(el.tag, str):       # comment / PI node (a fit agent may leave one)
                continue
            tag = ET.QName(el).localname
            if tag not in ("sp", "pic", "graphicFrame", "grpSp"):
                continue
            xfrm = el.find(".//a:xfrm", NS)
            if xfrm is None:
                xfrm = el.find(".//p:xfrm", NS)
            if xfrm is None:
                continue
            off = xfrm.find("a:off", NS)
            ext = xfrm.find("a:ext", NS)
            if off is None or ext is None:
                continue
            x, y = int(off.get("x")), int(off.get("y"))
            w, h = int(ext.get("cx")), int(ext.get("cy"))
            if x < -tol or y < -tol or x + w > cw + tol or y + h > ch + tol:
                overflow.append(f"{Path(sp).name}:{tag}@({x},{y},{w},{h})")
    # soft: report but only FAIL if a shape grossly overflows (> ~5% of a dimension)
    gross = [o for o in overflow if True]  # all listed; treat as soft note
    a.check("no body shape off-canvas", not overflow,
            "; ".join(overflow[:5]) + (f" (+{len(overflow)-5})" if len(overflow) > 5 else ""))

    # 9. leftover sample text (soft / advisory)
    leftover = _sample_text_scan(zf, slide_parts, slide_dirs, run)
    if leftover:
        a.note(f"possible leftover template text on {len(leftover)} slide(s): " +
               ", ".join(f"{k}({len(v)})" for k, v in list(leftover.items())[:8]))

    # optional: confirm soffice can open it
    if do_render:
        ok, detail = _soffice_opens(deck)
        a.check("soffice opens deck", ok, detail)

    zf.close()
    return a


def _sample_text_scan(zf, slide_parts, slide_dirs, run) -> dict[str, list[str]]:
    """Per slide: runs present in the deck that also occur verbatim in one of the slide's variant
    originals (template text) but in NONE of its filled.xml runs → likely un-replaced placeholder."""
    out: dict[str, list[str]] = {}
    dir_by_idx = {i + 1: d for i, d in enumerate(slide_dirs)}
    for i, sp in enumerate(slide_parts, start=1):
        d = dir_by_idx.get(i)
        if not d:
            continue
        deck_runs = {_norm(t.text) for t in ET.fromstring(zf.read(sp)).iter(A_T) if _norm(t.text or "")}
        filled = d / "filled.xml"
        filled_runs = set()
        if filled.exists():
            filled_runs = {_norm(t.text) for t in ET.parse(str(filled)).getroot().iter(A_T) if _norm(t.text or "")}
        orig_runs = set()
        for of in d.glob("original_*.shapes.xml"):
            try:
                orig_runs |= {_norm(t.text) for t in ET.parse(str(of)).getroot().iter(A_T) if _norm(t.text or "")}
            except Exception:
                pass
        suspects = [r for r in deck_runs if len(r) >= 4 and r in orig_runs and r not in filled_runs]
        if suspects:
            out[Path(sp).name] = suspects[:6]
    return out


def _soffice_opens(deck: Path) -> tuple[bool, str]:
    soffice = os.environ.get("SOFFICE") or shutil.which("soffice") or shutil.which("libreoffice") \
        or "/Applications/LibreOffice.app/Contents/MacOS/soffice"
    if not Path(soffice).exists():
        return True, "(soffice not found — skipped)"
    prof = Path(tempfile.mkdtemp(prefix="rpd_verify_"))
    out = Path(tempfile.mkdtemp(prefix="rpd_verify_out_"))
    try:
        subprocess.run([soffice, f"-env:UserInstallation=file://{prof}", "--headless",
                        "--convert-to", "pdf", "--outdir", str(out), str(deck)],
                       check=True, capture_output=True, timeout=300, env={**os.environ, "HOME": str(prof)})
        pdf = out / (deck.stem + ".pdf")
        return pdf.exists() and pdf.stat().st_size > 0, f"-> {pdf.name} ({pdf.stat().st_size} bytes)" if pdf.exists() else "no pdf"
    except subprocess.CalledProcessError as e:
        return False, (e.stderr or b"").decode()[-200:]
    finally:
        shutil.rmtree(prof, ignore_errors=True)
        shutil.rmtree(out, ignore_errors=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--deck", default=None)
    ap.add_argument("--render", action="store_true", help="also soffice-convert to confirm it opens")
    args = ap.parse_args()
    a = audit(args.run, args.deck, args.render)
    print("=== deck conformance audit ===")
    for name, ok, detail in a.checks:
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  — {detail}" if detail else ""))
    for n in a.notes:
        print(f"  [note] {n}")
    print(f"\n{'PASS' if a.passed else 'FAIL'} — {sum(ok for _,ok,_ in a.checks)}/{len(a.checks)} checks")
    return 0 if a.passed else 1


if __name__ == "__main__":
    sys.exit(main())
