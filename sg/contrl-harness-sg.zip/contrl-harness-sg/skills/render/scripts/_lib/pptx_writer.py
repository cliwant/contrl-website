"""ComposedDeck + frame 번들 → chrome 포함 .pptx 패키징.

compose_deck가 만든 슬라이드별 본문 spTree를, Phase 0 frame 번들(원본 slideMaster·
slideLayout·theme·media)에 얹어 배경·헤더·푸터가 살아있는 .pptx로 쓴다.

frame 번들은 불완전 OPC다 — `_rels/.rels`가 없고, presentation.xml/.rels/[Content_Types]에
원본 172 슬라이드 + notesMaster·handoutMaster·presProps·viewProps·tableStyles 참조가
남아 있는데 그 파일들은 frame에 없다(dangling). 그대로 zip하면 PowerPoint가 복구를 띄운다.
그래서 "실재 파일 화이트리스트"로 제어 파트를 재구성하고 누락된 `_rels/.rels`를 만든다.

Phase A: 열리는 chrome .pptx(본문 + 상속 chrome). Phase B(placeholder 주입)는 후속.
"""
from __future__ import annotations

import copy
import re
import zipfile
from pathlib import Path

import lxml.etree as ET

from .catalog import Catalog
from .models import ComposedDeck, PackageReport
from .ooxml import A_NS, MEDIA_CONTENT_TYPES, P_NS, R_NS, _sptree, _max_cnvpr_id, harvest_media, renumber_cnvpr

CT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
PR_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
_SLIDE_CT = "application/vnd.openxmlformats-officedocument.presentationml.slide+xml"


def _xml(root: ET._Element) -> bytes:
    return ET.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)


def _layout_n(layout_id: str | None) -> int | None:
    """'layout-22' → 22. frame slideLayout{N}.xml과 숫자 매핑."""
    if not layout_id:
        return None
    m = re.fullmatch(r"layout-(\d+)", layout_id)
    return int(m.group(1)) if m else None


# ───────────────────────── frame 로드 ─────────────────────────
def _load_frame_parts(frame_dir: str | Path) -> dict[str, bytes]:
    """frame 디렉토리의 실재 파트만 arcname→bytes로 로드(manifest.json 제외).
    실재 파일만 담으므로 dangling(notesMaster 등)은 자연히 빠진다."""
    frame_dir = Path(frame_dir)
    parts: dict[str, bytes] = {}
    for p in sorted(frame_dir.rglob("*")):
        if p.is_file() and p.name != "manifest.json":
            parts[p.relative_to(frame_dir).as_posix()] = p.read_bytes()
    return parts


def _package_root_rels() -> bytes:
    """frame에 없는 패키지 루트 `_rels/.rels` 생성(rId1→ppt/presentation.xml)."""
    root = ET.Element(f"{{{PR_NS}}}Relationships", nsmap={None: PR_NS})
    rel = ET.SubElement(root, f"{{{PR_NS}}}Relationship")
    rel.set("Id", "rId1")
    rel.set("Type", f"{R_NS}/officeDocument")
    rel.set("Target", "ppt/presentation.xml")
    return _xml(root)


# ───────────────────────── 제어 파트 리셋 ─────────────────────────
def _slide_rid_base(rels_xml: bytes) -> int:
    """유지되는 관계(slideMaster·theme)의 최대 rId를 base로 잡아 슬라이드 rId를 그 위
    (base+1..)에서 매기게 한다 — 슬라이드 rId를 kept rId와 disjoint하게 만들어 같은 .rels
    안 중복 rId(→ PowerPoint repair·슬라이드 유실)를 원천 차단한다. 슬라이드(sldIdLst r:id)와
    슬라이드 관계(Relationship Id)가 같은 base를 써야 하므로 caller가 1회 계산해 둘에 넘긴다.
    kept가 없으면 1(슬라이드는 rId2부터 — 기존 동작 유지)."""
    root = ET.fromstring(rels_xml)
    kept = []
    for r in root:
        if (r.get("Type") or "").endswith(("/slideMaster", "/theme")):
            m = re.match(r"rId(\d+)$", r.get("Id") or "")
            if m:
                kept.append(int(m.group(1)))
    return max(kept, default=1)


def _reset_presentation(xml: bytes, n: int, base: int = 1) -> bytes:
    """sldIdLst를 새 n장으로 교체(id=256+i, r:id=rId{base+i}). 파일 없는
    notesMasterIdLst/handoutMasterIdLst 제거. sldMasterIdLst·sldSz·notesSz·
    defaultTextStyle·extLst는 유지."""
    P = f"{{{P_NS}}}"
    root = ET.fromstring(xml)
    for tag in ("notesMasterIdLst", "handoutMasterIdLst"):
        el = root.find(f"{P}{tag}")
        if el is not None:
            root.remove(el)
    lst = root.find(f"{P}sldIdLst")
    if lst is None:
        lst = ET.Element(f"{P}sldIdLst")
        m = root.find(f"{P}sldMasterIdLst")
        root.insert((list(root).index(m) + 1) if m is not None else 0, lst)
    for c in list(lst):
        lst.remove(c)
    for i in range(1, n + 1):
        sid = ET.SubElement(lst, f"{P}sldId")
        sid.set("id", str(255 + i))
        sid.set(f"{{{R_NS}}}id", f"rId{base + i}")
    return _xml(root)


def _reset_presentation_rels(xml: bytes, n: int, base: int = 1) -> bytes:
    """slideMaster·theme 관계만 유지하고 slide/notesMaster/handoutMaster/presProps/
    viewProps/tableStyles(전부 frame에 없음) 제거. 새 슬라이드 rId{base+i} 추가
    (base=kept rId 최대치 → 슬라이드 rId를 master·theme rId와 disjoint하게, dup rId 방지)."""
    root = ET.fromstring(xml)
    keep = [r for r in list(root)
            if (r.get("Type") or "").endswith(("/slideMaster", "/theme"))]
    for r in list(root):
        root.remove(r)
    for r in keep:
        root.append(r)
    for i in range(1, n + 1):
        rel = ET.SubElement(root, f"{{{PR_NS}}}Relationship")
        rel.set("Id", f"rId{base + i}")
        rel.set("Type", f"{R_NS}/slide")
        rel.set("Target", f"slides/slide{i}.xml")
    return _xml(root)


def _reset_content_types(xml: bytes, kept_parts: set[str], n: int) -> bytes:
    """복사된 XML 파트의 Override만 유지(없는 파트·옛 슬라이드 Override 제거),
    새 슬라이드 Override n개 추가. Default(png/rels/xml 등)는 전부 유지."""
    CT = f"{{{CT_NS}}}"
    root = ET.fromstring(xml)
    for ov in list(root.findall(f"{CT}Override")):
        pn = (ov.get("PartName") or "").lstrip("/")
        if pn.startswith("ppt/slides/") or pn not in kept_parts:
            root.remove(ov)
    for i in range(1, n + 1):
        ov = ET.SubElement(root, f"{CT}Override")
        ov.set("PartName", f"/ppt/slides/slide{i}.xml")
        ov.set("ContentType", _SLIDE_CT)
    return _xml(root)


def _ensure_media_defaults(xml: bytes, exts: set[str]) -> bytes:
    """Add a <Default Extension=… ContentType=…> for every embedded-media extension not already
    declared. Re-homed icons (gif/wmf/wdp/…) need their type registered or PowerPoint repairs."""
    CT = f"{{{CT_NS}}}"
    root = ET.fromstring(xml)
    have = {(d.get("Extension") or "").lower() for d in root.findall(f"{CT}Default")}
    for ext in sorted(exts):
        ct = MEDIA_CONTENT_TYPES.get(ext)
        if ct and ext not in have:
            d = ET.SubElement(root, f"{CT}Default")
            d.set("Extension", ext)
            d.set("ContentType", ct)
    return _xml(root)


# ───────────────────────── placeholder 주입 (Phase B) ─────────────────────────
# master placeholder엔 catalog상 name이 없어 slot 어휘 → OOXML ph_type 사전 매핑.
# (master_fills는 현 실데이터가 비어 best-effort. 미매핑/실파일無는 skip+warning.)
_MASTER_SLOT_PH = {
    "footer": "ftr", "footer_text": "ftr", "ftr": "ftr",
    "page_number": "sldNum", "page_no": "sldNum", "slide_number": "sldNum", "sldNum": "sldNum",
    "date": "dt", "datetime": "dt", "dt": "dt", "title": "title", "body": "body",
}


def _ph_target(ph: dict) -> tuple[str | None, str | None]:
    """catalog placeholder → (ph_type, ph_idx). v6 중첩 target + 구 flat 모두 지원."""
    t = ph.get("target") or ph
    return t.get("ph_type"), t.get("ph_idx")


# PATCH(render-proposal-deck) #4 — master_fills page_number="slidenum" must become an <a:fld>
# slide-number auto-field, not a literal "slidenum" text run (which renders the word on every slide).
# Re-apply on re-sync; report upstream to contrl. ↓
# slot 값이 리터럴 텍스트가 아니라 자동 필드(슬라이드 번호/날짜)를 뜻하는 센티넬.
# 예) page_number="slidenum" → <a:fld type="slidenum"> (PowerPoint가 실제 페이지 번호로 렌더).
_FIELD_SENTINELS = {
    "sldNum": {"slidenum", "sldnum", "auto", "‹#›", "#", "page_number"},
    "dt": {"datetime", "date", "auto", "today"},
}
_FLD_GUID = "{734CEA42-BB7C-4C50-89E1-0849808E74D7}"


def _field_type_for(ph_type: str, value: str) -> str | None:
    """ph_type가 자동필드 타입(sldNum/dt)이고 value가 그 센티넬이면 a:fld type을 반환, 아니면 None(리터럴)."""
    sents = _FIELD_SENTINELS.get(ph_type)
    if sents and re.sub(r"\s+", "", (value or "").lower()) in sents:
        return "slidenum" if ph_type == "sldNum" else "datetime"
    return None


def _thin_ph_sp(ph_type: str, ph_idx, name: str, text: str, sid: int, fld_type: str | None = None) -> ET._Element:
    """빈 spPr를 가진 thin placeholder <p:sp> — 위치·서식은 layout/master ph에서 상속,
    여기선 ph(type,idx) 매칭과 텍스트만 채운다(layout 파일은 공유라 직접 수정 안 함).
    fld_type가 주어지면 리터럴 run 대신 <a:fld>(슬라이드번호/날짜 자동필드)를 넣는다."""
    P, A = f"{{{P_NS}}}", f"{{{A_NS}}}"
    sp = ET.Element(f"{P}sp")
    nv = ET.SubElement(sp, f"{P}nvSpPr")
    cnv = ET.SubElement(nv, f"{P}cNvPr"); cnv.set("id", str(sid)); cnv.set("name", name or ph_type)
    ET.SubElement(ET.SubElement(nv, f"{P}cNvSpPr"), f"{A}spLocks").set("noGrp", "1")
    ph = ET.SubElement(ET.SubElement(nv, f"{P}nvPr"), f"{P}ph"); ph.set("type", ph_type)
    if ph_idx not in (None, ""):
        ph.set("idx", str(ph_idx))
    ET.SubElement(sp, f"{P}spPr")                          # 빈 spPr = 상속
    tx = ET.SubElement(sp, f"{P}txBody")
    ET.SubElement(tx, f"{A}bodyPr"); ET.SubElement(tx, f"{A}lstStyle")
    p = ET.SubElement(tx, f"{A}p")
    if fld_type:                                           # 자동필드: <a:fld type=...><a:t>‹#›</a:t></a:fld>
        fld = ET.SubElement(p, f"{A}fld"); fld.set("id", _FLD_GUID); fld.set("type", fld_type)
        ET.SubElement(fld, f"{A}rPr").set("lang", "en-US")
        ET.SubElement(fld, f"{A}t").text = "‹#›"
    else:
        r = ET.SubElement(p, f"{A}r")
        ET.SubElement(r, f"{A}t").text = text
    return sp


def _phkey(ptype, pidx) -> tuple:
    """(ph_type, ph_idx) 정규화 키 — idx는 ''·None을 None으로 통일해 양쪽 비교가 맞게."""
    return (ptype, str(pidx) if pidx not in (None, "") else None)


def _existing_ph_keys(sptree: ET._Element) -> set:
    """이미 spTree 안에 들어있는 placeholder들의 {(ph_type, ph_idx)}. assemble 단계에서 layout
    placeholder를 seed에 미리 주입(Option 1)하면, 패키저가 같은 fill을 또 주입하지 않도록 dedup용."""
    P = f"{{{P_NS}}}"
    return {_phkey(ph.get("type"), ph.get("idx")) for ph in _sptree(sptree).iter(f"{P}ph")}


def _inject_layout_fills(fills: list[dict], layout_def: dict, seed: int, existing: set | None = None):
    """layout_fills → thin ph sp 목록. slot은 catalog placeholder.name과 매칭,
    ph_type 없으면(구 스키마 null 등) skip+warning. `existing`에 이미 있는 (ph_type,idx)는
    슬라이드가 그 placeholder를 이미 들고 있다는 뜻이라 재주입하지 않는다(중복 방지)."""
    by_name = {p["name"]: p for p in (layout_def.get("placeholders") or []) if p.get("name")}
    existing = existing or set()
    sps, warns, sid = [], [], seed
    for f in fills or []:
        slot = f.get("slot")
        ph = by_name.get(slot)
        ptype, pidx = _ph_target(ph) if ph else (None, None)
        if not ptype:
            warns.append(f"layout slot {slot!r} has no ph_type; skipping")
            continue
        if _phkey(ptype, pidx) in existing:               # 이미 seed에 주입됨 → 패키저는 건너뜀
            continue
        v = f.get("value")
        sps.append(_thin_ph_sp(ptype, pidx, slot, "" if v is None else str(v), sid)); sid += 1
    return sps, warns


def _inject_master_fills(fills: list[dict], master_def: dict, seed: int):
    """master_fills → thin ph sp 목록. slot→ph_type(_MASTER_SLOT_PH)→master placeholder."""
    by_type = {}
    for p in (master_def or {}).get("placeholders") or []:
        by_type.setdefault(p.get("ph_type"), p)
    sps, warns, sid = [], [], seed
    for f in fills or []:
        slot = f.get("slot")
        ptype = _MASTER_SLOT_PH.get(slot)
        ph = by_type.get(ptype) if ptype else None
        if not ph:
            warns.append(f"master slot {slot!r} is unmapped; skipping")
            continue
        _, pidx = _ph_target(ph)
        v = f.get("value")
        vs = "" if v is None else str(v)
        fld_type = _field_type_for(ptype, vs)             # page_number="slidenum" → 자동필드
        sps.append(_thin_ph_sp(ptype, pidx, slot, vs, sid, fld_type=fld_type)); sid += 1
    return sps, warns


# ───────────────────────── 슬라이드 생성 ─────────────────────────
def _build_slide_el(cs, ph_sps=()) -> ET._Element:
    """ComposedSlide.sptree(본문 도형들) + 주입 placeholder sp들을 유효 <p:sld> 엘리먼트로 래핑.
    spTree 표준 헤더(nvGrpSpPr/grpSpPr) + 본문 자식 + placeholder + clrMapOvr(master 상속).
    본문 도형의 <a:blip>는 아직 DSMEDIA 센티넬을 달고 있다 — 직렬화 전에 harvest_media가 re-home한다."""
    P, A = f"{{{P_NS}}}", f"{{{A_NS}}}"
    sld = ET.Element(f"{P}sld", nsmap={"a": A_NS, "r": R_NS, "p": P_NS})
    csld = ET.SubElement(sld, f"{P}cSld")
    sptree = ET.SubElement(csld, f"{P}spTree")
    nv = ET.SubElement(sptree, f"{P}nvGrpSpPr")
    cnv = ET.SubElement(nv, f"{P}cNvPr"); cnv.set("id", "1"); cnv.set("name", "")
    ET.SubElement(nv, f"{P}cNvGrpSpPr")
    ET.SubElement(nv, f"{P}nvPr")
    gpr = ET.SubElement(sptree, f"{P}grpSpPr")
    xf = ET.SubElement(gpr, f"{A}xfrm")
    for t in ("off", "chOff"):
        e = ET.SubElement(xf, f"{A}{t}"); e.set("x", "0"); e.set("y", "0")
    for t in ("ext", "chExt"):
        e = ET.SubElement(xf, f"{A}{t}"); e.set("cx", "0"); e.set("cy", "0")
    for child in list(_sptree(cs.sptree)):          # 본문 도형(grpSp 등)
        if child.tag in (f"{P}nvGrpSpPr", f"{P}grpSpPr"):   # raw spTree 인용으로 딸려온 group
            continue                                        # header는 버린다(위에서 1개 달았음) → 이중 헤더 방지
        sptree.append(copy.deepcopy(child))
    for sp in ph_sps:                                # 주입 placeholder(본문 위)
        sptree.append(sp)
    renumber_cnvpr(sptree)                            # 본문·주입 다 모인 뒤 cNvPr id 1..n 재부여 → slide 내 유일성 보장
    cmo = ET.SubElement(sld, f"{P}clrMapOvr")
    ET.SubElement(cmo, f"{A}masterClrMapping")
    return sld


def _build_slide_rels(layout_n: int, media_rels: dict[str, str] | None = None) -> bytes:
    """slideLayout 관계(rId1) + 본문 아이콘 이미지 관계(harvest_media가 부여한 rId→arcname)."""
    root = ET.Element(f"{{{PR_NS}}}Relationships", nsmap={None: PR_NS})
    rel = ET.SubElement(root, f"{{{PR_NS}}}Relationship")
    rel.set("Id", "rId1")
    rel.set("Type", f"{R_NS}/slideLayout")
    rel.set("Target", f"../slideLayouts/slideLayout{layout_n}.xml")
    for rid, arc in (media_rels or {}).items():
        r = ET.SubElement(root, f"{{{PR_NS}}}Relationship")
        r.set("Id", rid)
        r.set("Type", f"{R_NS}/image")
        r.set("Target", f"../media/{Path(arc).name}")
    return _xml(root)


def _write_zip(parts: dict[str, bytes], out: str | Path) -> None:
    """결정론 zip: [Content_Types].xml 선두, 나머지 정렬, date_time 고정."""
    order = sorted(parts, key=lambda k: (k != "[Content_Types].xml", k))
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in order:
            zi = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            zf.writestr(zi, parts[name], zipfile.ZIP_DEFLATED)


# ───────── picture placeholder 레이아웃 백업 (Keynote/PowerPoint 삽입 지원) ─────────
# 슬라이드 top-level pic placeholder의 삽입 버튼은 Google만 orphan을 honor하고
# Keynote/PowerPoint는 슬라이드 레이아웃에 동일 type=pic idx 백업을 요구한다. frame 레이아웃은
# 공유라 직접 수정하면 유령 placeholder가 생기므로, (base layout, idx-set)별로 레이아웃을 복제해
# 복제본에만 매칭 pic ph를 심고 슬라이드 rels를 복제본으로 돌린다.
_LAYOUT_CT = "application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"


def _scan_pic_phs(sptree: ET._Element) -> list[tuple[str | None, ET._Element]]:
    """slide spTree 직속 sp 중 picture placeholder(<p:ph type='pic'>)를 [(idx, sp)]로."""
    P = f"{{{P_NS}}}"
    out = []
    for c in sptree:
        if not isinstance(c.tag, str):        # comment / PI node (fit agent may leave one) — not an element
            continue
        if ET.QName(c).localname != "sp":
            continue
        ph = c.find(f"{P}nvSpPr/{P}nvPr/{P}ph")
        if ph is not None and ph.get("type") == "pic":
            out.append((ph.get("idx"), c))
    return out


def _pic_geom(sp: ET._Element) -> ET._Element | None:
    return sp.find(f"{{{P_NS}}}spPr/{{{A_NS}}}xfrm")


def _layout_pic_sp(idx, geom_xfrm: ET._Element | None, sid: int) -> ET._Element:
    """레이아웃 백업용 매칭 picture placeholder <p:sp> — 슬라이드 sp의 geometry를 복사."""
    P, A = f"{{{P_NS}}}", f"{{{A_NS}}}"
    sp = ET.Element(f"{P}sp")
    nv = ET.SubElement(sp, f"{P}nvSpPr")
    cn = ET.SubElement(nv, f"{P}cNvPr"); cn.set("id", str(sid)); cn.set("name", f"Picture Placeholder {idx}")
    sl = ET.SubElement(ET.SubElement(nv, f"{P}cNvSpPr"), f"{A}spLocks")
    sl.set("noGrp", "1"); sl.set("noChangeAspect", "1")
    ph = ET.SubElement(ET.SubElement(nv, f"{P}nvPr"), f"{P}ph"); ph.set("type", "pic")
    if idx not in (None, ""):
        ph.set("idx", str(idx))
    spPr = ET.SubElement(sp, f"{P}spPr")
    if geom_xfrm is not None:
        spPr.append(copy.deepcopy(geom_xfrm))
    tx = ET.SubElement(sp, f"{P}txBody")
    ET.SubElement(tx, f"{A}bodyPr"); ET.SubElement(tx, f"{A}lstStyle"); ET.SubElement(tx, f"{A}p")
    return sp


def _clone_layout_with_pics(base_xml: bytes, idx_geoms, sid_seed: int) -> bytes:
    """base 레이아웃 복제 후 각 (idx, geom)에 매칭 pic ph append. base에 동일 idx pic ph 있으면 skip."""
    P = f"{{{P_NS}}}"
    root = ET.fromstring(base_xml)
    sp_tree = _sptree(root)
    existing = {ph.get("idx") for ph in sp_tree.iter(f"{P}ph") if ph.get("type") == "pic"}
    sid = sid_seed
    for idx, geom in idx_geoms:
        if idx in existing:
            continue
        sp_tree.append(_layout_pic_sp(idx, geom, sid)); sid += 1
    return _xml(root)


def _clone_layout_rels() -> bytes:
    """복제 레이아웃 rels 폴백(base rels 없을 때): rId1 → slideMaster1."""
    root = ET.Element(f"{{{PR_NS}}}Relationships", nsmap={None: PR_NS})
    rel = ET.SubElement(root, f"{{{PR_NS}}}Relationship")
    rel.set("Id", "rId1"); rel.set("Type", f"{R_NS}/slideMaster")
    rel.set("Target", "../slideMasters/slideMaster1.xml")
    return _xml(root)


def _register_clone_in_master(master_root: ET._Element, master_rels_root: ET._Element, clone_n: int) -> None:
    """master.rels에 새 rId=slideLayout, master.xml sldLayoutIdLst에 새 sldLayoutId append(in-place)."""
    P = f"{{{P_NS}}}"
    rids = [int(r.get("Id")[3:]) for r in master_rels_root
            if (r.get("Id") or "").startswith("rId") and r.get("Id")[3:].isdigit()]
    new_rid = f"rId{(max(rids) if rids else 0) + 1}"
    rel = ET.SubElement(master_rels_root, f"{{{PR_NS}}}Relationship")
    rel.set("Id", new_rid); rel.set("Type", f"{R_NS}/slideLayout")
    rel.set("Target", f"../slideLayouts/slideLayout{clone_n}.xml")
    idlst = master_root.find(f"{P}sldLayoutIdLst")
    if idlst is None:
        idlst = ET.SubElement(master_root, f"{P}sldLayoutIdLst")
    lids = [int(c.get("id")) for c in idlst if (c.get("id") or "").isdigit()]
    sid = ET.SubElement(idlst, f"{P}sldLayoutId")
    sid.set("id", str((max(lids) if lids else 2147483648) + 1))
    sid.set(f"{{{R_NS}}}id", new_rid)


def _register_clone_content_type(ct_root: ET._Element, clone_n: int) -> None:
    ov = ET.SubElement(ct_root, f"{{{CT_NS}}}Override")
    ov.set("PartName", f"/ppt/slideLayouts/slideLayout{clone_n}.xml")
    ov.set("ContentType", _LAYOUT_CT)


# ───────────────────────── 진입점 ─────────────────────────
def write_deck_pptx(deck: ComposedDeck, cat: Catalog | None, frame_dir: str | Path,
                    out: str | Path, *, strict: bool = True) -> PackageReport:
    """ComposedDeck + frame 번들 → chrome + placeholder 텍스트가 든 .pptx.

    Phase A(본문+chrome 상속) + Phase B(layout_fills/master_fills를 layout·master
    placeholder에 주입). cat이 None이면 주입 생략(Phase A 동작)."""
    parts = _load_frame_parts(frame_dir)
    frame_keys = set(parts)
    rep = PackageReport(slide_count=len(deck.slides),
                        media_kept=sum(1 for k in frame_keys if k.startswith("ppt/media/")))
    # Shared body-icon pool the composed shapes reference via DSMEDIA sentinels (None ⇒ no catalog,
    # e.g. a chrome-only Phase-A test: sentinels, if any, are simply left unresolved).
    pool_dir = (Path(cat.root) / "media") if cat is not None else None
    media_exts: set[str] = set()
    avail = {k for k in frame_keys
             if re.fullmatch(r"ppt/slideLayouts/slideLayout\d+\.xml", k)}
    # TODO(CTRL-501 후속): layout_id "layout-N"을 물리 slideLayoutN과 같은 번호로 가정한다.
    # Phase 0 v6 frame은 논리(예 24)↔물리(예 93) 번호가 달라질 수 있어 manifest 기반
    # 논리→물리 매핑이 필요하다. 그전까지는 미매핑 시 실재하는 최소 layout으로 loud-warn
    # fallback하고(하나도 없으면 hard-fail), 미실재일 수 있는 slideLayout1에 의존하지 않는다.
    avail_n = sorted(int(re.search(r"(\d+)", k).group(1)) for k in avail)
    fallback_n = avail_n[0] if avail_n else None
    master = next(iter(cat.masters.values()), {}) if cat else {}

    # picture placeholder 레이아웃 백업용 master/clone 상태(master xml/rels는 1회 파싱→in-place→1회 직렬화)
    master_key = next((k for k in frame_keys
                       if re.fullmatch(r"ppt/slideMasters/slideMaster\d+\.xml", k)), None)
    master_rels_key = f"ppt/slideMasters/_rels/{Path(master_key).name}.rels" if master_key else None
    can_clone = bool(master_key and master_rels_key and master_rels_key in frame_keys)
    master_root = ET.fromstring(parts[master_key]) if can_clone else None
    master_rels_root = ET.fromstring(parts[master_rels_key]) if can_clone else None
    next_layout_n = (max(avail_n) + 1) if avail_n else 1
    clone_cache: dict[tuple, int] = {}        # (base_ln, frozenset(idx)) → clone_n
    clone_ns: list[int] = []

    for i, cs in enumerate(deck.slides, 1):
        ln = _layout_n(cs.layout_id)
        if ln is None or f"ppt/slideLayouts/slideLayout{ln}.xml" not in avail:
            if fallback_n is None:
                raise ValueError(f"frame has no slideLayout parts: {Path(frame_dir)}")
            rep.warnings.append(
                f"slide{i}: layout_id={cs.layout_id!r} unmapped; falling back to slideLayout{fallback_n}")
            ln = fallback_n
        rep.layouts_used.append(ln)

        # 이 슬라이드의 top-level picture placeholder → (base_ln, idx-set)별 레이아웃 복제로 백업
        eff_ln = ln
        pic_phs = _scan_pic_phs(_sptree(cs.sptree))
        if pic_phs and can_clone:
            sig = (ln, frozenset(idx for idx, _ in pic_phs))
            if sig in clone_cache:
                eff_ln = clone_cache[sig]
            else:
                clone_n = next_layout_n; next_layout_n += 1
                base_xml = parts[f"ppt/slideLayouts/slideLayout{ln}.xml"]
                idx_geoms = [(idx, _pic_geom(sp)) for idx, sp in pic_phs]
                seed = _max_cnvpr_id(ET.fromstring(base_xml)) + 1
                parts[f"ppt/slideLayouts/slideLayout{clone_n}.xml"] = \
                    _clone_layout_with_pics(base_xml, idx_geoms, seed)
                base_rels = parts.get(f"ppt/slideLayouts/_rels/slideLayout{ln}.xml.rels")
                parts[f"ppt/slideLayouts/_rels/slideLayout{clone_n}.xml.rels"] = \
                    base_rels if base_rels is not None else _clone_layout_rels()
                _register_clone_in_master(master_root, master_rels_root, clone_n)
                clone_cache[sig] = clone_n; clone_ns.append(clone_n); eff_ln = clone_n
                rep.layouts_cloned += 1
            rep.pic_backups += len(pic_phs)
        elif pic_phs and not can_clone:
            rep.warnings.append(f"slide{i}: master not found; skipping picture-placeholder layout backup (Google only)")

        ph_sps = []
        if cat is not None:
            base = max(9100, _max_cnvpr_id(_sptree(cs.sptree)) + 1)   # 본문 group id와 충돌 방지(PHB)
            # 슬라이드가 이미 들고 있는 layout placeholder(assemble 단계 주입분)는 재주입하지 않는다.
            present = _existing_ph_keys(cs.sptree)
            lf, w1 = _inject_layout_fills(cs.layout_fills, cat.layouts.get(cs.layout_id, {}), base, present)
            mf, w2 = _inject_master_fills(deck.master_fills, master, base + len(lf))
            ph_sps = lf + mf
            rep.injected += len(ph_sps)
            rep.warnings += [f"slide{i}: {w}" for w in (w1 + w2)]
        slide_el = _build_slide_el(cs, ph_sps)
        # Re-home embedded icons: DSMEDIA sentinels → real rIds + ppt/media parts (deck-wide dedup).
        mrels: dict[str, str] = {}
        if pool_dir is not None:
            mrels, mmedia = harvest_media(slide_el, pool_dir)
            for arc, data in mmedia.items():
                parts.setdefault(arc, data)
                media_exts.add(Path(arc).suffix.lstrip(".").lower())
            rep.media_embedded += len(mrels)
        parts[f"ppt/slides/slide{i}.xml"] = _xml(slide_el)
        parts[f"ppt/slides/_rels/slide{i}.xml.rels"] = _build_slide_rels(eff_ln, mrels)

    n = len(deck.slides)
    # 슬라이드 rId를 유지되는 master·theme rId 위에서 매겨 dup rId(→ PowerPoint repair)를 막는다.
    # sldIdLst r:id와 슬라이드 Relationship Id가 같은 base를 써야 하므로 1회 계산해 둘에 넘긴다.
    rid_base = _slide_rid_base(parts["ppt/_rels/presentation.xml.rels"])
    parts["ppt/presentation.xml"] = _reset_presentation(parts["ppt/presentation.xml"], n, rid_base)
    parts["ppt/_rels/presentation.xml.rels"] = _reset_presentation_rels(
        parts["ppt/_rels/presentation.xml.rels"], n, rid_base)
    parts["[Content_Types].xml"] = _reset_content_types(
        parts["[Content_Types].xml"], frame_keys, n)
    if media_exts:                       # declare any embedded-icon extension the frame didn't have
        parts["[Content_Types].xml"] = _ensure_media_defaults(parts["[Content_Types].xml"], media_exts)

    # 복제 레이아웃 반영: master(in-place 갱신본) 직렬화 + Content_Types Override 추가(reset 이후)
    if clone_ns:
        parts[master_key] = _xml(master_root)
        parts[master_rels_key] = _xml(master_rels_root)
        ct_root = ET.fromstring(parts["[Content_Types].xml"])
        for clone_n in sorted(clone_ns):
            _register_clone_content_type(ct_root, clone_n)
        parts["[Content_Types].xml"] = _xml(ct_root)

    parts["_rels/.rels"] = _package_root_rels()
    _write_zip(parts, out)
    return rep
