"""Per-slide plan-record → slide dict + validation (VENDORED from slide-plan).

The render skill is deliberately self-contained — its `_lib/` never imports from
another skill (see `_lib/` convention). To let S6 admit ONE slide directly from
its S5 DECISION record (`.plan/slide_{index}.json`) instead of the assembled
`slide_plan.json`, the three small, stdlib-only functions S5 uses to turn a
record into a validated slide are VENDORED here verbatim:

  - `record_to_slide`        ← slide-plan/scripts/assemble.py `_record_to_slide`
    (+ `_dedup_block_headings` / `_is_headline_slot`, the block-heading dedup it
     calls — both must stay identical here and in assemble.py, or per-slide seeds
     would diverge from the assembled slide_plan.json)
  - `validate_slide`         ← slide-plan/scripts/assemble.py `validate_slide`
  - `allowed_list_violations`← slide-plan/scripts/assemble.py `allowed_list_violations`
    (+ `_allowed_sets`, the slot-name helpers, and `FALLBACK_VARIANT_ID`)

Keep these in sync with the source; they are pure dict logic with no catalog
parsing, so the render-side `Catalog.data` (the raw catalog.json dict) is a valid
input for `catalog`. This is the same source-of-truth reuse the plan calls for,
done by vendoring rather than a cross-skill import.
"""
from __future__ import annotations

import sys
from typing import Any

# The degraded floor component (mirrors slide-plan/scripts/make_floor.py
# FALLBACK_VARIANT_ID and validate-artifacts.mjs). A floor slide's variant is
# exempt from the allowed-list check.
FALLBACK_VARIANT_ID = "single-bordered-bullet-box"


# ── Record → slide ───────────────────────────────────────────────────────────
def _is_headline_slot(slot: str) -> bool:
    """A component's own title/banner/header slot — the one that collides with a
    block's adornment heading. Excludes sub-headings (subtitle/subhead*) and any
    `sub…`-prefixed slot; column headers (…_header) match by name but survive the
    value guard in `_dedup_block_headings` since their text differs from the
    heading."""
    s = slot or ""
    if s.startswith("sub") or "subtitle" in s or "subhead" in s:
        return False
    return s.endswith(("title", "header", "heading")) or "banner" in s


def _dedup_block_headings(blocks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Root-fix the S5 double-heading. block_matching gives every block a
    heading-bearing adornment (which renders the block heading in its `title`
    slot), while slot_mapping independently fills the component's own headline
    slot from the same source — the two steps don't see each other, so the heading
    is planted twice. Where the adornment already carries the heading, drop it from
    the component's headline fill so it renders once: a fill that IS the heading is
    dropped; a fill that is the heading followed by an extra editorial line keeps
    only that extra line. The value guard (equal, or heading as a leading line)
    means non-duplicates — subtitles, column headers with different text, body —
    are left untouched, and adornments/components/variant_ids are never modified
    (only component `fills` values). Mechanical + deterministic; keep byte-identical
    with the vendored copy in the other skill so per-slide seeds stay equal to the
    assembled slide_plan.json."""
    for b in blocks or []:
        if not b.get("adornment_id"):
            continue
        heading = next(
            (f.get("value", "").strip()
             for f in (b.get("adornment_fills") or [])
             if f.get("slot") == "title" and (f.get("value") or "").strip()),
            "",
        )
        if not heading:
            continue
        for c in b.get("components") or []:
            fills = c.get("fills")
            if not fills:
                continue
            kept: list[dict[str, Any]] = []
            for f in fills:
                headline = _is_headline_slot(f.get("slot") or "")
                v = (f.get("value") or "").strip()
                if headline and v == heading:
                    continue  # pure duplicate of the adornment heading → drop
                if headline and v.startswith(heading) and v[len(heading):len(heading) + 1] == "\n":
                    rest = v[len(heading):].lstrip("\n").strip()
                    if rest:
                        kept.append({**f, "value": rest})
                    continue
                kept.append(f)
            c["fills"] = kept
    return blocks


def record_to_slide(rec: dict[str, Any]) -> dict[str, Any]:
    """Build the artifact Slide dict from a DECISION record, merging the agent's
    top-level proposal_body into layout_fills (audit §5/§6)."""
    layout_fills = list(rec.get("layout_fills") or [])
    pb = (rec.get("proposal_body") or "").strip() if isinstance(rec.get("proposal_body"), str) else ""
    if pb and not any(f.get("slot") == "proposal_body" for f in layout_fills):
        layout_fills.append({"slot": "proposal_body", "value": pb})
    return {
        "slide_number": None,
        "source": rec.get("source", "section"),
        "subtitle": rec.get("subtitle", ""),
        "section_id": rec.get("section_id"),
        "intent_id": rec.get("intent_id"),
        "layout_id": rec.get("layout_id"),
        "layout_fills": layout_fills,
        "blocks": _dedup_block_headings(rec.get("blocks") or []),
    }


# ── Pre-validation slot-name helpers (dict-based) ────────────────────────────
def _layout_placeholder_names(catalog: dict[str, Any], layout_id: str) -> set[str]:
    for layout in catalog.get("layouts", []):
        if layout.get("id") == layout_id:
            return {p["name"] for p in (layout.get("placeholders") or []) if p.get("name")}
    return set()


def _variant_slot_names(catalog: dict[str, Any], vid: str) -> set[str]:
    for v in catalog.get("variants", []):
        if v.get("id") == vid:
            names: set[str] = set()
            for s in v.get("slots", []):
                if s.get("name"):
                    names.add(s["name"])
                for sub in (s.get("subslots") or []):
                    if sub.get("name"):
                        names.add(sub["name"])
            return names
    return set()


def _adornment_slot_names(catalog: dict[str, Any], aid: str) -> set[str]:
    for a in catalog.get("adornments", []):
        if a.get("id") == aid:
            return {s["name"] for s in (a.get("slots") or []) if s.get("name")}
    return set()


def validate_slide(slide: dict[str, Any], catalog: dict[str, Any]) -> list[str]:
    """Referential integrity of one slide's plan against the catalog (existence of
    intent/layout/variant/adornment ids + every fill slot). None intent/layout
    (a floor slide) is not an error — it's the explicit fallback signal."""
    issues: list[str] = []
    intent_ids = {i.get("id") for i in catalog.get("intents", [])}
    layout_ids = {layout.get("id") for layout in catalog.get("layouts", [])}
    variant_ids = {v.get("id") for v in catalog.get("variants", [])}
    adornment_ids = {a.get("id") for a in catalog.get("adornments", [])}

    intent_id = slide.get("intent_id")
    layout_id = slide.get("layout_id")
    if intent_id is not None and intent_id not in intent_ids:
        issues.append(f"missing intent_id: {intent_id}")
    if layout_id is not None:
        if layout_id not in layout_ids:
            issues.append(f"missing layout_id: {layout_id}")
        else:
            ph_names = _layout_placeholder_names(catalog, layout_id)
            for f in slide.get("layout_fills", []) or []:
                if f.get("slot") not in ph_names:
                    issues.append(f"{layout_id}.layout_fills missing slot: {f.get('slot')}")
    for b in slide.get("blocks", []) or []:
        aid = b.get("adornment_id")
        if aid:
            if aid not in adornment_ids:
                issues.append(f"missing adornment_id: {aid}")
            else:
                ad_names = _adornment_slot_names(catalog, aid)
                for f in b.get("adornment_fills", []) or []:
                    if f.get("slot") not in ad_names:
                        issues.append(f"{aid}.adornment_fills missing slot: {f.get('slot')}")
        for c in b.get("components", []) or []:
            vid = c.get("variant_id")
            if vid not in variant_ids:
                issues.append(f"missing variant_id: {vid}")
                continue
            names = _variant_slot_names(catalog, vid)
            for f in c.get("fills", []) or []:
                if f.get("slot") not in names:
                    issues.append(f"{vid}.fills missing slot: {f.get('slot')}")
            for rf in c.get("repeating_fills", []) or []:
                if rf.get("slot") not in names:
                    issues.append(f"{vid}.repeating_fills missing slot: {rf.get('slot')}")
    return issues


# ── allowed-list (mirrors validate-artifacts.mjs) ──────────────────
def _allowed_sets(catalog: dict[str, Any]) -> tuple[dict[str, set[str]], set[str]]:
    """(intent_id → allowed_variant_ids set, catalog fallback pool set)."""
    allowed_by_intent = {
        i.get("id"): set(i.get("allowed_variant_ids") or [])
        for i in catalog.get("intents", [])
    }
    pool = {v.get("id") for v in catalog.get("variants", []) if v.get("is_fallback")}
    return allowed_by_intent, pool


def allowed_list_violations(
    slide: dict[str, Any],
    allowed_by_intent: dict[str, set[str]],
    pool: set[str],
) -> list[str]:
    """Every component variant on a NON-floor slide must be in its intent's
    allowed_variant_ids ∪ fallback pool ∪ FALLBACK_VARIANT_ID. Floor slides
    (intent_id None) are exempt. Returns human-readable violations."""
    intent_id = slide.get("intent_id")
    if intent_id is None:
        return []
    out: list[str] = []
    allowed = allowed_by_intent.get(intent_id)
    if allowed is None:
        out.append(f"unknown intent_id '{intent_id}'")
        return out
    for b in slide.get("blocks", []) or []:
        for c in b.get("components", []) or []:
            vid = c.get("variant_id")
            if not vid or vid == FALLBACK_VARIANT_ID:
                continue
            if vid not in allowed and vid not in pool:
                out.append(f"variant '{vid}' not in intent '{intent_id}' allowed ∪ fallback pool")
    return out


# ── Render-side per-slide admission gate ─────────────────────────────────────
def _has_component(slide: dict[str, Any]) -> bool:
    """Whether the slide carries at least one component with a variant_id."""
    return any(
        c.get("variant_id")
        for b in (slide.get("blocks") or [])
        for c in (b.get("components") or [])
    )


def validate_admission(slide: dict[str, Any], catalog: dict[str, Any]) -> None:
    """Per-slide admission gate — the slide-level equivalent of `gate S5 after` /
    Stage-1's whole-plan validation, run as each slide enters S6. In the combined
    S5↔S6 pipeline the whole `slide_plan.json` doesn't exist until the end, so the
    deck-level gate can't run mid-run; this reproduces every per-slide guarantee
    that gate makes (so each slide is validated the moment it's rendered, not only
    at the end):

      - **No empty slide** — every slide (body, floor, front-matter) must carry
        ≥1 component with a `variant_id` (S5's "절대 빈 슬라이드 금지"; mirrors
        `validateSlidePlanVariants` + render's verify_deck structural check).
      - **Allowed-list** — each variant ∈ its intent's allowed_variant_ids ∪
        fallback pool ∪ FALLBACK_VARIANT_ID (floor slides exempt).
      - **Referential integrity** — intent/layout/variant/adornment ids and every
        fill slot exist in the catalog.

    Mid-pipeline we cannot floor a bad slide (no input-slide context — flooring
    stays the end-of-run assemble.py's job), so a NON-floor slide that fails is
    surfaced fail-loud rather than silently degraded. Floor slides (intent_id
    None) are exempt from the allowed-list and their referential issues are
    warn-only, matching assemble.py — but the no-empty check applies to them too.
    The whole-deck `gate S5 after` still runs at the tail as the backstop (it adds
    the deck-level `_meta.catalog_sha256` match this per-slide gate can't make)."""
    if not _has_component(slide):
        raise SystemExit(
            f"assemble_slide: slide {slide.get('slide_number')} is empty "
            "(no component with a variant_id) — fix the S5 record"
        )
    allowed_by_intent, pool = _allowed_sets(catalog)
    violations = allowed_list_violations(slide, allowed_by_intent, pool)
    issues = validate_slide(slide, catalog)
    if slide.get("intent_id") is None:
        for i in issues:
            print(f"warn: floor slide issue (left as-is): {i}", file=sys.stderr)
        return
    hard = violations + issues
    if hard:
        raise SystemExit(
            "assemble_slide: slide failed per-slide validation "
            "(fix the S5 record, not here):\n  " + "\n  ".join(hard)
        )
