"""rendering 공용 데이터 모델 (수동적 데이터 정의만 — 동작/I-O는 없음).

- ``ComposedSlide``/``ComposedDeck``: slide_composer의 합성 결과 (pptx_writer 입력)
- ``PackageReport``: pptx_writer 패키징 결과 리포트

디자인 시스템 로더(``Catalog``)는 파일 I/O·XML 파싱이 본체라 ``catalog.py``에 둔다.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import lxml.etree as ET


@dataclass
class ComposedSlide:
    slide_number: int
    layout_id: str
    sptree: ET._Element                       # 배치된 컴포넌트 그룹들을 담은 spTree
    placed: list[dict] = field(default_factory=list)
    issues: list[str] = field(default_factory=list)
    layout_fills: list[dict] = field(default_factory=list)   # 슬라이드 placeholder fills — pptx_writer가 패키징 시 layout ph에 주입
    image_placeholders: list[dict] = field(default_factory=list)   # image 슬롯 → 사용자-삽입 picture placeholder 메타({idx, rect, desc}). 리포트/디버깅용(pptx_writer는 spTree를 직접 스캔)


@dataclass
class ComposedDeck:
    slides: list[ComposedSlide] = field(default_factory=list)
    master_fills: list[dict] = field(default_factory=list)   # 덱 master fills — pptx_writer가 패키징 시 master ph에 주입


@dataclass
class PackageReport:
    slide_count: int = 0
    layouts_used: list[int] = field(default_factory=list)
    media_kept: int = 0
    media_embedded: int = 0       # 본문 도형이 참조하는 아이콘 미디어를 ppt/media로 re-home한 관계 수
    injected: int = 0
    layouts_cloned: int = 0       # image placeholder 백업용으로 복제한 slideLayout 수
    pic_backups: int = 0          # 레이아웃에 백업한 picture placeholder 수
    skipped: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
