"""Phase 1 plan.json → 합성 슬라이드 (Phase 2 공급 어댑터 골격, substrate B).

이 모듈은 **변형 로직을 만들지 않는다.** resize는 `component_resizer`, 배치는
`group_placer.wrap_and_place`를 그대로 쓴다(둘 다 catalog 원자 위에서 성능 유지 실증됨).
여기서 새로 하는 일은 **공급단**뿐:

    plan.json 읽기(+무결성 검증) → catalog variant `shapes.xml`(원자) instantiate
      → fills 주입(text/richtext/composite) → repeated resize → layout.content_box에
      furniture-aware 배치(블록 위→아래 stack)

경계(아직 미구현, 명시 TODO):
  - image fills(pic 교체), nested repeated, table fills(repeating→셀), richtext 다중 run.
  이들은 골격의 훅 지점에 TODO로 표시했고, 채우면 단계적으로 완성된다.
  (adornment 주입·resize·content_box 배치는 구현됨. chrome 상속 + layout/master
   placeholder 주입은 pptx_writer.write_deck_pptx가 패키징 단계에서 수행.)

용어/구조 = Notion "Phase1 Component·Slot Filling Output" + catalog.json.
"""
from __future__ import annotations

import copy
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import lxml.etree as ET

from . import group_placer as GP
from . import component_resizer as CR
from .catalog import Catalog
from .models import ComposedDeck, ComposedSlide
from .ooxml import A_NS, P_NS, _sptree, _max_cnvpr_id, tag_media_embeds

_BODY_TAGS = ("sp", "grpSp", "pic", "graphicFrame")
_GAP_EMU = 120000          # 블록 사이 세로 간격
_FURNITURE_PAD = 30000     # furniture 아래로 내릴 때 여유

logger = logging.getLogger(__name__)


# ───────────────────────── plan 읽기·검증 (A1·A13) ─────────────────────────
def read_plan(path: str | Path) -> dict:
    return json.loads(Path(path).read_text())


def validate_plan(plan: dict, cat: Catalog) -> list[str]:
    """참조 무결성 — output의 모든 ID가 catalog 안에 존재하는지(spec §5.2)."""
    errs: list[str] = []
    if plan.get("intent_id") not in cat.intents:
        errs.append(f"missing intent_id: {plan.get('intent_id')}")
    lid = plan.get("layout_id")
    if lid not in cat.layouts:
        errs.append(f"missing layout_id: {lid}")
    else:                                            # layout_fills slot 검증(adornment_fills와 대칭)
        ph_names = {p["name"] for p in (cat.layouts[lid].get("placeholders") or []) if p.get("name")}
        for f in (plan.get("layout_fills") or []):
            if f.get("slot") not in ph_names:
                errs.append(f"{lid}.layout_fills missing slot: {f.get('slot')}")
    for b in plan.get("blocks", []):
        aid = b.get("adornment_id")
        if aid and aid not in cat.adornments:
            errs.append(f"missing adornment_id: {aid}")
        elif aid:
            ad_names = {s["name"] for s in cat.adornment_slots(aid)}
            for f in (b.get("adornment_fills") or []):
                if f.get("slot") not in ad_names:
                    errs.append(f"{aid}.adornment_fills missing slot: {f.get('slot')}")
        for c in b.get("components", []):
            vid = c.get("variant_id")
            if vid not in cat.variants:
                errs.append(f"missing variant_id: {vid}")
                continue
            names = {s["name"] for s in cat.slots(vid)}
            for f in (c.get("fills") or []):
                if f.get("slot") not in names:
                    errs.append(f"{vid}.fills missing slot: {f.get('slot')}")
            for rf in (c.get("repeating_fills") or []):
                if rf.get("slot") not in names:
                    errs.append(f"{vid}.repeating_fills missing slot: {rf.get('slot')}")
    return errs


# ───────────────────────── 공통 헬퍼 ─────────────────────────
def _body(sptree: ET._Element) -> list[ET._Element]:
    return [c for c in sptree if ET.QName(c).localname in _BODY_TAGS]


def _texts(el: ET._Element) -> list[ET._Element]:
    return el.findall(f".//{{{A_NS}}}t")


def _fit_paras(shape: ET._Element, n: int) -> list[ET._Element]:
    """컨테이너 txBody의 a:p 문단 수를 n에 맞춘다(repeated 단위 = 문단).
    grow는 **마지막 문단을 deepcopy**(번호/불릿/서식 유지)해 뒤에 잇고, 초과분은 뒤에서 제거.
    문단이 0개거나 n<=0이면 손대지 않고 현재 문단을 반환(주입 없음 → blank가 처리)."""
    txs = shape.xpath(".//*[local-name()='txBody']")
    paras = txs[0].findall(f"{{{A_NS}}}p") if txs else []
    if not paras or n <= 0:
        return paras
    tx = txs[0]
    while len(paras) < n:
        clone = copy.deepcopy(paras[-1])
        paras[-1].addnext(clone)
        paras.append(clone)
    while len(paras) > n:
        tx.remove(paras.pop())
    return paras


def _set_nth(el: ET._Element, n: int, text: str, touched: set | None = None) -> bool:
    ts = _texts(el)
    if 1 <= n <= len(ts):
        ts[n - 1].text = text
        if touched is not None:
            touched.add(ts[n - 1])
        return True
    return False


def _set_text(el: ET._Element, text: str, touched: set | None = None) -> bool:
    """단일 text 슬롯 주입: 실제 텍스트가 든 첫 run을 교체하고 **나머지 텍스트 run은 비운다**
    (빈 첫 run에 써서 도너 텍스트가 다른 run에 남는 문제 방지). run이 다 비었으면 첫 run에.
    touched가 주어지면 값을 채운 run을 기록(blank_unfilled가 미충전 run만 골라 비우는 근거)."""
    ts = _texts(el)
    if not ts:
        return False
    nonempty = [t for t in ts if (t.text or "").strip()]
    tgt = nonempty[0] if nonempty else ts[0]
    tgt.text = text
    if touched is not None:
        touched.add(tgt)
    for t in ts:
        if t is not tgt and (t.text or "").strip():
            t.text = ""
    return True


def _bbox(body: list[ET._Element]) -> tuple[int, int, int, int]:
    xs, ys, xe, ye = [], [], [], []
    for e in body:
        o, x = GP._get_off(e), GP._get_ext(e)
        if o:
            xs.append(o[0]); ys.append(o[1])
            if x:
                xe.append(o[0] + x[0]); ye.append(o[1] + x[1])
    if not xs or not xe or not ye:               # offset만 있고 extent 없는(불완전) 도형 방어
        return (0, 0, 0, 0)
    return (min(xs), min(ys), max(xe) - min(xs), max(ye) - min(ys))


# ───────────────────────── fills 주입 (A2·A8) ─────────────────────────
def _merge_rows(rows: list):
    """PATCH(render-proposal-deck): shape_ids 단위는 개수가 고정이라 카드를 기계적으로 늘리지
    않는다(contrl resize_component의 nested-group 좌표 손상 회피). 단위 수를 넘는 행은 잘리지 않게
    마지막 단위에 무손실 병합한다 — fit 에이전트가 시각적으로 카드를 늘리거나 정리한다.
    dict 행 → 같은 subslot 값들을 줄바꿈 결합; str 행 → 줄바꿈 결합."""
    if rows and all(isinstance(r, dict) for r in rows):
        keys: list = []
        for r in rows:
            for k in r:
                if k not in keys:
                    keys.append(k)
        return {k: "\n".join(str(r[k]) for r in rows if r.get(k) is not None) for k in keys}
    if rows and all(isinstance(r, str) for r in rows):
        return "\n".join(rows)
    return "\n".join(str(r) for r in rows)


def _inject_slot(slot: dict, value, idm: dict, anchor, stat: dict, touched: set | None = None, row_index: int | None = None) -> None:
    """slot 1개에 value를 도형에 연결·주입(재귀). **값 타입 우선 디스패치**라 catalog kind와
    값이 어긋나도(예: richtext로 선언됐는데 dict가 옴 — Phase1 데이터 흔들림) 구조로 연결한다:
      dict  → composite(subslot 재귀)      list → repeated/table(단위별 재귀)
      str   → 단일 텍스트(shape_id/a_t_xpath/group)
    anchor = a_t_xpath/group의 기준 element. 연결 못 하면 stat['skipped']에 사유 남김(크래시 X).
    touched = 값을 실제로 채운 a:t를 모으는 set(blank_unfilled가 미충전 run만 비우는 근거)."""
    if slot is None or value is None:
        return
    tgt = slot.get("target") or {}
    name = slot.get("name", "?")
    subs = slot.get("subslots") or []

    if isinstance(value, dict):                              # composite — subslot 묶음
        if not subs:
            stat["skipped"].append(f"{name}:dict value has no subslots"); return
        sub_anchor = idm.get(str(tgt.get("shape_id"))) if tgt.get("shape_id") else anchor
        sub_by = {s.get("name"): s for s in subs}
        for k, v in value.items():
            if k in sub_by:
                _inject_slot(sub_by[k], v, idm, sub_anchor, stat, touched)
            else:
                stat["skipped"].append(f"{name}.{k}:missing subslot")

    elif isinstance(value, list):                            # repeated/table — 행들
        if tgt.get("shape_ids"):                              # 단위 = 도형들
            units = [idm[str(s)] for s in tgt["shape_ids"] if str(s) in idm]
        elif tgt.get("a_t_xpath") and anchor is not None:     # 단위 = xpath 매치(bullets 문단 등)
            try:
                units = anchor.xpath(tgt["a_t_xpath"], namespaces={"a": A_NS, "p": P_NS})
            except (ET.XPathError, TypeError, ValueError):        # xpath 문법·인자 오류만 graceful, 시스템 오류는 전파
                units = []
        elif subs and (sid := str(tgt.get("shape_id"))) in idm and (
                (container := idm[sid]).find(f".//{{{A_NS}}}tbl") is None):
            # 단수 컨테이너 도형 1개 + 서브슬롯: 도형 안의 a:p 문단을 반복 단위로(번호/불릿 리스트).
            # 표(a:tbl)는 셀 단위라 여기서 제외 — inject_fills가 _inject_table로 따로 묶어 처리한다.
            units = _fit_paras(container, len(value))
        else:
            units = []
        if not units:
            stat["skipped"].append(f"{name}:no repeated units"); return
        rows = value
        if len(rows) > len(units):                            # PATCH: 카드 기계적 성장 없음 → 초과분 마지막 단위에 무손실 병합
            rows = list(rows[:len(units) - 1]) + [_merge_rows(rows[len(units) - 1:])]
        for i, row in enumerate(rows[:len(units)]):           # 단위가 anchor
            unit = units[i]
            if isinstance(row, dict):                         # Row[] — subslot별
                for sub in subs:
                    _inject_slot(sub, row.get(sub.get("name")), idm, unit, stat, touched, row_index=i)
            elif isinstance(row, (str, list)):                # string[] / 중첩 — 단일 subslot으로
                if len(subs) == 1:
                    _inject_slot(subs[0], row, idm, unit, stat, touched)
                elif isinstance(row, str):
                    ok = _set_text(unit, row, touched); stat["injected"] += int(ok)
                    if not ok:
                        stat["skipped"].append(f"{name}[{i}]")
                else:
                    stat["skipped"].append(f"{name}[{i}]:ambiguous subslot")
            else:
                stat["skipped"].append(f"{name}[{i}]:unsupported type({type(row).__name__})")

    elif isinstance(value, str):                             # 단일 텍스트
        if slot.get("kind") == "image":
            stat["skipped"].append(f"{name}:image slot not implemented (A8)"); return
        if tgt.get("shape_id") and str(tgt["shape_id"]) in idm:
            ok = _set_text(idm[str(tgt["shape_id"])], value, touched)
        elif tgt.get("shape_ids"):
            ids = tgt["shape_ids"]
            if row_index is not None:                        # Row[] 단위 안 — 이 행에 해당하는 도형 1개 (PR contrl#228)
                idx = row_index if row_index < len(ids) else 0
                u = idm.get(str(ids[idx]))
                ok = _set_text(u, value, touched) if u is not None else False
            else:                                            # 최상위 다중 타겟(예: toc_pages) — 줄을 도형들에 1:1 배분
                shapes = [idm.get(str(s)) for s in ids]
                lines = value.split("\n")
                if len(lines) > len(shapes):                 # 도형 수 초과분은 list 경로(_merge_rows)처럼 마지막 도형에 무손실 병합
                    lines = lines[: len(shapes) - 1] + ["\n".join(lines[len(shapes) - 1:])]
                ok = False
                for sh, ln in zip(shapes, lines):
                    if sh is not None:
                        ok = _set_text(sh, ln, touched) or ok
        elif tgt.get("a_t_xpath") and anchor is not None:
            n = _xpath_index(tgt["a_t_xpath"])
            ok = _set_nth(anchor, n, value, touched) if n else _set_text(anchor, value, touched)
        elif tgt.get("group") and anchor is not None:        # adornment 등 그룹 루트 텍스트
            ok = _set_text(anchor, value, touched)
        else:
            ok = False
        stat["injected"] += int(ok)
        if not ok:
            stat["skipped"].append(name)
    else:
        stat["skipped"].append(f"{name}:unsupported value type({type(value).__name__})")


# ───────────────────────── 표(a:tbl) 셀 주입 ─────────────────────────
# 단수 shape_id가 graphicFrame(내부 a:tbl)인 슬롯은 도형/문단 단위가 아니라 셀(a:tc)
# 단위라 _inject_slot의 일반 경로로는 매핑이 안 된다(거기선 '단위없음'으로 skip). 카탈로그에
# 표 슬롯 모델이 **둘** 있어 슬롯 kind로 분기한다:
#   (1) kind="table" 단일 슬롯  — fill의 모든 행(헤더 포함, 보통 row 0)이 표 행에 1:1 매핑.
#       subslot 없이 row dict의 col1..colN(또는 값 순서)을 셀에 위치 매핑. (예: multi-column-data-table-banded)
#   (2) kind="repeated" 헤더/본문 쌍 — cardinality.resizable로 헤더/본문을 가른다:
#       resizable:false = 헤더(row 0의 가시 셀에 값 평탄화 매핑, gridSpan/hMerge 구조 보존)
#       resizable:true  = 본문(row 1+; 한 fill row = 한 a:tr, subslot = 행의 가시 셀) (예: two-axis-grouped-risk-response-table)
# 본문은 fill row 수에 맞춰 a:tr을 clone/삭제하고 병합(rowSpan/vMerge)을 정리한다.
def _tbl_of(shape: ET._Element | None) -> ET._Element | None:
    return shape.find(f".//{{{A_NS}}}tbl") if shape is not None else None


def _row_cells(tr: ET._Element) -> list[ET._Element]:
    return tr.findall(f"{{{A_NS}}}tc")


def _visible_cells(tr: ET._Element) -> list[ET._Element]:
    """병합 연속 셀(hMerge/vMerge)을 뺀, 화면에 보이는 a:tc만 문서 순서로."""
    return [tc for tc in _row_cells(tr) if not tc.get("hMerge") and not tc.get("vMerge")]


def _unmerge_cell(tc: ET._Element) -> None:
    """본문 정규화: 셀을 독립·가시 셀로 — 가로/세로 병합 속성 제거(원자 한 행=한 fill row)."""
    for attr in ("hMerge", "vMerge", "gridSpan", "rowSpan"):
        tc.attrib.pop(attr, None)


def _blank_cell(tc: ET._Element) -> None:
    """셀의 run 텍스트를 모두 비운다(서식·run은 유지). fill이 닿지 않는 가시 셀의 도너 제거용 —
    표 셀은 blank_unfilled(_in_table)의 사정권 밖이라 여기서 직접 정리(CR.blank_text 재사용)."""
    CR.blank_text(tc)


def _set_cell_text(tc: ET._Element, text: str, touched: set | None = None) -> bool:
    """셀 텍스트 주입 — run이 있으면 _set_text(서식 유지), 비었으면 첫 문단에 run 생성.
    빈 셀(병합 해제로 드러난 연속 셀)도 채울 수 있게 한다."""
    if _set_text(tc, text, touched):
        return True
    txb = tc.find(f"{{{A_NS}}}txBody")
    if txb is None:
        return False
    p = txb.find(f"{{{A_NS}}}p")
    if p is None:
        p = ET.SubElement(txb, f"{{{A_NS}}}p")
    t = ET.SubElement(ET.SubElement(p, f"{{{A_NS}}}r"), f"{{{A_NS}}}t")
    t.text = text
    if touched is not None:
        touched.add(t)
    return True


def _map_cells(name: str, values: list, cells: list, stat: dict, touched: set | None) -> None:
    """값 리스트를 가시 셀에 위치 매핑. 값이 셀보다 많으면 초과분은 잘리는데(표 열 수는 고정),
    조용히 사라지지 않게 stat['skipped']에 기록한다(fail-loud)."""
    if len(values) > len(cells):
        stat["skipped"].append(f"{name}:too many columns({len(values)}>{len(cells)})")
    for val, cell in zip(values, cells):
        if val is not None and _set_cell_text(cell, str(val), touched):
            stat["injected"] += 1


def _header_values(slot: dict, items: list) -> list[str]:
    """헤더 한 행에 들어갈 셀 값들을 문서 순서로 평탄화.
    item이 dict면 subslot 순서대로(없으면 값 순서), scalar면 그대로 —
    (3 item × 1 subslot = 3셀)·(1 item × 2 subslot = 2셀) 두 패턴을 모두 커버."""
    sub_names = [s.get("name") for s in (slot.get("subslots") or [])]
    out: list = []
    for item in (items or []):
        if isinstance(item, dict):
            out += [item.get(n) for n in sub_names] if sub_names else list(item.values())
        else:
            out.append(item)
    return out


def _ordered_col_values(row: dict) -> list:
    """subslot 없는 표 행 dict → 셀 순서 값 리스트. col1..colN처럼 키 끝 숫자가 모두 고유하면
    숫자순(col2 < col10) 정렬, 아니면 입력(JSON) 순서 유지."""
    keys = list(row.keys())
    nums = ["".join(c for c in k if c.isdigit()) for k in keys]
    if keys and all(d != "" for d in nums) and len({int(d) for d in nums}) == len(keys):
        keys = [k for _, k in sorted(zip((int(d) for d in nums), keys))]
    return [row[k] for k in keys]


def _row_cell_values(slot: dict, row) -> list:
    """한 fill 행 → 그 행의 셀에 위치 매핑할 값 리스트.
    dict+subslots → subslot 순서, dict(subslot 없음) → col 순서, list → 그대로, str → 단일."""
    if isinstance(row, dict):
        subs = slot.get("subslots") or []
        return [row.get(s.get("name")) for s in subs] if subs else _ordered_col_values(row)
    if isinstance(row, list):
        return row
    if isinstance(row, str):
        return [row]
    return []


def _fill_body_rows(tbl: ET._Element, header_rows: int, slot: dict,
                    fill_rows: list, stat: dict, touched: set | None) -> None:
    """본문 — header_rows 이후 a:tr을 fill row 수 N으로 rebuild하고 행값(subslot/col 순서)을 가시 셀에 매핑.
    가시 셀이 가장 많은 본문 행을 스타일 템플릿으로 골라 병합 해제 후 N번 복제한다(병합/빈 연속 셀 회피).
    각 새 행은 템플릿 행 높이를 그대로 물려받고(행 수↓ → 표↓, 행 수↑ → 표↑), 프레임 ext는
    _fit_frame_to_table이 표 높이에 맞춰 재조정한다(렌더러가 필요 시 셀 높이 자동 grow)."""
    name = slot.get("name", "?")
    all_trs = tbl.findall(f"{{{A_NS}}}tr")
    header_trs, body_trs = all_trs[:header_rows], all_trs[header_rows:]
    if not body_trs:
        stat["skipped"].append(f"{name}:no body rows"); return
    if not fill_rows:
        stat["skipped"].append(f"{name}:no fill rows"); return
    template = copy.deepcopy(max(body_trs, key=lambda tr: len(_visible_cells(tr))))
    for tc in _row_cells(template):
        _unmerge_cell(tc)
        _blank_cell(tc)              # 도너 비우기 — subslot보다 열이 많아도 남은 셀에 원문이 새지 않게(H1)
    # 삽입 기준점은 본문 제거 후에도 트리에 남는 요소여야 한다(헤더 마지막 행 또는 tblGrid).
    anchor = header_trs[-1] if header_trs else tbl.find(f"{{{A_NS}}}tblGrid")
    for tr in body_trs:
        tbl.remove(tr)
    new_trs: list[ET._Element] = []
    for row in fill_rows:
        nr = copy.deepcopy(template)
        values = _row_cell_values(slot, row)
        if not values:
            stat["skipped"].append(f"{name}:unsupported row type({type(row).__name__})")
        _map_cells(name, values, _visible_cells(nr), stat, touched)   # subslot/col 순서대로 가시 셀에
        new_trs.append(nr)
    prev = anchor                                        # 헤더 뒤(없으면 tblGrid 뒤·둘 다 없으면 끝)에 순서대로 삽입
    for nr in new_trs:
        if prev is not None:
            prev.addnext(nr)
        else:
            tbl.append(nr)
        prev = nr


def _fit_frame_to_table(container: ET._Element, tbl: ET._Element) -> None:
    """graphicFrame ext.cy를 표 전체 행 높이 합에 맞춘다 — 행 수가 줄면 프레임도 짧아져야
    아래 블록이 밀리지 않는다(예: 12행 템플릿 → 5행이면 프레임이 12행 높이를 차지하면 안 됨)."""
    total = sum(int(tr.get("h") or 0) for tr in tbl.findall(f"{{{A_NS}}}tr"))
    if total > 0:
        CR.set_ext(container, cy=total)


def _fill_full_table(tbl: ET._Element, slot: dict, fill_rows: list, stat: dict, touched: set | None) -> None:
    """kind="table" 단일 슬롯 — fill의 모든 행이 표 행에 1:1. row 0=헤더(convention)는 in-place로
    채워 헤더 스타일(짙은 행 등) 보존, row 1+는 본문으로 rebuild. 행값은 col 순서로 셀에 매핑."""
    name = slot.get("name", "?")
    if not fill_rows:
        stat["skipped"].append(f"{name}:no fill rows"); return
    all_trs = tbl.findall(f"{{{A_NS}}}tr")
    if not all_trs:
        stat["skipped"].append(f"{name}:no rows"); return
    hvals = _row_cell_values(slot, fill_rows[0])             # 헤더 행(in-place, 스타일 보존)
    hcells = _visible_cells(all_trs[0])
    _map_cells(name, hvals, hcells, stat, touched)
    for cell in hcells[len(hvals):]:
        _blank_cell(cell)
    if len(fill_rows) > 1:                                   # 본문 = 나머지 fill 행
        _fill_body_rows(tbl, 1, slot, fill_rows[1:], stat, touched)
    else:                                                    # 헤더만 — 본문 도너 행 제거
        for tr in all_trs[1:]:
            tbl.remove(tr)


def _inject_table(container: ET._Element, table_slots: list[dict], fills_map: dict,
                  stat: dict, touched: set | None) -> None:
    """한 표(graphicFrame)를 가리키는 슬롯들을 셀에 주입. 슬롯 kind로 모델 분기:
    kind="table" 단일 슬롯이 있으면 전체-표 모델(_fill_full_table)로 처리하고 끝낸다.
    아니면 헤더/본문 쌍 모델 — header_rows는 **fill 유무가 아니라 catalog 구조**(resizable:false
    슬롯 수)로 정해 헤더 미충전 시에도 정적 헤더 행을 본문 rebuild에서 보호한다."""
    tbl = _tbl_of(container)
    if tbl is None:
        return
    full = [s for s in table_slots if s.get("kind") == "table"]
    if full:
        for slot in full:                                    # 보통 1개
            name = slot.get("name", "?")
            rows = fills_map.get(name)
            if rows is not None:
                _fill_full_table(tbl, slot, rows or [], stat, touched)
            else:
                stat["skipped"].append(f"{name}:missing fill")   # expose unfilled donor text (#6)
        for s in table_slots:                                # 전체-표 모델에선 다른 슬롯 미지원(#5)
            if s.get("kind") != "table":
                stat["skipped"].append(f"{s.get('name','?')}:cannot coexist with kind=table")
        _fit_frame_to_table(container, tbl)
        return
    resizable = lambda s: bool((s.get("cardinality") or {}).get("resizable"))
    header_slots = [s for s in table_slots if not resizable(s)]
    body_slots = [s for s in table_slots if resizable(s)]
    header_rows = len(header_slots)
    trs = tbl.findall(f"{{{A_NS}}}tr")
    for hi, slot in enumerate(header_slots):
        name = slot.get("name", "?")
        items = fills_map.get(name)
        if items is None:
            stat["skipped"].append(f"{name}:missing fill"); continue       # expose unfilled donor text (#6)
        if hi >= len(trs):
            stat["skipped"].append(f"{name}:missing header row"); continue
        cells = _visible_cells(trs[hi])
        values = _header_values(slot, items)
        _map_cells(name, values, cells, stat, touched)
        for cell in cells[len(values):]:           # 값이 없는 잉여 헤더 셀의 도너 제거(H2)
            _blank_cell(cell)
    done_body = False                              # 한 표의 본문 영역은 한 슬롯만 rebuild 가능 — 둘째부터는 데이터 유실 방지로 skip(C1)
    for slot in body_slots:
        name = slot.get("name", "?")
        rows = fills_map.get(name)
        if rows is None:
            stat["skipped"].append(f"{name}:missing fill"); continue       # expose unfilled donor text (#6)
        if done_body:
            stat["skipped"].append(f"{name}:multiple body slots in one table not supported"); continue
        _fill_body_rows(tbl, header_rows, slot, rows or [], stat, touched)
        done_body = True
    _fit_frame_to_table(container, tbl)


def inject_fills(root: ET._Element, slots: list[dict], fills: list[dict],
                 repeating_fills: list[dict] | None = None) -> dict:
    """plan의 fills(단일) + repeating_fills(반복)를 catalog target으로 도형에 재귀 주입.
    text/richtext=str · composite=dict(subslot 재귀) · repeated/table=rows(단위별 재귀).
    표(a:tbl)를 가리키는 repeated 슬롯은 셀 단위라 _inject_table로 묶어 처리(헤더/본문 분리).
    TODO(A8): kind=image 그림 교체 미구현."""
    idm = CR.shape_id_map(root)
    by_name = {s["name"]: s for s in slots}
    touched: set = set()
    stat = {"injected": 0, "skipped": []}
    for f in (fills or []):
        slot = by_name.get(f.get("slot"))
        if slot is None:
            stat["skipped"].append(f"{f.get('slot')}:missing slot"); continue
        _inject_slot(slot, f.get("value"), idm, root, stat, touched)
    # 표(a:tbl) 컨테이너를 가리키는 슬롯은 catalog 기준으로 미리 묶는다 — header_rows를
    # 구조(헤더 슬롯 수)로 정해야 헤더 미충전 시에도 정적 헤더 행을 본문 rebuild에서 보호한다.
    tbl_slots: dict[str, list[dict]] = {}
    for s in slots:
        if s.get("kind") not in ("repeated", "table"):   # 헤더 행 계산은 표 슬롯만 — 같은 프레임을
            continue                                      # 가리키는 text/composite 슬롯이 헤더로 오인되지 않게
        sid = (s.get("target") or {}).get("shape_id")
        cont = idm.get(str(sid)) if sid is not None else None
        if cont is not None and _tbl_of(cont) is not None:
            tbl_slots.setdefault(str(sid), []).append(s)
    tbl_fills: dict[str, dict] = {}                      # sid → {slot_name: rows}
    for rf in (repeating_fills or []):
        name = rf.get("slot")
        slot = by_name.get(name)
        if slot is None:
            stat["skipped"].append(f"{name}:missing slot"); continue
        sid = str((slot.get("target") or {}).get("shape_id"))
        if sid in tbl_slots:
            tbl_fills.setdefault(sid, {})[name] = rf.get("rows")
        else:
            _inject_slot(slot, rf.get("rows"), idm, root, stat, touched)
    for sid, fills_map in tbl_fills.items():
        _inject_table(idm[sid], tbl_slots[sid], fills_map, stat, touched)
    return {"injected": stat["injected"], "skipped": stat["skipped"], "touched": touched}


def _xpath_index(xp: str) -> int | None:
    """'.//a:t[2]' → 2. 단순 1-based 위치 인덱스만 해석(0·음수는 None — list 역참조 방지)."""
    if "a:t[" in xp:
        try:
            n = int(xp.split("a:t[")[1].split("]")[0])
        except (ValueError, IndexError):
            return None
        return n if n > 0 else None
    return None


# ───────────────────────── repeated resize ─────────────────────────
def resize_component(root: ET._Element, slots: list[dict], repeating_fills: list[dict]) -> list[dict]:
    """PATCH(render-proposal-deck): NO-OP. contrl의 CR.resize_repeated(occurrence shift/drop/reflow)가
    multi-level nested-group 변종(카드/브래킷)의 *그룹 내 자식* 좌표를 슬라이드 좌표계 기준 거리로
    옮겨 도형을 페이지 하단으로 흩뜨리는 버그가 있다(resize on=흩어짐 / off=정상, 실측 확인).
    그래서 기계적 카디널리티 resize를 끈다. 단위 수를 넘는 행은 fill 단계의 _merge_rows가 마지막
    단위에 무손실 병합하고, 카드 개수 조정은 fit 에이전트가 시각적으로 처리한다.
    (표 행 성장은 _fill_body_rows가 별도 담당 — 이 NO-OP의 영향 없음.)"""
    return []


# ───────────────────────── 미충전 slot blank (A13 안전망) ─────────────────────────
def _in_table(t: ET._Element) -> bool:
    """a:t가 표 셀(a:tbl 하위)인지. table(tr/tc)은 blank 범위 밖 — composite가 텍스트 도형+표
    프레임을 함께 target해도(예: body=[text, tbl]) 표 셀 도너는 건드리지 않는다."""
    return bool(t.xpath("ancestor::*[local-name()='tbl']"))


def _grp_by_name(root: ET._Element, name: str) -> ET._Element | None:
    """cNvPr@name == name 인 grpSp(adornment 그룹)를 찾는다."""
    for g in root.iter(f"{{{P_NS}}}grpSp"):
        cn = g.find(f"{{{P_NS}}}nvGrpSpPr/{{{P_NS}}}cNvPr")
        if cn is not None and cn.get("name") == name:
            return g
    return None


def _slot_text_nodes(slot: dict, idm: dict, root: ET._Element) -> list[ET._Element]:
    """slot이 '소유'하는 a:t 목록(읽기 전용). blank_unfilled가 비울 후보의 모집단.
    결정: target 도형 아래의 a:t를 통째로 모은다(선언 안 된 run 포함). 단 표 셀은 제외하고
    image slot은 소유 a:t 없음으로 본다(둘 다 범위 밖).
    subslot은 **부모 도형 하위에 있다는 보장이 없다** — 실데이터 composite엔 부모의 형제
    도형을 target하거나 부모 target이 null인 subslot이 있다. 그래서 자체 shape를 가진
    subslot은 재귀로 합집합한다(부모와 같은 a:t를 가리킬 수 있어 id 기준 dedup).
    a_t_xpath subslot은 부모 도형 _texts에 이미 포함되므로 재귀하지 않는다(앵커=부모라 root
    기준 재해석은 부정확). 어떤 slot target에도 안 걸린 a:t(슬롯 밖 정적 텍스트)는 모집단 밖.
    한계(둘 다 후속): (1) resize가 grow(clone)한 unit은 새 id라 declared shape_ids 밖 → 미커버.
    (2) catalog가 target=null로 둔 (sub)slot 리프(예: module_pair.card_header.title)는 어떤 shape도
    못 가리켜 slot 모델 자체가 주소화 못 함 — inject도 못 채우고 blank도 못 비운다(카탈로그 정비 영역)."""
    if slot.get("kind") == "image":                   # image 범위 밖 — 소유 a:t 없음으로 취급
        return []
    tgt = slot.get("target") or {}
    sid = tgt.get("shape_id"); sids = tgt.get("shape_ids")
    xp = tgt.get("a_t_xpath"); grp = tgt.get("group")
    nodes: list[ET._Element] = []
    if sid is not None and str(sid) in idm:
        nodes += _texts(idm[str(sid)])
    elif sids:
        for s in sids:
            if str(s) in idm:
                nodes += _texts(idm[str(s)])
    elif xp:                                          # top-level a_t_xpath(드묾) — inject 인덱스 의미와 일치
        n = _xpath_index(xp)
        ts = _texts(root)
        if n and 1 <= n <= len(ts):
            nodes.append(ts[n - 1])
        else:
            try:
                nodes += [e for e in root.xpath(xp, namespaces={"a": A_NS, "p": P_NS})
                          if isinstance(e, ET._Element) and ET.QName(e).localname == "t"]
            except (ET.XPathError, TypeError, ValueError):
                pass
    elif grp:                                         # adornment 그룹 — 해당 grpSp 하위만(슬롯 밖 정적 보존)
        g = _grp_by_name(root, grp)
        nodes += _texts(g if g is not None else root)
    for sub in (slot.get("subslots") or []):          # 형제·null부모 subslot까지 도달
        st = sub.get("target") or {}
        # 자체 shape가 있거나(형제 케이스) 구조 컨테이너(target=null인데 더 깊은 shape subslot 보유,
        # 예: framework_band→band_title/columns)면 재귀. a_t_xpath/null 리프는 부모 shape _texts가 커버.
        if st.get("shape_id") is not None or st.get("shape_ids") or sub.get("subslots"):
            nodes += _slot_text_nodes(sub, idm, root)
    seen: set = set(); uniq: list[ET._Element] = []   # id dedup(부모·subslot 중복) + 표 셀 제외(모든 branch 단일 적용)
    for t in nodes:
        if id(t) in seen or _in_table(t):
            continue
        seen.add(id(t)); uniq.append(t)
    return uniq


def blank_unfilled(root: ET._Element, slots: list[dict], touched: set) -> dict:
    """plan이 채우지 않은 slot target run(미충전 a:t)의 도너 텍스트를 비운다(안전망).
    **inject→resize 이후** 호출 — 현재 트리에서 idmap을 재생성하므로 resize가 drop한 도형은
    자동 제외되고, reduce가 이미 비운 run은 빈 문자열이라 무시된다. 채운 run은 touched로 보존.
    geometry는 건드리지 않는다(빈 도형은 남되 텍스트만 사라짐). 반환: {blanked, slots}."""
    idm = CR.shape_id_map(root)
    blanked = 0
    blanked_slots: list[str] = []
    for slot in slots:
        hits = [t for t in _slot_text_nodes(slot, idm, root) if t not in touched and t.text]
        for t in hits:
            t.text = ""
        if hits:
            blanked += len(hits)
            blanked_slots.append(slot.get("name", "?"))
    return {"blanked": blanked, "slots": blanked_slots}


# ───────────────────────── 배치 (A5, furniture-aware) ─────────────────────────
def _rect(r: Any) -> tuple[int, int, int, int]:
    if isinstance(r, dict):
        return (r["x"], r["y"], r["w"], r["h"])
    return tuple(r)


def _furniture_top(content_box: tuple, furniture: list, top: int) -> int:
    """content_box 상단부에 끼어든 furniture(헤더·페이지번호 등 고정 요소) 아래로 배치 top을 내림.
    소제목 띠는 furniture가 아니라 adornment — block.adornment로 따로 instantiate·배치한다(compose_slide)."""
    cbx, cby, cbw, cbh = content_box
    eff = top
    for f in furniture or []:
        fx, fy, fw, fh = _rect(f.get("rect") or f if isinstance(f, dict) else f)
        x_overlap = not (fx + fw <= cbx or fx >= cbx + cbw)
        if x_overlap and fy < cby + cbh * 0.5 and fy + fh > top:
            eff = max(eff, fy + fh + _FURNITURE_PAD)
    return eff


def place_atom(target_sptree: ET._Element, body: list[ET._Element],
               content_box: tuple, top: int, fit_h: int | None = None) -> tuple[ET._Element, tuple, int]:
    """body(원자 도형들)를 (target_x, top)에 배치(width sacred).
    가로는 **원자의 원본 minx를 보존**(중앙 여백 유지; x_scale=1이면 off.x=chOff.x라
    가로 드리프트 0) — content_box.x로 당기면 원래 중앙정렬을 깨고 좌측 쏠림이 생김.
    너무 넓/높으면 scale-to-fit하고, 축소 시엔 content_box 중앙 정렬. 반환: (grpSp, bbox, 다음 top).
    fit_h: 세로 scale 기준 높이(없으면 content_box 전체 cbh). _compose_pages는 furniture로
    줄어든 **페이지 실제 가용 높이**(bottom-start_top)를 넘겨 cbh-기준 silent overflow를 막는다(CTRL-515)."""
    cbx, cby, cbw, cbh = content_box
    bx, _, w, h = _bbox(body)
    if w <= 0 or h <= 0:                                         # 좌표·크기 불완전 원자 → 빈 배치로 skip(wrap_and_place 크래시 방지)
        return None, (cbx, top, 0, 0), top
    x_scale = min(1.0, cbw / w) if w else 1.0
    fit = cbh if fit_h is None else fit_h
    y_scale = min(1.0, fit / h) if h else 1.0                   # 가용 높이 기준 — 자투리 짓누름 방지 + furniture 반영(CTRL-515)
    pw = int(w * x_scale)
    target_x = bx if w <= cbw else cbx + (cbw - pw) // 2         # 맞으면 원본 minx 보존 / 넘치면 중앙
    target_x = max(cbx, min(target_x, cbx + cbw - pw))           # content_box 밖이면 클램프
    grp, (pw, ph) = GP.wrap_and_place(target_sptree, body, target_x, top,
                                      x_scale=x_scale, y_scale=y_scale)
    return grp, (target_x, top, pw, ph), top + ph + _GAP_EMU


# ─────────────────── image 슬롯 → 사용자-삽입 picture placeholder ───────────────────
_IMG_LN_COLOR = "C15F3C"


def _build_pic_placeholder(box, desc: str, ph_idx: int, cnvpr_id: int) -> ET._Element:
    """빈 picture placeholder <p:sp>. **반드시 비어 있어야**(내용·fill 없음) 앱의 이미지 삽입
    버튼이 동작. description은 화면이 아니라 cNvPr@descr/@name(alt-text)에 넣고, 점선 ln으로
    '이미지 자리'를 표시. pptx_writer가 슬라이드 레이아웃에 동일 idx pic ph를 백업해
    Keynote/PowerPoint에서도 삽입이 살아난다(Google은 백업 없이도 동작)."""
    x, y, cx, cy = box
    d = (desc or "").strip() or "Image"
    P, A = f"{{{P_NS}}}", f"{{{A_NS}}}"
    sp = ET.Element(f"{P}sp")
    nv = ET.SubElement(sp, f"{P}nvSpPr")
    cn = ET.SubElement(nv, f"{P}cNvPr")
    cn.set("id", str(cnvpr_id)); cn.set("name", f"Image: {d}"); cn.set("descr", f"{d} - Insert image")
    ET.SubElement(ET.SubElement(nv, f"{P}cNvSpPr"), f"{A}spLocks").set("noGrp", "1")
    ph = ET.SubElement(ET.SubElement(nv, f"{P}nvPr"), f"{P}ph")
    ph.set("type", "pic"); ph.set("idx", str(ph_idx))
    spPr = ET.SubElement(sp, f"{P}spPr")
    xf = ET.SubElement(spPr, f"{A}xfrm")
    o = ET.SubElement(xf, f"{A}off"); o.set("x", str(int(x))); o.set("y", str(int(y)))
    e = ET.SubElement(xf, f"{A}ext"); e.set("cx", str(int(cx))); e.set("cy", str(int(cy)))
    g = ET.SubElement(spPr, f"{A}prstGeom"); g.set("prst", "rect"); ET.SubElement(g, f"{A}avLst")
    ln = ET.SubElement(spPr, f"{A}ln"); ln.set("w", "19050")
    ET.SubElement(ET.SubElement(ln, f"{A}solidFill"), f"{A}srgbClr").set("val", _IMG_LN_COLOR)
    ET.SubElement(ln, f"{A}prstDash").set("val", "dash")
    tx = ET.SubElement(sp, f"{P}txBody")
    ET.SubElement(tx, f"{A}bodyPr"); ET.SubElement(tx, f"{A}lstStyle"); ET.SubElement(tx, f"{A}p")
    return sp


def _image_slots(slots: list[dict], fills: list[dict]) -> list[tuple[dict, str]]:
    """variant의 모든 image 슬롯 → (slot, description). description은 **카탈로그 슬롯 정의**에서
    가져온다(Phase 0 추출 — 예 "인증서 스캔". slot_mapping 프롬프트는 image fill에 value=""만 싣고
    description을 싣지 않으므로). 슬롯에 없으면 fill의 description(있으면), 그것도 없으면 ''.
    (fill 유무와 무관하게 모든 image 슬롯을 처리해 donor pic의 dangling을 남김없이 해소.)"""
    fill_desc = {f.get("slot"): f.get("description") for f in (fills or [])}
    out = []
    for s in slots:
        if s.get("kind") == "image":
            out.append((s, s.get("description") or fill_desc.get(s.get("name")) or ""))
    return out


def _find_donor_pic(scope: ET._Element, slot: dict) -> ET._Element | None:
    """slot.target.shape_id로 donor <p:pic>를 scope(배치된 wrap group) 안에서 찾는다.
    pic이 아닌 도형(target 오지정 등)은 None — drop_shape가 엉뚱한 sp/grpSp subtree를 지우지 않게."""
    sid = (slot.get("target") or {}).get("shape_id")
    if sid is None:
        return None
    el = CR.shape_id_map(scope).get(str(sid))
    return el if (el is not None and ET.QName(el).localname == "pic") else None


def _group_chain(donor: ET._Element, top_grp: ET._Element) -> list[ET._Element]:
    """donor에서 top_grp(포함)까지의 ancestor grpSp들을 inner→outer로 모은다."""
    chain, cur = [], donor.getparent()
    while cur is not None:
        if ET.QName(cur).localname == "grpSp":
            chain.append(cur)
        if cur is top_grp:
            break
        cur = cur.getparent()
    return chain


def _emit_image_placeholders(target: ET._Element, grp: ET._Element | None,
                             slots: list[dict], fills: list[dict], state: dict) -> list[dict]:
    """grp(배치된 wrap group) 안의 image donor pic을 top-level 빈 picture placeholder로 교체.
    donor 제거(r:embed dangling 해소) + 그룹 변환 역산한 절대좌표에 placeholder를 wrap grp의
    **형제**(슬라이드 top-level)로 append. 반환: [{idx, rect, desc}]."""
    out: list[dict] = []
    if grp is None:
        return out
    for slot, desc in _image_slots(slots, fills):
        donor = _find_donor_pic(grp, slot)
        if donor is None:                          # pic 아님 / 이미지 없는 variant / shape_id 불일치
            continue
        local = CR.get_box(donor)
        if local is None:                          # 좌표 불완전 → graceful skip
            continue
        chain = _group_chain(donor, grp)
        rect = GP.child_abs_box(local, chain)
        idx = state["idx"]; state["idx"] += 1
        target.append(_build_pic_placeholder(rect, desc, idx, _max_cnvpr_id(target) + 1))
        CR.drop_shape(donor)
        meta = {"idx": idx, "rect": rect, "desc": desc}
        if any(GP.group_has_flip_rot(g) for g in chain):   # child_abs_box가 rot/flip 미반영 → 근사 표시
            meta["approx"] = True
        out.append(meta)
    return out


# ───────────────────────── compose (overflow 페이지네이션 포함) ─────────────────────────
def _new_sptree() -> ET._Element:
    return ET.SubElement(ET.Element(f"{{{P_NS}}}placeholder"), f"{{{P_NS}}}spTree")


@dataclass
class _PreparedAtom:
    """배치 전 합성·측정된 한 원자(adornment 또는 component). nat_h로 페이지 적합을 판정한 뒤
    _place_prepared가 실제 배치한다 — 측정·배치 분리라 overflow를 짓누르지 않고 미리 안다."""
    body: list                       # target으로 옮길 도형들(deepcopy됨, 아직 미부착)
    nat_h: int                       # 자연(scale=1) bbox 높이
    meta: dict                       # placed 기록용(bbox는 배치 시 채움)
    slots: list                      # image placeholder emit용(component만)
    fills: list
    is_adornment: bool


def _prepare_adornment(aid: str, ad_fills: list, cat: Catalog) -> _PreparedAtom:
    ad_root = copy.deepcopy(cat.adornment_root(aid))
    tag_media_embeds(ad_root, cat.adornment_rels(aid))   # embedded icons → DSMEDIA sentinel (pptx_writer re-homes)
    ad_slots = cat.adornment_slots(aid)
    inj = inject_fills(ad_root, ad_slots, ad_fills or [])
    blanked = blank_unfilled(ad_root, ad_slots, inj["touched"])   # 이동 전(idmap=ad_root)
    body = list(_body(_sptree(ad_root)))
    return _PreparedAtom(body, _bbox(body)[3],
                         {"adornment": aid, "injected": inj["injected"], "blanked": blanked},
                         [], [], True)


def _prepare_component(c: dict, cat: Catalog) -> _PreparedAtom | None:
    vid = c.get("variant_id")
    if vid not in cat.variants:
        return None
    root = copy.deepcopy(cat.variant_root(vid))
    tag_media_embeds(root, cat.variant_rels(vid))   # embedded icons → DSMEDIA sentinel (pptx_writer re-homes)
    slots = cat.slots(vid)
    fills = c.get("fills") or []
    rfills = c.get("repeating_fills") or []
    inj = inject_fills(root, slots, fills, rfills)
    rez = resize_component(root, slots, rfills)
    blanked = blank_unfilled(root, slots, inj["touched"])   # resize 이후: 미충전 도너 제거
    body = list(_body(_sptree(root)))
    return _PreparedAtom(body, _bbox(body)[3],
                         {"variant_id": vid, "injected": inj["injected"],
                          "resizes": rez, "blanked": blanked},
                         slots, fills, False)


def _block_to_units(b: dict, cat: Catalog) -> list[_PreparedAtom]:
    """블록(adornment? + components)을 합성·측정된 원자 순서로. adornment 있으면 맨 앞(A4: 소제목 띠)."""
    units: list[_PreparedAtom] = []
    aid = b.get("adornment_id")
    if aid and aid in cat.adornments:
        units.append(_prepare_adornment(aid, b.get("adornment_fills") or [], cat))
    for c in b.get("components", []):
        pa = _prepare_component(c, cat)
        if pa is not None:
            units.append(pa)
    return units


def _place_prepared(pa: _PreparedAtom, target: ET._Element, content_box: tuple,
                    cur_top: int, img_state: dict, fit_h: int | None = None) -> tuple[int, dict, list[dict]]:
    """측정된 원자를 target spTree에 실제 배치. 반환: (next_top, placed_entry, image_metas)."""
    for e in pa.body:
        target.append(e)
    grp, bbox, next_top = place_atom(target, pa.body, content_box, cur_top, fit_h)
    entry = dict(pa.meta)
    entry["bbox"] = bbox
    imgs: list[dict] = []
    if not pa.is_adornment:
        imgs = _emit_image_placeholders(target, grp, pa.slots, pa.fills, img_state)
        entry["image_placeholders"] = imgs
    return next_top, entry, imgs


@dataclass
class _Page:
    """합성 중인 한 물리 슬라이드의 누적 상태."""
    start_top: int
    target: ET._Element = field(default_factory=_new_sptree)
    placed: list = field(default_factory=list)
    image_phs: list = field(default_factory=list)
    img_state: dict = field(default_factory=lambda: {"idx": 100})   # ph idx(카탈로그 ph와 충돌 회피)·페이지별 리셋
    has_content: bool = False
    cur_top: int = 0

    def __post_init__(self) -> None:
        self.cur_top = self.start_top

    def place(self, pa: _PreparedAtom, content_box: tuple, fit_h: int | None = None) -> None:
        nt, entry, imgs = _place_prepared(pa, self.target, content_box, self.cur_top, self.img_state, fit_h)
        self.placed.append(entry)
        self.image_phs.extend(imgs)
        self.cur_top = nt
        self.has_content = True


def _mk_slide(plan: dict, lid, page: _Page, issues: list) -> ComposedSlide:
    return ComposedSlide(slide_number=plan.get("slide_number", 0), layout_id=lid,
                         sptree=page.target, placed=page.placed, issues=issues,
                         layout_fills=plan.get("layout_fills") or [],   # 보존만, 주입 X
                         image_placeholders=page.image_phs)


def _compose_pages(plan: dict, cat: Catalog) -> list[ComposedSlide]:
    """plan 한 장 합성. 블록이 content_box를 넘치면 continuation 슬라이드로 greedy 분할(CTRL-515).
    블록 단위 기본(소제목+컴포넌트 한 묶음 유지). 단일 블록이 슬라이드보다 크면 컴포넌트 단위 fallback
    (adornment는 첫 컴포넌트와 동거해 고아 방지). issues는 첫 페이지에만 둔다."""
    lid = plan.get("layout_id")
    layout = cat.layouts.get(lid, {})
    content_box = _rect(layout.get("content_box") or {"x": 0, "y": 0, "w": 7561250, "h": 10693400})
    furniture = layout.get("furniture", []) or []
    issues = validate_plan(plan, cat)
    cbh = content_box[3]
    bottom = content_box[1] + cbh
    start_top = _furniture_top(content_box, furniture, content_box[1])
    available = max(1, bottom - start_top)             # furniture 아래 페이지 실제 가용 높이(CTRL-515)

    pages: list[ComposedSlide] = []
    page = _Page(start_top)

    def emit() -> None:
        nonlocal page
        pages.append(_mk_slide(plan, lid, page, issues if not pages else []))
        page = _Page(start_top)

    def place_scaled(grp: list[_PreparedAtom]) -> None:
        """grp 합이 가용 높이를 넘으면(빈 페이지에도 안 들어감) 균일 축소해 단독 페이지에 배치.
        gap은 보존하고 원자 높이만 (available-gap)/Σnat_h로 줄여 박스 안에 맞춘다(불가피·CTRL-515)."""
        if page.has_content:
            emit()
        sum_h = sum(u.nat_h for u in grp) or 1
        gap_total = _GAP_EMU * (len(grp) - 1)
        gscale = max(0.01, (available - gap_total) / sum_h)
        logger.warning("CTRL-515: block group exceeds available height; placed at %.2fx scale %s",
                       gscale, [u.meta for u in grp])
        for u in grp:
            page.place(u, content_box, fit_h=int(gscale * u.nat_h))
        emit()

    for b in plan.get("blocks", []):
        units = _block_to_units(b, cat)
        if not units:
            continue
        block_h = sum(u.nat_h for u in units) + _GAP_EMU * (len(units) - 1)
        if block_h <= available:                           # 블록이 빈 슬라이드(가용 높이)에 들어감 → 블록 단위
            if page.has_content and page.cur_top + block_h > bottom:
                emit()                                     # 현 페이지에 안 맞음 → continuation
            for u in units:
                page.place(u, content_box, fit_h=available)
        else:                                              # 거대 블록 → 컴포넌트 단위 fallback
            i = 0
            while i < len(units):
                grp = [units[i]]
                if units[i].is_adornment and i + 1 < len(units):
                    grp.append(units[i + 1])               # 소제목 고아 방지: 첫 컴포넌트와 동거
                grp_h = sum(u.nat_h for u in grp) + _GAP_EMU * (len(grp) - 1)
                if grp_h > available:                      # 빈 페이지에도 안 들어감 → 불가피 균일 축소(단독)
                    place_scaled(grp)
                else:
                    if page.has_content and page.cur_top + grp_h > bottom:
                        emit()
                    for u in grp:
                        page.place(u, content_box, fit_h=available)
                i += len(grp)

    if page.has_content or not pages:                  # 빈 trailing 페이지(solo emit 후) 방지; 전부 비면 1장 보장
        pages.append(_mk_slide(plan, lid, page, issues if not pages else []))
    return pages


def compose_slide(plan: dict, cat: Catalog) -> ComposedSlide:
    """PATCH(render-proposal-deck): plan 한 장 → **단일 슬라이드, 페이지 분할 없음**.
    모든 블록 유닛을 content_box 가용 높이 안에 **균일 scale-to-fit**해서 한 슬라이드에 다 담는다
    (넘치면 비율 축소, 남으면 원본 크기). 미세 배치·빈 공간 채움·recreate는 fit 에이전트 몫.
    contrl의 overflow 페이지네이션(_compose_pages)은 쓰지 않는다 — 1 plan 슬라이드 = 1 물리 슬라이드."""
    lid = plan.get("layout_id")
    layout = cat.layouts.get(lid, {})
    content_box = _rect(layout.get("content_box") or {"x": 0, "y": 0, "w": 7561250, "h": 10693400})
    furniture = layout.get("furniture", []) or []
    issues = validate_plan(plan, cat)
    start_top = _furniture_top(content_box, furniture, content_box[1])
    available = max(1, content_box[1] + content_box[3] - start_top)
    units = [u for b in plan.get("blocks", []) for u in _block_to_units(b, cat)]
    page = _Page(start_top)
    if units:
        gap_total = _GAP_EMU * (len(units) - 1)
        sum_h = sum(u.nat_h for u in units) or 1
        gscale = min(1.0, max(0.01, (available - gap_total) / sum_h))   # 넘칠 때만 축소
        for u in units:
            page.place(u, content_box, fit_h=int(gscale * u.nat_h))
    return _mk_slide(plan, lid, page, issues)


def compose_deck(deck: dict, cat: Catalog) -> ComposedDeck:
    """PATCH(render-proposal-deck): 1 plan 슬라이드 = 1 물리 슬라이드 (overflow 페이지 분할 제거).
    각 plan 슬라이드를 compose_slide로 scale-to-fit해 한 장씩 합성. master_fills 보존만."""
    slides = [compose_slide(s, cat) for s in deck.get("slides", [])]
    for i, cs in enumerate(slides, 1):
        cs.slide_number = i
    return ComposedDeck(slides=slides, master_fills=deck.get("master_fills") or [])
