"""Phase 2 · 컴포넌트 resize + composite로 슬라이드 합성 (Design System 기반, 결정론적).

- ``ooxml``: OOXML 공용 프리미티브 (네임스페이스 URI + spTree 로케이터).
- ``catalog``: 디자인 시스템 로더 (catalog.json + shapes.xml 파싱).
- ``models``: 공용 데이터 모델 (ComposedSlide/Deck, PackageReport).
- ``component_resizer``: 데이터 개수에 맞춘 컴포넌트 동적 resize.
- ``group_placer``: 컴포넌트를 PPTX 네이티브 그룹(grpSp)으로 묶어 배치 (composite).
- ``slide_composer``: plan → instantiate → 값 주입 → resize → content_box 배치 (Phase 2 진입점).
"""
