"""
Target-based slot engine (Phase 2 rendering core).

핸드오프 계약(slots.json explicit target: shape_id / shape_ids / tr_index·tc_index)
기반으로 detection 없이 슬롯을 채우고(fill) 카디널리티를 줄인다(reduce).

개선:
  #1 blank/drop 정책 자동결정 (per-item 고정프레임/connector/배열 기반) + override
  #2 drop 후 re-flow(남은 항목 재중심) + connector(연결선) 동반 제거
  #3 table tr_index 행삭제
순수 XML 연산만 — 렌더는 harness가 담당.
"""
from __future__ import annotations
import copy
from lxml import etree

from .ooxml import A_NS

def _ln(t): return f"*[local-name()='{t}']"

# ── id map / 기하 ──
def shape_id_map(slide_elem):
    m = {}
    for cn in slide_elem.xpath(f".//{_ln('cNvPr')}"):
        anc = cn.xpath("ancestor::*[local-name()='sp' or local-name()='pic' or "
                       "local-name()='graphicFrame' or local-name()='cxnSp' or local-name()='grpSp'][1]")
        if anc: m[cn.get("id")] = anc[0]
    return m

def own_xfrm(shape):
    # sp/pic: spPr/xfrm, grpSp: grpSpPr/xfrm, graphicFrame: 직속 p:xfrm
    for pr in shape.xpath(f"./{_ln('spPr')} | ./{_ln('grpSpPr')}"):
        xf = pr.xpath(f"./{_ln('xfrm')}")
        if xf: return xf[0]
    xf = shape.xpath(f"./{_ln('xfrm')}")          # graphicFrame 직속
    if xf: return xf[0]
    xf = shape.xpath(f"./*/{_ln('xfrm')}")
    return xf[0] if xf else None

def get_box(shape):
    xf = own_xfrm(shape)
    if xf is None: return None
    off = xf.find(f"{{{A_NS}}}off"); ext = xf.find(f"{{{A_NS}}}ext")
    if off is None or ext is None: return None
    return (int(off.get("x")), int(off.get("y")), int(ext.get("cx")), int(ext.get("cy")))

def shift_box(shape, dx=0, dy=0):
    xf = own_xfrm(shape)
    if xf is None: return False
    off = xf.find(f"{{{A_NS}}}off")
    if off is None: return False
    off.set("x", str(int(off.get("x")) + dx)); off.set("y", str(int(off.get("y")) + dy))
    return True

def a_texts(shape): return shape.xpath(f".//{_ln('t')}")
def blank_text(shape):
    ts = a_texts(shape)
    for t in ts: t.text = ""
    return bool(ts)
def drop_shape(shape):
    p = shape.getparent()
    if p is not None: p.remove(shape); return True
    return False

def box_near(b1, b2, tol=130000):
    x1,y1,cx1,cy1=b1; x2,y2,cx2,cy2=b2
    return (x1-tol < x2+cx2 and x2-tol < x1+cx1 and y1-tol < y2+cy2 and y2-tol < y1+cy1)

def fixed_shapes(slots_doc, idmap):
    """slots.json fixed 도형의 (elem, box) 목록."""
    out = []
    for f in slots_doc.get("fixed", []):
        sp = idmap.get(f.get("shape_id"))
        if sp is not None:
            b = get_box(sp)
            if b: out.append((sp, b))
    return out

def separately_framed(units, fixed):
    """각 unit에 대해 **unit 밖(non-descendant)** 고정프레임이 겹치는 수.
    unit 안에 nested된 프레임은 단위의 일부이므로 세지 않음(drop/redistribute로 함께 처리)."""
    cnt = 0
    for u in units:
        ub = get_box(u)
        if ub is None: continue
        desc = set(u.iter())
        if any((fe not in desc) and box_near(ub, fb, 0) for fe, fb in fixed):
            cnt += 1
    return cnt

# ── #1 정책 결정 ──
def arrangement(boxes):
    if len(boxes) < 2: return "single"
    xs=[b[0] for b in boxes]; ys=[b[1] for b in boxes]
    xr=max(xs)-min(xs); yr=max(ys)-min(ys)
    if xr < 250000: return "vstack"
    if yr < 250000: return "hrow"
    if len(boxes) <= 4: return "spread"   # 방사/대칭
    return "grid"

def decide_policy(slide_elem, idmap, slot, slots_doc):
    """반환: (policy, reason). policy ∈ {blank, drop}."""
    ids = slot.get("target", {}).get("shape_ids", [])
    units = [idmap[i] for i in ids if i in idmap]
    boxes = [get_box(u) for u in units if get_box(u)]
    if not boxes: return ("blank", "no target box; safe blank")
    arr = arrangement(boxes)
    # unit '밖'의 고정 프레임이 각 타깃을 감싸면 drop시 빈 프레임 잔존 → blank.
    # (unit 안에 nested된 프레임은 drop으로 함께 제거되므로 세지 않음.)
    framed = separately_framed(units, fixed_shapes(slots_doc, idmap))
    if framed >= max(1, len(boxes)//2):
        return ("blank", f"separate per-item fixed frames {framed}/{len(boxes)} would leave empty frames on drop; blank")
    if arr in ("spread", "grid"):
        return ("blank", f"{arr} arrangement preserves geometry better with blank")
    return ("drop", f"{arr} self-contained stack/row -> drop+reflow")

# ── #2 reflow (drop 후 재중심) ──
def reflow_recenter(kept_shapes, all_boxes, axis):
    kb = [get_box(s) for s in kept_shapes if get_box(s)]
    if not kb or len(all_boxes) < 2: return
    if axis == "y":
        full = (min(b[1] for b in all_boxes), max(b[1]+b[3] for b in all_boxes))
        kspan = (min(b[1] for b in kb), max(b[1]+b[3] for b in kb))
        freed = (full[1]-full[0]) - (kspan[1]-kspan[0])
        if freed > 0:
            for s in kept_shapes: shift_box(s, dy=freed//2 - (kspan[0]-full[0]))
    else:
        full = (min(b[0] for b in all_boxes), max(b[0]+b[2] for b in all_boxes))
        kspan = (min(b[0] for b in kb), max(b[0]+b[2] for b in kb))
        freed = (full[1]-full[0]) - (kspan[1]-kspan[0])
        if freed > 0:
            for s in kept_shapes: shift_box(s, dx=freed//2 - (kspan[0]-full[0]))

# ── reduce (메인) ──
def reduce_repeated(slide_elem, idmap, slot, K, mode="auto", slots_doc=None, link_connectors=True):
    """repeated slot을 K개로 축소. mode=auto면 정책 자동결정.
    반환: dict(policy, dropped, blanked, connectors_removed, reflowed)."""
    ids = slot.get("target", {}).get("shape_ids", [])
    if not ids: return {"policy": "n/a", "note": "no shape_ids (table?)"}
    if mode == "auto":
        policy, reason = decide_policy(slide_elem, idmap, slot, slots_doc or {})
    else:
        policy, reason = mode, "override"
    target_shapes = [idmap[i] for i in ids if i in idmap]
    all_boxes = [b for b in (get_box(s) for s in target_shapes) if b]
    keep = target_shapes[:K]; extra = target_shapes[K:]
    res = {"policy": policy, "reason": reason, "dropped": 0, "blanked": 0,
           "connectors_removed": 0, "reflowed": False, "observed": len(ids), "K": K}
    conns = find_connectors(slide_elem) if (policy == "drop" and link_connectors) else []
    for s in extra:
        b = get_box(s)
        if policy == "blank":
            if blank_text(s): res["blanked"] += 1
        else:  # drop
            if policy == "drop" and link_connectors and b:
                for cx, cb in conns:
                    if box_near(b, cb, 80000) and cx.getparent() is not None:
                        drop_shape(cx); res["connectors_removed"] += 1
            if drop_shape(s): res["dropped"] += 1
    if policy == "drop" and keep and all_boxes:
        arr = arrangement(all_boxes)
        if arr in ("vstack", "hrow"):
            reflow_recenter(keep, all_boxes, "y" if arr == "vstack" else "x")
            res["reflowed"] = True
    res["final_count"] = len(keep)
    if all_boxes:
        res["touched"] = {"bbox": (min(b[0] for b in all_boxes), min(b[1] for b in all_boxes),
                                   max(b[0] + b[2] for b in all_boxes) - min(b[0] for b in all_boxes),
                                   max(b[1] + b[3] for b in all_boxes) - min(b[1] for b in all_boxes))}
    return res

def find_connectors(slide_elem):
    out = []
    for cx in slide_elem.xpath(f".//{_ln('cxnSp')}"):
        b = get_box(cx)
        if b: out.append((cx, b))
    return out

# ── 고도화: grow(clone) + shrink + 가로/세로 비율 재배분 ──
def _next_id(slide_elem):
    ids = [int(x) for x in slide_elem.xpath(f".//{_ln('cNvPr')}/@id") if str(x).isdigit()]
    return (max(ids) + 1) if ids else 1000

def clone_unit(template, start_id):
    """단위 도형 deepcopy + cNvPr id 전부 재발급(유일). 반환 (clone, next_id)."""
    clone = copy.deepcopy(template)
    nid = start_id
    for cn in clone.xpath(f".//{_ln('cNvPr')}"):
        cn.set("id", str(nid)); nid += 1
    return clone, nid

def set_off(shape, x=None, y=None):
    xf = own_xfrm(shape)
    if xf is None: return
    off = xf.find(f"{{{A_NS}}}off")
    if off is None: return
    if x is not None: off.set("x", str(int(x)))
    if y is not None: off.set("y", str(int(y)))

def set_ext(shape, cx=None, cy=None):
    xf = own_xfrm(shape)
    if xf is None: return
    ext = xf.find(f"{{{A_NS}}}ext")
    if ext is None: return
    if cx is not None: ext.set("cx", str(int(cx)))
    if cy is not None: ext.set("cy", str(int(cy)))

def shrink_fonts(shape, ratio, floor=800):
    """sp(단일도형) 텍스트 폰트 sz 비례 축소. grpSp는 ext 스케일로 텍스트가 함께 줄어 불필요."""
    if ratio >= 1.0: return
    for rpr in shape.xpath(f".//{_ln('rPr')} | .//{_ln('defRPr')} | .//{_ln('endParaRPr')}"):
        sz = rpr.get("sz")
        if sz and sz.isdigit():
            rpr.set("sz", str(max(floor, int(int(sz) * ratio))))

def attached_decorations(slide_elem, idmap, units, target_ids, ax, thin=90000, margin=90000):
    """타깃 아닌 thin 장식(구분선/cxnSp)을 각 단위에 엣지-거리로 페어링 → {unit_idx:[shape]}.
    셀 단위에 안 묶인 구분선/밑줄을 단위와 함께 이동/삭제/복제하기 위함(자족성 보완).
    cross-axis로 얇고(텍스트 없음) 단위 bbox 영역에 든 도형만 후보."""
    ubox = [get_box(u) for u in units]
    cax = 1 - ax                                       # cross-axis
    cmin = min(b[cax] for b in ubox); cmax = max(b[cax] + b[cax + 2] for b in ubox)
    amin = min(b[ax] for b in ubox); amax = max(b[ax] + b[ax + 2] for b in ubox)
    tset = set(target_ids)
    pairs = {i: [] for i in range(len(units))}
    for k, sh in idmap.items():
        if k in tset: continue
        ln = etree.QName(sh).localname
        if ln not in ("sp", "cxnSp"): continue
        b = get_box(sh)
        if b is None: continue
        if not ((b[ax + 2] < thin) or ln == "cxnSp"): continue           # along-axis로 얇은 선(구분선)만
        if any((t.text or "").strip() for t in a_texts(sh)): continue    # 텍스트 있으면 장식 아님
        c_center = b[cax] + b[cax + 2] // 2; a_center = b[ax] + b[ax + 2] // 2
        if not (cmin - margin <= c_center <= cmax + margin): continue     # 단위 영역 안
        if not (amin - margin <= a_center <= amax + margin): continue
        best = 0; bd = 1 << 62                                            # 엣지(상/하)거리 최소 단위
        for i, bb in enumerate(ubox):
            d = min(abs(a_center - bb[ax]), abs(a_center - (bb[ax] + bb[ax + 2])))
            if d < bd: bd = d; best = i
        pairs[best].append(sh)
    return pairs

def redistribute_repeated(slide_elem, idmap, slot, target_count, link_connectors=True, move_decorations=True):
    """repeated 단위를 target_count로 grow(clone)/shrink하고, span에 비율 맞게 재배분.
    hrow/vstack만 지원(spread/grid는 미지원→drop/blank 권장). 단위가 자족형(프레임 포함)이어야
    clean. move_decorations=True면 셀에 안 묶인 구분선/밑줄을 단위와 함께 이동/삭제/복제. 반환 summary."""
    ids = slot.get("target", {}).get("shape_ids", [])
    units = [idmap[i] for i in ids if i in idmap]
    if not units: return {"note": "no units"}
    boxes = [get_box(u) for u in units]
    if any(b is None for b in boxes): return {"note": "missing box coordinates"}
    arr = arrangement(boxes)
    if arr not in ("hrow", "vstack"):
        return {"note": f"redistribute unsupported for arrangement({arr})", "arr": arr}
    ax = 0 if arr == "hrow" else 1            # along-axis: 0=x,1=y
    order = sorted(range(len(units)), key=lambda k: boxes[k][ax])
    units = [units[k] for k in order]; boxes = [boxes[k] for k in order]
    start = min(b[ax] for b in boxes)
    end = max(b[ax] + b[ax + 2] for b in boxes)
    span = end - start
    orig_size = boxes[0][ax + 2]
    n0 = len(units)
    res = {"arr": arr, "from": n0, "to": target_count, "grown": 0, "dropped": 0,
           "connectors_removed": 0, "decorations_moved": 0, "shrunk_ratio": 1.0}
    # 장식(구분선/cxn) 페어링: 단위별 부속 [(shape, off_from_unit_pos)] — 단위와 함께 이동/삭제/복제
    if move_decorations:
        pairs = attached_decorations(slide_elem, idmap, units, ids, ax)
        decs = [[(d, get_box(d)[ax] - boxes[i][ax]) for d in pairs.get(i, [])] for i in range(n0)]
        res["decorations_paired"] = sum(len(v) for v in pairs.values())
    else:
        decs = [[] for _ in range(n0)]
    # GROW: 마지막 단위 clone (+그 단위의 부속도 clone)
    donor = next((decs[i][0] for i in range(n0) if decs[i]), None)   # (template_elem, off)
    pattern_last_bare = (not decs[n0 - 1]) and any(decs[i] for i in range(n0 - 1))
    nid = _next_id(slide_elem)
    while len(units) < target_count:
        clone, nid = clone_unit(units[-1], nid)
        units[-1].addnext(clone); units.append(clone)
        new_d = []
        for d, off in decs[-1]:
            dc, nid = clone_unit(d, nid); d.addnext(dc); new_d.append((dc, off))
        decs.append(new_d); res["grown"] += 1
    # grow 패턴 정규화: 원래 "마지막 셀만 구분선 없음"이면 → 중간 셀 전부 구분선·진짜 마지막은 없음
    if donor and pattern_last_bare and len(units) > n0:
        dt, doff = donor
        for i in range(len(units) - 1):
            if not decs[i]:
                dc, nid = clone_unit(dt, nid); units[i].addnext(dc)
                decs[i] = [(dc, doff)]
                res["donor_dividers_added"] = res.get("donor_dividers_added", 0) + 1
        for d, _ in decs[-1]: drop_shape(d)
        decs[-1] = []
    # SHRINK: trailing drop (+ 근처 connector + 그 단위의 부속)
    if target_count < n0:
        conns = find_connectors(slide_elem) if link_connectors else []
        for i in range(target_count, n0):
            u = units[i]; b = get_box(u)
            if link_connectors and b:
                for cx, cb in conns:
                    if box_near(b, cb, 80000) and cx.getparent() is not None:
                        drop_shape(cx); res["connectors_removed"] += 1
            for d, _ in decs[i]: drop_shape(d)
            drop_shape(u); res["dropped"] += 1
        units = units[:target_count]; decs = decs[:target_count]
    # REPROPORTION: span에 n개 고르게. 들어가면 원크기+균등gap, 넘치면 축소+폰트
    n = len(units)
    if n == 0: return res
    min_gap = max(0, int(span * 0.02))
    unit_size = orig_size
    ratio = 1.0
    if n * orig_size + (n - 1) * min_gap > span:        # overflow → 축소
        unit_size = max(1, int((span - (n - 1) * min_gap) / n))
        ratio = unit_size / orig_size
        res["shrunk_ratio"] = round(ratio, 3)
        for u in units:
            if ax == 0: set_ext(u, cx=unit_size)
            else: set_ext(u, cy=unit_size)
            if etree.QName(u).localname == "sp":         # sp는 폰트 별도 축소(grpSp는 ext스케일로 자동)
                shrink_fonts(u, ratio)
    gap = (span - n * unit_size) // (n + 1) if n > 0 else 0   # 균등 분배(양끝 여백 포함)
    pos = start + gap
    for i, u in enumerate(units):
        if ax == 0: set_off(u, x=pos)
        else: set_off(u, y=pos)
        for d, off in decs[i]:                           # 부속도 단위 따라 이동(축소비율 반영)
            npos = int(pos + off * ratio)
            if ax == 0: set_off(d, x=npos)
            else: set_off(d, y=npos)
            res["decorations_moved"] += 1
        pos += unit_size + gap
    cmin = min(b[1 - ax] for b in boxes); cmax = max(b[1 - ax] + b[1 - ax + 2] for b in boxes)
    res["touched"] = {"ax": ax, "start": start, "end": end, "span": span,
                      "cmin": cmin, "cmax": cmax, "final_count": len(units)}
    return res


def _cluster_count(vals, tol=200000):
    """정렬된 값들을 tol 간격으로 군집화한 대표값 리스트."""
    vs = sorted(vals)
    if not vs: return []
    clusters = [[vs[0]]]
    for v in vs[1:]:
        if v - clusters[-1][-1] < tol: clusters[-1].append(v)
        else: clusters.append([v])
    return [sum(c) // len(c) for c in clusters]

def redistribute_grid(slide_elem, idmap, slot, target_count):
    """2D 격자(cols×rows) repeated 단위를 target_count로 grow/shrink하고
    **원래 격자 bbox 안에서** cols 유지·rows 재계산해 재배치(넘치면 셀 축소+폰트).
    radial/scatter엔 부적합(호출 측이 진짜 격자일 때만 사용)."""
    ids = slot.get("target", {}).get("shape_ids", [])
    units = [idmap[i] for i in ids if i in idmap]
    boxes = [get_box(u) for u in units]
    if not units or any(b is None for b in boxes): return {"note": "missing units or box coordinates"}
    cols = max(1, len(_cluster_count([b[0] for b in boxes])))   # x 군집 = 열 수
    x0 = min(b[0] for b in boxes); y0 = min(b[1] for b in boxes)
    gx = max(b[0] + b[2] for b in boxes) - x0
    gy = max(b[1] + b[3] for b in boxes) - y0
    orig_w = boxes[0][2]; orig_h = boxes[0][3]
    # row-major 정렬(위→아래, 좌→우)
    order = sorted(range(len(units)), key=lambda k: (round(boxes[k][1] / 200000), boxes[k][0]))
    units = [units[k] for k in order]
    n0 = len(units)
    res = {"method": "grid", "cols": cols, "from": n0, "to": target_count, "grown": 0, "dropped": 0}
    nid = _next_id(slide_elem)
    while len(units) < target_count:
        clone, nid = clone_unit(units[-1], nid); units[-1].addnext(clone); units.append(clone); res["grown"] += 1
    if target_count < n0:
        for u in units[target_count:]:
            drop_shape(u); res["dropped"] += 1
        units = units[:target_count]
    n = len(units)
    rows = max(1, -(-n // cols))                # ceil
    gap = max(0, int(min(gx, gy) * 0.04))
    cell_w = (gx - (cols - 1) * gap) // cols
    cell_h = (gy - (rows - 1) * gap) // max(1, rows)
    ratio = min(cell_w / orig_w, cell_h / orig_h)
    res["rows"] = rows; res["shrunk_ratio"] = round(ratio, 3)
    for i, u in enumerate(units):
        c = i % cols; r = i // cols
        set_off(u, x=x0 + c * (cell_w + gap), y=y0 + r * (cell_h + gap))
        if ratio < 1.0:
            set_ext(u, cx=cell_w, cy=cell_h)
            if etree.QName(u).localname == "sp": shrink_fonts(u, ratio)
    res["touched"] = {"x0": x0, "y0": y0, "gx": gx, "gy": gy, "cols": cols, "final_count": len(units)}
    return res

def redistribute_radial(slide_elem, idmap, slot, target_count):
    """허브 둘레 2-컬럼(좌/우) radial 배치. N → 좌 ceil(N/2)·우 floor(N/2),
    각 컬럼은 원래 세로 span에 균등 배치(넘치면 높이 축소). 2=양쪽1, 3=2+1(삼각형), 6=3+3."""
    ids = slot.get("target", {}).get("shape_ids", [])
    units = [idmap[i] for i in ids if i in idmap]
    boxes = [get_box(u) for u in units]
    if not units or any(b is None for b in boxes): return {"note": "missing units or box coordinates"}
    xcl = _cluster_count([b[0] for b in boxes], tol=500000)
    if len(xcl) < 2: return {"note": f"not a two-column radial layout (x clusters={len(xcl)})"}
    left_x, right_x = xcl[0], xcl[-1]
    y0 = min(b[1] for b in boxes); y1 = max(b[1] + b[3] for b in boxes); span = y1 - y0
    h0 = boxes[0][3]
    # 원래 순서(좌상→) 보존: 좌측열 먼저, 우측열 다음으로 재배열
    units.sort(key=lambda u: (get_box(u)[0] > (left_x + right_x) // 2, get_box(u)[1]))
    n0 = len(units)
    res = {"method": "radial", "from": n0, "to": target_count, "grown": 0, "dropped": 0}
    nid = _next_id(slide_elem)
    while len(units) < target_count:
        clone, nid = clone_unit(units[-1], nid); units[-1].addnext(clone); units.append(clone); res["grown"] += 1
    if target_count < n0:
        for u in units[target_count:]: drop_shape(u); res["dropped"] += 1
        units = units[:target_count]
    N = len(units); L = -(-N // 2); R = N - L     # 좌 ceil, 우 floor
    res["left"] = L; res["right"] = R
    def place(col, cx):
        n = len(col)
        if n == 0: return
        ph = h0 if n * h0 < span else max(1, int(span * 0.9 / n))
        gap = (span - n * ph) // (n + 1)
        pos = y0 + gap
        for u in col:
            set_off(u, x=cx, y=pos)
            if ph < h0:
                set_ext(u, cy=ph)
                if etree.QName(u).localname == "sp": shrink_fonts(u, ph / h0)
            pos += ph + gap
    place(units[:L], left_x); place(units[L:], right_x)
    res["touched"] = {"left_x": left_x, "right_x": right_x, "y0": y0, "y1": y1,
                      "span": span, "final_count": len(units)}
    return res

def resize_repeated(slide_elem, idmap, slot, target_count, slots_doc=None):
    """통합 진입점: 임의 target_count(grow/shrink)로 카디널리티 조정. 방법 자동 선택.
    - hrow/vstack & 자족형 단위 → redistribute(grow clone + shrink + 비율 재배분)
    - 그 외 & 축소 → reduce(blank/drop 정책)
    - 그 외 & 확대 → blocked(grow 불가; Phase0 단위모델 필요)."""
    if slot.get("kind") == "composite":          # composite는 고정 구조 — 개수 조정 대상 아님
        return {"method": "n/a", "note": "composite is fixed-structure; cardinality adjustment does not apply"}
    ids = slot.get("target", {}).get("shape_ids", [])
    units = [idmap[i] for i in ids if i in idmap]
    if not units: return {"method": "n/a", "note": "no shape_ids (table?)"}
    boxes = [get_box(u) for u in units]
    if any(b is None for b in boxes): return {"method": "n/a", "note": "missing box coordinates"}
    arr = arrangement(boxes); observed = len(units)
    # cardinality.base = Phase0가 정의한 권위 원본 개수(있으면 len 추론 대신 grow/shrink 라우팅 기준으로 pivot).
    # 개수 결정과 min/max 판단은 Phase 1 책임 — Phase 2는 받은 target_count대로만 resize하고,
    # clamp(min/max)나 veto(resizable=false)로 plan이 준 개수를 덮어쓰지 않는다.
    card = slot.get("cardinality") or {}
    if isinstance(card.get("base"), int):        # 라우팅 기준(개수 제한 아님)
        observed = card["base"]

    framed = separately_framed(units, fixed_shapes(slots_doc or {}, idmap))
    self_contained = framed < max(1, observed // 2)
    xclusters = _cluster_count([b[0] for b in boxes], tol=500000)
    grp_ratio = sum(1 for u in units if etree.QName(u).localname == "grpSp") / len(units)
    if arr == "spread" and len(xclusters) == 2 and (self_contained or grp_ratio >= 0.5):
        r = redistribute_radial(slide_elem, idmap, slot, target_count)  # 좌/우 2컬럼=허브 둘레 radial
        if "note" not in r: r["method"] = "radial"; return r
    if arr in ("hrow", "vstack") and self_contained:
        r = redistribute_repeated(slide_elem, idmap, slot, target_count)
        r["method"] = "redistribute"; return r
    if arr == "grid" and self_contained:          # 명확한 격자(>4)만 — spread(≤4)는 radial 모호성으로 제외
        return redistribute_grid(slide_elem, idmap, slot, target_count)
    if target_count < observed:
        r = reduce_repeated(slide_elem, idmap, slot, target_count, mode="auto", slots_doc=slots_doc)
        r["method"] = "reduce(blank/drop)"; return r
    return {"method": "blocked", "arr": arr, "framed": framed, "observed": observed,
            "note": f"{arr}/frame{framed} cannot grow; Phase 0 unit model required"}
