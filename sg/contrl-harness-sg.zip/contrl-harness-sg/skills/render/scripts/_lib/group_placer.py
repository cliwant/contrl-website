"""
grpSp wrap — Variant body를 PPTX 네이티브 그룹으로 묶어 통째 이동/스케일.

핵심: 좌표 계산을 우리가 하지 않고 PPTX 그룹 변환에 위임.
  child_render = off + (child - chOff) * (ext / chExt)
→ chOff/chExt를 원본 bbox로 두면, off(이동)/ext(스케일)만 바꿔도 내부 100% 보존.

복합 구조(소제목+카드+배경)도 액자째 옮기듯 어긋남 없이 배치된다.
per-shape/block 재배치(좌표 직접 계산)가 복합 구조에서 깨지던 문제의 근본 해결.
"""
from lxml import etree

from .ooxml import A_NS, P_NS

_GROUP_ID = 9000


def _get_off(elem):
    for p in (f"{{{P_NS}}}grpSpPr/{{{A_NS}}}xfrm/{{{A_NS}}}off",
              f"{{{P_NS}}}spPr/{{{A_NS}}}xfrm/{{{A_NS}}}off",
              f"{{{P_NS}}}xfrm/{{{A_NS}}}off"):
        o = elem.find(p)
        if o is not None:
            return int(o.get("x", "0")), int(o.get("y", "0"))
    return None


def _get_ext(elem):
    for p in (f"{{{P_NS}}}grpSpPr/{{{A_NS}}}xfrm/{{{A_NS}}}ext",
              f"{{{P_NS}}}spPr/{{{A_NS}}}xfrm/{{{A_NS}}}ext",
              f"{{{P_NS}}}xfrm/{{{A_NS}}}ext"):
        x = elem.find(p)
        if x is not None:
            return int(x.get("cx", "0")), int(x.get("cy", "0"))
    return None


def _get_choff(elem):
    o = elem.find(f"{{{P_NS}}}grpSpPr/{{{A_NS}}}xfrm/{{{A_NS}}}chOff")
    return (int(o.get("x", "0")), int(o.get("y", "0"))) if o is not None else None


def _get_chext(elem):
    x = elem.find(f"{{{P_NS}}}grpSpPr/{{{A_NS}}}xfrm/{{{A_NS}}}chExt")
    return (int(x.get("cx", "0")), int(x.get("cy", "0"))) if x is not None else None


def child_abs_box(child_box, groups_inner_to_outer):
    """child의 group-local box (x,y,cx,cy)를 바깥 그룹 체인으로 환산해 절대 box 반환.
    그룹 변환: render = off + (local - chOff) * (ext / chExt). 체인은 **inner→outer**
    순(child 직속 grpSp부터 가장 바깥 wrap grp까지)으로 누적 적용한다. off/ext/chOff/chExt가
    불완전한 그룹은 건너뛴다(좌표 보존). chExt==0은 1.0 스케일로 방어.
    단 **rot/flipH/flipV는 미반영**(선형 off/scale만) — 그런 그룹이 체인에 있으면 결과 rect가
    근사이므로, 호출부가 group_has_flip_rot로 감지해 표시한다(현 카탈로그 pic엔 해당 없음)."""
    x, y, cx, cy = (float(v) for v in child_box)
    for g in groups_inner_to_outer:
        off, ext, choff, chext = _get_off(g), _get_ext(g), _get_choff(g), _get_chext(g)
        if not (off and ext and choff and chext):
            continue
        fx = ext[0] / chext[0] if chext[0] else 1.0
        fy = ext[1] / chext[1] if chext[1] else 1.0
        x = off[0] + (x - choff[0]) * fx
        y = off[1] + (y - choff[1]) * fy
        cx *= fx; cy *= fy
    return int(x), int(y), int(cx), int(cy)


def group_has_flip_rot(elem):
    """그룹 xfrm에 회전/뒤집기(rot/flipH/flipV)가 있나 — child_abs_box가 미반영하는 변환."""
    xf = elem.find(f"{{{P_NS}}}grpSpPr/{{{A_NS}}}xfrm")
    if xf is None:
        return False
    return (xf.get("rot") not in (None, "0")) or xf.get("flipH") == "1" or xf.get("flipV") == "1"


def wrap_and_place(sp_tree, body_elems, target_x, target_y,
                   x_scale=1.0, y_scale=1.0, shrink_fonts=True, min_font=400,
                   scale=None):
    """body_elems를 1개 grpSp로 묶어 (target_x, target_y)에 배치.

    가로/세로 스케일을 분리한다. composing에서는 가로 폭을 보존(width sacred)하려고
    x_scale=1.0으로 두고 y_scale만 줄인다. x_scale=1.0이면 off.x==chOff.x가 되어
    가로 드리프트(치우침)가 구조적으로 0이다.

    Args:
        sp_tree: 대상 슬라이드의 spTree element
        body_elems: 그룹으로 묶을 shape element 리스트 (이미 sp_tree의 자식)
        target_x, target_y: 그룹의 새 위치 (EMU)
        x_scale, y_scale: 가로/세로 배율 (1.0 = 원본)
        shrink_fonts: 축소 시 폰트도 비례 축소 (그룹 스케일은 폰트를 자동으로 안 줄임)
        scale: 하위호환 별칭. 주어지면 x_scale=y_scale=scale.
    Returns:
        생성된 grpSp element, (width, height) of placed group
    """
    global _GROUP_ID
    if scale is not None:
        x_scale = y_scale = scale
    if not body_elems:
        return None, (0, 0)

    # 원본 bbox
    xs, ys, xe, ye = [], [], [], []
    for e in body_elems:
        off = _get_off(e)
        ext = _get_ext(e)
        if off is None:
            continue
        xs.append(off[0]); ys.append(off[1])
        if ext:
            xe.append(off[0] + ext[0]); ye.append(off[1] + ext[1])
    if not xs or not xe or not ye:                # off·ext 불완전 도형들 → 빈 그룹 방지(max() 크래시 회피)
        return None, (0, 0)
    minx, miny = min(xs), min(ys)
    maxx, maxy = max(xe), max(ye)
    W, H = maxx - minx, maxy - miny

    # grpSp 생성
    _GROUP_ID += 1
    grp = etree.SubElement(sp_tree, f"{{{P_NS}}}grpSp")
    nv = etree.SubElement(grp, f"{{{P_NS}}}nvGrpSpPr")
    cnv = etree.SubElement(nv, f"{{{P_NS}}}cNvPr")
    cnv.set("id", str(_GROUP_ID)); cnv.set("name", f"WrapGroup{_GROUP_ID}")
    etree.SubElement(nv, f"{{{P_NS}}}cNvGrpSpPr")
    etree.SubElement(nv, f"{{{P_NS}}}nvPr")
    gpr = etree.SubElement(grp, f"{{{P_NS}}}grpSpPr")
    xfrm = etree.SubElement(gpr, f"{{{A_NS}}}xfrm")
    # off=새위치, ext=스케일 / chOff=chExt=원본 bbox → PPTX가 자식 자동 변환
    o = etree.SubElement(xfrm, f"{{{A_NS}}}off")
    o.set("x", str(int(target_x))); o.set("y", str(int(target_y)))
    e2 = etree.SubElement(xfrm, f"{{{A_NS}}}ext")
    e2.set("cx", str(int(W * x_scale))); e2.set("cy", str(int(H * y_scale)))
    co = etree.SubElement(xfrm, f"{{{A_NS}}}chOff")
    co.set("x", str(minx)); co.set("y", str(miny))
    ce = etree.SubElement(xfrm, f"{{{A_NS}}}chExt")
    ce.set("cx", str(W)); ce.set("cy", str(H))

    # 자식 이동
    for e in body_elems:
        sp_tree.remove(e)
        grp.append(e)

    # 폰트 비례 축소 (그룹 스케일이 폰트를 자동으로 안 줄이므로)
    font_scale = min(x_scale, y_scale)
    if shrink_fonts and font_scale < 1.0:
        for tag in (f"{{{A_NS}}}rPr", f"{{{A_NS}}}defRPr"):
            for pr in grp.iter(tag):
                sz = pr.get("sz")
                if sz:
                    pr.set("sz", str(max(min_font, int(int(sz) * font_scale))))

    return grp, (int(W * x_scale), int(H * y_scale))
