"""OOXML 공용 프리미티브 — 네임스페이스 URI + spTree 로케이터.

slide_composer·pptx_writer가 함께 쓰는 패키지 전역 인프라라, 둘 중 한 모듈이
소유하고 다른 모듈이 그쪽을 import하는 의존을 피하기 위해 leaf 모듈로 둔다.
"""
from __future__ import annotations

from pathlib import Path

import lxml.etree as ET

P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

_EMBED = f"{{{R_NS}}}embed"
_LINK = f"{{{R_NS}}}link"

# Interim r:embed value carrying a pooled media filename (e.g. ``DSMEDIA::<hash>.png``).
# slide_composer rewrites a variant/adornment's <a:blip> embeds to this when preparing an atom —
# at that point we know which design-system entity (hence which rels/media pool) the blip belongs
# to, but not yet the deck-global relationship id. pptx_writer resolves the sentinel back to a real
# per-slide rId at packaging time. Never serialized to the output package.
MEDIA_SENTINEL = "DSMEDIA::"

# Content-type Defaults for the media formats a deck can embed (so [Content_Types].xml declares
# every extension we copy in — otherwise PowerPoint flags the package for repair).
MEDIA_CONTENT_TYPES = {
    "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif",
    "bmp": "image/bmp", "tif": "image/tiff", "tiff": "image/tiff", "svg": "image/svg+xml",
    "emf": "image/x-emf", "wmf": "image/x-wmf", "wdp": "image/vnd.ms-photo",
}


def tag_media_embeds(root: ET._Element, rels: dict[str, str]) -> int:
    """Rewrite each embedded/linked-media reference in `root` to a ``MEDIA_SENTINEL`` value that
    carries its pooled filename. `rels` maps the fragment-local rId → pooled filename. References
    absent from `rels` (hyperlinks, unresolved) are left untouched. Returns the count rewritten."""
    n = 0
    for el in root.iter():
        for attr in (_EMBED, _LINK):
            rid = el.get(attr)
            if rid and rid in rels:
                el.set(attr, MEDIA_SENTINEL + rels[rid])
                n += 1
    return n


def harvest_media(slide_el: ET._Element, pool_dir: Path, rid_seed: int = 2):
    """Resolve ``MEDIA_SENTINEL`` embeds in a built slide element into real, package-bound media.

    For each sentinel, read the pooled bytes (``pool_dir/<filename>``), assign a slide-local rId
    (``rId{rid_seed}`` upward, after slideLayout's rId1), and rewrite the embed to that rId. Media
    are content-addressed (the pooled filename is a content hash), so an icon reused across the deck
    maps to one ``ppt/media/`` part. A sentinel whose pooled file is missing is left as-is.

    Returns ``(rels: {rId: arcname}, media: {arcname: bytes})``.
    """
    rels: dict[str, str] = {}
    media: dict[str, bytes] = {}
    seen: dict[str, str] = {}          # filename → slide-local rId (one rId per icon per slide)
    rid = rid_seed
    for el in slide_el.iter():
        for attr in (_EMBED, _LINK):
            val = el.get(attr)
            if not val or not val.startswith(MEDIA_SENTINEL):
                continue
            fname = val[len(MEDIA_SENTINEL):]
            if fname in seen:
                el.set(attr, seen[fname])
                continue
            src = pool_dir / fname
            if not src.exists():
                continue
            r = f"rId{rid}"
            rid += 1
            seen[fname] = r
            el.set(attr, r)
            arc = f"ppt/media/{fname}"
            rels[r] = arc
            if arc not in media:
                media[arc] = src.read_bytes()
    return rels, media


def _sptree(root: ET._Element) -> ET._Element:
    if root.tag.endswith("}spTree"):
        return root
    t = root.find(f".//{{{P_NS}}}spTree")
    return t if t is not None else root


def _max_cnvpr_id(elem: ET._Element) -> int:
    """elem 하위 모든 p:cNvPr/@id의 최댓값(없으면 0). 주입·생성 도형 id가 본문 group id와
    겹치지 않게 시드를 잡는 데 쓴다 — group_placer._GROUP_ID는 모듈 전역 누적이라
    장수명 프로세스(배치/대량 variant)에서 베이스를 넘길 수 있다."""
    return max((int(c.get("id")) for c in elem.iter(f"{{{P_NS}}}cNvPr")
                if (c.get("id") or "").isdigit()), default=0)


def renumber_cnvpr(sptree: ET._Element) -> int:
    """sptree 하위 모든 p:cNvPr/@id를 문서 순서로 1..n 재부여하고 n을 돌려준다.
    spTree 자신의 group header가 첫 cNvPr이라 id 1을 유지한다. 슬라이드 내 cNvPr id
    유일성을 구성적으로 보장한다 — id가 어디서 왔든(donor 도형·group_placer 래퍼·fit 편집·
    주입 placeholder) 무관하게 조립이 끝난 뒤 한 번에 다시 매긴다. PowerPoint가 repair를
    띄우는 slide 내 중복·0 cNvPr id를 원천 제거한다. 이 파이프라인은 slide 내부 id 참조
    (p:timing/@spid·도형 id 링크)를 내보내지 않으므로 blanket 재부여가 안전하다 — 참조가
    생기면 old→new 매핑으로 참조도 함께 갱신해야 한다."""
    n = 0
    for cnv in sptree.iter(f"{{{P_NS}}}cNvPr"):
        n += 1
        cnv.set("id", str(n))
    return n
