"""디자인 시스템 로더 — catalog.json + 타입별 shapes.xml 인덱싱/파싱.

``Catalog``은 데이터가 아니라 동작(파일 I/O · XML 파싱)이 본체라 models와 분리한다.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import lxml.etree as ET


@dataclass
class Catalog:
    """디자인 시스템 단일 원천(catalog.json + 타입별 shapes.xml)."""

    root: Path
    data: dict
    variants: dict[str, dict] = field(default_factory=dict)
    layouts: dict[str, dict] = field(default_factory=dict)
    adornments: dict[str, dict] = field(default_factory=dict)
    intents: dict[str, dict] = field(default_factory=dict)
    masters: dict[str, dict] = field(default_factory=dict)

    @classmethod
    def load(cls, design_system_dir: str | Path) -> "Catalog":
        root = Path(design_system_dir)
        data = json.loads((root / "catalog.json").read_text())
        idx = lambda key: {x["id"]: x for x in (data.get(key) or []) if "id" in x}
        return cls(root=root, data=data, variants=idx("variants"),
                   layouts=idx("layouts"), adornments=idx("adornments"),
                   intents=idx("intents"), masters=idx("masters"))

    def variant_root(self, vid: str) -> ET._Element:
        """variants/<vid>/shapes.xml 파싱(원자 1개). 호출자가 deepcopy해서 쓴다."""
        return ET.parse(str(self.root / "variants" / vid / "shapes.xml")).getroot()

    def slots(self, vid: str) -> list[dict]:
        return (self.variants.get(vid) or {}).get("slots", [])

    def variant_rels(self, vid: str) -> dict[str, str]:
        """variants/<vid>/shapes.xml.rels → {rId: pooled media filename}. {} when it embeds none."""
        return self._media_rels("variants", vid)

    def adornment_root(self, aid: str) -> ET._Element:
        """adornments/<aid>/shapes.xml 파싱. 호출자가 deepcopy + _body 추출해서 쓴다."""
        return ET.parse(str(self.root / "adornments" / aid / "shapes.xml")).getroot()

    def adornment_slots(self, aid: str) -> list[dict]:
        return (self.adornments.get(aid) or {}).get("slots", [])

    def adornment_rels(self, aid: str) -> dict[str, str]:
        """adornments/<aid>/shapes.xml.rels → {rId: pooled media filename}. {} when none."""
        return self._media_rels("adornments", aid)

    def _media_rels(self, pool: str, eid: str) -> dict[str, str]:
        """Map a carved fragment's embed rIds to their pooled media filenames (basename of the rels
        Target, which lives under the shared ``<root>/media/`` pool). Empty when the entity embeds
        no icons (no sibling .rels)."""
        p = self.root / pool / eid / "shapes.xml.rels"
        if not p.exists():
            return {}
        root = ET.parse(str(p)).getroot()
        return {r.get("Id"): Path(r.get("Target")).name for r in root if r.get("Id") and r.get("Target")}
