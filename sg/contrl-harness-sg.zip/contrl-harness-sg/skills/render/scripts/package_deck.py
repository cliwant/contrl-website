#!/usr/bin/env python3
"""Stage 4 — assemble the fit-edited slides into one multi-slide deck.pptx.

Reads each `slides/<n>/` dir's edited spTree (default `adjusted.xml`) + its `block_meta.json`,
rebuilds a `ComposedDeck` (in slide-number order) **without re-composing** — so the fit agent's
edits are preserved verbatim — and runs the vendored `write_deck_pptx` (frame inheritance, media
re-home, layout/master placeholder fills). Page numbers come out right here (deck order), unlike
the per-slide previews.

Usage: package_deck.py --run <run> [--out <deck.pptx>] [--xml adjusted.xml]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import lxml.etree as ET

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from _lib.catalog import Catalog
from _lib.models import ComposedDeck, ComposedSlide
from _lib.pptx_writer import write_deck_pptx


def package(run: str | Path, out: str | Path | None = None, xml_name: str = "adjusted.xml"):
    run = Path(run)
    cand = [d for d in (run / "slides").iterdir() if d.is_dir() and (d / "block_meta.json").exists()]
    if not cand:
        sys.exit(f"no slide dirs under {run / 'slides'}")
    pairs = sorted(((json.loads((d / "block_meta.json").read_text()), d) for d in cand),
                   key=lambda mp: mp[0]["slide_number"])      # deck order
    metas = [m for m, _ in pairs]
    slide_dirs = [d for _, d in pairs]
    cat = Catalog.load(metas[0]["ds_root"])
    frame_dir = metas[0]["frame_dir"]
    master_fills = metas[0].get("master_fills") or []      # deck-level, identical across dirs

    slides = []
    for d, m in zip(slide_dirs, metas):
        sptree = ET.parse(str(d / xml_name)).getroot()
        slides.append(ComposedSlide(slide_number=m["slide_number"], layout_id=m["layout_id"],
                                    sptree=sptree, layout_fills=m.get("layout_fills") or []))
    deck = ComposedDeck(slides=slides, master_fills=master_fills)
    out = Path(out) if out else run / "deck.pptx"
    rep = write_deck_pptx(deck, cat, frame_dir, out)
    print(f"deck → {out}  ({rep.slide_count} slides)")
    print(f"  layouts_used={rep.layouts_used}")
    print(f"  media_embedded={rep.media_embedded} injected={rep.injected} "
          f"layouts_cloned={rep.layouts_cloned} pic_backups={rep.pic_backups}")
    if rep.warnings:
        print(f"  warnings ({len(rep.warnings)}):", rep.warnings[:6])
    return rep


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--out", default=None)
    ap.add_argument("--xml", default="adjusted.xml")
    a = ap.parse_args()
    package(a.run, a.out, a.xml)
