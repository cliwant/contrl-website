#!/usr/bin/env python3
"""Render ONE composed slide (a slide working dir) to PNG via the vendored packager.

The fit-loop tool: package the dir's spTree (default `adjusted.xml`) on its real layout —
inherit the frame, re-home media, inject layout/master placeholder fills — then soffice → PNG.
Packaging the **edited** spTree directly (never re-composing) is the seam where the fit step
plugs between compose and the deck packager.

Usage: render_slide.py <slide_dir> [xml_name=adjusted.xml] [out_stem=after]
Prints the PNG path.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import lxml.etree as ET

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from _lib.catalog import Catalog
from _lib.models import ComposedDeck, ComposedSlide
from _lib.pptx_writer import write_deck_pptx


def _resolve_soffice() -> str:
    """soffice binary: $SOFFICE if set, else the macOS app bundle, else whatever's on PATH."""
    env = os.environ.get("SOFFICE")
    if env and Path(env).exists():
        return env
    mac = "/Applications/LibreOffice.app/Contents/MacOS/soffice"
    if Path(mac).exists():
        return mac
    return shutil.which("soffice") or shutil.which("libreoffice") or mac


SOFFICE = _resolve_soffice()


def render(slide_dir: str | Path, xml_name: str = "adjusted.xml", stem: str = "after") -> Path:
    """Package <slide_dir>/<xml_name> as a one-slide deck and render it to <slide_dir>/<stem>.png.
    Reads block_meta.json for the layout/fills/design-system the packager needs (self-contained,
    so the fit agent can call this with only the dir)."""
    d = Path(slide_dir).resolve()
    meta = json.loads((d / "block_meta.json").read_text())
    cat = Catalog.load(meta["ds_root"])
    sptree = ET.parse(str(d / xml_name)).getroot()
    cs = ComposedSlide(slide_number=meta.get("slide_number", 1), layout_id=meta["layout_id"],
                       sptree=sptree, layout_fills=meta.get("layout_fills") or [])
    deck = ComposedDeck(slides=[cs], master_fills=meta.get("master_fills") or [])
    pptx = d / f"{stem}.pptx"
    write_deck_pptx(deck, cat, meta["frame_dir"], pptx)
    # soffice converts a 1-slide deck to a single PNG named after the pptx stem.
    # Each soffice instance needs its OWN UserInstallation profile: a shared profile is single-instance,
    # so concurrent renders (parallel fit agents) collide on its lock and silently emit no PNG. Key the
    # profile by the absolute slide dir (+ stem) so same-slide re-renders reuse it while different slides
    # rendering at once never clash. Pass it via -env:UserInstallation (the documented concurrency knob).
    slug = hashlib.sha1(f"{d}|{stem}".encode()).hexdigest()[:16]
    # Profiles live under the RUN's _work/ (build intermediates), not the system temp dir: each
    # profile is 10–50MB of LibreOffice state keyed by (slide dir, stem), so run-scoped placement
    # means deleting/cleaning a run reclaims them — in the global temp dir they accumulated
    # unbounded across runs (hundreds of dirs over a benchmark campaign). d is …/run/slides/<n>.
    profile = d.parent.parent / "_work" / f"soffice_{slug}"
    profile.mkdir(parents=True, exist_ok=True)
    out_png = d / f"{stem}.png"
    # Render into a private temp dir on the SAME filesystem, then os.replace into place — so the write
    # of after.png is ATOMIC. A concurrent reader (slide_diagnostics inlines after.png as base64 during
    # a background refit) then never sees a half-written PNG; on failure the previous (last-good) PNG is
    # left intact rather than cleared. soffice names its output after the pptx stem.
    tmp_out = d / f".render_{slug}"
    tmp_out.mkdir(exist_ok=True)
    tmp_png = tmp_out / f"{stem}.png"
    tmp_png.unlink(missing_ok=True)                        # so a silent no-op never yields a stale temp
    try:
        subprocess.run([SOFFICE, f"-env:UserInstallation=file://{profile}",
                        "--headless", "--convert-to", "png", "--outdir", str(tmp_out), str(pptx)],
                       check=True, capture_output=True, timeout=120,
                       env={**os.environ, "HOME": str(profile)})
        if not tmp_png.exists():
            raise RuntimeError(f"soffice produced no PNG for {pptx} (profile {profile})")
        os.replace(tmp_png, out_png)                      # atomic within the slide dir
    finally:
        shutil.rmtree(tmp_out, ignore_errors=True)
    return out_png


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("usage: render_slide.py <slide_dir> [xml_name] [out_stem]")
    xml = sys.argv[2] if len(sys.argv) > 2 else "adjusted.xml"
    stem = sys.argv[3] if len(sys.argv) > 3 else "after"
    print("rendered ->", render(sys.argv[1], xml, stem))
