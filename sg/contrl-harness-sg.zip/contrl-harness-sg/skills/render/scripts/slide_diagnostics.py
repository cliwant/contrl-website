#!/usr/bin/env python3
"""Render the Slide diagnostics panel for contrl-shell.

Slide diagnostics puts each slide's **render** (S6 `after.png`) beside its **plan
decision** (S5 intent / layout / variant, shown as catalog `preview.png`
thumbnails) plus a deck-level **distribution**, so a human can localize a bad slide
to the plan (S5) or the render/fit (S6).

This script is a *data extractor*: it reads the plan, the catalog previews, and the
render run, and emits ONE self-contained HTML whose embedded JSON payload the
template's client-side JS renders into the overview grid + focused overlay +
distribution. Images are inlined as base64 data URIs (same as catalog.html) so the
panel references nothing and survives the shell's periodic iframe reload.

Two streams are joined by absolute `slide_number`:
  - PLAN (appears first, at plan-time). Priority:
      1. the finished deck `slide_plan.json` (standalone S6 / final review) — has
         `slide_number` + `_meta`;
      2. else the streaming per-slide records `.plan/slide_{i}.json` + the
         `cover_toc.json` front-matter (combined S5↔S6 pipeline, mid-run, where the
         deck plan does not exist yet). `slide_number = front_matter_count + i + 1`.
  - RENDER (fills in as each slide reaches `fit_done`). Each `slides/<label>/`
    that has `status.json` (its `n` = slide_number) contributes its `after.png`.

Usage:
    slide_diagnostics.py <project> --root <abs>
        [--run <run_dir>]        # render source; omit → setup-time seed (no-clobber)
        [--catalog <path>]       # default <root>/design-system/catalog.json
        [--plan <slide_plan>]    # default …/artifacts/slides/slide_plan.json
        [--plan-dir <.plan>]     # default …/artifacts/slides/.plan
        [--cover-toc <json>]     # default …/artifacts/slides/cover_toc.json
        [--batch-size <n>]       # collapsible-section size = review pause cadence (default 10)
        [--expand-all]           # expand every batch section (final/whole-deck review)
        [--total-slides <n>]     # caps the last batch's label end (e.g. 51–53 not 51–60)
        [--output <html>]        # default …/outputs/render/slide_diagnostics.html
"""
from __future__ import annotations

import argparse
import base64
import io
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE_PATH = SKILL_ROOT / "templates" / "slide-diagnostics.html"

# The degraded floor variant every block collapses to when nothing matched (single
# source: slide-plan/make_floor.py). A NON-floor slide that still carries this (or
# any catalog `is_fallback` variant) is the "Fallback variant" class — skeleton is
# right, some substance dropped to a generic box.
FALLBACK_VARIANT_ID = "single-bordered-bullet-box"

_RENDER_MAX_EDGE = 900   # after.png inline size (line/text art → JPEG crushes it)
_PREVIEW_MAX_EDGE = 620  # catalog preview.png inline size

try:
    from PIL import Image
    _HAVE_PIL = True
except Exception:  # Pillow absent — inline the raw bytes untouched
    _HAVE_PIL = False


# ── image inlining (ported from extract-design-system/catalog_html.py) ─────────
def data_uri(p: Path | None, max_edge: int) -> str | None:
    """Inline an image as a base64 data URI, downscaled to `max_edge` and re-encoded
    as JPEG (flattening any alpha onto white), so the panel is self-contained and
    light. Returns None when the file is absent/unreadable."""
    if p is None or not p.exists():
        return None
    try:
        raw = p.read_bytes()
    except OSError:
        return None
    if _HAVE_PIL:
        try:
            im = Image.open(io.BytesIO(raw))
            if im.mode in ("RGBA", "LA", "PA") or (im.mode == "P" and "transparency" in im.info):
                im = im.convert("RGBA")
                bg = Image.new("RGB", im.size, (255, 255, 255))
                bg.paste(im, mask=im.split()[-1])
                im = bg
            else:
                im = im.convert("RGB")
            w, h = im.size
            scale = max_edge / max(w, h)
            if scale < 1:
                im = im.resize((max(1, round(w * scale)), max(1, round(h * scale))), Image.LANCZOS)
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=78, optimize=True)
            return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
        except Exception:
            pass  # any decode/resize failure → inline original bytes
    return "data:image/png;base64," + base64.b64encode(raw).decode("ascii")


# ── catalog ────────────────────────────────────────────────────────────────────
def _load_json(p: Path) -> Any | None:
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def load_catalog(catalog_path: Path) -> dict[str, Any]:
    cat = _load_json(catalog_path)
    if not isinstance(cat, dict):
        raise SystemExit(f"catalog not found or invalid JSON: {catalog_path}")
    return cat


def _index_by_id(items: list[dict] | None) -> dict[str, dict]:
    return {it["id"]: it for it in (items or []) if isinstance(it, dict) and it.get("id")}


# ── plan discovery / normalization ─────────────────────────────────────────────
def _norm_slide(raw: dict, slide_number: int) -> dict:
    """Normalize a plan slide (from slide_plan.json, a .plan record, or a cover_toc
    entry) to the internal shape the DATA payload is built from."""
    blocks = []
    for b in raw.get("blocks", []) or []:
        comps = [{"variant_id": c.get("variant_id")} for c in (b.get("components") or [])]
        blocks.append({
            "heading": b.get("heading") or "",
            "adornment_id": b.get("adornment_id"),
            "components": comps,
        })
    return {
        "slide_number": slide_number,
        "source": raw.get("source"),
        "subtitle": raw.get("subtitle") or "",
        "section_id": raw.get("section_id"),
        "intent_id": raw.get("intent_id"),
        "layout_id": raw.get("layout_id"),
        "blocks": blocks,
        "plan_status": raw.get("status"),  # ok|fallback|failed (only on .plan records)
    }


def discover_plan(artifacts_slides: Path, plan_path: Path,
                  plan_dir: Path, cover_toc: Path) -> tuple[list[dict], int, str]:
    """Return (normalized plan slides sorted by slide_number, front_matter_count,
    plan_source). Prefers the finished deck plan; falls back to the streaming
    per-slide records + cover_toc front-matter."""
    plan = _load_json(plan_path)
    if isinstance(plan, dict) and plan.get("slides"):
        meta = plan.get("_meta") or {}
        fmc = int(meta.get("front_matter_count") or 0)
        slides = [_norm_slide(s, int(s.get("slide_number") or (i + 1)))
                  for i, s in enumerate(plan["slides"])]
        slides.sort(key=lambda s: s["slide_number"])
        return slides, fmc, "slide_plan"

    # streaming: cover_toc front-matter (slide_number 1..fmc) + .plan body records
    fmc = 0
    front: list[dict] = []
    ct = _load_json(cover_toc)
    if isinstance(ct, dict):
        entries = ct.get("slides") or []
        fmc = int(ct.get("front_matter_count") or len(entries))
        front = [_norm_slide(e, i + 1) for i, e in enumerate(entries)]

    body: list[dict] = []
    if plan_dir.is_dir():
        for f in plan_dir.glob("slide_*.json"):
            m = re.match(r"slide_(\d+)\.json$", f.name)
            if not m:
                continue
            rec = _load_json(f)
            if not isinstance(rec, dict):
                continue
            idx = int(rec.get("index", m.group(1)))
            if rec.get("status") == "failed":
                # failed records are not seeded mid-run (they floor at deck-finalize);
                # surface them so the drop is never silent.
                body.append({**_norm_slide(rec, fmc + idx + 1), "plan_status": "failed"})
            else:
                body.append(_norm_slide(rec, fmc + idx + 1))

    slides = front + body
    slides.sort(key=lambda s: s["slide_number"])
    source = "plan_dir" if (front or body) else "none"
    return slides, fmc, source


# ── render run ─────────────────────────────────────────────────────────────────
def collect_renders(run: Path | None) -> dict[int, dict]:
    """{slide_number: {after, needs_attention, residual}} for every
    slides/<label>/ that reached fit_done (status.json present, `n` = slide_number).
    The fit agent's self-assessment (`needs_attention` + `residual`) is the render
    (S6) side of fault localization — it complements the plan (S5) signals."""
    out: dict[int, dict] = {}
    if run is None:
        return out
    slides_dir = run / "slides"
    if not slides_dir.is_dir():
        return out
    for d in sorted(slides_dir.iterdir()):
        if not d.is_dir():
            continue
        status = _load_json(d / "status.json")
        if not isinstance(status, dict):
            continue
        try:
            n = int(status.get("n"))
        except (TypeError, ValueError):
            digits = "".join(c for c in d.name if c.isdigit())
            if not digits:
                continue
            n = int(digits)
        ap = d / "after.png"
        if ap.is_file():
            out[n] = {
                "after": ap,
                "needs_attention": bool(status.get("needs_attention")),
                "residual": (status.get("residual") or "").strip(),
            }
    return out


# ── signal computation ─────────────────────────────────────────────────────────
def _allowed_sets(catalog: dict) -> tuple[dict[str, set[str]], set[str]]:
    allowed_by_intent = {i.get("id"): set(i.get("allowed_variant_ids") or [])
                         for i in catalog.get("intents", []) if isinstance(i, dict)}
    pool = {v.get("id") for v in catalog.get("variants", [])
            if isinstance(v, dict) and v.get("is_fallback")}
    return allowed_by_intent, pool


def _classify(slide: dict, allowed_by_intent: dict[str, set[str]], pool: set[str]) -> dict:
    """Attach diagnostic signals to one slide: status class (floor|fallback|ok),
    per-component `allowed` (✓/✗ against the intent), and `allowed_ok`."""
    intent_id = slide.get("intent_id")
    is_floor = intent_id is None
    allowed = allowed_by_intent.get(intent_id, set()) if not is_floor else set()
    allowed_universe = allowed | pool | {FALLBACK_VARIANT_ID}

    has_fallback_variant = False
    allowed_ok = True
    for b in slide["blocks"]:
        for c in b["components"]:
            vid = c.get("variant_id")
            in_allowed = (is_floor or vid in allowed_universe)
            c["allowed"] = bool(in_allowed)
            if not is_floor and not in_allowed:
                allowed_ok = False
            if vid == FALLBACK_VARIANT_ID or vid in pool:
                has_fallback_variant = True

    if is_floor:
        status = "floor"
    elif has_fallback_variant:
        status = "fallback"
    else:
        status = "ok"
    slide["status"] = status
    slide["allowed_ok"] = allowed_ok
    return slide


# ── DATA payload ────────────────────────────────────────────────────────────────
def build_data(project: str, run_label: str, catalog: dict, catalog_root: Path,
               plan_slides: list[dict], renders: dict[int, dict],
               front_matter_count: int, plan_source: str,
               batch_size: int, expand_all: bool, total_slides: int | None) -> dict:
    allowed_by_intent, pool = _allowed_sets(catalog)
    intents_by_id = _index_by_id(catalog.get("intents"))
    layouts_by_id = _index_by_id(catalog.get("layouts"))
    variants_by_id = _index_by_id(catalog.get("variants"))
    adorn_by_id = _index_by_id(catalog.get("adornments"))

    # union of slide_numbers across plan + render (never drop a rendered slide)
    plan_by_n = {s["slide_number"]: s for s in plan_slides}
    all_ns = sorted(set(plan_by_n) | set(renders))

    ref_layouts: set[str] = set()
    ref_variants: set[str] = set()
    ref_adorns: set[str] = set()
    dist_intents: dict[str, int] = {}
    dist_layouts: dict[str, int] = {}
    dist_variants: dict[str, int] = {}
    floor_count = fallback_count = 0

    out_slides: list[dict] = []
    for n in all_ns:
        s = plan_by_n.get(n)
        if s is None:  # rendered but no plan yet (rare, e.g. front-matter mid-run)
            s = {"slide_number": n, "source": None, "subtitle": "", "section_id": None,
                 "intent_id": None, "layout_id": None, "blocks": [], "plan_status": None,
                 "status": "unknown", "allowed_ok": True}
        else:
            _classify(s, allowed_by_intent, pool)

        if s["status"] == "floor":
            floor_count += 1
        elif s["status"] == "fallback":
            fallback_count += 1

        iid, lid = s.get("intent_id"), s.get("layout_id")
        if iid:
            dist_intents[iid] = dist_intents.get(iid, 0) + 1
        if lid:
            dist_layouts[lid] = dist_layouts.get(lid, 0) + 1
            ref_layouts.add(lid)
        for b in s["blocks"]:
            if b.get("adornment_id"):
                ref_adorns.add(b["adornment_id"])
            for c in b["components"]:
                vid = c.get("variant_id")
                if vid:
                    dist_variants[vid] = dist_variants.get(vid, 0) + 1
                    ref_variants.add(vid)

        r = renders.get(n)
        out_slides.append({
            **s,
            "intent_name": (intents_by_id.get(iid) or {}).get("name", iid) if iid else None,
            "layout_name": (layouts_by_id.get(lid) or {}).get("name", lid) if lid else None,
            "render": data_uri(r["after"], _RENDER_MAX_EDGE) if r else None,
            "needs_attention": bool(r["needs_attention"]) if r else False,
            "residual": r["residual"] if r else "",
        })

    # catalog lookups — referenced entities plus each used intent's non-selected
    # children (its layout_affinity layouts + allowed variants), so the overlay can
    # show the Options that were available at each decision point. Cost is bounded
    # by catalog size, not deck size. Previews inlined once.
    def _preview(subdir: str, eid: str) -> str | None:
        return data_uri(catalog_root / subdir / eid / "preview.png", _PREVIEW_MAX_EDGE)

    for iid in dist_intents:
        it = intents_by_id.get(iid) or {}
        for aff in it.get("layout_affinity") or []:
            if aff.get("layout_id"):
                ref_layouts.add(aff["layout_id"])
        for vid in it.get("allowed_variant_ids") or []:
            ref_variants.add(vid)

    cat_layouts = {lid: {"name": (layouts_by_id.get(lid) or {}).get("name", lid),
                         "preview": data_uri(
                             catalog_root / "_work" / "layout_previews" / lid / "preview.png",
                             _PREVIEW_MAX_EDGE)}
                   for lid in ref_layouts}
    cat_variants = {}
    for vid in ref_variants:
        v = variants_by_id.get(vid) or {}
        cat_variants[vid] = {
            "name": v.get("name", vid),
            "description": v.get("description") or v.get("note") or "",
            "slots": len(v.get("slots") or []),
            "used_by": v.get("used_by_intents") or [],
            "preview": _preview("variants", vid),
        }
    cat_adorns = {aid: {"name": (adorn_by_id.get(aid) or {}).get("name", aid),
                        "preview": _preview("adornments", aid)}
                  for aid in ref_adorns}
    # ALL catalog intents, not just the used ones — the overlay lists non-selected
    # intent options (text only; intents are abstract, no preview image). Used intents
    # additionally carry their children so their layout/variant options resolve.
    cat_intents = {i["id"]: {"name": i.get("name", i["id"]),
                             "description": i.get("description", ""),
                             "layout_affinity": i.get("layout_affinity") or [],
                             "allowed_variant_ids": i.get("allowed_variant_ids") or []}
                   for i in catalog.get("intents", []) if isinstance(i, dict) and i.get("id")}

    def _dist(counts: dict[str, int], names: dict[str, dict]) -> list[dict]:
        return sorted(
            ({"id": k, "name": (names.get(k) or {}).get("name", k), "count": v}
             for k, v in counts.items()),
            key=lambda d: (-d["count"], d["name"]))

    emu = (catalog.get("meta") or {}).get("slide_emu") or {}
    w, h = int(emu.get("w") or 12192000), int(emu.get("h") or 6858000)
    orientation = "portrait" if h > w else "landscape"

    return {
        "project": project,
        "run_label": run_label,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "orientation": orientation,
        "slide_aspect": (w / h) if h else 1.7778,
        "meta": {
            "slide_count": len(out_slides),
            "front_matter_count": front_matter_count,
            "floor_count": floor_count,
            "fallback_count": fallback_count,
            "distinct_intents": len(dist_intents),
            "rendered_count": sum(1 for s in out_slides if s["render"]),
            "attention_count": sum(1 for s in out_slides if s["needs_attention"]),
            "plan_source": plan_source,
        },
        "distribution": {
            "intents": _dist(dist_intents, cat_intents),
            "layouts": _dist(dist_layouts, cat_layouts),
            "variants": _dist(dist_variants, cat_variants),
        },
        "batch": {
            "size": batch_size,
            "expand_all": expand_all,
            "total_slides": total_slides,
        },
        "catalog": {
            "intents": cat_intents,
            "layouts": cat_layouts,
            "variants": cat_variants,
            "adornments": cat_adorns,
        },
        "slides": out_slides,
    }


def render_html(data: dict) -> str:
    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    # Readiness drives the shell's menu-dim + auto-advance. Un-dim S6 only when there
    # is real reviewable progress: at least one rendered slide. A seed — plan records
    # possibly present but nothing rendered yet — stays dimmed, matching the old
    # empty-seed semantics.
    m = data["meta"]
    panel_ready = m["rendered_count"] > 0
    payload = json.dumps(data, ensure_ascii=False)
    # embed safely inside <script> — escape the sequence that could close the tag
    payload = payload.replace("</", "<\\/")
    repl = {
        "TITLE": f"Slide Diagnostics - {data['project']}",
        "DATA_JSON": payload,
        "PANEL_READY": "true" if panel_ready else "false",
    }
    for k, v in repl.items():
        template = template.replace(f"{{{{{k}}}}}", v)
    return template


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Render the Slide diagnostics panel HTML.")
    p.add_argument("project", help="Project name under projects/.")
    p.add_argument("--root", required=True, help="Absolute path to the dir that contains projects/ and design-system/.")
    p.add_argument("--run", help="Render run dir (…/outputs/render/<run_label>). Omit → setup-time seed (no-clobber).")
    p.add_argument("--catalog", help="catalog.json (default: <root>/design-system/catalog.json).")
    p.add_argument("--plan", help="slide_plan.json (default: …/artifacts/slides/slide_plan.json).")
    p.add_argument("--plan-dir", dest="plan_dir", help=".plan dir (default: …/artifacts/slides/.plan).")
    p.add_argument("--cover-toc", dest="cover_toc", help="cover_toc.json (default: …/artifacts/slides/cover_toc.json).")
    p.add_argument("--batch-size", dest="batch_size", type=int, default=10,
                   help="N — collapsible-section size (slides per batch) = the review pause cadence "
                        "(render/references/review-loop.md is the source for N; the caller passes "
                        "whatever value is in effect for this run). Default: 10.")
    p.add_argument("--expand-all", dest="expand_all", action="store_true",
                   help="Expand every batch section (final/whole-deck review). Default: only the latest batch open.")
    p.add_argument("--total-slides", dest="total_slides", type=int, default=None,
                   help="Total deck slide count (slide_plan.json._meta.slide_count). Caps the last batch's "
                        "label end (e.g. '51–53' not '51–60'). Omit → last batch shows the full N-span.")
    p.add_argument("--output", help="HTML output path (default: …/outputs/render/slide_diagnostics.html).")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    root = Path(args.root).resolve()
    project = args.project
    proj_root = root / "projects" / project
    artifacts_slides = proj_root / "artifacts" / "slides"
    out_render_dir = proj_root / "outputs" / "render"

    catalog_path = Path(args.catalog).resolve() if args.catalog else root / "design-system" / "catalog.json"
    plan_path = Path(args.plan).resolve() if args.plan else artifacts_slides / "slide_plan.json"
    plan_dir = Path(args.plan_dir).resolve() if args.plan_dir else artifacts_slides / ".plan"
    cover_toc = Path(args.cover_toc).resolve() if args.cover_toc else artifacts_slides / "cover_toc.json"
    output = Path(args.output).resolve() if args.output else out_render_dir / "slide_diagnostics.html"

    # No --run = setup-time seed (lay down the panel so the shell's probe iframe
    # doesn't 404). NEVER clobber an existing panel: a resume re-runs setup
    # mid-render, and the re-seed would wipe every render thumbnail until the next
    # fit_done refresh.
    if not args.run and output.exists():
        print(f"{output} (seed skipped — panel already present, not clobbering)")
        return

    catalog = load_catalog(catalog_path)
    catalog_root = catalog_path.parent

    plan_slides, fmc, plan_source = discover_plan(artifacts_slides, plan_path, plan_dir, cover_toc)

    run = Path(args.run).resolve() if args.run else None
    run_label = run.name if run else ""
    renders = collect_renders(run)

    data = build_data(project, run_label, catalog, catalog_root,
                      plan_slides, renders, fmc, plan_source,
                      args.batch_size, args.expand_all, args.total_slides)
    html_text = render_html(data)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html_text, encoding="utf-8")
    m = data["meta"]
    print(f"{output} (slides={m['slide_count']} rendered={m['rendered_count']} "
          f"floor={m['floor_count']} fallback={m['fallback_count']} src={m['plan_source']})")


if __name__ == "__main__":
    main()
