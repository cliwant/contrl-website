#!/usr/bin/env node

import { readdir, readFile, lstat, mkdir } from "node:fs/promises";
import { dirname, relative, resolve, sep } from "node:path";
import { createHash } from "node:crypto";

const projectsRoot = resolve(process.cwd(), "projects");
// design system은 프로젝트 바깥의 단수 공유 폴더 — projects/와 나란히 CWD 기준으로 푼다.
const catalogPath = resolve(process.cwd(), "design-system", "catalog.json");
// Degraded component used by the intent==null floor and by block_matching failure
// fallback. Always a legitimate variant choice (exempt from the allowed-list check).
const FALLBACK_VARIANT_ID = "single-bordered-bullet-box";

const paths = {
  references: "inputs/references",
  rfp: "artifacts/rfp/rfp.json",
  rfpAnalysis: "artifacts/rfp/analysis.md",
  rfpStatus: "artifacts/rfp/status.json",
  framework3c: "artifacts/strategy/framework_3c.json",
  winThemes: "artifacts/strategy/win_themes.json",
  themeStatements: "artifacts/strategy/theme_statements.json",
  slideContents: "artifacts/slides/slide_contents.json",
  slidePlan: "artifacts/slides/slide_plan.json",
  deck: "artifacts/render/deck.pptx",
  renderSlides: "artifacts/render/slides",
};

const reservedLocations = new Map([
  ["rfp.json", paths.rfp],
  ["analysis.md", paths.rfpAnalysis],
  ["status.json", paths.rfpStatus],
  ["framework_3c.json", paths.framework3c],
  ["win_themes.json", paths.winThemes],
  ["theme_statements.json", paths.themeStatements],
  ["slide_contents.json", paths.slideContents],
  ["slide_plan.json", paths.slidePlan],
  ["deck.pptx", paths.deck],
]);

// S0 is split into two independently-gated sub-stages so the human-paced S1
// interview does not block on the heavier rfp.json extraction:
//   S0A (seed)    references -> framework_3c.json + analysis.md. Synchronous; unblocks S1.
//   S0B (extract) references -> rfp.json + status.json. Runs in the background
//                 during S1; its completion is enforced at the S2 gate.
// S0 is kept as a convenience alias meaning "both sub-stages done".
const beforeRequirements = {
  S0: ["references"],
  S0A: ["references"],
  S0B: ["references"],
  S1: ["framework3c", "rfpAnalysis"],
  S2: ["rfp", "rfpStatus", "framework3c"],
  S3: ["rfp", "rfpStatus", "framework3c", "winThemes"],
  S4: ["rfp", "rfpStatus", "framework3c", "winThemes", "themeStatements"],
  S5: ["slideContents", "rfp", "rfpStatus", "themeStatements", "catalog"],
  S6: ["slidePlan", "catalog"],
};

const afterAdditions = {
  S0: ["rfp", "rfpStatus", "framework3c", "rfpAnalysis"],
  S0A: ["framework3c", "rfpAnalysis"],
  S0B: ["rfp", "rfpStatus"],
  S1: ["framework3c"],
  S2: ["winThemes"],
  S3: ["themeStatements"],
  S4: ["slideContents"],
  S5: ["slidePlan"],
  S6: ["deck", "renderSlides"],
};

const canonicalDirectories = [
  paths.references,
  dirname(paths.rfp),
  dirname(paths.framework3c),
  dirname(paths.slideContents),
  dirname(paths.deck),
  paths.renderSlides,
];

function fail(message) {
  process.stderr.write(`artifact gate failed: ${message}\n`);
  process.exitCode = 1;
}

function projectRoot(projectName) {
  if (!projectName || projectName === "." || projectName === ".." || /[\\/]/.test(projectName)) {
    throw new Error("project name must be one directory name without path separators");
  }
  const root = resolve(projectsRoot, projectName);
  if (!root.startsWith(`${projectsRoot}${sep}`)) {
    throw new Error("project path escapes projects/");
  }
  return root;
}

async function pathType(target) {
  try {
    return await lstat(target);
  } catch (error) {
    if (error?.code === "ENOENT") return null;
    throw error;
  }
}

async function walkFiles(root, current = root) {
  const info = await pathType(current);
  if (!info) return [];
  if (info.isFile()) return [current];
  if (!info.isDirectory()) return [];
  const entries = await readdir(current, { withFileTypes: true });
  const nested = await Promise.all(entries.map((entry) => walkFiles(root, resolve(current, entry.name))));
  return nested.flat();
}

async function validateJson(target, relativePath, options = {}) {
  try {
    const value = JSON.parse(await readFile(target, "utf8"));
    if (relativePath === paths.rfpStatus && value?.status !== "ready") {
      fail(`${relativePath} must contain status=ready`);
    }
    if (options.requireNoPendingInterviewUpdates && relativePath === paths.framework3c) {
      validateFramework3c(value, relativePath);
    }
    if (relativePath === paths.slideContents) {
      const items = value?.items;
      if (!Array.isArray(items) || items.length === 0) {
        fail(`${relativePath} must contain a non-empty items array`);
      }
    }
    if (relativePath === paths.slidePlan) {
      await validateSlidePlanVariants(value, relativePath);
    }
  } catch (error) {
    fail(`${relativePath} is not valid JSON: ${error.message}`);
  }
}

function validateFramework3c(value, relativePath) {
  const pending = value?._meta?.pending_interview_updates;
  if (pending != null) {
    if (!Array.isArray(pending)) {
      fail(`${relativePath} _meta.pending_interview_updates must be an array when present`);
    } else if (pending.length > 0) {
      fail(`${relativePath} has pending interview updates: ${pending.join(", ")}`);
    }
  }

  const bulletCount = ["customer", "company", "competitor"].reduce((sum, axis) => {
    const bullets = value?.[axis];
    return sum + (Array.isArray(bullets) ? bullets.length : 0);
  }, 0);
  if (bulletCount === 0) {
    fail(`${relativePath} has no 3C bullets (customer+company+competitor); complete the S1 interview first`);
  }
}

// Every component variant on a non-floor slide must be in that slide's
// intent allowed_variant_ids ∪ the catalog fallback pool (is_fallback variants) ∪
// the degraded FALLBACK_VARIANT_ID. Catches a variant borrowed across intent
// boundaries (e.g. staffing-status using a variant only allowed for track-record).
// validate_plan previously checked only global catalog membership, not allowed-list.
async function validateSlidePlanVariants(plan, relativePath) {
  const catInfo = await pathType(catalogPath);
  if (!catInfo?.isFile()) return; // catalog presence/JSON is gated separately
  let catalogBytes, catalog;
  try {
    catalogBytes = await readFile(catalogPath);            // raw bytes — hashed below
    catalog = JSON.parse(catalogBytes.toString("utf8"));
  } catch {
    return; // invalid catalog reported by its own validateJson
  }

  // The plan must carry the catalog's content fingerprint so S6 can abort on a
  // stale plan (render compares _meta.catalog_sha256 against the catalog it reads).
  // Checking it here surfaces "re-run S5" at the S5 gate instead of deep in the
  // render. SHA over the raw bytes matches loaders.catalog_sha256 (Python read_bytes).
  const expectedSha = createHash("sha256").update(catalogBytes).digest("hex");
  const stampedSha = plan?._meta?.catalog_sha256;
  if (!stampedSha) {
    fail(`${relativePath} _meta.catalog_sha256 is missing (S6 catalog-match check needs it)`);
  } else if (stampedSha !== expectedSha) {
    fail(`${relativePath} _meta.catalog_sha256 (${stampedSha.slice(0, 16)}…) != current catalog (${expectedSha.slice(0, 16)}…) — re-run S5`);
  }

  const allowedByIntent = new Map(
    (catalog.intents ?? []).map((i) => [i.id, new Set(i.allowed_variant_ids ?? [])]),
  );
  const fallbackPool = new Set(
    (catalog.variants ?? []).filter((v) => v?.is_fallback).map((v) => v.id),
  );
  for (const slide of Array.isArray(plan?.slides) ? plan.slides : []) {
    // No empty slides — every slide (body, floor, or front-matter) must carry at
    // least one component with a variant_id. This is S5's load-bearing guarantee
    // ("절대 빈 슬라이드 금지") and parallels render's verify_deck structural check.
    const hasComponent = (slide?.blocks ?? []).some(
      (b) => (b?.components ?? []).some((c) => c?.variant_id),
    );
    if (!hasComponent) {
      fail(`${relativePath} slide ${slide?.slide_number}: empty slide (no component with a variant_id)`);
    }

    const intentId = slide?.intent_id;
    if (intentId == null) continue; // floor slides are exempt from the allowed-list check
    const allowed = allowedByIntent.get(intentId);
    if (!allowed) {
      fail(`${relativePath} slide ${slide?.slide_number}: unknown intent_id '${intentId}'`);
      continue;
    }
    for (const block of slide?.blocks ?? []) {
      for (const comp of block?.components ?? []) {
        const vid = comp?.variant_id;
        if (!vid) continue;
        if (vid === FALLBACK_VARIANT_ID) continue;
        if (!allowed.has(vid) && !fallbackPool.has(vid)) {
          fail(
            `${relativePath} slide ${slide?.slide_number}: variant '${vid}' not in intent '${intentId}' allowed_variant_ids ∪ fallback pool`,
          );
        }
      }
    }
  }
}

async function validateRequired(root, key, options = {}) {
  if (key === "catalog") {
    const info = await pathType(catalogPath);
    if (!info?.isFile()) {
      fail("design-system/catalog.json must exist as a regular file");
      return;
    }
    await validateJson(catalogPath, "design-system/catalog.json", options);
    return;
  }

  const relativePath = paths[key];
  const target = resolve(root, relativePath);

  if (key === "references") {
    const files = await walkFiles(target);
    if (files.length === 0) fail(`${relativePath}/ must contain at least one regular file`);
    return;
  }

  if (key === "renderSlides") {
    const files = (await walkFiles(target)).filter((file) => file.toLowerCase().endsWith(".png"));
    if (files.length === 0) fail(`${relativePath}/ must contain at least one PNG file`);
    return;
  }

  const info = await pathType(target);
  if (!info?.isFile()) {
    fail(`${relativePath} must exist as a regular file`);
    return;
  }
  if (relativePath.endsWith(".json")) await validateJson(target, relativePath, options);
}

async function validateConventions(root) {
  if (await pathType(resolve(root, ".contrl"))) fail("legacy .contrl/ directory is forbidden");

  const scanDirs = ["artifacts", "inputs"];
  const allFiles = (await Promise.all(scanDirs.map((d) => walkFiles(resolve(root, d))))).flat();
  for (const file of allFiles) {
    const actual = relative(root, file).split(sep).join("/");
    const expected = reservedLocations.get(file.split(sep).at(-1));
    if (expected && actual !== expected) {
      fail(`${actual} uses a reserved artifact filename; expected ${expected}`);
    }
  }
}

async function initialize(projectName) {
  const root = projectRoot(projectName);
  await Promise.all(canonicalDirectories.map((path) => mkdir(resolve(root, path), { recursive: true })));
  process.stdout.write(`${relative(process.cwd(), root)} initialized\n`);
}

async function gate(projectName, stage, timing) {
  const root = projectRoot(projectName);
  if (!beforeRequirements[stage]) throw new Error("stage must be one of S0, S0A, S0B, S1..S6");
  if (timing !== "before" && timing !== "after") throw new Error("timing must be before or after");

  const rootInfo = await pathType(root);
  if (!rootInfo?.isDirectory()) {
    fail(`projects/${projectName}/ must exist as a directory`);
    return;
  }

  await validateConventions(root);
  const required = [...beforeRequirements[stage], ...(timing === "after" ? afterAdditions[stage] : [])];
  const requireNoPendingInterviewUpdates = stage === "S2" && timing === "before";
  for (const key of new Set(required)) {
    await validateRequired(root, key, { requireNoPendingInterviewUpdates });
  }

  if (!process.exitCode) process.stdout.write(`artifact gate passed: ${projectName} ${stage} ${timing}\n`);
}

const [command, projectName, stage, timing] = process.argv.slice(2);

try {
  if (command === "init") await initialize(projectName);
  else if (command === "gate") await gate(projectName, stage?.toUpperCase(), timing);
  else throw new Error("usage: validate-artifacts.mjs <init PROJECT | gate PROJECT S0|S0A|S0B|S1..S6 before|after>");
} catch (error) {
  fail(error.message);
}
