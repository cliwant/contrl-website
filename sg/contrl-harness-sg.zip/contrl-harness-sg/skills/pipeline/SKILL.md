---
name: pipeline
description: >-
  CONTRL proposal automation orchestrator. Runs all or part of the RFP → Interview → Win Theme → Theme Statements → Slide Contents → Slide Plan → Render workflow in dependency order.
  Use when the user asks to run CONTRL, generate a proposal workflow, continue to the next stage, rerun/update a stage, resume from existing artifacts, or execute a named pipeline stage.
---

# CONTRL 문서 자동화 실행

## Customer Delivery Defaults

For this branch, all user-facing outputs and artifacts must be written in English. If source documents are Korean or another language, translate or summarize their meaning into natural business English before writing artifacts, progress panels, slide text, or deck content.

For procurement pre-research, market scans, or bid-signal lookups, use Singapore public procurement as the default scope. Prefer the Cliwant global MCP Singapore/GeBIZ route (`mcp__global_cliwant.global_search_bids` with `region: "SG"`) and Singapore-only contact tools when available. Do not use Korea Nara Marketplace/KONEPS/G2B, Korea-focused `signals` procurement routes, or US/SAM.gov unless the user explicitly asks for that country context.

## 사용자 표시 문장 규칙

사용자에게 보이는 모든 메시지는 아래 규칙을 따른다. 적용 대상은 채팅 진행, 상태 보고, 선택지 제시, 막힘 안내, 완료 요약, 재실행 안내, 파일·결과 안내를 모두 포함한다.

1. **단계는 도메인 기능명으로만 부른다.** `S1`·`S2` 같은 코드나 "단계 N" 순번을 노출하지 않는다.
   S0a→RFP 분석 · S0b→RFP 요건 정리 · S1→전략 인터뷰 · S2→윈테마 만들기 · S3→섹션별 메시지 정리 · S4→슬라이드 구성 · S5→슬라이드 설계 · S6→슬라이드 만들기.
   슬라이드를 만드는 기본 경로는 **S5+S6 결합**이라, 다음 단계로 제시·실행할 땐 둘을 묶어 **"슬라이드 설계와 만들기"**로 부른다(설계-only/렌더-only는 명시 요청 시에만 개별 명칭).
2. **메커니즘이 아니라 상황을 말한다.** pipeline·workflow→"전체 진행"·"작업 흐름" / contract·계약·아티팩트 핸드오프 계약→"정해진 기준"·"결과를 이어받는 방식" / gate→"~할 준비가 됐는지 확인" / cascade·하위 삭제→"이걸 바꾸면 뒤 내용이 달라져서 영향받는 부분을 다시 만들게요" / fan-out→"여러 섹션을 동시에 작업 중이에요" / artifact·파일·경로→"결과"·"지금까지 만든 내용" / join·status 확인→"준비가 다 됐는지 확인하고 이어서" / orchestrator·runner·agent→호칭하지 않고 1인칭 "제가 ~하고 있어요". 막힘(gate 실패)은 "아직 ~가 안 끝나서 그것부터 마치고 진행할게요"처럼 **상황 + 다음 행동**으로 옮긴다.
3. **domain 용어는 유지한다.** Win Theme, 제안서, RFP, 슬라이드 등 사용자가 업무 맥락에서 이해할 수 있는 용어는 그대로 쓴다.
4. **3C는 약어로 먼저 말하지 않는다.** 첫 안내에서는 "고객이 원하는 것, 우리가 잘할 수 있는 것, 경쟁사와 다른 점을 정리하고 있어요"처럼 작업 의미를 말한다. 이후에는 "고객·자사·경쟁사 관점 정리"를 기본 표현으로 쓰고, 내부 식별이 필요할 때만 괄호로 `3C`를 덧붙인다.

CONTRL의 문서 자동화 흐름을 정해진 결과 연결 방식에 따라 단계적으로 진행한다.
각 스테이지는 `선행 아티팩트 검증(Gate) → 스테이지 실행 → 후행 아티팩트 write`.
실행 전에 `references/artifact-contract.md`를 읽고 canonical path를 그대로 사용한다.
각 스테이지는 매칭 skill이 소유한 prompt, schema, algorithm 기준을 그대로 사용한다.

## Stage Progression Guardrail

Default behavior is staged, not autopilot. Passing a gate proves that the next stage is technically ready; it is not permission to start the next stage.

- If the user asks to analyze an RFP, start a GeBIZ bid, start CONTRL, or "run CONTRL" without clearly asking for all stages, run only S0: source/reference preparation, RFP analysis, RFP extraction, `status.json`, and the initial `framework_3c.json`. Then stop and ask whether to start the Strategy Interview.
- After each later stage completes, stop and ask for explicit approval before starting the next stage: Strategy Interview → Win Themes → Theme Statements → Slide Contents → Slide Plan/Render.
- Do not generate `win_themes.json`, `theme_statements.json`, `slide_contents.json`, `slide_plan.json`, or `deck.pptx` merely because the previous gate passed.
- Full autopilot is allowed only when the user gives an unmistakable all-stage override such as "run everything", "run all stages", "continue through render without pausing", "full pipeline end-to-end", "다 진행해줘", or "끝까지 자동으로 진행해줘".
- When in doubt, stop at the current stage and ask. Stage confirmation should be treated as part of the user-facing workflow, not as an implementation detail.

S0 means pre-research and RFP analysis/extraction. It includes collecting the source packet and attachments, creating `analysis.md`, extracting `rfp.json` and `status.json`, and seeding `framework_3c.json`. S0 does not include Strategy Interview, Win Themes, Theme Statements, Slide Contents, Slide Plan, or Render.

## 실행 패턴 — 순차 핸드오프 + 선택적 background

스테이지는 `projects/{name}/artifacts/` 파일을 순서대로 이어받아 진행하고, 각 스테이지 내부 실행은 해당 skill 기준을 따른다. **stage runner는 동기 spawn이 기본**이며 S2~S5는 반환값을 inline으로 받는다. background(`run_in_background:true`)는 사용자 대기를 줄이는 세 경우 — 프로젝트 표시 준비·S0b·S1 내부 3C 갱신 — 에만 쓴다.

**S0b ‖ S1 병렬은 예외 경로:** S1 인터뷰는 사람이 답하는 멀티턴이라 대기가 길고, `rfp.json` 추출(S0b)은 S1의 하드 의존이 아니다(아래 게이트 그래프). 이 병렬화는 사용자가 Strategy Interview 시작을 이미 승인했거나 full autopilot override를 준 경우에만 사용한다. 기본 RFP 분석 요청에서는 S0a와 S0b를 끝낸 뒤 멈추고, S1을 자동으로 열지 않는다. 병렬 경로를 쓸 때만 `references/background-execution.md`의 spawn·join 절차를 읽고 따른다.

## 스테이지 ↔ 에이전트 ↔ 스킬 매핑

| Stage | Skill | Executor | Input artifacts → Output artifacts |
|------|------|---------|------------------------------|
| S0a 시드 | rfp-extraction | rfp-extraction-runner | references/source packet → `artifacts/strategy/framework_3c.json` (3C 시드) + `artifacts/rfp/analysis.md` (RFP 산문 분석) |
| S0b RFP 추출 | rfp-extraction | rfp-extraction-runner | references/source packet → `artifacts/rfp/{rfp,status}.json` |
| S1 인터뷰 | interview | main/orchestrator + framework-3c-updater(background) | 3C 시드 + `analysis.md` + optional `pre_research.json` → `artifacts/strategy/framework_3c.json`(갱신) |
| S2 Win Theme | win-themes | win-theme-runner | rfp+3c → `artifacts/strategy/win_themes.json` |
| S3 Theme Statement | theme-statements | theme-statement-runner(코디네이터) → theme-statement-group-runner(level-1 그룹) fan-out | +win → `artifacts/strategy/theme_statements.json` + rfp.requirement_mapping |
| S4 Slide Contents | slide-contents | slide-contents-runner → slide-group-runner(level-1 단원) 단원 단위 fan-out (섹션·슬라이드는 단원 안에서 한 패스 생성) | +ts → `artifacts/slides/slide_contents.json` |
| S5 Slide Plan | slide-plan | slide-planner(코디네이터) → 슬라이드별 서브에이전트 fan-out (flatten·layout_fills·cover_toc·make_floor·assemble 제공 스크립트 호출) | +contents+catalog → `artifacts/slides/slide_plan.json` |
| S6 렌더 | render | main/orchestrator (inline) | slide_plan + catalog → `artifacts/render/deck.pptx` + `artifacts/render/slides/*.png` |
| **S5↔S6 결합** *(기본)* | slide-plan + render | pipeline orchestrator가 `slide-planner`와 render fit을 per-slide로 교차 스케줄링 | contents+catalog → 슬라이드별 plan→seed→fit 파이프라인 → `slide_plan.json` + `deck.pptx`. 절차: `references/pipeline-render.md` |

## 진행 표시 — 통합 progress shell
스테이지별 결과 HTML을 **상단 메뉴바로 단계를 오가는 단일 창**으로 묶는다. 유저는 이 창 하나만 열어두면 단계가 지날 때마다 메뉴가 채워지고 결과가 누적된다.
- **단일 표면:** `projects/{name}/outputs/index.html`. 템플릿 `skills/pipeline/templates/contrl-shell.html`을 워크플로 진입 시 이 경로로 1회 복사(seed)한다. 파일명을 `index.html`로 두는 이유는 `outputs/`를 정적 서버 루트로 서빙할 때 루트(`http://localhost:PORT/`)가 곧 셸이 되게 하려는 것(디렉터리 인덱스 = index.html). 
- **세팅은 최소 동기 + background 표시 준비:** 디렉터리 `init`만 S0a 전에 동기로 완료한다(출력 경합 방지용 최소 준비). shell 복사 + 빈 downstream 패널 seed(S1·S2·S3·S4 렌더러를 입력 없이 각 1회 실행 → "아직 준비 안됨" 빈 상태)는 입력 아티팩트가 필요 없으므로 background로 띄우고 S0a 시작을 막지 않는다. S0 패널은 `rfp-extraction/scripts/render-s0-html.py`가 S0 완료 후 생성한다.
- **패널은 각 스테이지 skill 소유.** 각 렌더러가 자기 패널 HTML을 자기 IO 경로에 쓰기만 하고(skill은 shell을 몰라도 된다), shell이 그 경로를 iframe으로 끼워 보여준다. 단계↔menu id↔패널 경로 맵의 단일 소스는 shell 템플릿의 `STAGES` 배열이며, 패널 경로는 각 skill의 IO 경로를 그대로 가리킨다. 패널이 있는 스테이지는 Bid Detail·S0·S1·S2·S3·S4·**S6**(`STAGES` 참조), 그 외는 메뉴에 없다. S0 패널(`rfp/analysis.html`)은 S0 결과를 보여주고, `rfp/bid_detail.html`은 그 앞단의 selected bid detail을 보여준다. S6 패널(`render/slide_diagnostics.html`)은 각 슬라이드의 render를 그 plan 결정(catalog 조각)과 나란히 놓아 결함을 S5/S6로 localize하는 Slide diagnostics 표면이다(아래 "S5↔S6 결합 진행").
- **유저 안내(preview로 띄움):** 셸은 직접 파일로 열지 말고 **정적 서버로 띄워 preview에 보여준다** — orchestrator는 **각 phase에 진입할 때마다** `projects/{name}/outputs/`를 정적 서버 루트로 서빙해 preview에 표시해달라고 한다. 루트 index가 셸(index.html)이라 `http://localhost:PORT/`만으로 셸이 열리고, 같은 루트라 `STAGES`의 상대 패널 경로가 그대로 풀린다.

## Win Theme 선택 (S2↔S3 사이, orchestrator 책임)
S2 생성과 S3 사이의 Win Theme 선택은 유저 결정이라 에이전트가 아니라 orchestrator가 수행한다 — 생성·반환 → 결과 설명 → 선택 제시 → 기록 → 패널 렌더는 `win-theme-runner`를 다시 호출해 시킴 → resolve해 S3에 주입.
**S2를 마치고 선택을 진행할 때 `references/wintheme-selection.md`의 절차(생성→설명→선택→기록→패널 렌더→resolve)를 읽고 따른다.**

## 제안서 목차 확인 (S3 진입 직전, orchestrator 책임)
제안서 목차(`rfp.json`의 `required_proposal_structure`)는 S3 이후 모든 단계의 뼈대인데 추출이 틀리거나 누락될 수 있고, 잘못된 목차로 이어가면 뒤가 통째로 무효가 된다. 그래서 목차를 처음 소비하는 S3 직전에 멈춰 유저가 확인·보완하게 한다 — 목차를 **제안서 목차** 뷰(S3 패널)에 띄우고, 추출됨/식별 안됨에 따라 안내를 제시한 뒤 진행·수정·자료 전달을 받는다.
**Win Theme 선택을 마치고 S3 생성을 시작하기 전에 `references/rps-review.md`의 절차(재렌더·안내→분기→응답 해석→재확인 반복)를 읽고 따른다.** 이 확인을 통과하기 전에는 `theme-statement-runner`를 띄우지 않는다.

## S4 분량 모드 선택 + 편차 처리 (S4 전후, orchestrator 책임)
분량 모드의 의미·예산 산식·비교 스펙·`_meta` 계약은 `slide-contents` skill "분량 모드와 예산" 절에 있다. orchestrator는 모드 결정과 편차 후 유저 선택 흐름만 맡는다.

**모드 선택 (S4 진입 직전, runner spawn 전):**
1. **재실행이면 묻지 않는다** — 기존 `slide_contents.json` `_meta.slide_budget.mode`를 유지하고 5로 간다. 모드 변경은 유저가 명시적으로 요청할 때만이며, 변경은 S4 전체 재생성(+캐스케이드)이다.
2. `artifacts/rfp/rfp.json`의 `required_proposal_structure.page_limit`을 읽는다.
3. 값이 있으면 AskUserQuestion으로 모드를 묻는다 — "RFP의 페이지 제한(N장)에 맞춰 분량을 배분할까요(예산 모드), 섹션별 메시지 분량대로 자유롭게 만들까요(자유 모드)?" 예산 모드는 목표치라 정확히 N장이 아니라 비슷한 장수로 맞추고 큰 편차만 잡는다는 점을 함께 안내한다.
4. `null`이면 AskUserQuestion으로 목표 분량을 묻는다 — "RFP에서 페이지 제한을 찾지 못했습니다. 슬라이드를 몇 장 정도로 만들까요?" 선택지: **RFP에서 분량 정보 다시 찾아보기** / **분량 제약 없이 작성(자유 모드)**. 목표 장수 직접 입력은 Other로 받는다고 질문 문구에 안내한다. 유저 지정 값은 rfp.json을 덮어쓰지 않는다 — 본문 목표 산식과 `_meta` 기록(`source:"user"`)은 스킬 "분량 모드와 예산" 절을 따른다.
5. 결정한 모드(+예산 모드면 목표치 — rfp의 `page_limit` 또는 유저 지정 본문 목표)를 `slide-contents-runner` 호출 인자로 주입한다.

**편차 처리 (S4 완료 후):** runner 반환값의 compare 보고서(+미달 시 inventory 여력 보고서)를 본다.
`needs_review`가 아니면 목표/실제 요약만 전하고 다음 단계로 간다 — 기본은 보고다, 편차는 오류가 아니다.
**`needs_review`면 `references/deviation-review.md`의 절차(초과/미달 분기 → 여력 진단 기반 처방 제시 → 보강 인터뷰·재배분 → `deviation_groups` 재호출)를 읽고 따른다.**

## 디자인 템플릿 선택 (S5 진입 직전, orchestrator 책임)
S5부터는 design system(`design-system/catalog.json`)이 필수 입력인데, 처음 쓰는 작업 디렉터리에는 아예 없을 수 있고, 회사에 따라 보관 중인 템플릿이 여럿일 수도 있다. 그래서 슬라이드 설계(또는 결합 파이프라인)를 시작하기 직전 — `gate S5 before`를 돌리기 **전** — 어떤 디자인 템플릿으로 만들지 유저가 결정하게 한다. 게이트는 검증이지 선택 UI가 아니다: 유저가 인터뷰·슬라이드 구성까지 다 마친 뒤에야 "catalog가 없다"는 게이트 에러로 처음 알게 되는 흐름을 만들지 않는다.

**선택 절차 (첫 S5 진입 시, runner spawn 전):**
1. **재실행이면 묻지 않는다** — 기존 `slide_plan.json`의 `_meta.catalog_sha256`가 현재 catalog와 일치하면 같은 템플릿으로 계속 간다. 템플릿 변경은 유저가 명시적으로 요청할 때만이며, 변경은 S5·S6 전체 재생성(캐스케이드)이다.
2. 사용 가능한 디자인 템플릿을 조사한다 — canonical `design-system/catalog.json`과, 있으면 `design-system/*/catalog.json`(하위 폴더 보관본)을 스캔해 이름·출처를 수집한다.
3. AskUserQuestion으로 두 갈래를 제시한다:
   - **옵션 1 (기본): 현재 디자인 템플릿 사용** — 스캔에서 찾은 템플릿(들)을 이름으로 나열해 그중 고르게 한다. 하나뿐이면 그 하나를 기본 선택지로 제시한다.
   - **옵션 2: 내 PPTX로 새 디자인 템플릿 만들기** — 회사 제안서 PPTX 템플릿 파일을 업로드하거나 파일 경로를 알려 달라고 질문 문구에 안내한다.
4. **옵션 2를 고르면:** 받은 PPTX를 `extract-design-system` 스킬로 추출하고, 산출물 중 스킬 소비 항목(`catalog.json`·`frame/`·`variants/`·`adornments/`·`media/`)을 `design-system/` canonical 경로에 배치한다(기존 catalog가 있으면 덮어쓰기 전에 하위 폴더로 보존). 추출은 수 분 이상 걸리는 작업임을 시작 전에 알린다.
5. **하위 폴더 보관본을 고르면** canonical 경로가 그 보관본의 스킬 소비 항목을 가리키게 배치한다.
6. 선택·배치가 끝난 뒤에야 `gate S5 before`를 실행한다. 게이트가 실패하면 배치 결과를 점검하고 유저에게 상황+다음 행동으로 알린다.

**스캔 결과가 하나도 없으면** 옵션 1을 빼고, "아직 디자인 템플릿이 없습니다 — 회사 제안서 PPTX 템플릿을 주시면 그걸로 디자인 시스템을 만들어 시작할게요"로 옵션 2를 기본 경로로 안내한다.

## S5↔S6 결합 진행 (per-slide 파이프라인, **기본 경로**, orchestrator 책임)
S5(슬라이드 설계)와 S6(렌더)는 **기본적으로 슬라이드 단위 파이프라인으로 교차 진행**한다 — S6가 모든 슬라이드의 S5 완료를 기다리지 않고, S5가 한 슬라이드를 끝내는 즉시 그 슬라이드를 렌더로 흘려보내며 뒤 슬라이드는 계속 설계한다. 합산 대기시간을 줄이고, N장 단위로 점진 검토(+자연어 피드백)를 받는다. **S5만/ S6만 따로 돌리는 건 유저가 명시적으로 요청할 때만**(둘 다 단독 실행 가능, 두 스킬·계약은 분리 유지 — 교차 진행만 orchestrator가 더한다).
**슬라이드 설계 후 렌더로 이어질 때(또는 결합 실행을 시작할 때) `references/pipeline-render.md`의 절차(선계산→두 풀 스케줄러→N장 일시정지·점진 검토·피드백→덱 마무리)를 읽고 따른다.**

**다음 단계 제시는 결합이 기본이다.** S4(슬라이드 구성)를 마친 뒤 다음 단계를 유저에게 물을 때 'S5 슬라이드 설계'만 제시하지 말고 **"슬라이드 설계와 만들기(렌더)를 이어서 진행할까요?"로 결합 파이프라인을 기본값으로 제시**한다. 유저가 승낙하거나 "슬라이드 플랜/설계 시작" 류로 답하면 **디자인 템플릿 선택(위 절)을 먼저 통과시킨 뒤 곧장 결합 파이프라인(`pipeline-render.md`)을 실행**한다 — 설계(S5)만 하고 멈추지 않는다. S5 단독(설계까지만)·S6 단독(기존 slide_plan으로 렌더만)은 유저가 **명시적으로** 요청할 때만.

## 게이트 그래프 (의존성 = 실행 순서)

각 스테이지 실행 전·후에 공통 gate command를 실행한다.
스크립트는 이 SKILL.md와 같은 디렉터리의 `scripts/validate-artifacts.mjs`다.
실행 시 이 파일의 절대 경로를 기준으로 스크립트 경로를 계산해 **절대 경로**로 호출한다
(CWD가 유저 레포이므로 상대 경로 `scripts/...`는 동작하지 않음).

```
node "<이 SKILL.md 디렉터리의 절대 경로>/scripts/validate-artifacts.mjs" gate <project-name> <stage> before
# stage 실행 및 canonical path에 저장
node "<이 SKILL.md 디렉터리의 절대 경로>/scripts/validate-artifacts.mjs" gate <project-name> <stage> after
```

`before` 실패 시 선행 스테이지를 먼저 실행한다.
`after` 실패 시 실행 성공으로 보고하지 않고 다음 스테이지로 넘어가지 않는다.
경로·파일명·존재·JSON 문법 검증은 반드시 이 command의 결과를 사용한다.

순차 흐름에서는 직전 `after`와 중복되는 `before`를 생략한다 — **진입 스테이지와 S2·S5 before는 항상 실행**하고 나머지 비-진입 `before`는 직전 `after`로 갈음한다. **`before` gate 호출 시점은 `references/artifact-contract.md`의 "before gate 호출 시점"을 읽고 따른다.**

**핵심 의존성 (S0 분리):**
- `S1 before`는 `framework_3c.json`(3C 시드) + `analysis.md`(RFP 산문 분석)를 요구한다 — `rfp.json` 아님. `pre_research.json`이 있으면 S1 질문/요약의 optional enrichment로 반드시 주입한다. S1 오프닝은 S0a가 만든 `analysis.md`를 그대로 제시하므로 RFP를 다시 읽지 않는다.
- `S2 before`가 `rfp.json` + `status.json`을 요구하고, `framework_3c.json`의 `_meta.pending_interview_updates`가 비어 있으며 **3C 세 축(customer+company+competitor) bullet 합 > 0**임을 요구한다 → 백그라운드 S0b와 S1 3C 갱신이 늦어도 S2 진입 전에 끝나야 하고, 인터뷰 결과가 빈 3C로는 S2에 진입할 수 없음을 강제한다.
- `S0` alias는 두 sub-stage(S0a+S0b)가 모두 끝났는지 한 번에 확인할 때만 쓴다.
- 기본 초기 실행은 `S0` alias 통과 후 멈춘다. `S1 before` 통과는 인터뷰를 시작할 준비가 됐다는 뜻일 뿐, 인터뷰 시작 허가가 아니다.

## 캐스케이드 규칙 (부분 재실행 시 필수)
상위 산출물을 재생성하면 하위가 무효화되므로, **재생성·선택 변경 전에 orchestrator 단독으로 하위 아티팩트를 삭제**한다 (runner·skill 아님). **부분 재실행·재생성·선택 변경을 다룰 때 `references/cascade-rules.md`의 스테이지별 무효화 매핑을 읽고 그대로 삭제한다.**

## Phase 1: 컨텍스트 확인 (초기/후속/부분 재실행 판별)
워크플로 시작 시 `projects/{name}/artifacts/`의 기존 아티팩트를 조사해 실행 모드(초기·이어서·부분 재실행·새 입력)를 정하고 해당 진입점부터 실행한다. **시작할 때 `references/execution-modes.md`를 읽고 모드를 판별한다.**

## 테스트 시나리오
- **기본 초기 흐름:** `init`(동기) + 표시 준비(background) → S0a → S0b → `gate S0 after` → 멈춤 → S0 결과와 다음 가능 작업(Strategy Interview 시작)을 보고. 여기서 S1, S2, S3, S4, S5, S6 산출물을 만들면 실패다.
- **명시적 전체 진행 흐름:** full autopilot override가 있을 때만 `init`(동기) + 표시 준비(background) → S0a → [S0b background ‖ S1 인터뷰] → S2 직전 join → S2 → Win Theme 선택·기록·패널 렌더 → **제안서 목차 확인**(S3 직전 pause·재렌더·확인) → S3 → S4 → **디자인 템플릿 선택**(S5 직전 pause — 현재 템플릿 사용 vs 내 PPTX로 추출) → **S5↔S6 결합 파이프라인**(슬라이드별 plan→seed→fit, N장마다 일시정지·점진 검토·피드백) → `slide_plan.json` + `deck.pptx`. 각 단계 후 후행 아티팩트 존재 + 스키마 검증. 메뉴 게이팅은 패널의 `ready` 보고가 처리한다(orchestrator 별도 stamp 없음).
- **결합 파이프라인:** S5 첫 슬라이드 완료 즉시 S6가 그 슬라이드 fit 시작, 뒤 슬라이드는 계속 설계(오버랩). N번째 `fit_done`마다 미리보기 패널이 차고 일시정지 → 검토/피드백 → 재개. 마지막 `fit_done` 뒤에만 최종 assemble→package→verify→복사. `slide_plan.json`·`deck.pptx` 둘 다 산출.
- **백그라운드 join:** S1 인터뷰 종료 시점에 S0b 또는 S1 pending 3C 갱신이 아직 안 끝남 → S2 진입을 막고 완료를 기다린 뒤 `gate S2 before` 재검증 → 통과하면 S2 진행.
- **에러 흐름:** S2 실행 시 framework_3c 비어있음 → `framework_3c_missing` 보고, S1 인터뷰를 먼저 완료하도록 안내 (S3로 진행하지 않음). S0b 추출 실패 시 인터뷰 결과 (갱신 3C)는 보존하고 S0b만 1회 재시도.
- **제안서 목차 확인:** Win Theme 선택 후 S3 직전 → S3 패널 재렌더로 **제안서 목차** 뷰에 목차 표시 + 메뉴 켜짐. 분기는 `sections` 유무로만 정하고 정해진 두 문장만 제시한다(추천 목차 합성·제시 없음). (a) 목차 있음(내용 정상) → 완료 안내 → 유저 "진행" → S3 실행. (b) 목차 있음이지만 내용이 틀림(예: 제출 서류 목록이 추출됨) → 정합성 판정·추천 목차 합성 없이 그대로 **있음** 안내 → 유저가 국소 수정은 `rps-edit`, 통째 교체는 올바른 목차 서술/자료 전달로 `rps-extract` → 재확인 → 진행. (c) 목차 없음(`sections` 빈 배열) → 식별 안됨 안내(진행 미제시) → 유저가 PDF 참고 자료 전달 → `rps-extract`(파일 소스, docx/hwp면 PDF 변환 요청) → 목차 채워짐 → 재확인 → S3. (d) 목차 없음 → 유저가 채팅으로 목차를 통째로 불러줌 → `rps-extract`(유저 텍스트 소스 — 같은 절차 2 추출, 형식 제약 없음, 편집 아님) → 재확인 → S3.
- **부분 재실행:** win_theme 선택 변경 → theme_statements/slide_contents 캐스케이드 삭제 후 S3부터 재실행.
- **S4 분량 모드:** page_limit 있는 RFP → S4 직전 모드 질문 → 예산 모드 선택 → 완료 후 compare `needs_review`(미달) → inventory 여력 진단 → 여력 있는 단원은 재료 재주입 재생성, 여력 없는 단원은 보강 인터뷰(답변 = 재생성 힌트 + 3C background 적재) 또는 재배분(absorb + 수혜 단원 확장) → 처방 정해진 단원만 재실행 → 재비교 통과(재배분 후 잔여 미달은 보고만).
