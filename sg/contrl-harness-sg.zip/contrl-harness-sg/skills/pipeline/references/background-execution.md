# S0b 백그라운드 실행 프로토콜

`pipeline` 오케스트레이터가 S1을 시작할 명시적 허가를 이미 받은 경우에만 쓰는 spawn·join 절차다. 기본 RFP 분석 요청에서는 S0a와 S0b를 완료한 뒤 멈추며, 이 문서의 S1 병렬 절차를 사용하지 않는다.

사용 가능한 경우:

- The user explicitly approved starting the Strategy Interview while S0b completes.
- The user gave a full autopilot override such as "run everything", "run all stages", "continue through render without pausing", "full pipeline end-to-end", "다 진행해줘", or "끝까지 자동으로 진행해줘".

이 경우에는 S0a가 끝난 뒤 S2 진입 전까지 `rfp.json`만 마련되면 되고, 그 사이 S1 인터뷰가 사람을 기다리므로 S0b를 병렬로 돌린다.

1. **프로젝트 최소 준비 (동기):** `validate-artifacts.mjs init {project}`로 canonical directory만 먼저 만든다. 이 작업은 출력 경합을 피하기 위한 최소 준비이므로 S0a 전에 끝낸다.
2. **표시 준비 spawn (백그라운드):** 셸 복사(`outputs/index.html`)와 S1·S2·S3·S4 빈 패널 seed를 background로 시작한다. 이 작업은 입력 아티팩트가 필요 없으므로 S0a를 기다리게 하지 않는다. 셸을 preview로 띄워야 하는 시점에 셸 파일이 아직 없으면 셸 복사까지만 join하고, 빈 패널 seed는 계속 background로 둔다.
3. **S0a (동기):** 표시 준비 반환을 기다리지 않고 `rfp-extraction-runner`로 reference 텍스트 1회 추출 + 3C 시드 + `analysis.md`(RFP 산문 분석) 생성 → `gate S0A after` 통과. 추출한 raw 텍스트를 S0b가 재사용하도록 보존한다. S1 허가가 있는 이 예외 경로에서는 runner 반환값의 `analysis.md` 경로를 S1 오프닝에 넘긴다.
4. **S0b spawn (백그라운드):** `rfp-extraction-runner`를 `run_in_background:true`로 호출해 `rfp.json`(+`status.json`) 추출을 시작한다. 반환을 기다리지 않는다. S0b는 완료돼도 orchestrator에 반환하지 않고 디스크에만 silent하게 쓰므로, join은 `status.json` 존재로만 판단한다.
5. **S1 (포그라운드):** main/orchestrator가 `interview` skill로 인터뷰를 직접 진행한다. 오프닝은 S0a가 만든 `analysis.md`를 `<rfp_analysis>`로 주입해 그대로 제시한다(재추출·재분석 없음). `pre_research.json`이 있으면 `<pre_research_context>`로 함께 주입해 발주처 뉴스, 과거 유사 발주, 수주사/경쟁 신호, topic trends가 첫 질문의 가설과 후속 요약에 자동 반영되게 한다. `rfp.json`은 아직 없을 수 있으므로 후속 턴의 **선택적** enrichment로 취급 — 있으면 주입, 없으면 3C 시드로 진행. 각 user 답변을 받은 뒤에는 다음 질문을 먼저 생성하고, 방금 받은 답변의 3C 반영만 `framework-3c-updater`로 background 실행한다.
6. **Join (S2 직전):** `gate S2 before`로 `rfp.json`+`status.json` 존재와 `framework_3c.json`의 pending 3C 갱신이 없음을 확인한다. S0b가 아직 안 끝났거나 S1 3C background 작업이 남아 있으면 해당 백그라운드 작업 완료를 기다린 뒤 게이트를 재검증한다. S0b가 실패했으면 그때 S0b만 재시도(1회) — 인터뷰 결과(S1 갱신 3C)는 버리지 않는다. S1 3C 갱신이 실패했으면 인터뷰 결과는 보존하되 `_meta.last_failed_input`을 남기고 pending 목록은 정리한 뒤 재검증한다. 표시 준비는 S2의 하드 의존이 아니지만, 사용자에게 화면을 열어야 하는 순간에는 shell 파일 존재까지만 확인한다.

부분/이어서 실행이라 `rfp.json`이 이미 있으면 S0b spawn을 건너뛴다. S1을 건너뛰는 실행(예: S2부터 재시작)이면 병렬화 이득이 없으므로 S0b를 동기로 실행해도 된다.
