# S5↔S6 per-slide 파이프라인 (orchestrator 책임, 기본 경로)

`pipeline` 오케스트레이터가 **S5(슬라이드 설계)와 S6(슬라이드 만들기)를 슬라이드 단위로 파이프라인**할 때 따르는 절차. 목적은 단 하나 — **S6가 모든 슬라이드의 S5 완료를 기다리지 않게 한다.** S5가 한 슬라이드를 끝내는 즉시 그 슬라이드는 S6로 흘러가고, 뒤 슬라이드는 계속 설계된다. 그래서 (1) S5+S6 합산 대기시간이 줄고 (2) 유저가 덱 전체가 아니라 **N장 단위로** 렌더 결과를 점진 검토할 수 있다.

> **S5와 S6는 그대로 분리된 스테이지다.** 둘을 하나의 거대 스테이지로 합치지 않는다. 각자 자기 스킬(`slide-plan`/`render`)·에이전트·계약을 그대로 유지하고, **둘 다 단독 실행 가능**하다(S6는 완성된 `slide_plan.json`으로 비파이프라인 실행 가능). 이 문서가 정의하는 건 **두 스테이지 사이의 배리어를 없애는 교차 진행(interleave)뿐**이며, 그건 정의상 orchestrator(cross-stage) 책임이다. 프롬프트·스키마·IO·검증의 단일 출처는 여전히 두 스킬이다 — 여기서 재서술하지 않고 호출한다.

**이 결합 파이프라인이 S5→S6의 기본 경로다.** 슬라이드 설계까지 끝낸 흐름이 이어서 렌더로 갈 때, 별도 요청이 없으면 이 모드로 진행한다. **S5만 또는 S6만 따로 돌리는 건 유저가 명시적으로 요청할 때만** 한다(예: "설계까지만", "이미 만든 slide_plan으로 렌더만"). 따로 돌릴 때는 각 스킬의 단독 실행 경로를 그대로 쓴다.

## 진입 전제

- `gate S5 before`가 요구하는 입력(`slide_contents.json` + catalog)이 준비돼 있어야 한다. S5 진입 게이트는 orchestrator가 검증한다(러너 재검증 안 함).
- **카탈로그 SHA:** 실행 시작 시 라이브 `design-system/catalog.json`의 SHA를 1회 계산해 고정한다(`loaders.catalog_sha256`). 카탈로그는 런 내내 동결. **결합 모드엔 시작 시점에 비교 대상 `slide_plan.json`이 아직 없으므로** S6 Stage-0의 "`plan._meta.catalog_sha256` 대조" 가드는 그대로는 못 돈다 — 끝단 `assemble.py`가 같은 SHA를 plan에 스탬프하고, 그 정합은 `gate S5 after`/`gate S6 after`가 본다.
- `render` Stage 0는 **venv·soffice 확인만** 수행한다. **`gate S6 before`는 결합 모드에서 실행하지 않는다** — 그 게이트는 `slide_plan.json`을 요구하는데 그건 끝단에만 생긴다. S6 입력 정합은 `gate S5 after`(= 완성된 plan) + 끝단 `gate S6 after`로 갈음한다. (단독 S6 실행에서는 평소대로 `gate S6 before`를 돈다.)
- **per-slide 검증 (deck 게이트의 슬라이드 단위 대체):** 결합 모드엔 전체 plan이 끝까지 없어 deck-level `gate S5 after`/`gate S6 before`를 미드런에 못 돌린다. 대신 **각 슬라이드가 seed될 때 `assemble_slide`가 `validate_admission`을 돌려** 그 슬라이드를 검사한다(검사 집합은 `render/SKILL.md` Stage 2가 소유 — 표지·목차 포함 **모든** 슬라이드에 적용). deck-level 보장(`_meta.catalog_sha256` 대조 등)은 끝단 `gate S5 after`가 backstop으로 본다.

## 셋업 — 결정론 선계산 (런 시작 시 1회)

1. **flatten** — `flatten.py --contents <slide_contents.json> --split-dir <.plan> --out <flatten.json>`로 절대 인덱스 `input_slides`(0..N-1)를 편다(작업목록·순서). `--out` 매니페스트는 다음 단계의 TOC 페이지 해석 입력이다.
2. **front-matter** — `cover_toc.py … --input-slides <flatten.json>`로 cover+TOC front-matter(`cover_toc.json`)를 만든다. **결정론이라 지금 계산 가능.** `--input-slides`를 줘야 **TOC 페이지 번호가 flatten 순서로 채워진다**(각 장 첫 슬라이드 번호; 안 주면 빈칸). `front_matter_count`는 `cover_toc.json`의 `front_matter_count`를 그대로 읽는다 — 표지·목차는 각각 skip될 수 있어 **0·1·2 중 하나다(2로 가정 금지).**
3. **번호 규칙 확정** — 본문 슬라이드(인덱스 `i`)의 **절대 `slide_number = front_matter_count + i + 1`**. flatten 순서와 front_matter_count가 둘 다 지금 알려져 있으므로, 각 슬라이드의 최종 번호는 S5/S6 시작 전에 결정된다. (이 번호를 `assemble_slide --plan-slide --slide-number`로 넘긴다.)
4. **렌더 런 디렉터리** `$RUN = projects/{name}/outputs/render/{run_label}` 와 `$RUN/slides/`를 만든다.
5. **진단 패널 seed** — `render/references/review-loop.md` "리뷰 표면 + 셋업"의 seed 절차를 그대로 1회 실행한다(seed 커맨드·플래그·no-clobber 규칙은 그 문서에만 적고 여기 재서술하지 않는다). shell의 probe iframe이 404 나지 않게(S1~S4 패널 seed와 동일). 이 시점엔 render가 없어 패널은 `ready:false`를 보고하므로 메뉴는 dim으로 유지된다. 진행 표시 셸은 기존대로 `outputs/`를 정적 서버로 띄워 보여준다.
6. **표지·목차 up-front seed** — cover/TOC는 `.plan` 레코드가 없으니 제공 스크립트로 한 번에 seed한다: `assemble_slide.py --ds "$DS" --front-matter <cover_toc.json> --run "$RUN"`. 이 모드가 `cover_toc.json` 엔트리에 `slide_number`를 1..front_matter_count로 박아 seed한다 — **손으로 미니 plan을 만들지 않고(레코드 verbatim 원칙 유지)**, 엔트리 수가 0·1·2 어느 쪽이든 그대로 처리한다(`master_fills`는 빈 [] — 아래 "master_fills" 참고). seed된 표지·목차는 FIT 풀 첫 디스패치로 렌더돼 패널·N 카운트에 포함되고, 끝단 package/verify가 `slides/01`(·`slides/02`)를 찾는다.

## 리뷰 UX — 공용 루프 참조

**진입 질문(점진/일괄) · N장 일시정지 · 일시정지 질문 · 자연어 피드백 · 진단 패널 · 최종 전체 리뷰는 단독 S6와 공용이다 — 단일 출처 `render/references/review-loop.md`를 읽고 그대로 따른다. 결합 파이프라인은 그 위에 **아래 결합 고유분만** 더한다: 슬라이드별 seed 소스가 `--plan-slide`(S5 레코드)라는 점, PLAN 풀이 동시에 앞 슬라이드를 설계한다는 점(두 풀 스케줄러), 표지·목차 up-front seed(셋업 6), `failed` 레코드 deferred + 끝단 floor(아래).

## 슬라이드 상태기계

각 본문 슬라이드는 `pending → planned → seeded → fitting → fit_done`. **상태는 전부 디스크에서 판정**한다(resume free):

- `planned` — `artifacts/slides/.plan/slide_{i}.json` 존재(`status ∈ {ok, fallback, failed}`). S5 슬라이드별 서브에이전트의 산출물(= `slide-plan` 스킬 계약). 단, **`failed`/누락 레코드는 미드런에서 seed하지 않는다** — 아래 "floor 처리" 참고.
- `seeded` — `assemble_slide.py --plan-slide` 가 `slides/<n>/{filled.xml, adjusted.xml(seed), block_meta.json, …}` 를 씀(초 단위, 기계적).
- `fit_done` — `slides/<n>/status.json` 존재. fit 서브에이전트 완료 마커(= `render` 스킬 Stage 3 계약과 동일).
- **표지·목차(slide_number 1·2)** — `.plan` 없이 셋업에서 `--front-matter` 경로로 seed돼 본문과 똑같이 fit→`fit_done`. 카운트·패널·N 정지에 포함된다.

## 두 풀 스케줄러 (분리 유지가 핵심)

서브에이전트가 두 종류이고 **자원이 다르다 — 절대 한 풀로 합치지 않는다:**

- **PLAN 풀** — LLM만. S5 슬라이드별 설계 서브에이전트. 동시 ≤4, 연속 top-up(= `slide-planner` 계약).
- **FIT 풀** — LLM **+ 로컬 soffice**(`render_slide.py`가 호출). soffice가 로컬 CPU 자원이라 PLAN과 따로 둔다. 디스패치·top-up·동시 예산·refit 슬롯 공유·freed-slot 우선순위는 `render/references/review-loop.md` §FIT 디스패치가 소유한다.

orchestrator는 두 풀 다 **백그라운드 + 연속 top-up**으로 돌린다 — FIT 풀은 `review-loop.md` §FIT 디스패치의 메커니즘(상한까지 채우고 하나 끝나는 즉시 다음) 그대로, PLAN 풀도 같은 패턴(상한·top-up = `slide-planner` 계약). 결합 고유의 이득: PLAN과 FIT은 자원이 안 겹치므로 **슬라이드 K를 fit하는 동안 K+1·K+2…가 이미 planned**된다 — 유저가 원한 교차 파이프라인이다. S5 설계는 슬라이드 격리라 planned면 곧장 렌더 가능(순서 제약은 슬라이드별 plan→seed→fit뿐).

top-up 규칙 (이벤트 구동 — 폴링·배리어 아님):
1. PLAN 풀에 여유가 생기면 `pending`을 인덱스 오름차순으로 상한까지 백그라운드 디스패치한다.
2. PLAN 서브에이전트가 **하나 완료될 때마다** 그 `planned`(ok/fallback) 슬라이드를 즉시 inline seed한다: `assemble_slide.py --ds "$DS" --plan-slide "artifacts/slides/.plan/slide_{i}.json" --run "$RUN" --slide-number <front_matter_count + i + 1>`. (초 단위라 inline 직렬로 충분.) **`master_fills`는 빈 [] 로 둔다(의도적) — 마스터/푸터/페이지번호 fill은 끝단 `package_deck`(Stage 4)이 주입하므로 per-slide seed(및 표지·목차 seed)엔 `--master-fills`를 넘기지 않는다.**
3. FIT 풀에 여유가 생기면 `seeded`를 slide_number 오름차순으로 상한까지 띄우고, **FIT 하나가 완료될 때마다 다음 `seeded`를 띄운다.** FIT 디스패치·N 일시정지·질문·피드백·패널은 `render/references/review-loop.md`를 따른다(표지·목차 1·2가 가장 먼저 fit). 결합 모드는 일시정지 중에도 **PLAN을 계속 돌려** 앞 슬라이드를 미리 설계한다(단독 S6엔 PLAN 없음).

## floor/failed 레코드 처리

`--plan-slide`는 ok/fallback 레코드만 seed한다(fallback = intent_id null 포함, floor 슬라이드로 정상 처리). **재시도 vs defer 구분:** PLAN 서브에이전트 **호출 자체가** transient 실패(크래시·게이트웨이)면 orchestrator가 1회 재디스패치한다("에러는 1회 재시도"). 반면 서브에이전트가 `status:"failed"`로 **정상 반환**(이미 자기 transient 재시도를 소진)했거나 레코드가 누락이면 재시도 없이 **미드런 deferred**로 둔다(미드런엔 floor를 만들 input-slide 맥락이 없다 — flooring은 끝단 `assemble.py`의 일). 둘 다 silent drop 금지 — 실패 인덱스를 보고하고, 끝단에서 floor+렌더한다(아래).

## 덱 레벨 마무리 (마지막 슬라이드가 `fit_done` 된 뒤 1회)

본문 전부가 `fit_done`(또는 cap에서 flagged) 되고 **refit finalize 게이트**를 통과할 때 1회 돈다 — 게이트 규칙은 `review-loop.md`(최종 산출물 절)가, 검사 커맨드·출력 형식은 `record_round.py --help`가 소유한다. 진행 중 refit이 있으면 완료를 기다렸다 마무리한다.

1. **최종 `slide_plan.json`** — `slide-plan` 스킬의 `assemble.py`로 `.plan/` 레코드 전체를 정상 마감한다(failed/누락은 여기서 floor, front-matter prepend, 절대 번호, `_meta`+SHA). 이게 권위 아티팩트다. `gate S5 after` 실행. (S5 산출 계약은 그대로 — 미드런 미러 파일을 따로 만들지 않는다.)
2. **deferred(floored) 슬라이드 마저 렌더** — 1에서 floor된, 아직 `slides/<n>/`가 없는 슬라이드를 비파이프라인 경로로 seed+fit한다: `assemble_slide.py --plan "$PLAN" --slide <n>` → fit 서브에이전트. 그래야 덱이 빈 구멍 없이 완성된다. (표지·목차는 셋업에서 이미 렌더됨.)
3. **package** — `render` 스킬 Stage 4 `package_deck.py --run "$RUN"`. (모든 `slides/<n>/`가 있어야 하는 자연 배리어. `block_meta.slide_number` 순.)
4. **verify** — Stage 5 `verify_deck.py --run "$RUN"`. PASS 아니면 Stage 6로 가지 않고 실패 항목 보고.
5. **artifact copy + 게이트** — Stage 6(복사) 후 `gate S6 after`.

> **일시정지는 완료가 아니다.** 덱 마무리(package/verify/게이트)는 **마지막** 슬라이드가 `fit_done` 된 뒤에만 돈다 — N장 일시정지에서 절대 돌리지 않는다. 일시정지 중인 런은 부분 `slides/`에 최종 `slide_plan.json`/`deck.pptx`가 없으므로, `gate S6 after`·`validate-artifacts.mjs`를 그 반쯤 만든 트리에 돌리지 않는다. (백그라운드 refit drain은 위 finalize 게이트가 보장한다.)

## Resume

상태가 전부 디스크에 있다(`.plan/slide_{i}.json` = S5 내구성, `adjusted.xml`/`status.json` = S6 idempotence). 재시작 시 orchestrator는 먼저 `review-loop.md` §재개의 선행 절차(reconcile → 재-offer 두 갈래)를 그대로 수행한 뒤, 각 슬라이드 상태를 디스크에서 다시 계산하고 `pending`/`seeded`인 것부터 이어간다. fit_done 카운트도 디스크에서 센다.

## 에러·캐스케이드

- **에러는 1회 재시도 후 보고**(스킬이 다른 횟수를 명시하면 그 횟수). 부분 실패는 silent drop 금지 — 실패 슬라이드 목록을 보고한다. 다음 진행 판단은 orchestrator 몫.
- **캐스케이드는 기존 규칙 그대로**(`cascade-rules.md`). 파이프라인 런을 재시작/부분 재실행할 때 하위 아티팩트 무효화는 orchestrator 단독으로 수행한다.

## 리스크 (운영 주의)

- **soffice 경합(최상위):** FIT 풀에만 soffice budget을 두고 PLAN 풀과 분리한다(수치는 `review-loop.md` §FIT 디스패치). 안 그러면 render→look→fix 루프가 서로 자원을 빼앗아 thrash한다. PLAN(soffice 없음)은 더 넓게 돌려도 된다.
- **refit 공유 예산:** `review-loop.md` §FIT 디스패치 소유 — 마무리 전 drain은 finalize 게이트가 보장한다.
- **덱 배리어:** package/verify는 전 슬라이드 필요 — 위 "마무리" 배리어를 지킨다.