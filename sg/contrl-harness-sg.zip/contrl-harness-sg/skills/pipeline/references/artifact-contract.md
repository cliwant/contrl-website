# Artifact Contract

프로젝트별 데이터는 작업 디렉터리(실행 시점 CWD)의 `projects/{name}/` 아래에 둔다. `{name}`은 경로 구분자를 포함하지 않는 단일 directory name이다. `.contrl/`은 만들거나 읽지 않는다.

design system은 프로젝트별 데이터가 아니라 여러 프로젝트가 공유하는 외부 입력이므로, `projects/`와 나란한 `design-system/` 폴더에 둔다 — 회사당 하나, 고정 경로, 모든 프로젝트가 같은 한 부를 읽는다.

## Canonical layout

```text
<작업 디렉터리>/                      # contrl 실행 위치 (실행 시점 CWD)
├── design-system/                   # 회사 하나의 공유 design system
│   ├── catalog.json                 # selection index: variants/layouts/intents/adornments
│   ├── frame/                       # master·layout·theme·media inheritance bundle
│   ├── variants/<id>/               # shapes.xml (+ shapes.xml.rels, preview.png)
│   ├── adornments/<id>/             # shapes.xml (+ shapes.xml.rels, preview.png)
│   └── media/                       # shapes.xml.rels가 참조하는 공유 media 풀
└── projects/{name}/                 # per-project — 제안 건마다 따로
    ├── inputs/
    │   └── references/              # RFP PDF/DOCX and other source files
    └── artifacts/
        ├── rfp/
        │   ├── rfp.json
        │   ├── analysis.md
        │   └── status.json
        ├── strategy/
        │   ├── framework_3c.json
        │   ├── win_themes.json
        │   └── theme_statements.json
        ├── slides/
        │   ├── slide_contents.json
        │   └── slide_plan.json
        └── render/
            ├── deck.pptx
            └── slides/
                └── *.png
```

Artifact filename은 위 위치에서만 사용할 수 있다. 같은 이름의 파일이 프로젝트 내 다른
경로에 있으면 convention 위반이다. 임의의 fallback path나 legacy path를 탐색하지 않는다.

`design-system/`은 스테이지 산출물이 아니며, 위 항목만 S5·S6가 소비한다. 파이프라인 스테이지가 자동 생성하지 않는다 — 다만 S5 직전 **디자인 템플릿 선택**(pipeline SKILL.md)에서 유저가 자기 PPTX를 제공하면 orchestrator가 `extract-design-system`으로 추출해 이 canonical 경로에 배치한다. 추출 부산물(`_work/`, `catalog.html`, `evidence.json` 등)은 둬도 무시된다.

## Gate command

```bash
node "<SKILL.md 디렉터리 절대 경로>/scripts/validate-artifacts.mjs" init <project-name>
node "<SKILL.md 디렉터리 절대 경로>/scripts/validate-artifacts.mjs" gate <project-name> <S0|S0A|S0B|S1|S2|S3|S4|S5|S6> <before|after>
```

스크립트 경로는 이 파일과 함께 로드된 SKILL.md의 절대 경로 기준으로 계산한다.
아티팩트는 스크립트 위치가 아닌 **실행 시점의 CWD** 아래 `projects/` 에 생성된다.

- `init`은 canonical directory만 생성하며 기존 파일을 덮어쓰지 않는다. 초기 실행에서 `init`은 S0a 전에 동기로 끝내고, shell 복사와 빈 패널 seed 같은 표시 준비는 S0a를 막지 않는 background 작업으로 처리한다.
- `before`는 해당 stage 입력의 정확한 경로, 파일 존재, JSON 문법을 검증한다.
- `after`는 해당 stage 출력을 포함해 같은 검증을 수행한다.
- gate exit code가 0일 때만 stage를 시작하거나 다음 stage로 이동한다.
- 실패 시 파일을 이동하거나 추측하지 말고 오류에 표시된 canonical path를 보고한다.

## before gate 호출 시점 (순차 흐름에서의 생략)

`before` gate는 한 종류가 아니다 — **핸드오프 검사**(직전 stage 출력 존재)와 **배리어/입력 검사**(외부 입력·background join)가 섞여 있다. 핸드오프 검사는 직전 stage의 `after`와 중복이므로, 같은 세션의 순차 흐름에서는 직전 `after` 통과를 신뢰하고 생략한다. 배리어/입력 검사는 어떤 `after`로도 대체되지 않으므로 항상 실행한다.

- **진입(entry) stage** — 이 세션에 선행 검증이 없으므로 `before`를 **무조건 실행**한다. (Phase 1 execution-modes에서 정한 진입점)
- **순차 흐름의 비-진입 stage** — `before`를 **생략**하고 직전 `after`로 갈음한다. **단 S2와 S5는 예외로 항상 실행**한다:
  - **S2 before** — background-join 배리어(아래 Stage requirements의 `pending_interview_updates` 비었음 + 3C bullet 합 > 0)는 어떤 `after`도 검사하지 않는다. S0b ‖ S1 병렬 예외 경로 또는 staged S1 완료 뒤의 join 지점이라 순차 실행이라도 반드시 통과시킨다.
  - **S5 before** — `catalog`(design-system 외부 입력)을 처음 요구하는 지점이라 어떤 `after`도 대체하지 못한다.
- **S6 before** — 생략 가능하다. `catalog`은 S5 before에서 이미 검증됐고(정적 입력이라 사라지지 않음) `slide_plan.json`은 S5 `after`가 검증한다.
- `after` gate는 위 생략과 무관하게 **모든 실행 stage에서 항상 실행**한다 — 순차 흐름의 핸드오프 신뢰가 성립하는 근거가 이 `after` 통과다.

## Stage requirements

| Stage | Before | After adds |
|---|---|---|
| S0a Seed | `inputs/references/` regular file ≥ 1 | `artifacts/strategy/framework_3c.json` (3C 시드), `artifacts/rfp/analysis.md` (RFP 산문 분석) |
| S0b RFP extraction | `inputs/references/` regular file ≥ 1 | `artifacts/rfp/rfp.json`, `artifacts/rfp/status.json` |
| S1 Interview | 3C + RFP analysis (`analysis.md`) + optional pre-research (`pre_research.json`) | 갱신된 3C |
| S2 Win Themes | RFP + 3C | `artifacts/strategy/win_themes.json` |
| S3 Theme Statements | RFP + 3C + Win Themes | `artifacts/strategy/theme_statements.json` |
| S4 Slide Contents | RFP + 3C + Win Themes + Theme Statements | `artifacts/slides/slide_contents.json` |
| S5 Slide Plan | Slide Contents + RFP + Theme Statements + catalog | `artifacts/slides/slide_plan.json` |
| S6 Render | Slide Plan + catalog | `artifacts/render/deck.pptx`, render PNG ≥ 1 |

S0는 두 sub-stage로 나뉜다.
**S0a(seed)** 는 reference 텍스트 1회 추출 + 3C 시드 + `analysis.md`(RFP 산문 분석)를 만든다. 3C 시드와 분석은 같은 추출 텍스트를 재사용하므로 RFP를 다시 읽지 않는다.
**S0b(extract)** 는 더 무거운 `rfp.json`(요구사항 + 제안 목차)을 만든다. 기본 RFP 분석 실행에서는 S0a와 S0b를 모두 완료한 뒤 멈춘다.
S1 인터뷰는 사용자가 명시적으로 시작을 승인한 뒤에만 열린다. 따라서 **S1 before는 `framework_3c.json` + `analysis.md`** 를 요구하고 `rfp.json`은 요구하지 않는다 — 인터뷰 오프닝은 S0a가 만든 `analysis.md`를 그대로 제시하고, `pre_research.json`이 있으면 S1 질문/요약의 optional enrichment로 주입하며, `rfp.json`은 후속 턴의 선택적 enrichment다.
S1 인터뷰 내부의 3C 갱신도 사용자 응답성을 위해 background로 돌 수 있으며, pending 턴은 `framework_3c.json`의 `_meta.pending_interview_updates`에 기록한다.
S0b 완료와 S1 pending 3C 갱신 완료는 **S2 before**(`rfp.json` + `status.json` 필요, pending 3C 갱신 없음)에서 join·검증한다.
`status.json`이 S0b의 완료 신호다.
`S0` 라벨은 두 sub-stage가 모두 끝났는지 한 번에 확인하는 convenience alias다. 기본 초기 실행은 이 alias가 통과하면 멈추고 다음 단계 허가를 묻는다.

`artifacts/rfp/status.json`은 정확히 `{"status":"ready"}`를 포함해야 한다.
S2 before gate는 추가로 `artifacts/strategy/framework_3c.json`의 `_meta.pending_interview_updates`가 없거나 빈 배열인지 확인한다.
그 밖의 schema와 semantic quality gate는 각 stage의 별도 검증 절차가 책임진다.
