# 캐스케이드 규칙 (부분 재실행 시 필수)

상위 산출물을 재생성하면 하위가 무효화된다. 이 삭제는 **orchestrator 단독**이 수행한다. **상위 재실행·선택 변경 전에 하위 아티팩트를 삭제**한 뒤 진행한다:

- `artifacts/rfp/rfp.json` 재추출(S0b) → 요구사항·목차가 바뀌므로 `win_themes.json`, `theme_statements.json`, `slide_contents.json`, `slide_plan.json` 삭제. (3C 시드는 raw RFP에서 별도 파생이라 자동 무효화 대상은 아니나, 새 RFP면 S0a도 다시 시드한다.)
- `artifacts/strategy/win_themes.json` 재생성/선택 변경 → `artifacts/strategy/theme_statements.json`, `artifacts/slides/slide_contents.json`, `artifacts/slides/slide_plan.json` 삭제. (같은 값 재선택은 no-op — 불필요한 캐스케이드 삭제 방지.)
- `artifacts/strategy/theme_statements.json` 재생성 → `artifacts/slides/slide_contents.json` 삭제.
- `artifacts/slides/slide_contents.json` 재생성 → `artifacts/slides/slide_plan.json` 재실행 필요.

**S6 렌더 런 dir (부분 재플랜 시):** 슬라이드 i를 재플래닝(`slide_indices` 부분 재실행)한 뒤 같은 렌더 런 dir에 재-seed하려면, orchestrator가 **먼저 그 슬라이드의 `$RUN/slides/<n>/`을 삭제**한다(번호 규칙: `pipeline-render.md` §셋업 3). `assemble_slide`의 resume skip 가드(`render/SKILL.md` Stage 2)는 seed가 완료된 dir를 덮어쓰지 않으므로, 지우지 않으면 옛 플랜의 슬라이드가 조용히 유지된 채 fit_done으로 남아 덱에 실린다.

**S5 `.plan/` 중간 산출물:** `slide_plan.json`을 무효화(삭제)할 때는 S5의 per-slide DECISION 레코드 디렉터리 `artifacts/slides/.plan/`도 함께 비운다. 이 레코드는 slide_contents flatten의 **절대 인덱스**로 키되므로, slide_contents가 바뀐 뒤 남은 stale 레코드가 부분 재플래닝(`slide_indices`)에서 잘못된 콘텐츠로 재사용될 수 있다. 전체 재실행은 slide-planner가 시작 시 `.plan/`을 비우므로 안전하지만, 부분 재실행 경로에서는 위 캐스케이드(rfp·win_themes·theme_statements·slide_contents 재생성)가 `slide_plan.json`을 지울 때 `.plan/`도 같이 지운다.
