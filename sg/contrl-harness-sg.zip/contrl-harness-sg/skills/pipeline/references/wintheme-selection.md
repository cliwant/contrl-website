# Win Theme 선택 프로토콜 (S2↔S3, orchestrator 책임)

`pipeline` 오케스트레이터가 S2(Win Theme 생성)와 S3(Theme Statement) 사이에서 수행하는 유저 선택 절차. 선택은 유저 결정이므로 에이전트 세션이 아니라 orchestrator가 진행한다.

1. `win-theme-runner`가 3개 테마를 생성·반환한다 (`selected_win_theme_id: null`로 저장). 반환값에는 (a) 각 테마의 전체 구성요소(스키마 그대로)와 (b) 선택 전 제시용 옵션별 설명 텍스트가 함께 담겨 있다.
2. **결과 설명 (선택지 제시 전):** orchestrator는 runner 반환의 옵션별 설명 텍스트(b)를 그대로 유저에게 제시한다. JSON을 다시 파싱해 설명을 재서술하지 않는다. (설명의 구성요소·형식·인용 처리의 단일 출처는 `win-themes` 스킬의 "옵션 설명" 절이며 runner가 그에 따라 작성한다.)
3. **선택 제시:** 그 설명에 이어 3개를 선택지(`label` + `headline`)로 제시하고 선택을 받는다.
4. orchestrator가 `win_themes.json`에 `selected_win_theme_id`(1-3)를 기록한다. 같은 값 재선택은 no-op다. 다른 값으로의 변경이면 **기록 전에** 하위 아티팩트(theme_statements·slide_contents 등)를 `cascade-rules.md`의 무효화 매핑대로 먼저 삭제한 뒤 기록한다.
5. **선택 결과 패널 렌더:** 기록 직후 orchestrator가 `win-theme-runner`를 다시 호출해 `win_themes.html`을 렌더하게 한다. orchestrator는 python을 직접 실행하지 않는다 — 렌더 명령·행동 명세의 단일 출처는 `win-themes` 스킬의 "선택 결과 패널" 절이고, 그 스킬을 읽는 주체는 runner다. runner는 `win_themes.json`(방금 기록한 `selected_win_theme_id` 포함)을 입력으로 패널을 그린다. 재선택 시에도 같은 호출로 덮어쓴다. 렌더 실패는 스테이지를 막지 않는다.
6. **resolve:** orchestrator가 `win_themes.json`에서 해당 테마 객체를 꺼내 `index` 필드를 제거하고, 그 `selected_win_theme` 객체 + `win_theme_index`를 S3(`theme-statement-runner`) 호출 인자로 넘긴다.
