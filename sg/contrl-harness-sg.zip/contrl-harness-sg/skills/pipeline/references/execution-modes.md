# 실행 모드 판별 (초기/이어서/부분 재실행/새 입력)

`pipeline` 워크플로 시작 시(Phase 1) `projects/{name}/artifacts/`의 기존 아티팩트를 조사해 실행 모드를 정하고, 해당 진입점부터 실행한다.

- **초기 실행 기본값:** framework_3c.json 없음 → S0a부터(시드) → S0b → `gate S0 after` → 멈춤. S0 결과를 보고하고 Strategy Interview를 시작할지 묻는다. S1은 자동으로 시작하지 않는다.
- **초기 실행 full autopilot override:** 사용자가 "run everything", "run all stages", "continue through render without pausing", "full pipeline end-to-end", "다 진행해줘", "끝까지 자동으로 진행해줘"처럼 모든 단계를 명시적으로 지시한 경우에만 S0a → S0b background spawn → S1로 이어간다.
- **이어서:** 일부 아티팩트 존재 → 가장 앞선 미완 스테이지부터. (예: theme_statements 있고 slide_contents 없으면 S4부터.) 3C 시드는 있으나 rfp.json이 없으면(인터뷰 도중 중단 등) S0b를 먼저 마저 돌려 S2 게이트를 채운다.
- **부분 재실행:** 유저가 특정 스테이지 수정 요청 → 그 스테이지만 재실행 + 캐스케이드 하위 삭제 후 필요 스테이지 재실행.
- **새 입력:** 유저가 새 RFP/요청 제공 → 영향 범위부터 재실행 (캐스케이드 준수).
