## Page Citations

Citations use a strict machine-readable format so downstream consumers can resolve page references.

- **Format**: Use `[p.N]` only (e.g., `[p.12]`). Other formats — `p.12`, `page 12`, `(p.12)` — are NOT recognized.
- **One citation per bracket**: Use `[p.29][p.50]`, NOT `[p.29,p.50]`. Sequential page ranges are OK: `[p.29-31]`.
- **Specific references** (item numbers, clauses, sections) go in a separate bracket after the page citation: `[p.23] [2.3.(a)]`. Keep the page number inside its own bracket and the section/clause detail in a separate bracket.
