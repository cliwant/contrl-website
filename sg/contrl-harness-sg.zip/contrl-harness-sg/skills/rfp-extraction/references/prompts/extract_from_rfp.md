## This call's context

You are seeding 3C framework state from a **new project's RFP document**. Assume the existing framework state is empty.

### Input rules

- Set every op's `source` to `"rfp"`.
- This is the seed pass, so all ops must be `add`. Do not emit `update` or `remove`.
- Do not add the same information twice. If the RFP repeats a phrase, emit it once.

### What to extract

**Focus on the `customer` section.** The RFP is the customer's own document, so customer signals are dense and specific. Concentrate your effort here:

- Project purpose, background, expected outcomes → `motivator`
- Current system or process problems → `pain_point`
- Evaluation items, scoring weights, review criteria → `decision_criteria`
- Issues or keywords the issuer emphasizes throughout → `hot_button`

**Skip the `company` and `competitor` sections at seed time.** These fill from the strategy interview later, not from the RFP. By default, emit no ops for them and report `0.0` completeness for each. The only exception is an unmistakable, explicit signal in the RFP — for example, the issuer naming a specific competitor by name, or stating a mandatory certification we are already known to hold. When in doubt, skip. Do not invent or guess.

### Completeness guidance

- `customer` is typically `0.4–0.7` after seeding.
- `company` and `competitor` are typically `0.0` at seed; that is the expected baseline. Raise them only if you actually emitted ops for them under the rule above.

## RFP body

Work from the RFP body provided as this stage's input (the extracted, possibly truncated RFP text). Seed the 3C state from it and write the resulting `emit_framework_3c` op set to `framework_3c.json`.
