---
name: rfp-extraction
description: >-
  CONTRL pipeline S0 — RFP Extraction. Extracts requirements and the required proposal structure from uploaded RFP files (PDF/DOCX), writes rfp.json, and creates the initial 3C seed framework_3c.json.
  Use for RFP analysis/extraction, rfp.json generation, proposal-structure extraction, 3C seeding, project analysis kickoff, S0 execution, or the first step of CONTRL proposal automation.
  Downstream stages consume these artifacts.
---

# S0 — RFP 추출 (RFP Extraction)

## Customer Delivery Defaults

Write all generated artifacts, analysis, summaries, headings, labels, and progress-panel text in English. Translate Korean or other non-English source material into natural business English before writing `rfp.json`, `analysis.md`, or `framework_3c.json`.

CONTRL 데이터 파이프라인의 첫 스테이지. 원본 RFP에서 구조화된 사실(`rfp.json`)과
3C 프레임워크 초기 시드(`framework_3c.json`)를 만든다. 뒤 모든 스테이지가 소비하는
1급 데이터이므로 명시적인 첫 스테이지로 실행한다.

## 입출력 계약 (I/O Contract)

- **입력:** `projects/{name}/inputs/references/`의 RFP 파일(PDF/docx)에서 추출한 본문.
  파일당 150,000자로 절단(truncate)하고 `### [filename]\n<text>` 로 라벨링해 이어붙인다.
- **출력:**
  - `projects/{name}/artifacts/rfp/rfp.json` — 코어 추출 + `required_proposal_structure`
  - `projects/{name}/artifacts/rfp/status.json` — `{"status":"ready"}` (성공 시)
  - `projects/{name}/artifacts/rfp/pre_research.json` — source-backed pre-research outside the RFP analysis
  - `projects/{name}/artifacts/rfp/analysis.md` — RFP 산문 통찰 분석 (S1 인터뷰 오프닝이 그대로 제시)
  - `projects/{name}/artifacts/strategy/framework_3c.json` — 3C 초기 시드
- **출력 (패널, read-only 파생물, gate 비대상):**
  - `projects/{name}/outputs/rfp/analysis.html` — S0 result panel with two in-page sub-tabs: `Pre-Research` for evidence-backed issuer/opportunity research outside the RFP analysis, and `RFP Analysis` for `analysis.md`, `rfp.json`, proposal outline, and initial 3C seed

## 두 sub-stage로 분리 (S0a 시드 / S0b 추출)

이 스킬의 산출은 의존성이 다른 두 묶음이고 별도 게이트로 검증한다:
- **S0a (시드, 동기):** 아래 절차 0·4·5 — reference 텍스트 1회 추출 + `framework_3c.json`
  3C 시드 + `analysis.md` 산문 분석. S1 인터뷰의 하드 선행이므로 먼저, 빠르게 만든다.
  3C 시드와 분석은 같은 추출 텍스트(절차 0)를 재사용하므로 RFP를 다시 읽지 않는다.
- **S0b (추출):** 아래 절차 1·2·3 — `rfp.json`(요구사항 + 제안 목차) + `status.json`. 기본 RFP 분석 실행에서는 S0a와 S0b를 완료한 뒤 멈춘다. 사용자가 S1 시작을 이미 승인했거나 full autopilot override를 준 경우에만 S1 인터뷰가 도는 동안 백그라운드로 돌리고, S2 진입 전에 완료를 join한다.

reference 텍스트 추출(절차 0)은 **한 번만** 하고 S0a·S0b·S1이 공유한다.

## 절차 (Algorithm)

네 LLM 작업과 한 evidence-backed research step으로 구성된다. 1·2는 `rfp.json`을(S0b), 4는 `framework_3c.json`을·5는 `analysis.md`를(S0a), 6은 `pre_research.json`을 만든다.
3은 결정론 단계다.

### 0. reference 텍스트 추출 (공유, LLM 아님)
`inputs/references/`의 각 파일을 텍스트로 추출해 파일당 150,000자 truncate, `### [filename]\n<text>`
로 라벨링·결합한다. 이 결합 텍스트를 S0a·S0b·S1이 모두 재사용한다.

### 1. 코어 RFP 추출 → rfp.json
- 시스템 프롬프트: `references/prompts/system_extraction.md`
- 입력: RFP 본문 텍스트(라벨링/절단된 결합 텍스트)
- 출력: 아래 `_EXTRACTION_OUTPUT_SCHEMA`에 **정확히** 맞는 JSON. `additionalProperties:false`,
  모든 `required` 필드 채움. structured-output처럼 스키마를 엄격히 지킬 것.
- `required_proposal_structure` 키가 없으면 `{"page_limit": null, "sections": []}`로 기본 채움.
- 이 결과를 `rfp.json`으로 저장.

### 2. 제안 목차구조 추출 → rfp.json 병합
- 시스템 프롬프트: `references/prompts/system_proposal_structure.md`
- 입력: 동일 RFP 본문
- 출력: `_PROPOSAL_STRUCTURE_OUTPUT_SCHEMA`에 맞는 JSON (`required_proposal_structure`)
- 1의 `rfp.json`을 로드해 `required_proposal_structure`를 덮어쓰고 다시 저장.

### 3. 안정 section_id 부여 (결정론, 제공 스크립트)
결정론 단계라 LLM이 아니라 제공 스크립트가 수행한다 — 알고리즘·상수의 단일 소스는 `scripts/assign_section_ids.py`(stdlib-only)다. S0b 초기 추출과 아래 "제안서 목차 재추출·편집" 두 경로가 이 한 스크립트를 공유한다.
```bash
python3 "${CLAUDE_PLUGIN_ROOT}/skills/rfp-extraction/scripts/assign_section_ids.py" \
  --rfp <projects/{name}/artifacts/rfp/rfp.json 절대경로> --write
```
`required_proposal_structure.sections[]`(플랫 리스트 — 계층은 각 노드 `level`)의 각 노드에 `section_id`가 없으면 `sec_0001`, `sec_0002`, … 순서로 부여(4자리 zero-pad, 9999 초과 시 폭 확장)하고, 이미 `sec_NNNN`이면 보존한다(idempotent·순서 보존). 새 id는 high-water(`max(_section_id_counter, 기존 최대 sec 번호)`) 다음부터 매겨 **삭제된 노드 id를 재사용하지 않는다** — 그래서 최고 카운터를 `rfp.json`의 `_section_id_counter`에 기록·재사용한다. `--write` 없이 호출하면 dry-run(변경 없이 보고만; 반환 JSON에 `not_found`= `sections` 빈 배열 여부 포함). `requirement_mapping`(중첩 트리)은 건드리지 않는다.
- **이 단계는 필수** — 뒤 S3/S4/S5가 `section_id`를 라우팅 키로 쓴다.

### 4. 3C 초기 시드 → framework_3c.json
- 시스템 프롬프트: `references/prompts/framework_3c_system.md`
- 유저 프롬프트: `references/prompts/extract_from_rfp.md` (`{rfp_text}` = 절단된 RFP 본문)
- 출력: `emit_framework_3c` 도구 입력 형태 — `ops[]` (add/update/remove) + `completeness`.
  자세한 스키마는 아래 "3C ops 스키마". 여기선 신규 생성이므로 전부 `op:"add"`,
  `source:"rfp"`.
- ops를 적용해 `framework_3c.json` 상태를 만든다 (아래 "3C 상태 형태").
  ops를 적용할 때 bullet `id`를 `{section}-{N}` 류의 안정 id로 순서대로 부여
  (예: `c1`, `co1`, `cm1` … customer/company/competitor 접두).

### 5. RFP 산문 통찰 분석 → analysis.md (S0a)
- 시스템 프롬프트: `references/prompts/system_rfp_analysis.md` (`{citation_rule}`은 `references/prompts/page_citation_rule.md`로 치환).
- 입력: `<document_context>` = 절차 0의 결합 텍스트(3C 시드와 동일 — RFP를 다시 읽지 않는다).
- 출력: 4-렌즈 통찰 산문(메뉴·질문·도구 호출 없이 분석 본문만). 그대로 `artifacts/rfp/analysis.md`에 저장.
- 이 산출은 S1 인터뷰의 오프닝이 **재생성 없이 그대로 제시**한다. 인터뷰는 이 분석을 소비할 뿐 다시 만들지 않는다 — 형식·렌즈·인용 규칙의 단일 소스는 이 절과 위 시스템 프롬프트다.

### 6. 근거 기반 사전조사 → pre_research.json
Pre-Research는 source packet 요약이 아니다. RFP 분석 바깥의 시장·발주처·수주사·트렌드 근거를 모아 `artifacts/rfp/pre_research.json`에 저장한다.

필수 섹션:

- `issuer_news`: 발주처와 ServiceSG 관련 최신 뉴스, 전략 방향, 조직/서비스 변화.
- `past_similar_procurements`: 같은 발주처의 유사 과거 발주와 Singapore public-sector 유사 contact-centre/AI-bot 발주.
- `winner_company_analysis`: 과거 유사 사업 수주 기업, 반복 등장 공급자, 경쟁 구도, 수주 시사점.
- `topic_trends`: 본 RFP 주제와 직접 연결되는 AI bot, contact-centre automation, public-service AI, governance/security trends.

조사 원칙:

- Singapore public procurement and related Singapore public sources only unless the user explicitly asks otherwise.
- For procurement discovery and award evidence, use Cliwant global MCP Singapore/GeBIZ routes first: `mcp__global_cliwant.global_search_bids`, `global_search_contracts`, `global_get_project_info`, `global_search_contacts`, `global_get_contracts_by_business`, with `region: "SG"`.
- Use general web search only for issuer news, official public-sector strategy, governance frameworks, and topic trends not available from GeBIZ.
- Every finding must include `source_name`, `source_url` when available, and an `evidence` sentence that states the factual basis. If a GeBIZ/MCP record has no public URL, set `source_url:null` and state the MCP/GeBIZ query source in `source_name`.
- Keep all findings, implications, labels, and source summaries in English.

Suggested shape:

```json
{
  "status": "ready",
  "generated_at": "YYYY-MM-DD",
  "scope": "Singapore GeBIZ and Singapore public sources",
  "summary_cards": [{"label": "string", "value": "string", "note": "string"}],
  "sections": [{
    "id": "issuer_news|past_similar_procurements|winner_company_analysis|topic_trends",
    "title": "string",
    "items": [{
      "title": "string",
      "date": "string|null",
      "finding": "string",
      "evidence": "string",
      "implication": "string",
      "source_name": "string",
      "source_url": "string|null"
    }]
  }]
}
```

### 7. S0 결과 패널 렌더링
S0a와 S0b가 모두 끝나고 `gate S0 after`를 통과하면, S0 결과 HTML을 렌더한다. 이 렌더는 canonical artifacts를 바꾸지 않는 read-only 파생물이다.

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/skills/rfp-extraction/scripts/render-s0-html.py" \
  <project_name> --root "<projects/ 가 있는 절대경로>"
```

출력:

- `projects/{name}/outputs/rfp/analysis.html`

사용자에게 보여줄 때는 `projects/{name}/outputs/`를 정적 서버 루트로 서빙하고 `index.html#s=S0`을 열어 S0 결과 탭을 우측 artifact/browser에 표시한다. 이 탭의 사용자-facing 라벨은 English-only workspace에서는 `Pre-Research`이며, 내부에는 `Pre-Research`와 `RFP Analysis` 서브탭을 둔다. `Pre-Research` 서브탭은 발주처 뉴스, 과거 유사 발주, 수주 기업 분석, RFP 주제 트렌드처럼 RFP 분석 바깥의 정보만 보여주고, 모든 항목은 출처와 근거를 표시한다. 요구사항·제안 목차·3C seed는 `RFP Analysis` 서브탭에서만 보여준다.

## rfp.json 스키마

### 코어 (`_EXTRACTION_OUTPUT_SCHEMA`)
```json
{
  "source_documents": ["string"],
  "project_overview": {
    "project_name": "string", "issuing_organization": "string",
    "project_objective": "string", "project_duration": "string|null",
    "budget": "string|null", "evaluation_method": "string|null",
    "contract_type": "string|null"
  },
  "requirements": [{
    "id": "string", "summary": "string", "source": "string",
    "rfp_reference": "string",
    "category": "functional|technical|management|administrative|security|constraint|other",
    "priority": "H|M|L"
  }],
  "project_background": {
    "current_state": "string", "trigger": "string", "history": "string",
    "pain_points": [{"description":"string","source":"string","rfp_reference":"string"}]
  },
  "hidden_purpose": {
    "inference": "string",
    "evidence": [{"statement":"string","source":"string","rfp_reference":"string"}]
  }
}
```
모든 객체 `additionalProperties:false`, 위 모든 필드 `required`.

### 목차구조 (`_PROPOSAL_STRUCTURE_OUTPUT_SCHEMA`)
```json
{
  "required_proposal_structure": {
    "page_limit": "integer|null",
    "sections": [{"title":"string","level":"number","page":"string|null"}]
  }
}
```
section_id는 4단계에서 부여 → 저장된 노드는 `{title, level, page, section_id}`.

## 3C ops 스키마 (`emit_framework_3c`)
```json
{
  "ops": [{
    "op": "add|update|remove",
    "section": "customer|company|competitor",   // add 필수
    "type": "string",   // 아래 allowlist
    "id": "string",     // update/remove 필수, add 금지
    "text": "string",   // add 필수. 간결한 한국어 ~40자
    "source": "rfp"     // S0에서는 항상 rfp
  }],
  "completeness": {"customer": 0.0-1.0, "company": 0.0-1.0, "competitor": 0.0-1.0}
}
```
type allowlist (section별 닫힌 집합):
- customer ∈ {hot_button, pain_point, motivator, decision_criteria, other}
- company ∈ {strength, discriminator, proof_point, other}
- competitor ∈ {identified, competitor_strength, competitor_weakness, other}

## framework_3c.json 상태 형태
```json
{
  "version": 1, "status": "ready",
  "customer":   [{"id":"c1","type":"hot_button","text":"...","sources":["rfp"],"source_turns":[]}],
  "company":    [{"id":"co1","type":"strength","text":"...","sources":["rfp"],"source_turns":[]}],
  "competitor": [{"id":"cm1","type":"identified","text":"...","sources":["rfp"],"source_turns":[]}],
  "completeness": {"customer":0.0,"company":0.0,"competitor":0.0},
  "_meta": {"last_failed_input": null}
}
```

## 검증 (Validation)
- `rfp.json` 저장 후 `artifacts/rfp/status.json`을 `{"status":"ready"}`로 기록.
- 모든 `sections[]` 노드에 `sec_NNNN` 형식 `section_id` 존재 확인.
- `framework_3c.json`의 세 축 bullet 합이 0이면 S2(Win Theme)가 실패한다 — 시드가
  최소한의 bullet을 만들었는지 확인.
- `analysis.md`가 비어있지 않은지(분석 본문 존재) 확인 — S1 오프닝이 이 파일을 그대로 제시한다.
- `pre_research.json`의 네 필수 섹션이 존재하고, 모든 `items[]`가 `finding`, `evidence`, `source_name`, `implication`을 가진다. `source_url`은 URL이 없을 때만 `null`로 둔다.

`status.json`은 S0b(rfp.json 추출)의 **완료 신호**다 — 백그라운드로 돌 때 오케스트레이터는
이 파일로 완료를 join한다. `rfp.json`을 다 쓴 **뒤에** 마지막으로 기록한다.

## 제안서 목차 재추출·편집 (RPS review 지원)

S3 진입 직전 제안서 목차 확인(orchestrator의 `pipeline` `references/rps-review.md`)에서 유저가 목차를 새로 얻거나 고칠 때, `required_proposal_structure`만 다시 만든다. `rfp.json`의 나머지 키(`project_overview`·`requirements`·`project_background`·`hidden_purpose`·`requirement_mapping` 등)는 건드리지 않고 **머지(그 키만 덮어쓰기)** 한다 — 전체 재추출이 아니다.

두 연산으로 나뉜다 — 새 목차를 **통째로** 얻는 것은 텍스트 소스만 다를 뿐 하나의 추출(`rps-extract`)이고, 기존 목차에 **국소 변경**만 하는 것이 편집(`rps-edit`)이다:

1. **목차 추출 (`rps-extract`, text→구조):** 주어진 텍스트에 절차 2(`system_proposal_structure.md`)를 돌려 `required_proposal_structure`를 만든 뒤 기존 `rfp.json`의 그 키만 덮어쓴다. 입력 텍스트 소스는 둘이며 처리는 같다:
   - **참고 자료 파일:** 파일 텍스트를 추출(절차 0과 동일 규칙: 파일당 150,000자 truncate)해 입력으로 쓴다. 파일은 `inputs/references/`에 복사해 프로젝트 자료로 보존하고, 파일에서도 목차를 못 찾으면(빈 `sections`) 기존 참고 텍스트와 합쳐 한 번 더 시도한다.
   - **유저가 직접 부른 목차:** 유저 메시지의 목차 서술을 그대로 입력 텍스트로 쓴다 — RFP·자료 대신 유저 텍스트가 소스일 뿐 같은 절차 2 추출이며 편집이 아니다. (어느 유저 응답에서 이 소스가 오는지의 라우팅은 orchestrator `rps-review.md` 소관.)
2. **국소 편집 (`rps-edit`):** orchestrator가 정리해 넘긴 작은 변경(제목·`level`·한두 항목 추가/삭제/재정렬·`page_limit`)을 기존 `required_proposal_structure`에 델타로 적용한다.

두 연산 모두 반영 뒤 **절차 3(`scripts/assign_section_ids.py --write`)** 을 다시 돌린다 — idempotent라 기존 `sec_NNNN`은 보존되고 새 노드만 high-water 다음 번호를 받는다. 삭제된 노드의 `section_id`는 회수하지 않는다(`_section_id_counter` 감소 없음). `requirement_mapping`은 여기서 손대지 않는다 — 목차 변경으로 매핑이 stale해지는 무효화는 orchestrator의 캐스케이드 책임이다(`pipeline` `references/cascade-rules.md`).

**지원 입력 형식 (`rps-extract` 파일 소스):** PDF · 평문 텍스트 · 이미지 — 현행 추출 경로(runner의 Read 도구)가 직접 읽는 형식. docx·hwp·pptx·xlsx 등은 별도 변환기가 없어 지원하지 않는다. 그런 파일이면 추출하지 말고, orchestrator가 유저에게 PDF로 변환해 다시 전달해 달라고 안내한다(안내 문구는 `rps-review.md` 소관). 유저가 채팅으로 직접 부른 목차 텍스트는 파일이 아니라 형식 제약이 없다.

**not-found 신호:** `required_proposal_structure.sections`가 빈 배열(`[]`). 절차 2가 목차를 못 찾으면 `{"page_limit": null, "sections": []}`로 둔다 — 이게 "식별 안됨" 신호이며 목차 확인 뷰와 orchestrator 분기가 이걸로 판정한다.

**검증:** 반영 후 모든 `sections[]` 노드에 `sec_NNNN`이 있는지 확인하고, `required_proposal_structure`(+`_section_id_counter`) 외 `rfp.json` 키를 바꾸지 않았는지 확인한다.

## 참고: verify / 요약 (boundary)
`system_analysis.md`(출처 검증 Q&A), `system_summary.md`(RFP 요약)는 정규 파이프라인이
아닌 보조 기능용 프롬프트다. S0 산출에는 불필요하나 동일 RFP 컨텍스트를 쓰는 Q&A에 사용.
