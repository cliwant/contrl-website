#!/usr/bin/env python3
"""Render S0 RFP analysis outputs for the CONTRL progress shell."""

from __future__ import annotations

import argparse
import html
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render S0 RFP analysis HTML.")
    parser.add_argument("project", help="Project directory name under projects/.")
    parser.add_argument("--root", required=True, help="Absolute path to the directory that contains projects/.")
    parser.add_argument("--output", help="Output HTML path. Defaults to projects/<project>/outputs/rfp/analysis.html.")
    return parser.parse_args()


def assert_project_name(project: str) -> None:
    if not project or project in {".", ".."} or "/" in project or "\\" in project:
        raise SystemExit("project name must be one directory name without path separators")


def esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    return value if isinstance(value, dict) else {}


def inline_md(text: str) -> str:
    text = esc(text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    return text


def markdown_to_html(markdown: str) -> str:
    if not markdown.strip():
        return '<p class="empty">RFP analysis has not been generated yet.</p>'

    out: list[str] = []
    para: list[str] = []
    in_list = False

    def close_para() -> None:
        nonlocal para
        if para:
            out.append(f"<p>{inline_md(' '.join(para))}</p>")
            para = []

    def close_list() -> None:
        nonlocal in_list
        if in_list:
            out.append("</ul>")
            in_list = False

    for raw in markdown.splitlines():
        line = raw.strip()
        if not line:
            close_para()
            close_list()
            continue
        if line.startswith("#"):
            close_para()
            close_list()
            level = min(3, max(1, len(line) - len(line.lstrip("#"))))
            title = line.lstrip("#").strip()
            if level == 1:
                continue
            out.append(f"<h{level}>{inline_md(title)}</h{level}>")
            continue
        if line.startswith("- "):
            close_para()
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append(f"<li>{inline_md(line[2:].strip())}</li>")
            continue
        close_list()
        para.append(line)

    close_para()
    close_list()
    return "\n".join(out)


def fact(label: str, value: Any) -> str:
    value_text = str(value or "").strip() or "Not specified"
    return f"<div><dt>{esc(label)}</dt><dd>{esc(value_text)}</dd></div>"


def render_facts(overview: dict, status: dict) -> str:
    return (
        '<dl class="facts">'
        + fact("Buyer", overview.get("issuing_organization"))
        + fact("Notice", overview.get("notice_type") or overview.get("contract_type"))
        + fact("Posted", overview.get("posted_date"))
        + fact("Closing", overview.get("closing_date"))
        + fact("Status", "Ready" if status.get("status") == "ready" else "Draft")
        + fact("Channel", overview.get("procurement_channel") or "Singapore GeBIZ")
        + "</dl>"
    )


def markdown_section(markdown: str, heading: str, limit: int = 8) -> list[str]:
    lines: list[str] = []
    capture = False
    target = heading.strip().lower()
    for raw in markdown.splitlines():
        line = raw.strip()
        if line.startswith("## "):
            if capture:
                break
            capture = line.lstrip("#").strip().lower() == target
            continue
        if capture and line:
            lines.append(line)
            if len(lines) >= limit:
                break
    return lines


def render_summary_cards(cards: list[dict]) -> str:
    if not cards:
        return ""
    rendered = []
    for card in cards:
        label = str(card.get("label") or "Research Signal").strip()
        value = str(card.get("value") or "").strip()
        note = str(card.get("note") or "").strip()
        rendered.append(
            '<article class="summaryCard">'
            f"<h3>{esc(label)}</h3>"
            f"<strong>{esc(value or 'Ready')}</strong>"
            f"{f'<p>{esc(note)}</p>' if note else ''}"
            "</article>"
        )
    return f'<div class="summaryGrid">{"".join(rendered)}</div>'


def render_research_source(item: dict) -> str:
    date = str(item.get("date") or "").strip()
    source_name = str(item.get("source_name") or "Source not specified").strip()
    source_url = str(item.get("source_url") or "").strip()
    source = (
        f'<a href="{esc(source_url)}" target="_blank" rel="noreferrer">{esc(source_name)}</a>'
        if source_url
        else esc(source_name)
    )
    parts = []
    if date:
        parts.append(f"<span>{esc(date)}</span>")
    parts.append(f"<span>{source}</span>")
    return f'<p class="sourceLine">{"".join(parts)}</p>'


def render_research_item(item: dict) -> str:
    title = str(item.get("title") or "Research finding").strip()
    finding = str(item.get("finding") or "").strip()
    evidence = str(item.get("evidence") or "").strip()
    implication = str(item.get("implication") or "").strip()
    return (
        '<article class="researchItem">'
        f"<h3>{esc(title)}</h3>"
        f"{render_research_source(item)}"
        f"{f'<p>{esc(finding)}</p>' if finding else ''}"
        '<div class="evidenceBlock">'
        "<strong>Evidence</strong>"
        f"<p>{esc(evidence or 'Evidence not specified.')}</p>"
        "</div>"
        '<div class="implicationBlock">'
        "<strong>Proposal implication</strong>"
        f"<p>{esc(implication or 'Implication not specified.')}</p>"
        "</div>"
        "</article>"
    )


def render_structured_pre_research(pre_research: dict) -> str:
    sections = [s for s in pre_research.get("sections") or [] if isinstance(s, dict)]
    if not sections:
        return ""

    scope = str(pre_research.get("scope") or "Singapore GeBIZ and Singapore public sources.").strip()
    generated_at = str(pre_research.get("generated_at") or "").strip()
    summary_cards = [c for c in pre_research.get("summary_cards") or [] if isinstance(c, dict)]
    rendered_sections = []

    for section in sections:
        title = str(section.get("title") or section.get("id") or "Research Section").strip()
        items = [i for i in section.get("items") or [] if isinstance(i, dict)]
        item_html = "".join(render_research_item(item) for item in items)
        if not item_html:
            item_html = '<p class="empty">No evidence-backed findings have been captured for this section yet.</p>'
        rendered_sections.append(
            '<section class="researchSection">'
            f"<h2>{esc(title)}</h2>"
            f"{item_html}"
            "</section>"
        )

    meta = f"Scope: {scope}"
    if generated_at:
        meta += f" | Generated: {generated_at}"
    return f"""
      {render_summary_cards(summary_cards)}
      <p class="small muted">{esc(meta)}</p>
      {''.join(rendered_sections)}
    """


def render_pre_research(project_root: Path, overview: dict, source_packet: str, pre_research: dict) -> str:
    structured = render_structured_pre_research(pre_research)
    if structured:
        return structured

    references_dir = project_root / "inputs" / "references"
    files = sorted([p for p in references_dir.glob("*") if p.is_file()]) if references_dir.exists() else []
    source_lines = markdown_section(source_packet, "Source Documents Captured", 8)
    customer_lines = markdown_section(source_packet, "Customer Context", 3)
    captured_items = "".join(f"<li>{inline_md(line[2:].strip() if line.startswith('- ') else line)}</li>" for line in source_lines)
    if not captured_items:
        captured_items = '<li class="empty">No source-document summary has been captured yet.</li>'
    customer_context = " ".join(line for line in customer_lines if not line.startswith("- ")).strip()
    if not customer_context:
        customer_context = "No customer context paragraph has been captured yet."
    source_url = overview.get("source_url")
    source_link = (
        f'<a href="{esc(source_url)}" target="_blank" rel="noreferrer">Singapore GeBIZ source</a>'
        if source_url
        else "Singapore GeBIZ source not specified"
    )
    return f"""
      <div class="researchGrid">
        <article class="researchCard">
          <h3>Scope</h3>
          <p>Singapore GeBIZ opportunity detail, source packet, and available tender attachments were prepared in English before extraction.</p>
          <p class="small muted">{source_link}</p>
        </article>
        <article class="researchCard">
          <h3>Captured Materials</h3>
          <strong>{len(files)}</strong>
          <p class="small muted">reference files</p>
        </article>
        <article class="researchCard">
          <h3>Customer Context</h3>
          <p>{esc(customer_context)}</p>
        </article>
      </div>
      <h3>Source Documents Captured</h3>
      <ul>{captured_items}</ul>
    """


def render_requirements(rfp: dict) -> str:
    requirements = [r for r in rfp.get("requirements") or [] if isinstance(r, dict)]
    if not requirements:
        return '<p class="empty">No extracted requirements are available yet.</p>'
    category_counts = Counter(str(req.get("category") or "other") for req in requirements)
    high_count = sum(1 for req in requirements if str(req.get("priority") or "").upper() == "H")
    chips = [
        f'<span class="chip">{len(requirements)} requirements</span>',
        f'<span class="chip">{high_count} high priority</span>',
    ]
    chips.extend(f'<span class="chip">{esc(key)} {count}</span>' for key, count in sorted(category_counts.items()))
    rows = []
    for req in requirements[:14]:
        rows.append(
            "<tr>"
            f"<td>{esc(req.get('id'))}</td>"
            f"<td>{esc(req.get('summary'))}</td>"
            f"<td>{esc(req.get('category'))}</td>"
            f"<td>{esc(req.get('priority'))}</td>"
            "</tr>"
        )
    more = ""
    if len(requirements) > 14:
        more = f'<p class="small muted">Showing 14 of {len(requirements)} extracted requirements.</p>'
    return (
        f'<div class="chips">{"".join(chips)}</div>'
        '<div class="tableWrap"><table><thead><tr><th>ID</th><th>Requirement</th><th>Category</th><th>Priority</th></tr></thead>'
        f'<tbody>{"".join(rows)}</tbody></table></div>{more}'
    )


def render_outline(rfp: dict) -> str:
    structure = rfp.get("required_proposal_structure") if isinstance(rfp.get("required_proposal_structure"), dict) else {}
    sections = [s for s in structure.get("sections") or [] if isinstance(s, dict)]
    if not sections:
        return '<p class="empty">No proposal outline has been identified yet.</p>'
    items = []
    for section in sections:
        level = int(section.get("level") or 1)
        indent = min(max(level - 1, 0), 3)
        desc = str(section.get("description") or "").strip()
        sid = str(section.get("section_id") or "").strip()
        items.append(
            f'<li class="indent{indent}"><span class="sid">{esc(sid)}</span>'
            f'<span>{esc(section.get("title"))}</span>'
            f'{f"<small>{esc(desc)}</small>" if desc else ""}</li>'
        )
    page_limit = structure.get("page_limit")
    limit = f'<p class="small muted">Page limit: {esc(page_limit)}</p>' if page_limit else ""
    return f"{limit}<ol class=\"outline\">{''.join(items)}</ol>"


def render_framework(framework: dict) -> str:
    axes = [
        ("customer", "Customer"),
        ("company", "Company"),
        ("competitor", "Competitor"),
    ]
    cards = []
    for key, label in axes:
        bullets = [b for b in framework.get(key) or [] if isinstance(b, dict)]
        preview = []
        for bullet in bullets[:3]:
            text = bullet.get("summary") or bullet.get("text") or bullet.get("implication") or ""
            if text:
                preview.append(f"<li>{esc(text)}</li>")
        body = f"<ul>{''.join(preview)}</ul>" if preview else '<p class="empty">No seed bullets yet.</p>'
        cards.append(f'<article class="mini"><h3>{esc(label)}</h3><strong>{len(bullets)}</strong>{body}</article>')
    completeness = framework.get("completeness") if isinstance(framework.get("completeness"), dict) else {}
    overall = completeness.get("overall")
    overall_text = f'<p class="small muted">Overall seed completeness: {esc(overall)}</p>' if overall is not None else ""
    return f'<div class="miniGrid">{"".join(cards)}</div>{overall_text}'


def render_artifacts(project_root: Path) -> str:
    files = [
        ("Source packet", project_root / "inputs" / "references" / "gebiz_bid.md"),
        ("Pre-Research", project_root / "artifacts" / "rfp" / "pre_research.json"),
        ("RFP analysis", project_root / "artifacts" / "rfp" / "analysis.md"),
        ("RFP JSON", project_root / "artifacts" / "rfp" / "rfp.json"),
        ("Status", project_root / "artifacts" / "rfp" / "status.json"),
        ("Initial 3C", project_root / "artifacts" / "strategy" / "framework_3c.json"),
    ]
    rows = []
    for label, path in files:
        state = "Ready" if path.exists() and path.stat().st_size > 0 else "Missing"
        rows.append(f"<li><span>{esc(label)}</span><code>{esc(path.relative_to(project_root))}</code><b>{esc(state)}</b></li>")
    return f'<ul class="artifactList">{"".join(rows)}</ul>'


CSS = r"""
:root {
  color-scheme: light;
  --bg: #f7f4ef;
  --panel: #ffffff;
  --ink: #25211c;
  --muted: #746b61;
  --line: #ded6ca;
  --soft: #f1ebe3;
  --accent: #b85c38;
  --good: #3f7f5f;
  --shadow: 0 10px 30px rgba(37, 33, 28, 0.08);
}
* { box-sizing: border-box; }
body {
  margin: 0;
  min-height: 100vh;
  background: var(--bg);
  color: var(--ink);
  font-family: Pretendard, Inter, "Apple SD Gothic Neo", ui-sans-serif, system-ui, -apple-system, sans-serif;
}
a { color: inherit; text-decoration-color: rgba(184, 92, 56, 0.45); text-underline-offset: 3px; }
.shell { width: min(1120px, 100%); margin: 0 auto; padding: 18px; }
.panel {
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 8px;
  box-shadow: var(--shadow);
  padding: 18px;
}
.head {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 16px;
  align-items: start;
}
.eyebrow {
  color: var(--accent);
  font-size: 10px;
  font-weight: 760;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}
h1 { margin: 5px 0 0; font-size: 24px; line-height: 1.22; font-weight: 760; letter-spacing: 0; }
h2 { margin: 0 0 8px; color: #3c352e; font-size: 15px; line-height: 1.35; letter-spacing: 0; }
h3 { margin: 12px 0 6px; color: var(--muted); font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em; }
.status {
  display: inline-flex;
  align-items: center;
  min-height: 28px;
  border-radius: 999px;
  border: 1px solid rgba(63, 127, 95, 0.28);
  background: #eef8f1;
  color: var(--good);
  padding: 4px 10px;
  font-size: 11px;
  font-weight: 760;
  white-space: nowrap;
}
.facts {
  display: grid;
  grid-template-columns: repeat(6, minmax(0, 1fr));
  gap: 8px;
  margin: 16px 0 8px;
}
.facts div { border: 1px solid #eee7dd; border-radius: 8px; padding: 9px; background: #fffaf3; }
dt { color: var(--muted); font-size: 10px; font-weight: 760; text-transform: uppercase; letter-spacing: 0.04em; }
dd { margin: 3px 0 0; font-size: 12px; line-height: 1.4; overflow-wrap: anywhere; }
.grid {
  display: grid;
  grid-template-columns: minmax(0, 1.15fr) minmax(280px, 0.85fr);
  gap: 12px;
  margin-top: 14px;
}
.subtabs {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  border-top: 1px solid #eee7dd;
  margin-top: 12px;
  padding-top: 12px;
}
.subtab {
  appearance: none;
  border: 1px solid var(--line);
  border-radius: 999px;
  background: var(--panel);
  color: var(--ink);
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  font-weight: 720;
  min-height: 30px;
  padding: 5px 12px;
}
.subtab.active {
  background: var(--accent);
  border-color: var(--accent);
  color: #fff;
}
.tabPanel { display: none; }
.tabPanel.active { display: block; }
.mainColumn { min-width: 0; }
.mainColumn .section:first-child { border-top: 0; padding-top: 0; }
.section {
  border-top: 1px solid #eee7dd;
  padding-top: 14px;
  min-width: 0;
}
.section p, .section li, td {
  color: #3c352e;
  font-size: 12px;
  line-height: 1.56;
  overflow-wrap: anywhere;
}
.section p { margin: 0 0 9px; }
.section ul { margin: 0 0 10px; padding-left: 17px; }
.section li + li { margin-top: 4px; }
.muted, .empty { color: var(--muted); }
.small { font-size: 11px; line-height: 1.45; }
.chips { display: flex; flex-wrap: wrap; gap: 6px; margin: 0 0 10px; }
.chip {
  display: inline-flex;
  align-items: center;
  min-height: 22px;
  padding: 3px 8px;
  border: 1px solid var(--line);
  border-radius: 999px;
  background: var(--soft);
  color: var(--muted);
  font-size: 11px;
  font-weight: 680;
}
.tableWrap { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; min-width: 680px; }
th, td { border-bottom: 1px solid #eee7dd; padding: 8px 9px; text-align: left; vertical-align: top; }
th {
  color: var(--muted);
  font-size: 10px;
  font-weight: 760;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  background: #fbf8f3;
}
.outline { margin: 0; padding-left: 0; list-style: none; }
.outline li {
  display: grid;
  grid-template-columns: 74px minmax(0, 1fr);
  gap: 8px;
  border-bottom: 1px solid #eee7dd;
  padding: 8px 0;
}
.outline li.indent1 { padding-left: 18px; }
.outline li.indent2 { padding-left: 36px; }
.outline li.indent3 { padding-left: 54px; }
.outline small {
  grid-column: 2;
  color: var(--muted);
  font-size: 11px;
  line-height: 1.45;
}
.sid {
  color: var(--accent);
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
  font-size: 11px;
}
.miniGrid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; }
.mini { border: 1px solid #eee7dd; border-radius: 8px; background: #fffaf3; padding: 10px; min-width: 0; }
.mini h3 { margin-top: 0; }
.mini strong { display: block; color: var(--accent); font-size: 22px; line-height: 1; margin-bottom: 8px; }
.mini ul { margin-bottom: 0; }
.summaryGrid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 8px; margin-bottom: 12px; }
.summaryCard { border: 1px solid #eee7dd; border-radius: 8px; background: #fffaf3; padding: 10px; min-width: 0; }
.summaryCard h3 { margin-top: 0; }
.summaryCard strong { display: block; color: var(--accent); font-size: 21px; line-height: 1.1; margin-bottom: 5px; overflow-wrap: anywhere; }
.summaryCard p { margin: 0; color: var(--muted); font-size: 11px; line-height: 1.42; }
.researchGrid { display: grid; grid-template-columns: 1fr 0.72fr 1fr; gap: 8px; margin-bottom: 10px; }
.researchCard { border: 1px solid #eee7dd; border-radius: 8px; background: #fffaf3; padding: 10px; min-width: 0; }
.researchCard h3 { margin-top: 0; }
.researchCard strong { display: block; color: var(--accent); font-size: 28px; line-height: 1; margin: 2px 0 7px; }
.researchSection { border-top: 1px solid #eee7dd; padding-top: 13px; margin-top: 13px; }
.researchSection:first-of-type { margin-top: 10px; }
.researchItem {
  border: 1px solid #eee7dd;
  border-radius: 8px;
  background: #fffdf9;
  padding: 11px;
  margin-bottom: 8px;
}
.researchItem h3 {
  color: #3c352e;
  font-size: 13px;
  line-height: 1.35;
  text-transform: none;
  letter-spacing: 0;
  margin: 0 0 5px;
}
.sourceLine { display: flex; flex-wrap: wrap; gap: 6px; margin: 0 0 8px; }
.sourceLine span {
  display: inline-flex;
  min-height: 20px;
  align-items: center;
  border: 1px solid var(--line);
  border-radius: 999px;
  background: var(--soft);
  color: var(--muted);
  font-size: 10px;
  line-height: 1.2;
  padding: 2px 7px;
}
.evidenceBlock, .implicationBlock {
  border-left: 2px solid #d8b29f;
  padding-left: 8px;
  margin-top: 8px;
}
.implicationBlock { border-left-color: #9cb89d; }
.evidenceBlock strong, .implicationBlock strong {
  display: block;
  color: var(--muted);
  font-size: 10px;
  font-weight: 760;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  margin-bottom: 2px;
}
.evidenceBlock p, .implicationBlock p { margin: 0; }
.artifactList { list-style: none; margin: 0; padding: 0; }
.artifactList li {
  display: grid;
  grid-template-columns: 130px minmax(0, 1fr) auto;
  gap: 8px;
  align-items: center;
  border-bottom: 1px solid #eee7dd;
  padding: 7px 0;
}
code {
  color: #4f473f;
  background: #f6efe6;
  border-radius: 5px;
  padding: 1px 4px;
  font-size: 11px;
}
.artifactList b { color: var(--good); font-size: 11px; }
.nextBox {
  margin-top: 12px;
  border: 1px solid #ead7c7;
  background: #fff8ed;
  border-radius: 8px;
  padding: 12px;
}
.nextBox strong { display: block; margin-bottom: 3px; font-size: 13px; }
.nextBox span { color: #5f574e; font-size: 12px; line-height: 1.45; }
@media (max-width: 900px) {
  .head, .grid { grid-template-columns: 1fr; }
  .facts { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .miniGrid, .researchGrid, .summaryGrid { grid-template-columns: 1fr; }
}
"""


def render_analysis_html(project: str, root: Path, output: Path) -> None:
    project_root = root / "projects" / project
    analysis_path = project_root / "artifacts" / "rfp" / "analysis.md"
    rfp_path = project_root / "artifacts" / "rfp" / "rfp.json"
    status_path = project_root / "artifacts" / "rfp" / "status.json"
    framework_path = project_root / "artifacts" / "strategy" / "framework_3c.json"
    source_packet_path = project_root / "inputs" / "references" / "gebiz_bid.md"
    pre_research_path = project_root / "artifacts" / "rfp" / "pre_research.json"

    analysis = read_text(analysis_path)
    source_packet = read_text(source_packet_path)
    rfp = load_json(rfp_path)
    status = load_json(status_path)
    framework = load_json(framework_path)
    pre_research = load_json(pre_research_path)
    overview = rfp.get("project_overview") if isinstance(rfp.get("project_overview"), dict) else {}
    title = overview.get("project_name") or project
    ready = bool(analysis.strip()) and status.get("status") == "ready" and bool(rfp)
    source_url = overview.get("source_url")
    source_link = f'<a href="{esc(source_url)}" target="_blank" rel="noreferrer">Open GeBIZ source</a>' if source_url else ""

    html_text = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>S0 Pre-Research and RFP Analysis - {esc(title)}</title>
  <style>{CSS}</style>
</head>
<body>
  <main class="shell">
    <article class="panel">
      <div class="head">
        <div>
          <div class="eyebrow">S0 Pre-Research &amp; RFP Analysis</div>
          <h1>{esc(title)}</h1>
        </div>
        <span class="status">{'S0 Complete' if ready else 'Preparing S0'}</span>
      </div>
      {render_facts(overview, status)}
      <div class="chips">
        {f'<span class="chip">{source_link}</span>' if source_link else ''}
      </div>
      <div class="subtabs" role="tablist" aria-label="S0 views">
        <button class="subtab active" type="button" data-view="research" role="tab" aria-selected="true">Pre-Research</button>
        <button class="subtab" type="button" data-view="analysis" role="tab" aria-selected="false">RFP Analysis</button>
      </div>
      <section class="tabPanel active" data-panel="research" role="tabpanel">
        <div class="grid">
          <div class="mainColumn">
            <section class="section markdown">
              <h2>Pre-Research</h2>
              {render_pre_research(project_root, overview, source_packet, pre_research)}
            </section>
          </div>
          <aside>
            <section class="section">
              <h2>S0 Artifacts</h2>
              {render_artifacts(project_root)}
            </section>
            <div class="nextBox">
              <strong>Next step requires confirmation</strong>
              <span>Strategy Interview, Win Themes, and slide stages will not start unless the user explicitly asks to continue.</span>
            </div>
          </aside>
        </div>
      </section>
      <section class="tabPanel" data-panel="analysis" role="tabpanel">
        <div class="grid">
          <div class="mainColumn">
            <section class="section markdown">
              <h2>RFP Analysis</h2>
              {markdown_to_html(analysis)}
            </section>
          </div>
          <aside>
            <section class="section">
              <h2>Extracted Requirements</h2>
              {render_requirements(rfp)}
            </section>
            <section class="section">
              <h2>Proposal Outline</h2>
              {render_outline(rfp)}
            </section>
            <section class="section">
              <h2>Initial Strategy Context</h2>
              {render_framework(framework)}
            </section>
          </aside>
        </div>
      </section>
    </article>
  </main>
  <script>
    const views = new Set(["research", "analysis"]);
    function viewFromHash() {{
      const params = new URLSearchParams((location.hash || "").replace(/^#/, ""));
      const view = params.get("view");
      return views.has(view) ? view : "research";
    }}
    function postPanelHash(view) {{
      if (window.parent !== window) {{
        window.parent.postMessage({{__contrl: "panelhash", hash: "view=" + view}}, "*");
      }}
    }}
    function setView(view) {{
      const next = views.has(view) ? view : "research";
      document.querySelectorAll(".subtab").forEach((button) => {{
        const active = button.dataset.view === next;
        button.classList.toggle("active", active);
        button.setAttribute("aria-selected", active ? "true" : "false");
      }});
      document.querySelectorAll(".tabPanel").forEach((panel) => {{
        panel.classList.toggle("active", panel.dataset.panel === next);
      }});
      history.replaceState(null, "", "#view=" + next);
      postPanelHash(next);
    }}
    window.addEventListener("DOMContentLoaded", () => {{
      document.querySelectorAll(".subtab").forEach((button) => {{
        button.addEventListener("click", () => setView(button.dataset.view || "research"));
      }});
      setView(viewFromHash());
      if (window.parent !== window) {{
        window.parent.postMessage({{__contrl: "ready", ready: {str(ready).lower()}}}, "*");
      }}
    }});
    window.addEventListener("hashchange", () => setView(viewFromHash()));
  </script>
</body>
</html>
"""
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html_text, encoding="utf-8")


def main() -> None:
    args = parse_args()
    project = args.project
    assert_project_name(project)
    root = Path(args.root).resolve()
    project_root = root / "projects" / project
    output = Path(args.output).resolve() if args.output else project_root / "outputs" / "rfp" / "analysis.html"

    render_analysis_html(project, root, output)
    print(output)


if __name__ == "__main__":
    main()
