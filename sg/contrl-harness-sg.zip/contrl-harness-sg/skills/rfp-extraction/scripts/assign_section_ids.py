#!/usr/bin/env python3
"""Deterministic section_id assigner for required_proposal_structure (stdlib only).

Procedure 3 of the rfp-extraction skill, extracted into a committed, testable
script so the two call sites that need it share one implementation:
  - S0b initial extraction (after procedure 2 produces the outline), and
  - the S3-entry 제안서 목차 재추출·편집 path (rps-review), after a re-extraction
    or a user edit changes the outline.

This is the ONLY deterministic step of the RPS pipeline. The outline
*extraction* itself (procedure 2, ``system_proposal_structure.md``) is an LLM
call and is out of scope here — this script never invents, reorders, or drops
sections; it only stamps stable ids onto whatever sections it is given.

Algorithm (idempotent, order-preserving):
  - Walk ``required_proposal_structure.sections`` (a FLAT list; hierarchy lives
    in each node's ``level``, not in nesting — unlike requirement_mapping, which
    this script does NOT touch).
  - A node already carrying ``sec_<digits>`` is preserved untouched.
  - A node without a valid id gets the next id past a high-water mark =
    max(persisted ``_section_id_counter``, largest existing ``sec`` number). So a
    surviving node is never renumbered on re-run, and a removed node's id
    *retires* (the counter never decrements) rather than being handed to a new
    node — provided ``_section_id_counter`` is preserved across edits, which is
    exactly why it is persisted (this script is its first real reader).
  - The final high-water mark is written back to ``_section_id_counter``.

Downstream (S3/S4/S5) routes on ``section_id``, so every dict node must end up
with one. A missing ``required_proposal_structure`` is normalized to the
not-found default ``{"page_limit": null, "sections": []}``; an empty section
list is the not-found signal and is reported as ``not_found: true``.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

COUNTER_KEY = "_section_id_counter"
# Accept any digit count so ids past 9999 (sec_10000) still count as valid and
# feed the high-water mark; assignment zero-pads to 4 and naturally grows wider.
SECTION_ID_RE = re.compile(r"^sec_(\d+)$")


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise SystemExit(f"{path} must contain a JSON object")
    return value


def dump_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def assign(rfp: dict) -> dict:
    """Assign/preserve section_ids on rfp['required_proposal_structure'] in place.

    Returns a report dict; does not write to disk (the caller does)."""
    rps = rfp.get("required_proposal_structure")
    if rps is None:
        rps = {"page_limit": None, "sections": []}
        rfp["required_proposal_structure"] = rps
    if not isinstance(rps, dict):
        raise SystemExit("required_proposal_structure must be a JSON object")
    sections = rps.get("sections")
    if sections is None:
        sections = []
        rps["sections"] = sections
    if not isinstance(sections, list):
        raise SystemExit("required_proposal_structure.sections must be a list")

    counter_before = rfp.get(COUNTER_KEY)
    counter = counter_before if isinstance(counter_before, int) and counter_before >= 0 else 0
    # High-water mark = persisted counter unioned with every existing sec number,
    # so new ids never collide with a preserved one even if the counter is stale.
    for node in sections:
        if not isinstance(node, dict):
            continue
        sid = node.get("section_id")
        if isinstance(sid, str):
            match = SECTION_ID_RE.match(sid)
            if match:
                counter = max(counter, int(match.group(1)))

    assigned: list[dict] = []
    skipped_non_dict = 0
    for index, node in enumerate(sections):
        if not isinstance(node, dict):
            skipped_non_dict += 1
            continue
        sid = node.get("section_id")
        if isinstance(sid, str) and SECTION_ID_RE.match(sid):
            continue  # already stable — preserve
        counter += 1
        new_id = f"sec_{counter:04d}"
        node["section_id"] = new_id
        assigned.append({"index": index, "section_id": new_id})

    rfp[COUNTER_KEY] = counter
    return {
        "sections_total": len(sections),
        "assigned": assigned,
        "assigned_count": len(assigned),
        "preserved_count": len(sections) - len(assigned) - skipped_non_dict,
        "skipped_non_dict": skipped_non_dict,
        "counter_before": counter_before,
        "counter_after": counter,
        "not_found": len(sections) == 0,
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Assign stable sec_NNNN ids to required_proposal_structure.sections (procedure 3).",
    )
    parser.add_argument("--rfp", required=True, help="Path to the project's rfp.json.")
    parser.add_argument(
        "--write",
        action="store_true",
        help="Apply changes in place. Default is dry-run: report what would change without writing.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    path = Path(args.rfp)
    rfp = load_json(path)
    report = assign(rfp)
    if args.write:
        dump_json(path, rfp)
    report["written"] = bool(args.write)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main(sys.argv[1:])
