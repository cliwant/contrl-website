# Win Theme Discovery

Generate exactly 3 Win Themes. Anchor each theme in the **3C Framework Snapshot** (customer / company / competitor bullets distilled from the interview), and cross-check against the **RFP Extraction** (pre-extracted structural facts).

Rank themes by significance of the customer need — Theme 1 = most critical, Theme 3 = least critical of the three.

## Win Theme Structure (5 fields per theme)

Each theme is composed of 5 fields. Four are *decomposition* fields with citation tokens; `headline` is the *unifying* user-facing line on top.

**Every decomposition field must contain a NATURAL-LANGUAGE sentence (or short clause) that describes the dimension IN YOUR OWN WORDS, with the citation token(s) appearing INSIDE or AT THE END of that sentence.** Do NOT output a field whose entire value is only citation tokens (e.g. `"[c4] [c7]"`) — that is a failure mode. The reader needs a complete sentence; the citations are the source, not the content.

| Field | What it answers | Content + Citation policy |
|-------|-----------------|---------------------------|
| `headline` | One-to-two-sentence persuasive line that unifies the four dimensions below into a single message. UI card header. | Natural-language sentence(s). **No citation tokens.** No `[c{{n}}]` / `[co{{n}}]` / `[cm{{n}}]` in this field. |
| `customer_need` | What pain or goal does the customer have? | Short prose clause describing the need + at least one `[c{{n}}]` citation. Example: `"The agency treats operational continuity as a top evaluation priority [c1]"`. |
| `feature.statement` | What can our solution do in response? (capability claim) | Prose sentence stating the capability + at least one `[co{{n}}]`. Prefer `strength` / `discriminator` subtype. Example: `"Our operating framework sustains 95%+ service availability across comparable deployments [co3]"`. |
| `feature.discriminator` | (Optional) What part of this feature do competitors lack? | Prose sentence + BOTH `[co{{n}}]` (our side, prefer `discriminator` subtype) AND `[cm{{n}}]` (their gap). Else `null`. |
| `benefit` | What outcome / result does the customer get thanks to the feature? | Prose sentence naming the outcome + at least one 3C customer `[c{{n}}]` (prefer `motivator` / `decision_criteria`). Example: `"Evaluators can approve the approach without carrying unresolved operational-risk concerns [c2]"`. |
| `proof_points` | 1–3 concrete evidence items backing the feature claim. | Each item is one prose sentence/phrase (metric, certification, reference, case study) + at least one `[co{{n}}]`. Prefer subtype `proof_point`; fall back to `strength` / `other`. |

### `headline` — unifying line

The four decomposition fields each answer one dimension; `headline` weaves them into a single sentence (or two) the evaluator can read at a glance. Treat it as the *anchor* the downstream Theme Statement reduces to.

- 1–2 sentences. No citation tokens.
- All four dimensions should leave a trace — Customer Need anchored, Feature responds, Benefit names the outcome, Proof Point provides credibility.
- Distinct from `feature.statement` (which is a decomposed capability claim with `[co{{n}}]` citation). Do not just copy `feature.statement` into `headline`; do not just rephrase `label`.
- Must pass the **Swap Test**: if pasted into a different proposal it should read wrong.

### `feature` — capability claim + optional differentiator

- `feature.statement` (required): 1–2 sentences. *What* our solution does in response to the customer need. Always cite a 3C company bullet `[co{{n}}]`. Do NOT pour proof / metrics into this field — those belong in `proof_points`.
- `feature.discriminator` (optional, `null` when absent): one short sentence naming the *part of this feature competitors lack*. MUST cite both `[co{{n}}]` (our evidence) and `[cm{{n}}]` (the competitor gap). When the 3C `competitor` axis is empty or the competitive picture is weak, leave `null` — all three themes may be `null`, that is normal. Do not invent.

### `proof_points` — backing evidence

- 1–3 items per theme. Each item is one short sentence or phrase: a metric, certification, reference, case study — something the evaluator can verify.
- Each item cites 3C company `[co{{n}}]`. Subtype preference: `proof_point` > `strength` > `other`. Skip `discriminator` subtype (it belongs to `feature.discriminator`).
- Each proof point must directly back the same theme's `feature.statement`. Unrelated brag (different-domain wins, generic certs) does not belong.
- Do not duplicate `benefit` numbers — `benefit` predicts the customer's future outcome, `proof_points` show our past delivery.

## Ranking

- **Theme 1**: most critical customer need — closest to the project's hidden purpose or core pain.
- **Theme 2**: next most important need.
- **Theme 3**: a real but relatively lower-priority need.

All 3 themes must address **genuinely different customer needs** (not the same idea rephrased).

## Process

1. Read the 3C snapshot top-down. Map customer bullets to candidate needs; note which `company` bullets supply credible capability + proof for each; note which `competitor` bullets could power a defensible discriminator.
2. Cross-check with the RFP artifact's `hidden_purpose.inference`, `pain_points`, and high-priority `requirements`. Use RFP to confirm priority and to surface angles 3C may not cover for `customer_need` / `benefit`.
3. Rank customer needs by significance.
4. For each need, write the 4 decomposition fields with required citations.
5. Write the `headline` last — synthesize the 4 fields into one user-facing line. Verify Swap Test.
6. Verify each theme addresses a genuinely different customer need.

## Reference Citation Format

### Citation tokens

- `[c{{n}}]` — 3C customer bullet (e.g. `[c2]`)
- `[co{{n}}]` — 3C company bullet (e.g. `[co3]`)
- `[cm{{n}}]` — 3C competitor bullet (e.g. `[cm1]`)

All bullet ids you cite MUST exist in the 3C snapshot above. RFP page citations (`[p.N]`) are **not allowed** in Win Theme output — any page-level evidence must already be captured as a 3C bullet for you to cite.

### Where citations go

- `headline`, `label`: **NO citation tokens** (user-facing display text).
- `customer_need`: at least one `[c{{n}}]`.
- `feature.statement`: at least one `[co{{n}}]`.
- `feature.discriminator` (if not null): both `[co{{n}}]` AND `[cm{{n}}]`.
- `benefit`: at least one `[c{{n}}]`.
- `proof_points[*]`: each item at least one `[co{{n}}]`.

## Output Format

Two response modes, depending on what the user is asking for. See the Tool Usage section in the assembly prompt for when to use each.

### Generation mode (call `emit_win_themes`)

Invoke the tool exactly once. The tool input shape:

- `context.project_purpose`: One sentence — the customer's true objective / hidden purpose (not the surface scope). Rendered as a header above the option cards.
- `themes`: array of exactly 3 theme objects, ranked by significance.

Each theme object:
- `index` (1-based rank)
- `label` (short label for the customer need — no citations)
- `headline` (1–2 sentence unifying line — no citation tokens)
- `customer_need` (with `[c{{n}}]`)
- `feature.statement` (capability, with `[co{{n}}]`)
- `feature.discriminator` (optional, both `[co{{n}}]` AND `[cm{{n}}]`, or `null`)
- `benefit` (outcome, with `[c{{n}}]`)
- `proof_points` (1–3 items, each with `[co{{n}}]`)

Use **bold** markdown on important words in `label`, `headline`, and `benefit` to help them stand out — 2–4 bolded phrases max. Treat `context.project_purpose` as the option-set header and each theme as a selectable option with expandable details.

### Q&A mode (text reply, no tool call)

Plain conversational text. Refer to existing themes by index when the user asks about them. Do not invent new themes; do not embed JSON payloads. Keep the response focused on the user's question.
