## Win Theme Quality

### What Makes a Strong Win Theme

A win theme is the persuasive message delivered to the customer evaluator. It appears throughout the proposal and makes the evaluator feel: "This company understands our problem and can deliver."

| Field | Test |
|-------|------|
| `headline` | Are all four dimensions present? |
| `customer_need` | Would the customer nod "yes, that's our problem"? |
| `feature.statement` | Could a competitor copy-paste this claim? If yes, too generic. |
| `feature.discriminator` (opt.) | Is the competitor gap concretely cited? |
| `benefit` | Is it measurable or tangible? Answers "so what's in it for us?" |
| `proof_points` | Can the evaluator verify the metric / cert / reference? |

### Strong vs Weak: The Specificity Test

A strong win theme could only belong to this proposal, for this customer, from this company. A weak win theme could be pasted into any proposal unchanged.

Apply the **Swap Test** (defined in the Discovery instructions above) to each `headline` before finalizing.

**English Examples (`headline`):**

| Weak | Strong | Why the weak version fails |
|------|--------|--------------------------|
| "We provide high quality solutions." | "Reduce deployment risk with our 120+ enterprise rollout framework — 90-day production targets met on every engagement." | No customer need, no evidence. |
| "We are customer focused." | "Dedicated customer success team guaranteeing <24h response — proven across 3 government agency deployments." | Meaningless vs specific commitment + evidence. |


### Common Failure Patterns

| Pattern | Example | Fix |
|---------|---------|-----|
| `headline` is a slogan | "Industry-leading technology" | Bring in the customer need, the feature response, the outcome. |
| `headline` repeats `label` | label "Operational continuity" -> headline "We secure stable operations." | Headline must unify all four dimensions, not paraphrase the label. |
| `feature.statement` carries proof | "We provide a stable environment based on three public-sector operations references." | Move "three public-sector operations references" into `proof_points`; keep `feature.statement` to capability. |
| `proof_points` lists irrelevant brag | Different-domain wins, generic certs | Each proof must back THIS theme's feature claim. |
| `feature.discriminator` invented | No `[cm{{n}}]` citation but field is set | Leave `null` if competitor axis is empty / weak. |
| Same idea 3 ways | All 3 themes describe the same need rephrased | Each theme must address a different customer need (see Differentiation Check below). |

### Differentiation Check Across Themes

After writing all 3 themes, verify:

- Theme 1 `customer_need` ≠ Theme 2 ≠ Theme 3 — each must illuminate a different facet of the customer's situation.
- If two themes share the same `customer_need`, merge them or surface a different need from the 3C customer bullets.
- A different `feature.statement` paired with the same `customer_need` still counts as duplication — themes are differentiated by the *need they address*, not by the capability response.
- Ranking still holds: Theme 1 = most critical need, Theme 3 = least critical of the three (per `win_theme_system.md` priority order).
