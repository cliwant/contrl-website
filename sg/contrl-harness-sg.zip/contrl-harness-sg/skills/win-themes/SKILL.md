---
name: win-themes
description: >-
  CONTRL pipeline S2 — Win Themes. Reads rfp.json and framework_3c.json to generate three ranked Win Themes based on customer needs and writes win_themes.json.
  Use for Win Theme generation/regeneration/selection, strategy themes, pursuit strategy cards, or S2 execution. S3 Theme Statements consumes the selected Win Theme.
---

# S2 — Win Theme 생성 (Win Themes)

## Customer Delivery Defaults

Generate all Win Theme fields, option descriptions, labels, and HTML panel text in English. Translate Korean or other non-English evidence into natural business English while preserving official proper nouns when needed.

`rfp.json`과 3C 스냅샷을 입력으로 **고객 니즈 중요도 순 Win Theme 3개**를 생성한다. 각 테마는 customer_need / feature / benefit / proof_points 4차원을 headline으로 통합한다. 유저가 하나를 선택하면 S3가 그 테마로 환원된다.

## 입출력 계약

- **입력:** `projects/{name}/artifacts/rfp/rfp.json`,
  `projects/{name}/artifacts/strategy/framework_3c.json`
- **출력:** `projects/{name}/artifacts/strategy/win_themes.json`
- **출력 (패널, read-only 파생물, gate 비대상):** `projects/{name}/outputs/strategy/win_themes.html` — **선택된 단일 Win Theme**를 사용자에게 보여주는 contrl-shell 패널. 아래 "선택 결과 패널" 절이 단일 소스. 렌더 실패는 스테이지를 막지 않는다.

## 절차

1. 시스템 프롬프트 조립 (`references/prompts/win_theme_assembly.md` 템플릿):
   - `{rfp_json}` = rfp.json 직렬화
   - `{framework_3c_markdown}` = 3C를 마크다운으로. **각 bullet을 citation id와 함께**
     렌더 — customer는 `[c{n}]`, company는 `[co{n}]`, competitor는 `[cm{n}]` 형태로
     인용 가능하도록 id를 노출.
   - `{win_theme_instructions}` = win_theme_system.md
   - `{quality_checks}` = quality_checks_themes.md
2. 구조화 출력 (아래 스키마).
3. `WinThemesOutput` 검증 후 `win_themes.json`에 `selected_win_theme_id: null`로 저장.


## 선택 (절차는 orchestrator 소유)
어느 테마를 쓸지는 유저 결정이므로 에이전트 세션이 아니라 orchestrator에서 수행한다. **선택 절차의 단일 출처는 `pipeline` 스킬의 `references/wintheme-selection.md`다** — 옵션 제시·선택 기록·렌더 호출·resolve 순서는 그쪽이 소유한다. 이 스킬은 그 절차가 참조하는 도메인 명세 두 가지(아래 "옵션 설명" 콘텐츠 명세, "선택 결과 패널" 렌더 명세)만 소유한다. 선택 기록 후의 패널 렌더 *실행*은 `win-theme-runner`를 다시 호출해 수행하며(이 스킬의 "선택 결과 패널" 명령을 그대로 실행), orchestrator는 그 호출을 트리거만 한다.

### 옵션 설명 (runner 반환 텍스트의 단일 출처)
`win-theme-runner`는 3개 테마 각각을 아래 구성요소를 전부 들어 산문으로 설명한 텍스트를 반환값에 싣는다. `context.project_purpose`로 전체 맥락을 먼저 잡고, 각 테마를 스키마 필드 그대로 설명한다. citation 토큰(`[c2]`/`[co3]`/`[cm1]`/`[p.N]`)은 유저에게 의미 없으므로 제거/정규화한다. index 1=가장 중요 순서를 유지한다.
- **headline** — 이 테마의 핵심 설득 라인 (4차원 통합 1-2문장).
- **customer_need** — 어떤 고객 니즈/hot button에 답하나.
- **feature.statement (+ discriminator)** — 무엇으로 답하는 역량인지. `discriminator`가 있으면 "경쟁사가 못 하는 차별점"으로 강조, null이면 생략.
- **benefit** — 고객이 얻는 측정가능 성과.
- **proof_points** — feature를 뒷받침하는 1-3개 근거.

## 선택 결과 패널 (win_themes.html)
**선택된 단일 Win Theme 1개만** 전체 스키마 필드(headline / customer_need / feature(+discriminator) / benefit / proof_points)와 함께 정적 HTML 패널로 렌더해 contrl-shell 메뉴(`S2`)에 띄운다. 선택되지 않은 테마는 패널에 표시하지 않는다. `selected_win_theme_id`가 null이면(아직 선택 전·seed 직후) 카드 없이 안내 문구만 표시한다. citation 토큰(`[c2]`/`[co3]`/`[cm1]`/`[p.N]`)은 렌더러가 제거한다. 선택이 바뀌면(재선택) 같은 명령으로 다시 렌더해 덮어쓴다.

**렌더 명령** (CWD가 유저 레포라 상대경로 불가 → 스크립트는 `${CLAUDE_PLUGIN_ROOT}`, 출력 루트는 절대경로):
```bash
python3 "${CLAUDE_PLUGIN_ROOT}/skills/win-themes/scripts/render-selected-html.py" \
  <project_name> --root "<projects/ 가 있는 절대경로>"
```
출력 `projects/{name}/outputs/strategy/win_themes.html`. `selected_win_theme_id`가 null이면 카드 없이 안내 문구만 그린다.

## 출력 스키마 (win_themes.json)
```json
{
  "context": { "project_purpose": "한 문장: RFP 뒤 고객의 진짜 목적" },
  "themes": [
    {
      "index": 1,
      "label": "고객 니즈 짧은 이름 (citation 없음)",
      "headline": "4차원을 통합한 1-2문장 설득 라인 (citation 토큰 없음)",
      "customer_need": "니즈 서술 + 인용. 최소 1개 3C customer 인용 [c2]. RFP page [p.N] 금지",
      "feature": {
        "statement": "역량 주장. 3C company 인용 [co3]. 구체 근거는 proof_points로",
        "discriminator": "차별화(경쟁사 결여) 또는 null. 있으면 [co{n}]+[cm{n}] 둘 다 인용"
      },
      "benefit": "측정가능 성과 문장 + 3C customer 인용 [c2]. [p.N] 금지",
      "proof_points": ["feature 뒷받침 근거 1-3개. 각 3C company 인용 [co{n}]"]
    }
  ]
}
```
`proof_points` 1-3개.

저장 시 추가 필드:
```json
{ "selected_win_theme_id": null|1|2|3}
```

## 인용 규칙 (citation)
- 3C bullet만 인용: customer `[c{n}]`, company `[co{n}]`, competitor `[cm{n}]`.
- RFP page 인용 `[p.N]`은 customer_need/benefit에 **금지**.
- `label`/`headline`/`context.project_purpose`에는 citation 토큰 금지.
