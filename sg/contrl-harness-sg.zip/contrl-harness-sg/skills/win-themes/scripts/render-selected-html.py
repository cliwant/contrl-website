#!/usr/bin/env python3
"""Render the selected Win Theme as a static HTML panel for contrl-shell.

Reads `projects/<project>/artifacts/strategy/win_themes.json` and writes
`projects/<project>/outputs/strategy/win_themes.html`. Only the selected theme
(`selected_win_theme_id`) is rendered as a single card; non-selected themes are
not shown. When nothing is selected (null / seed), only a notice is rendered.
Citation tokens ([c2]/[co3]/[cm1]/[p.5]) are stripped, per the win-themes
citation rule (they are meaningless to the user).
"""
from __future__ import annotations

import argparse
import json
import re
from html import escape
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE_PATH = SKILL_ROOT / "templates" / "win-themes-selected.html"

# Citation tokens like [c2], [co3], [cm1], [p.5] — stripped for user-facing render.
CITATION_RE = re.compile(r"\s*\[(?:c|co|cm|p\.)[^\]]*\]")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render selected Win Theme panel HTML.")
    parser.add_argument("project", help="Project name under projects/.")
    parser.add_argument("--root", required=True, help="Absolute path to the dir that contains projects/.")
    parser.add_argument("--input", help="win_themes.json path. Defaults to the project artifact path.")
    parser.add_argument("--output", help="HTML output path. Defaults to the project outputs path.")
    return parser.parse_args()


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def clean(value: object) -> str:
    """Strip citation tokens, collapse whitespace, HTML-escape."""
    text = CITATION_RE.sub("", str(value or "")).strip()
    text = re.sub(r"\s{2,}", " ", text)
    return escape(text)


def render_field(title: str, body_html: str) -> str:
    return f'<div class="field"><span class="ftitle">{escape(title)}</span>{body_html}</div>'


def render_card(theme: dict) -> str:
    label = clean(theme.get("label"))
    headline = clean(theme.get("headline"))

    fields: list[str] = []
    if theme.get("customer_need"):
        fields.append(render_field("Customer Need", f"<p>{clean(theme['customer_need'])}</p>"))
    feature = theme.get("feature") or {}
    if feature.get("statement"):
        body = f"<p>{clean(feature['statement'])}</p>"
        if feature.get("discriminator"):
            body += f'<p class="disc"><span class="dtag">Discriminator</span>{clean(feature["discriminator"])}</p>'
        fields.append(render_field("Solution / Capability", body))
    if theme.get("benefit"):
        fields.append(render_field("Expected Outcome", f"<p>{clean(theme['benefit'])}</p>"))
    proof = [p for p in (theme.get("proof_points") or []) if str(p or "").strip()]
    if proof:
        items = "".join(f"<li>{clean(p)}</li>" for p in proof)
        fields.append(render_field("Proof", f"<ul>{items}</ul>"))

    head = '<span class="opt">Selected Win Theme <span class="check">✓</span></span>'
    if label:
        head += f'<span class="label">{label}</span>'
    basis = f'<div class="basis">{"".join(fields)}</div>' if fields else ""
    return (
        f'<article class="card selected">'
        f'<div class="cardHead">{head}</div>'
        f'<p class="headline">{headline}</p>'
        f"{basis}"
        f"</article>"
    )


def render_html(data: dict, project: str) -> str:
    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    themes = sorted(data.get("themes") or [], key=lambda t: t.get("index", 0))
    panel_ready = bool(themes)
    selected_id = data.get("selected_win_theme_id")
    selected = next((t for t in themes if t.get("index") == selected_id), None)
    cards = render_card(selected) if selected else ""

    purpose = clean((data.get("context") or {}).get("project_purpose"))
    notice_text, notice_class = "", "hidden"
    if selected is None:
        if not panel_ready:
            notice_text = "No Win Theme has been generated yet. Results will appear here as this stage progresses."
        else:
            notice_text = "No Win Theme has been selected yet. The selected Win Theme will appear here."
        notice_class = ""

    replacements = {
        "TITLE": f"Win Theme - {project}",
        "HEADING": "Win Theme",
        "PROJECT_LABEL": f"Project: {escape(project)}",
        "PURPOSE_TITLE": "Project Purpose",
        "PURPOSE_TEXT": purpose,
        "PURPOSE_CLASS": "" if purpose else "hidden",
        "NOTICE_CLASS": notice_class,
        "NOTICE_TEXT": notice_text,
        "CARDS_HTML": cards,
        "PANEL_READY": "true" if panel_ready else "false",
    }
    for key, value in replacements.items():
        template = template.replace(f"{{{{{key}}}}}", value)
    return template


def main() -> None:
    args = parse_args()
    root = Path(args.root).resolve()
    project = args.project
    input_path = (
        Path(args.input).resolve()
        if args.input
        else root / "projects" / project / "artifacts" / "strategy" / "win_themes.json"
    )
    output = (
        Path(args.output).resolve()
        if args.output
        else root / "projects" / project / "outputs" / "strategy" / "win_themes.html"
    )
    # 입력이 없으면(워크플로 진입 시 seed) 빈 데이터로 "아직 준비 안됨" 패널을 렌더한다.
    data = load_json(input_path) if input_path.exists() else {}
    html_text = render_html(data, project)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html_text, encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
