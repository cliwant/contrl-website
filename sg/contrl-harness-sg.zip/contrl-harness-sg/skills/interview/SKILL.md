---
name: interview
description: >-
  CONTRL pipeline S1 — Strategy Interview. Runs a multi-turn strategy interview from RFP context and updates framework_3c.json after each answer.
  Use for strategy interviews, 3C updates, customer/company/competitor synthesis, S1 execution, interview-question generation, interview summaries, and live 3C HTML feedback.
  Produces the updated framework_3c.json and a user-facing English 3C progress panel.
---

# S1 — 전략 인터뷰 (Strategy Interview)

## Customer Delivery Defaults

Ask interview questions and write summaries, 3C bullets, options, labels, and progress-panel text in English. Translate Korean or other non-English context into natural business English before updating `framework_3c.json`.

RFP만으로는 부족한 전략 컨텍스트(고객의 진짜 동기, 자사 강점, 경쟁 구도)를 멀티턴 인터뷰로 끌어내 **3C 프레임워크에 누적**한다. 이 단계의 산출물은 대화 자체가 아니라 **갱신된 `framework_3c.json`**

## 입출력 계약

- **입력:**
  - `projects/{name}/artifacts/rfp/analysis.md` — S0a가 만든 RFP 산문 분석. **첫 턴**이 `<rfp_analysis>` 블록으로 주입받아 그대로 제시(인터뷰는 분석을 다시 만들지 않는다)
  - `projects/{name}/artifacts/rfp/pre_research.json` — optional source-backed pre-research. When present, inject it as `<pre_research_context>` so Strategy Interview questions and summaries reflect issuer news, past similar procurements, winner-company signals, and topic trends gathered before S1.
  - `projects/{name}/artifacts/rfp/rfp.json` — `<rfp_context>` 블록으로 주입(후속 턴; 선택적 enrichment)
  - `projects/{name}/artifacts/strategy/framework_3c.json` — `<framework_3c>` 블록으로 주입
  - 대화 메시지 (user/assistant 교대)
- **출력:** `projects/{name}/artifacts/strategy/framework_3c.json` — 매 user 답변마다 갱신

## 인터뷰 중 3C Live Feedback

사용자가 답변하는 동안 `framework_3c.json`이 핵심 산출물로 축적되는 것을 사용자 확인용 HTML output으로 보여준다.
`framework_3c.json` 변경은 background 3C 갱신(`framework-3c-updater` agent) 단독이다 — 이 갱신이 어느 단계에서 일어나는지는 아래 Phase 2가 정의한다.
**비블로킹인 한** 진입 시드 렌더(foreground; 아래 Phase 2 ② 참조)와 갱신 후 렌더(background) 양쪽에서 emit될 수 있다.

- 원본: `projects/{name}/artifacts/strategy/framework_3c.json`
- output path: `projects/{name}/outputs/interview/framework_3c.html`


## 절차

오케스트레이터는 매 턴 phase를 판정해 프롬프트를 구동하고 직전 질문을 보관한다. **Phase 1 대화 로직은 이 SKILL이 단일 소스**이고, **Phase 2 대화 로직은 시스템 프롬프트** (`references/prompts/strategy_interview_system.md`, Phase 2 전용)가 단일 소스다. 
**3C 갱신은 Phase 2 인터뷰 답변에서만** 일어난다 — 아래는 Phase 1 → Phase 2 순서로 기술한다.

**컨텍스트 주입 (공통):** 구동 프롬프트 끝에
- `<rfp_analysis>{analysis.md}</rfp_analysis>` (첫 턴 전용 — S0a 산출 분석을 그대로 제시)
- `<pre_research_context>{pre_research.json}</pre_research_context>` (있을 때만 — S0 Pre-Research의 issuer news, past similar procurements, winner-company analysis, and topic trends. 첫 질문의 가설/선택지와 후속 요약에 자동 반영)
- `<rfp_context>{rfp.json}</rfp_context>` (후속 턴; 있을 때만)
- `<framework_3c>{customer,company,competitor,completeness}</framework_3c>`
  (bullet이 하나라도 있을 때)
를 붙인다. **프롬프트에만** 주입 — 채팅 히스토리엔 넣지 않아 토큰이 턴 수에 비례하지 않게.

**직전 질문 보관 (공통):** `AskUserQuestion` 호출 입력의 질문 텍스트·옵션을 직전 질문으로 보관해
다음 턴 Phase 2 3C 갱신(`{question}`)에 쓴다. 단 **Phase 1 경로 메뉴 질문은 3C 추출에 쓰지
않는다**.

### Phase 1 — RFP 개요 & Q&A (유저가 ②/③을 고르기 전)

Phase 1엔 **3C 갱신이 없다** — RFP 시드가 먼저 안착해야 하고, 메뉴 선택·RFP Q&A 응답은 전략
정보가 아니기 때문이다. RFP 분석·자유 Q&A는 **산문(텍스트)**, 경로 선택은 내장
`AskUserQuestion` 도구로 제시한다. **Phase 1에서는 Interview Summary 턴을 만들지 않는다**(요약은 Phase 2 종료에서만).

**첫 턴 (대화 이력 없음):** RFP 분석은 **이미 S0a가 만들어** `<rfp_analysis>` 블록으로 주입된다.
이 분석을 **다시 만들지 않는다** — 인터뷰는 그 본문을 오프닝으로 **그대로 제시**한다(필요하면 매끄러운
연결을 위한 한두 문장만 덧붙이되, 렌즈를 새로 돌리거나 RFP를 재요약하지 않는다. 분석 형식·렌즈·인용
규칙의 단일 소스는 `rfp-extraction` 스킬의 절차 5와 그 시스템 프롬프트다). `<pre_research_context>`가 있으면 그 내용을 별도 재조사하지 말고, 첫 질문의 선택지/가설에 자연스럽게 반영한다. 예: 발주처 뉴스와 ServiceSG 방향은 고객 핵심 니즈 가설에, 과거 유사 발주와 수주사 분석은 경쟁/운영 리스크 가설에, topic trends는 governance·accuracy·public-service AI 가설에 반영한다. 제시 뒤 아래 **경로 메뉴**
3개를 `AskUserQuestion` 질문 1개로 제시한다(`header` 예: "진행 방식", `multiSelect: false`). 옵션
라벨은 아래 canonical을 **그대로** 쓰고 각 옵션에 한 줄 `description`을 단다.

**후속 턴 (유저가 ①을 고른 뒤):** 유저가 끝났다고 명시할 때까지 RFP 질문을 계속 받는다. 매 턴
메뉴를 다시 띄우지 않는다 — 반복 노출은 유저의 질문이 잘못됐다는 신호로 읽힌다. 유저 답변은
셋 중 하나로 매핑된다:
- **A — ①을 골랐지만 아직 구체적 질문이 없음** (맨 "①", "더 확인하고 싶어요"): 질문을 권하고
  필요하면 RFP 기반 토픽 2–4개를 제안. 메뉴 없음.
- **B — 구체적 RFP 질문**: `[p.N]` 인용과 함께 답하고 "이 부분에 대해 더 궁금한 점이
  있으신가요?" 같은 열린 후속으로 마무리. 메뉴 없음.
- **C — 질문 종료 신호** ("이제 됐어요", "더 없어요", "충분합니다"): 짧게 확인하고 ①을 닫은 뒤
  남은 ②/③ 두 경로만 `AskUserQuestion`으로 제시.

답변이 진짜 모호하면(맥락 없는 "네", "잘 모르겠네요") Phase 1에 머물며 직전에 보여준 메뉴를
재제시한다(첫 턴이면 3개 전부, Sub-case C 이후면 ②/③). ②/③ 선택 시 **같은 턴에 짧은 확인과
함께 Phase 2로 전환**한다.

**턴 형태:**
- 메뉴 턴 (첫 턴, Sub-case C, 모호 재질문): 산문(첫 턴은 주입된 RFP 분석 제시) + `AskUserQuestion` 1회.
- Q&A 턴 (Sub-case A, B): 산문만, 도구 호출 없음.

**경로 메뉴 (canonical) — 옵션 라벨 단일 소스:**

1. 인터뷰 전에 RFP에 대해 먼저 확인하고 싶다 (이후 2/3으로 진행)
2. 우리 회사·경쟁사 정보를 반영한 차별화된 전략을 원한다 (추천)
3. 일단 RFP만으로 빠르게 초안을 받고, 나중에 보완하겠다

선택 매핑: 1→Phase 1 유지(RFP Q&A), 2→Phase 2 인터뷰, 3→Phase 2 요약 직행.

### Phase 2 — 인터뷰 / 요약 (유저가 ②/③ 선택 후)

②는 인터뷰, ③은 요약 직행이다.
한 인터뷰 턴은 두 단계로 구성된다 — **Q 단계**(질문: 다음 질문/요약 생성)와 **U 단계**(Update: 3C 갱신 background). 이 Q/U는 Phase 1의 `Sub-case A/B/C`와 다른 네임스페이스다.
②에서는 매 user 답변마다 **Q와 U를 같은 응답에 함께 emit**하되 **U(spawn)를 Q(blocking `AskUserQuestion`)보다 앞이나 병렬로 둔다** — 근거·실행 형태는 아래 실행 루프와 Anti-patterns에 단일 기술한다.
③에서는 곧장 요약(Q 단계)을 생성한다(U 단계 없음).

**② 진입 시드 렌더:** 인터뷰(②) 진입 직후, 첫 `AskUserQuestion`을 보낸 **뒤(또는 병렬로, 절대 그 앞이 아니라)** 현재 `framework_3c.json`(S0 시드 상태)을 1회 렌더해 baseline HTML을 보여준다.
이 시드 렌더는 canonical을 건드리지 않고 렌더 스크립트를 **호출만** 하며(메커닉은 `framework-3c-updater` agent가 단일 소스), 비블로킹이다.
③(요약 직행)에는 3C 갱신이 없으므로 시드 렌더도 하지 않는다.

실행 주체는 명확하다.
`AskUserQuestion`은 **현재 인터뷰를 진행 중인 main/orchestrator가 `interview` skill 지시대로 직접 호출**한다.
다음 질문 생성을 서브에이전트에 맡기고 그 응답을 기다린 뒤 `AskUserQuestion`을 호출하지 않는다.
3C 갱신만 `framework-3c-updater` background agent로 분리한다.

② 인터뷰 턴 실행 루프 (Q·U를 같은 응답에 함께, U 먼저):

```text
on_user_answer(answer):
  latest_turn = {question: previous_ask_user_question_input, answer, turn_index}

  # U. 방금 받은 답변의 3C 반영을 background로 먼저 띄운다.
  # spawn 직전에 framework_3c.json의 _meta.pending_interview_updates에 이 turn_index만 append해,
  # 혹시 spawn을 빠뜨려도 다음 렌더/게이트에서 누락이 드러나게 한다 (3C 본문은 절대 건드리지 않는다).
  Agent(subagent_type="contrl:framework-3c-updater", run_in_background=true)

  # Q. 같은 응답에서 다음 질문을 낸다.
  # main/orchestrator가 interview skill로 다음 질문을 결정해 AskUserQuestion을 호출한다.
  AskUserQuestion(next_question, options)
```

#### Q 단계 — 다음 질문 / 요약 생성

인터뷰(②)에서 user가 답하면, **직전 답변 자체를 primary input으로 삼아** 다음 질문을 먼저 생성한다.
이때 `framework_3c.json`은 직전까지 저장된 snapshot일 수 있으며, 방금 답변이 아직 3C에 반영되지 않았을 수 있다.
따라서 질문 생성 프롬프트에는 다음을 함께 주입한다:
- 직전까지 저장된 `<framework_3c>{customer,company,competitor,completeness}</framework_3c>`
- 저장된 `<pre_research_context>{pre_research.json}</pre_research_context>`가 있으면 함께 사용한다. 단, 이미 사용자에게 검증받은 사실처럼 단정하지 말고 "research signal" 또는 "hypothesis to validate"로 다룬다.
- `<latest_interview_turn>{question, answer, turn_index}</latest_interview_turn>`

시스템 프롬프트(`strategy_interview_system.md`)가 단일 소스.
인터뷰 턴(`AskUserQuestion`) → 충분하면 Interview Summary 턴(도구 호출 없이 본문으로 요약 작성, 그 자체가 S1 종료 신호).
두 모드(②=인터뷰, ③=요약 직행), `AskUserQuestion` 사용 형식, 종료(Completion) 조건은 모두 시스템 프롬프트가 정의한다 — 여기서 중복 기술하지 않는다.

#### U 단계 — 직전 답변으로 3C 갱신 (background)

추출·op 작성·적용 순서·스킵 판정 등 갱신 규칙은 `framework-3c-updater` 에이전트가 단일 소스로 정의·수행한다. 오케스트레이터는 위임만 하며 다음 둘만 책임진다:
- **입력 전달:** 현재 `framework_3c.json` 상태(운영 필드 `_meta`/`status` 제외, version/customer/company/competitor/completeness)와 `latest_interview_turn` = {turn_index, question(직전 assistant 질문), answer}.
- **pending append:** 위 코드블록대로 `_meta.pending_interview_updates`에 `turn_index`만 더한다(read→append→write, 3C 본문 미접촉 — 동시에 도는 직전 턴 updater의 쓰기와 충돌 방지). 정상 경로에선 updater가 시작 시 self-heal하므로 이 기록은 spawn 누락 감지용 안전장치다.

남은 pending은 인터뷰 중엔 허용되며 HTML output이 "답변 반영 중"으로 표시한다 — S2 진입 전 pipeline gate가 비운다.

### Anti-patterns

아래 방식은 이 스킬 계약 위반이다.

- 질문 생성을 서브에이전트에 위임하고, 그 결과를 기다린 뒤 main/orchestrator가 `AskUserQuestion`을 호출하는 구조.
  에이전트 왕복 시간이 Q 앞에 끼어 사용자가 다음 질문을 기다리게 된다.
- 오케스트레이터(main/orchestrator)가 `framework_3c.json`의 **3C 본문(`customer`/`company`/`competitor`/`completeness`)**을 직접 읽거나 수정하는 구조 — 시점·방법에 관계없이 금지. 모든 3C 본문 변경은 반드시 `framework-3c-updater` 에이전트를 통해서만 이루어진다. (운영 필드 `_meta.pending_interview_updates`에 turn_index를 append하는 것만 예외로 허용 — U 단계 참조.)
- `framework-3c-updater` 또는 U 단계 background 작업에 다음 질문 생성까지 포함하는 구조.
  U는 3C 갱신만 담당해야 하며, Q의 선행 조건이나 질문 생성 주체가 되면 안 된다.
- **Q(`AskUserQuestion`)를 먼저 호출하고 U(spawn)를 그 뒤에 두는 구조.** blocking인 Q에서 응답이 끝나 U가 누락된다. U는 non-blocking이므로 Q와 같은 응답에서 Q 앞이나 병렬로 spawn한다.
