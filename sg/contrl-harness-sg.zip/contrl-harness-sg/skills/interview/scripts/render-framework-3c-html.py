#!/usr/bin/env python3

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE_PATH = SKILL_ROOT / "templates" / "framework-3c-output.html"
SECTIONS = (
    ("customer", "Customer", "Buyer context", ("hot_button", "pain_point", "motivator", "decision_criteria", "other")),
    ("company", "Company", "Our offer", ("strength", "discriminator", "proof_point", "other")),
    ("competitor", "Competitor", "Competitive field", ("identified", "competitor_strength", "competitor_weakness", "other")),
)
TYPE_LABELS = {
    "hot_button": "Hot Button",
    "pain_point": "Pain Point",
    "motivator": "Motivator",
    "decision_criteria": "Decision",
    "constraint": "Constraint",
    "strength": "Strength",
    "discriminator": "Discriminator",
    "proof_point": "Proof Point",
    "identified": "Identified",
    "likely_competitor": "Likely Competitor",
    "competitor_strength": "Strength",
    "competitor_weakness": "Weakness",
    "other": "Other",
}
SOURCE_LABELS = {
    "rfp": "RFP",
    "interview": "Interview",
    "reference": "Ref",
    "pre_research": "Research",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Render framework_3c.json into a static user-facing HTML output.",
    )
    parser.add_argument("project", nargs="?", help="Project directory name under projects/.")
    parser.add_argument("--root", default=str(ROOT), help="Repo root containing projects/.")
    parser.add_argument("--input", help="Path to framework_3c.json. Defaults to the project artifact path.")
    parser.add_argument("--output", help="HTML output path. Defaults to projects/<project>/outputs/interview/framework_3c.html.")
    parser.add_argument("--previous", help="Optional previous framework_3c.json path for changed-bullet highlighting.")
    parser.add_argument("--no-cache", action="store_true", help="Do not read/write the default hidden snapshot cache.")
    return parser.parse_args()


def assert_project_name(project: str) -> None:
    if not project or project in {".", ".."} or "/" in project or "\\" in project:
        raise SystemExit("project name must be one directory name without path separators")


def default_input(root: Path, project: str) -> Path:
    assert_project_name(project)
    return root / "projects" / project / "artifacts" / "strategy" / "framework_3c.json"


def default_output(root: Path, project: str) -> Path:
    assert_project_name(project)
    return root / "projects" / project / "outputs" / "interview" / "framework_3c.html"


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise SystemExit(f"{path} must contain a JSON object")
    return value


def section_items(state: dict, key: str) -> list[dict]:
    value = state.get(key)
    return value if isinstance(value, list) else []


def bullet_key(section: str, bullet: dict) -> str:
    return f"{section}:{bullet.get('id', '')}"


def bullet_signature(bullet: dict) -> tuple[str, str, tuple[str, ...], tuple[str, ...]]:
    sources = bullet.get("sources")
    turns = bullet.get("source_turns")
    return (
        str(bullet.get("type", "")),
        bullet_text(bullet),
        tuple(str(item) for item in sources) if isinstance(sources, list) else (),
        tuple(str(item) for item in turns) if isinstance(turns, list) else (),
    )


def changed_keys(previous: dict | None, current: dict) -> set[str]:
    if not previous:
        return set()
    before: dict[str, tuple[str, str, tuple[str, ...], tuple[str, ...]]] = {}
    out: set[str] = set()
    for section, *_ in SECTIONS:
        for bullet in section_items(previous, section):
            if isinstance(bullet, dict) and bullet.get("id"):
                before[bullet_key(section, bullet)] = bullet_signature(bullet)
    for section, *_ in SECTIONS:
        for bullet in section_items(current, section):
            if not isinstance(bullet, dict) or not bullet.get("id"):
                continue
            key = bullet_key(section, bullet)
            if before.get(key) != bullet_signature(bullet):
                out.add(key)
    return out


def esc(value: object) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def bullet_text(bullet: dict) -> str:
    return str(bullet.get("text") or bullet.get("summary") or bullet.get("implication") or "")


def pct(value: object) -> int:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = 0.0
    return max(0, min(100, round(number * 100)))


def group_bullets(order: tuple[str, ...], bullets: list[dict]) -> list[tuple[str, list[dict]]]:
    groups: dict[str, list[dict]] = {item: [] for item in order}
    for bullet in bullets:
        if not isinstance(bullet, dict):
            continue
        kind = str(bullet.get("type") or "other")
        groups.setdefault(kind, []).append(bullet)
    return [(kind, items) for kind, items in groups.items() if items]


def render_bullet(section: str, bullet: dict, changed: set[str]) -> str:
    key = bullet_key(section, bullet)
    changed_class = " changed" if key in changed else ""
    sources = bullet.get("sources") if isinstance(bullet.get("sources"), list) else []
    evidence = str(bullet.get("evidence") or "").strip()
    implication = str(bullet.get("implication") or "").strip()
    chips = []
    for source in sources:
        raw = str(source)
        label = SOURCE_LABELS.get(raw, raw.upper())
        chips.append(f'<span class="chip {esc(raw)}">{esc(label)}</span>')
    supporting = ""
    if evidence or implication:
        parts = []
        if evidence:
            parts.append(f"<span><b>Evidence</b> {esc(evidence)}</span>")
        if implication:
            parts.append(f"<span><b>Implication</b> {esc(implication)}</span>")
        supporting = f'<div class="bulletMeta">{"".join(parts)}</div>'
    return (
        f'<div class="bullet{changed_class}" data-bullet-id="{esc(bullet.get("id", ""))}">'
        '<div class="bulletBody">'
        f'<div class="bulletText">{esc(bullet_text(bullet))}</div>'
        f"{supporting}"
        "</div>"
        f'<div class="chips">{"".join(chips)}</div>'
        "</div>"
    )


def render_tab(state: dict, section: str, title: str, alias: str, active: bool) -> str:
    bullets = section_items(state, section)
    selected = "true" if active else "false"
    tab_index = "0" if active else "-1"
    return (
        f'<button class="tab" id="tab-{esc(section)}" role="tab" type="button" '
        f'aria-selected="{selected}" aria-controls="panel-{esc(section)}" tabindex="{tab_index}">'
        '<span class="tabText">'
        f'<span class="tabTitle">{esc(title)}</span>'
        f'<span class="tabAlias">{esc(alias)}</span>'
        '</span>'
        f'<span class="tabCount">{len(bullets)}</span>'
        '</button>'
    )


def render_panel(state: dict, section: str, title: str, alias: str, order: tuple[str, ...], changed: set[str], active: bool) -> str:
    bullets = section_items(state, section)
    completeness = state.get("completeness") if isinstance(state.get("completeness"), dict) else {}
    complete_pct = pct(completeness.get(section))
    groups = group_bullets(order, bullets)
    if groups:
        body = ['<div class="groups">']
        for kind, items in groups:
            items_html = "".join(render_bullet(section, bullet, changed) for bullet in items)
            body.append(
                '<section class="group">'
                f'<div class="groupName">{esc(TYPE_LABELS.get(kind, kind))} <span class="count">{len(items)}</span></div>'
                f'<div class="groupItems">{items_html}</div>'
                "</section>"
            )
        body.append("</div>")
        body_html = "".join(body)
    else:
        body_html = f'<div class="empty">No bullets have been captured yet for {esc(alias)}.</div>'
    return (
        f'<section class="axis {esc(section)}" id="panel-{esc(section)}" role="tabpanel" '
        f'aria-labelledby="tab-{esc(section)}"{" hidden" if not active else ""}>'
        '<header class="axisHeader">'
        '<div class="axisTitleRow">'
        f'<div><h2 class="axisTitle">{esc(title)}</h2><div class="axisAlias">{esc(alias)}</div></div>'
        f'<div class="count">{len(bullets)} bullets</div>'
        '</div>'
        f'<div class="meter" aria-label="{esc(title)} completeness {complete_pct}%">'
        f'<div class="meterFill" style="width: {complete_pct}%"></div>'
        '</div>'
        '</header>'
        f'{body_html}'
        '</section>'
    )


def status_parts(state: dict) -> tuple[str, str]:
    pending = state.get("_meta", {}).get("pending_interview_updates") if isinstance(state.get("_meta"), dict) else None
    failed = state.get("status") == "failed" or bool(state.get("_meta", {}).get("last_failed_input")) if isinstance(state.get("_meta"), dict) else state.get("status") == "failed"
    if failed:
        return "failed", "Update failed"
    if isinstance(pending, list) and pending:
        return "pending", "Applying answer"
    if state.get("status") == "seeding":
        return "pending", "Seeding"
    return "", "Synced"


def render_html(project: str, source: Path, state: dict, changed: set[str]) -> str:
    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    pending = state.get("_meta", {}).get("pending_interview_updates") if isinstance(state.get("_meta"), dict) else None
    pending_text = f"Pending updates: {', '.join(str(item) for item in pending)}" if isinstance(pending, list) and pending else "Pending updates: 0"
    status_class, status_text = status_parts(state)
    notice_text = ""
    notice_class = "hidden"
    if state.get("status") == "failed":
        notice_text = "The 3C update failed. The interview can continue, and the last valid content has been preserved."
        notice_class = ""
    panel_ready = any(section_items(state, section[0]) for section in SECTIONS)
    section_tabs_html = "".join(
        render_tab(state, section[0], section[1], section[2], index == 0)
        for index, section in enumerate(SECTIONS)
    )
    section_panels_html = "".join(
        render_panel(state, *section, changed, index == 0)
        for index, section in enumerate(SECTIONS)
    )
    replacements = {
        "TITLE": f"3C Live Context - {project}",
        "HEADING": "3C Live Context",
        "PROJECT_LABEL": f"Project: {project}",
        "SOURCE_LABEL": f"Source: {source}",
        "STATUS_CLASS": status_class,
        "STATUS_TEXT": status_text,
        "PENDING_TEXT": pending_text,
        "NOTICE_CLASS": notice_class,
        "NOTICE_TEXT": notice_text,
        "SECTION_TABS_HTML": section_tabs_html,
        "SECTION_PANELS_HTML": section_panels_html,
        "PANEL_READY": "true" if panel_ready else "false",
    }
    for key, value in replacements.items():
        template = template.replace(f"{{{{{key}}}}}", value)
    return template


def main() -> None:
    args = parse_args()
    root = Path(args.root).resolve()
    if not args.project and not args.input:
        raise SystemExit("project is required unless --input is provided")
    project = args.project or Path(args.input).resolve().parents[2].name
    source = Path(args.input).resolve() if args.input else default_input(root, project)
    output = Path(args.output).resolve() if args.output else default_output(root, project)
    cache = output.with_suffix(".snapshot.json")
    # 입력이 없으면(워크플로 진입 시 seed) 빈 상태로 "아직 준비 안됨" 패널을 렌더한다.
    current = load_json(source) if source.exists() else {}
    previous: dict | None = None
    if args.previous:
        previous = load_json(Path(args.previous).resolve())
    elif not args.no_cache and cache.exists():
        previous = load_json(cache)
    changed = changed_keys(previous, current)
    html_text = render_html(project, source, current, changed)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html_text, encoding="utf-8")
    if not args.no_cache:
        cache.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
