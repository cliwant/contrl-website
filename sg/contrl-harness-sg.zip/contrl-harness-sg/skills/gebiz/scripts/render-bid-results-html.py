#!/usr/bin/env python3
"""Render GeBIZ bid discovery artifacts."""

from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import re
from pathlib import Path
from typing import Any


def esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def clean(value: Any) -> str:
    return str(value if value is not None else "").strip()


def md(value: Any) -> str:
    return clean(value).replace("|", "\\|").replace("\n", " ")


def slugify(value: Any, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", clean(value).lower()).strip("-")
    return (slug or fallback)[:72].strip("-") or fallback


def detail_filename(bid: dict[str, Any], index: int) -> str:
    rank = int(bid.get("rank") or index + 1)
    return f"bid-{rank:02d}-{slugify(bid.get('title'), f'bid-{rank:02d}')}.html"


def parse_date(value: str) -> dt.date | None:
    value = clean(value)
    if not value:
        return None
    try:
        return dt.date.fromisoformat(value[:10])
    except ValueError:
        return None


def status_for(bid: dict[str, Any], as_of: dt.date | None) -> str:
    if clean(bid.get("status")):
        return clean(bid["status"])
    closing = parse_date(clean(bid.get("closing")))
    if closing and as_of:
        return "Closed" if closing < as_of else "Open"
    return "Unknown"


def join_tags(values: list[str]) -> str:
    tags = [clean(v) for v in values if clean(v)]
    if not tags:
        return ""
    return "".join(f'<span class="tag">{esc(tag)}</span>' for tag in tags)


def paragraph(text: Any) -> str:
    text = clean(text)
    if not text:
        return '<p class="empty">Not provided in the available GeBIZ record.</p>'
    return f"<p>{esc(text)}</p>"


def list_block(items: list[Any], *, link_key: str | None = None) -> str:
    if not items:
        return '<p class="empty">Not provided in the available GeBIZ record.</p>'
    rendered = []
    for item in items:
        if isinstance(item, dict):
            label = clean(item.get("name") or item.get("label") or item.get("email") or item.get("url"))
            url = clean(item.get(link_key or "url"))
            detail_parts = [
                clean(item.get("role")),
                clean(item.get("email")),
                clean(item.get("phone")),
            ]
            detail = " | ".join(part for part in detail_parts if part and part != label)
            body = f'<a href="{esc(url)}" target="_blank" rel="noreferrer">{esc(label)}</a>' if url else esc(label)
            if detail:
                body += f' <span class="muted">- {esc(detail)}</span>'
        else:
            body = esc(item)
        rendered.append(f"<li>{body}</li>")
    return "<ul>" + "".join(rendered) + "</ul>"


def detail_sections(bid: dict[str, Any]) -> str:
    detail = bid.get("detail") or {}
    sections: list[tuple[str, str]] = [
        ("Project Overview", paragraph(detail.get("overview") or bid.get("summary"))),
        ("Eligibility", paragraph(detail.get("eligibility"))),
        ("Evaluation", paragraph(detail.get("evaluation"))),
        ("Submission", paragraph(detail.get("submission"))),
        ("Proposal Implications", paragraph(detail.get("proposal_implications") or bid.get("fit"))),
        ("Documents", list_block(detail.get("documents") or [], link_key="url")),
        ("Contacts", list_block(detail.get("contacts") or [])),
        ("Keyword Evidence", list_block(detail.get("keyword_evidence") or [])),
    ]
    return "".join(
        f'<section class="detailSection"><h3>{esc(title)}</h3>{body}</section>'
        for title, body in sections
    )


def pipeline_prompt(bid: dict[str, Any]) -> str:
    project_slug = "gebiz-" + slugify(bid.get("title"), clean(bid.get("project_id")) or "bid")
    lines = [
        "[$contrl:gebiz](/Users/junhocho/.codex/plugins/cache/contrl-harness/contrl/1.1.8/skills/gebiz/SKILL.md) Analyze the RFP for this selected Singapore GeBIZ bid. Run S0 RFP analysis/extraction only, then stop before Strategy Interview.",
        "",
        f"Project ID: {clean(bid.get('project_id'))}",
        f"Title: {clean(bid.get('title'))}",
        f"Agency: {clean(bid.get('agency'))}",
        f"Posted: {clean(bid.get('posted'))}",
        f"Closing: {clean(bid.get('closing'))}",
        f"Notice type: {clean(bid.get('notice_type'))}",
        f"Procurement type: {clean(bid.get('procurement_type'))}",
        f"Source URL: {clean(bid.get('url'))}",
        "",
        f"Create or reuse project: projects/{project_slug}",
        f"Create the English source packet at projects/{project_slug}/inputs/references/gebiz_bid.md, using the GeBIZ detail already captured in outputs/gebiz-ai-projects-recent-year.json if available.",
        "Create the S0 English artifacts only: analysis.md, rfp.json, status.json, and the initial framework_3c.json. Do not generate Win Themes, Theme Statements, Slide Contents, Slide Plan, or Render outputs unless I explicitly ask to continue.",
        "After S0 is ready, render the S0 result page and open the project output shell in the artifact/browser area at projects/{slug}/outputs/index.html#s=S0.".format(slug=project_slug),
    ]
    return "\n".join(lines)


def render_rows(bids: list[dict[str, Any]], as_of: dt.date | None) -> str:
    rows = []
    for index, bid in enumerate(bids):
        status = status_for(bid, as_of)
        row_id = f"bid-{index}"
        status_class = "open" if status.lower() == "open" else "closed" if status.lower() == "closed" else "unknown"
        rows.append(
            "<tr>"
            f'<td class="rank">{esc(bid.get("rank") or index + 1)}</td>'
            f'<td><a class="bidTitle" href="{esc(bid.get("url"))}" target="_blank" rel="noreferrer">{esc(bid.get("title"))}</a>'
            f'<div class="projectId">{esc(bid.get("project_id"))}</div></td>'
            f'<td>{esc(bid.get("agency"))}</td>'
            f'<td>{esc(bid.get("posted"))}</td>'
            f'<td>{esc(bid.get("closing"))}<span class="status {status_class}">{esc(status)}</span></td>'
            f'<td>{esc(bid.get("notice_type"))}<div class="procType">{esc(bid.get("procurement_type"))}</div></td>'
            f'<td><button class="detailBtn" type="button" data-target="{row_id}" aria-controls="detailPane">Details</button></td>'
            "</tr>"
        )
    return "\n".join(rows)


def render_detail_templates(bids: list[dict[str, Any]], as_of: dt.date | None) -> str:
    blocks = []
    for index, bid in enumerate(bids):
        row_id = f"bid-{index}"
        status = status_for(bid, as_of)
        tags = join_tags(
            [
                status,
                clean(bid.get("notice_type")),
                clean(bid.get("procurement_type")),
            ]
        )
        blocks.append(
            f'<template id="{row_id}">'
            f'<div class="detailHead"><div><div class="eyebrow">Bid Detail</div>'
            f'<h2>{esc(bid.get("title"))}</h2></div><div class="tags">{tags}</div></div>'
            f'<dl class="facts">'
            f'<div><dt>Agency</dt><dd>{esc(bid.get("agency"))}</dd></div>'
            f'<div><dt>Posted</dt><dd>{esc(bid.get("posted"))}</dd></div>'
            f'<div><dt>Closing</dt><dd>{esc(bid.get("closing"))}</dd></div>'
            f'<div><dt>Project ID</dt><dd>{esc(bid.get("project_id"))}</dd></div>'
            f'</dl>'
            f'<div class="sourceLine"><a href="{esc(bid.get("url"))}" target="_blank" rel="noreferrer">Open GeBIZ source</a></div>'
            f"{detail_sections(bid)}"
            "</template>"
        )
    return "\n".join(blocks)


def detail_page_html(data: dict[str, Any], bid: dict[str, Any], index: int, as_of: dt.date | None) -> str:
    generated = clean(data.get("generated_at"))
    search = data.get("search") or {}
    title = clean(bid.get("title")) or "GeBIZ Bid Detail"
    status = status_for(bid, as_of)
    tags = join_tags([status, clean(bid.get("notice_type")), clean(bid.get("procurement_type"))])
    prompt = pipeline_prompt(bid)
    prompt_json = json.dumps(prompt).replace("</", "<\\/")

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{esc(title)}</title>
  <style>
    :root {{
      color-scheme: light;
      --bg: #f7f4ef;
      --panel: #ffffff;
      --ink: #25211c;
      --muted: #746b61;
      --line: #ded6ca;
      --soft: #f1ebe3;
      --accent: #b85c38;
      --shadow: 0 10px 30px rgba(37, 33, 28, 0.08);
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      min-height: 100vh;
      background: var(--bg);
      color: var(--ink);
      font-family: Pretendard, Inter, "Apple SD Gothic Neo", ui-sans-serif, system-ui, -apple-system, sans-serif;
    }}
    a {{ color: inherit; text-decoration-color: rgba(184, 92, 56, 0.45); text-underline-offset: 3px; }}
    .shell {{ width: min(980px, 100%); margin: 0 auto; padding: 18px; }}
    .panel {{
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      box-shadow: var(--shadow);
      padding: 18px;
    }}
    .eyebrow {{
      color: var(--accent);
      font-size: 10px;
      font-weight: 760;
      letter-spacing: 0.06em;
      text-transform: uppercase;
    }}
    .head {{
      display: flex;
      justify-content: space-between;
      gap: 16px;
      align-items: flex-start;
    }}
    h1 {{ margin: 5px 0 0; font-size: 24px; line-height: 1.22; font-weight: 760; letter-spacing: 0; }}
    .tags {{ display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 6px; min-width: 160px; }}
    .tag {{
      display: inline-flex;
      align-items: center;
      min-height: 24px;
      padding: 4px 8px;
      border: 1px solid var(--line);
      border-radius: 999px;
      background: var(--soft);
      color: var(--muted);
      font-size: 10px;
      font-weight: 720;
      white-space: nowrap;
    }}
    .facts {{
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 8px;
      margin: 16px 0 12px;
    }}
    .facts div {{ border: 1px solid #eee7dd; border-radius: 8px; padding: 9px; background: #fffaf3; }}
    dt {{ color: var(--muted); font-size: 10px; font-weight: 760; text-transform: uppercase; letter-spacing: 0.04em; }}
    dd {{ margin: 3px 0 0; font-size: 12px; line-height: 1.4; overflow-wrap: anywhere; }}
    .sourceLine {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px 14px;
      margin: 8px 0 16px;
      color: var(--accent);
      font-size: 12px;
      font-weight: 720;
    }}
    .sourceLine span {{ color: var(--muted); font-weight: 500; }}
    .actionPanel {{
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 12px;
      align-items: center;
      margin: 12px 0 16px;
      padding: 12px;
      border: 1px solid #ead7c7;
      border-radius: 8px;
      background: #fff8ed;
    }}
    .actionText strong {{
      display: block;
      margin-bottom: 3px;
      font-size: 13px;
      line-height: 1.35;
    }}
    .actionText span {{
      display: block;
      color: #5f574e;
      font-size: 12px;
      line-height: 1.45;
    }}
    .primaryAction {{
      min-height: 34px;
      padding: 0 14px;
      border: 1px solid var(--accent);
      border-radius: 999px;
      background: var(--accent);
      color: #fff;
      font: inherit;
      font-size: 12px;
      font-weight: 760;
      cursor: pointer;
      white-space: nowrap;
    }}
    .primaryAction:hover {{ filter: brightness(0.96); }}
    .copyStatus {{
      grid-column: 1 / -1;
      color: var(--muted);
      font-size: 11px;
      line-height: 1.45;
    }}
    .promptBox {{
      grid-column: 1 / -1;
      border-top: 1px solid #ead7c7;
      padding-top: 8px;
      color: var(--muted);
      font-size: 11px;
    }}
    .promptBox summary {{ cursor: pointer; font-weight: 720; }}
    .promptBox textarea {{
      margin: 8px 0 0;
      width: 100%;
      max-height: 190px;
      overflow: auto;
      white-space: pre-wrap;
      color: #3c352e;
      background: #fff;
      border: 1px solid #eee7dd;
      border-radius: 8px;
      padding: 10px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
      font-size: 11px;
      line-height: 1.45;
      resize: vertical;
    }}
    .detailGrid {{
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 12px;
    }}
    .detailSection {{
      border-top: 1px solid #eee7dd;
      padding-top: 12px;
      min-width: 0;
    }}
    .detailSection h3 {{
      margin: 0 0 6px;
      color: var(--muted);
      font-size: 10px;
      font-weight: 760;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }}
    .detailSection p, .detailSection li {{
      margin: 0;
      color: #3c352e;
      font-size: 12px;
      line-height: 1.56;
      overflow-wrap: anywhere;
    }}
    .detailSection ul {{ margin: 0; padding-left: 16px; }}
    .detailSection li + li {{ margin-top: 4px; }}
    .empty, .muted {{ color: var(--muted); }}
    @media (max-width: 820px) {{
      .head {{ flex-direction: column; }}
      .tags {{ justify-content: flex-start; }}
      .facts {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
      .actionPanel {{ grid-template-columns: 1fr; }}
      .primaryAction {{ width: max-content; }}
      .detailGrid {{ grid-template-columns: 1fr; }}
    }}
  </style>
</head>
<body>
  <main class="shell">
    <article class="panel">
      <div class="head">
        <div>
          <div class="eyebrow">CONTRL GeBIZ Bid Detail</div>
          <h1>{esc(title)}</h1>
        </div>
        <div class="tags">{tags}</div>
      </div>
      <dl class="facts">
        <div><dt>Agency</dt><dd>{esc(bid.get("agency"))}</dd></div>
        <div><dt>Posted</dt><dd>{esc(bid.get("posted"))}</dd></div>
        <div><dt>Closing</dt><dd>{esc(bid.get("closing"))}</dd></div>
        <div><dt>Project ID</dt><dd>{esc(bid.get("project_id"))}</dd></div>
      </dl>
      <div class="sourceLine">
        <a href="{esc(bid.get("url"))}" target="_blank" rel="noreferrer">Open GeBIZ source</a>
        <span>{esc(search.get("window") or "Search window unavailable")}</span>
        <span>Generated {esc(generated)}</span>
      </div>
      <section class="actionPanel" aria-label="Pipeline action">
        <div class="actionText">
          <strong>Analyze this RFP</strong>
          <span>Copies the exact S0 command for this selected GeBIZ record. Later proposal stages require a separate chat confirmation.</span>
        </div>
        <button class="primaryAction" id="analyzeRfp" type="button">Analyze RFP</button>
        <div class="copyStatus" id="copyStatus">Click the button, then paste the copied command into the Codex chat to start S0 RFP analysis.</div>
        <details class="promptBox" id="promptBox">
          <summary>Show S0 command</summary>
          <textarea id="pipelinePrompt" readonly rows="9"></textarea>
        </details>
      </section>
      <div class="detailGrid">{detail_sections(bid)}</div>
    </article>
  </main>
  <script>
    const pipelinePrompt = {prompt_json};
    const promptEl = document.getElementById("pipelinePrompt");
    const promptBox = document.getElementById("promptBox");
    const statusEl = document.getElementById("copyStatus");
    const analyzeButton = document.getElementById("analyzeRfp");
    promptEl.value = pipelinePrompt;
    analyzeButton.addEventListener("click", async () => {{
      promptBox.open = true;
      try {{
        await navigator.clipboard.writeText(pipelinePrompt);
        statusEl.textContent = "S0 command copied. Paste it into the Codex chat and send to start RFP analysis.";
        analyzeButton.textContent = "Copied";
      }} catch (error) {{
        promptEl.focus();
        promptEl.select();
        const copied = document.execCommand && document.execCommand("copy");
        statusEl.textContent = copied
          ? "S0 command copied. Paste it into the Codex chat and send to start RFP analysis."
          : "Copy was blocked by the browser. The command below is selected; paste it into the Codex chat to start S0 RFP analysis.";
        analyzeButton.textContent = copied ? "Copied" : "Selected";
      }}
    }});
  </script>
</body>
</html>
"""


def write_detail_pages(data: dict[str, Any], details_dir: Path) -> list[tuple[dict[str, Any], Path]]:
    bids = data.get("bids") or []
    as_of = parse_date(clean(data.get("generated_at")))
    details_dir.mkdir(parents=True, exist_ok=True)
    written: list[tuple[dict[str, Any], Path]] = []
    for index, bid in enumerate(bids):
        path = details_dir / detail_filename(bid, index)
        path.write_text(detail_page_html(data, bid, index, as_of), encoding="utf-8")
        written.append((bid, path))
    return written


def render_markdown(data: dict[str, Any], detail_links: dict[str, str]) -> str:
    search = data.get("search") or {}
    lines = [
        f"# {md(data.get('title') or 'Singapore GeBIZ Bid Results')}",
        "",
        f"Search scope: {md(search.get('window') or 'Recent period')} | Source: {md(search.get('source') or 'Singapore GeBIZ')} | Search target: {md(search.get('search_target') or 'TITLE')}",
        "",
        "| # | Bid | Agency | Posted | Closing | Type | Details |",
        "|---:|---|---|---:|---:|---|---|",
    ]
    for index, bid in enumerate(data.get("bids") or []):
        key = clean(bid.get("project_id")) or str(index)
        detail_link = detail_links.get(key, "")
        details = f"[Details]({detail_link})" if detail_link else "Details"
        type_label = " / ".join(part for part in [clean(bid.get("notice_type")), clean(bid.get("procurement_type"))] if part)
        lines.append(
            f"| {md(bid.get('rank') or index + 1)} | {md(bid.get('title'))} | {md(bid.get('agency'))} | "
            f"{md(bid.get('posted'))} | {md(bid.get('closing'))} | {md(type_label)} | {details} |"
        )
    lines.append("")
    lines.append("Note: Closed notices are included when the requested scan covers the recent one-year period.")
    return "\n".join(lines)


def render_html(data: dict[str, Any]) -> str:
    bids = data.get("bids") or []
    generated = clean(data.get("generated_at"))
    as_of = parse_date(generated)
    search = data.get("search") or {}
    title = clean(data.get("title")) or "GeBIZ Bid Discovery"
    subtitle = clean(data.get("subtitle")) or "Singapore GeBIZ opportunity shortlist"
    rows = render_rows(bids, as_of)
    details = render_detail_templates(bids, as_of)
    first_title = esc(bids[0].get("title")) if bids else "No bid selected"
    first_count = len(bids)
    search_window = clean(search.get("window")) or "Recent period"
    keywords = search.get("keywords") or []
    keyword_html = join_tags([str(k) for k in keywords[:10]])

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{esc(title)}</title>
  <style>
    :root {{
      color-scheme: light;
      --bg: #f7f4ef;
      --panel: #ffffff;
      --ink: #25211c;
      --muted: #746b61;
      --line: #ded6ca;
      --soft: #f1ebe3;
      --accent: #b85c38;
      --accent-soft: #fff3e8;
      --good: #3f7f5f;
      --warn: #9a6a23;
      --shadow: 0 10px 30px rgba(37, 33, 28, 0.08);
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      min-height: 100vh;
      background: var(--bg);
      color: var(--ink);
      font-family: Pretendard, Inter, "Apple SD Gothic Neo", ui-sans-serif, system-ui, -apple-system, sans-serif;
    }}
    a {{ color: inherit; text-decoration-color: rgba(184, 92, 56, 0.45); text-underline-offset: 3px; }}
    .shell {{ width: min(1280px, 100%); margin: 0 auto; padding: 18px; }}
    .topbar {{
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      box-shadow: var(--shadow);
      padding: 16px 18px;
    }}
    .eyebrow {{
      color: var(--accent);
      font-size: 10px;
      font-weight: 760;
      letter-spacing: 0.06em;
      text-transform: uppercase;
    }}
    h1 {{ margin: 4px 0 6px; font-size: 22px; line-height: 1.2; font-weight: 760; letter-spacing: 0; }}
    .subtitle {{ margin: 0; color: #3c352e; font-size: 13px; line-height: 1.5; max-width: 920px; }}
    .meta {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 12px;
      color: var(--muted);
      font-size: 12px;
    }}
    .meta span, .tag {{
      display: inline-flex;
      align-items: center;
      min-height: 24px;
      padding: 4px 8px;
      border: 1px solid var(--line);
      border-radius: 999px;
      background: var(--soft);
      white-space: nowrap;
    }}
    .workspace {{
      display: grid;
      grid-template-columns: minmax(0, 1fr) 390px;
      gap: 14px;
      margin-top: 14px;
      align-items: start;
    }}
    .tablePanel, .detailPane {{
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      box-shadow: var(--shadow);
    }}
    .tableHead {{
      display: flex;
      justify-content: space-between;
      gap: 12px;
      padding: 12px 14px;
      border-bottom: 1px solid var(--line);
      color: var(--muted);
      font-size: 12px;
    }}
    .keywordRow {{ display: flex; flex-wrap: wrap; gap: 6px; padding: 0 14px 12px; }}
    .keywordRow .tag {{ min-height: 22px; font-size: 11px; background: #fffaf3; }}
    .tableWrap {{ overflow-x: auto; }}
    table {{ width: 100%; border-collapse: collapse; min-width: 920px; }}
    th, td {{ border-bottom: 1px solid #eee7dd; padding: 11px 12px; text-align: left; vertical-align: top; }}
    th {{
      color: var(--muted);
      font-size: 10px;
      font-weight: 760;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      background: #fbf8f3;
      position: sticky;
      top: 0;
      z-index: 1;
    }}
    td {{ font-size: 12px; line-height: 1.45; color: #3c352e; }}
    tr.isActive td {{ background: var(--accent-soft); }}
    .rank {{ width: 44px; color: var(--accent); font-weight: 760; }}
    .bidTitle {{ font-weight: 680; color: #2f2a24; }}
    .projectId, .procType {{ margin-top: 4px; color: var(--muted); font-size: 11px; overflow-wrap: anywhere; }}
    .status {{
      display: inline-flex;
      margin-left: 0;
      margin-top: 5px;
      padding: 2px 7px;
      border-radius: 999px;
      font-size: 10px;
      font-weight: 760;
      border: 1px solid var(--line);
      background: var(--soft);
      color: var(--muted);
    }}
    .status.open {{ color: var(--good); border-color: rgba(63, 127, 95, 0.3); background: #eef8f1; }}
    .status.closed {{ color: var(--warn); border-color: rgba(154, 106, 35, 0.28); background: #fff8ed; }}
    .detailBtn {{
      min-width: 76px;
      min-height: 32px;
      border: 1px solid var(--accent);
      border-radius: 999px;
      background: #fff;
      color: var(--accent);
      font: inherit;
      font-size: 12px;
      font-weight: 720;
      cursor: pointer;
    }}
    .detailBtn:hover, .detailBtn[aria-expanded="true"] {{ background: var(--accent); color: #fff; }}
    .detailPane {{
      position: sticky;
      top: 14px;
      max-height: calc(100vh - 28px);
      overflow: auto;
      padding: 16px;
    }}
    .detailHead {{ display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; }}
    .detailHead h2 {{ margin: 4px 0 0; font-size: 18px; line-height: 1.28; letter-spacing: 0; }}
    .tags {{ display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 6px; }}
    .tags .tag {{ font-size: 10px; background: #fffaf3; }}
    .facts {{
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
      margin: 14px 0;
    }}
    .facts div {{ border: 1px solid #eee7dd; border-radius: 8px; padding: 9px; background: #fffaf3; }}
    dt {{ color: var(--muted); font-size: 10px; font-weight: 760; text-transform: uppercase; letter-spacing: 0.04em; }}
    dd {{ margin: 3px 0 0; font-size: 12px; line-height: 1.4; overflow-wrap: anywhere; }}
    .sourceLine {{ margin: 6px 0 14px; font-size: 12px; font-weight: 720; color: var(--accent); }}
    .detailSection {{ padding-top: 12px; margin-top: 12px; border-top: 1px solid #eee7dd; }}
    .detailSection h3 {{ margin: 0 0 6px; color: var(--muted); font-size: 10px; font-weight: 760; text-transform: uppercase; letter-spacing: 0.04em; }}
    .detailSection p, .detailSection li {{ margin: 0; color: #3c352e; font-size: 12px; line-height: 1.55; overflow-wrap: anywhere; }}
    .detailSection ul {{ margin: 0; padding-left: 16px; }}
    .detailSection li + li {{ margin-top: 4px; }}
    .empty, .muted {{ color: var(--muted); }}
    @media (max-width: 980px) {{
      .workspace {{ grid-template-columns: 1fr; }}
      .detailPane {{ position: static; max-height: none; }}
    }}
  </style>
</head>
<body>
  <div class="shell">
    <header class="topbar">
      <div class="eyebrow">CONTRL GeBIZ Discovery</div>
      <h1>{esc(title)}</h1>
      <p class="subtitle">{esc(subtitle)}</p>
      <div class="meta">
        <span>{esc(search_window)}</span>
        <span>{esc(search.get("source") or "Singapore GeBIZ")}</span>
        <span>{first_count} shortlisted bids</span>
        <span>Generated {esc(generated)}</span>
      </div>
    </header>
    <main class="workspace">
      <section class="tablePanel" aria-label="Bid shortlist">
        <div class="tableHead">
          <span>Title-level search results with details loaded from GeBIZ records</span>
          <span>Default selection: {first_title}</span>
        </div>
        <div class="keywordRow">{keyword_html}</div>
        <div class="tableWrap">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Bid</th>
                <th>Agency</th>
                <th>Posted</th>
                <th>Closing</th>
                <th>Type</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
{rows}
            </tbody>
          </table>
        </div>
      </section>
      <aside class="detailPane" id="detailPane" aria-live="polite"></aside>
    </main>
  </div>
{details}
  <script>
    const pane = document.getElementById("detailPane");
    const rowsByTarget = new Map();
    document.querySelectorAll(".detailBtn").forEach((button) => {{
      const row = button.closest("tr");
      rowsByTarget.set(button.dataset.target, row);
      button.addEventListener("click", () => showDetail(button.dataset.target));
    }});
    function showDetail(id) {{
      const template = document.getElementById(id);
      if (!template) return;
      pane.replaceChildren(template.content.cloneNode(true));
      document.querySelectorAll(".detailBtn").forEach((button) => {{
        button.setAttribute("aria-expanded", String(button.dataset.target === id));
      }});
      document.querySelectorAll("tr.isActive").forEach((row) => row.classList.remove("isActive"));
      const row = rowsByTarget.get(id);
      if (row) row.classList.add("isActive");
      const hash = "detail=" + encodeURIComponent(id);
      history.replaceState(null, "", "#" + hash);
    }}
    const params = new URLSearchParams((location.hash || "").replace(/^#/, ""));
    showDetail(params.get("detail") || "bid-0");
  </script>
</body>
</html>
"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Path to structured bid results JSON.")
    parser.add_argument("--output", required=True, help="Path to write the HTML artifact.")
    parser.add_argument("--details-dir", help="Optional directory for one HTML detail page per bid.")
    parser.add_argument("--markdown-output", help="Optional path to write a Markdown shortlist for chat.")
    parser.add_argument(
        "--detail-link-prefix",
        default="",
        help="Optional URL/path prefix for Markdown detail links. Defaults to relative paths from the Markdown file.",
    )
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)
    data = json.loads(input_path.read_text(encoding="utf-8"))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(render_html(data), encoding="utf-8")

    written_details: list[tuple[dict[str, Any], Path]] = []
    if args.details_dir:
        written_details = write_detail_pages(data, Path(args.details_dir))

    if args.markdown_output:
        markdown_path = Path(args.markdown_output)
        markdown_path.parent.mkdir(parents=True, exist_ok=True)
        detail_links: dict[str, str] = {}
        for index, (bid, detail_path) in enumerate(written_details):
            key = clean(bid.get("project_id")) or str(index)
            if args.detail_link_prefix:
                detail_links[key] = args.detail_link_prefix.rstrip("/") + "/" + detail_path.name
            else:
                detail_links[key] = detail_path.relative_to(markdown_path.parent).as_posix()
        markdown_path.write_text(render_markdown(data, detail_links), encoding="utf-8")

    suffix = f", {len(written_details)} detail pages" if written_details else ""
    print(f"rendered {output_path} ({len(data.get('bids') or [])} bids{suffix})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
