---
name: gebiz
description: >-
  CONTRL GeBIZ pipeline — Singapore GeBIZ bid discovery plus staged English proposal automation. Use when the user invokes contrl:gebiz, asks to find an AI/software/IT/digital bid on Singapore GeBIZ, asks to analyze a selected GeBIZ RFP, or explicitly asks to continue one CONTRL stage at a time. Full end-to-end automation is allowed only when the user explicitly requests all stages through render without pausing.
---

# GeBIZ Bid Pipeline

## Purpose

Use this as the customer-specific entry point for Singapore public procurement work. It finds a relevant Singapore GeBIZ opportunity, prepares an English source packet, runs the S0 RFP analysis/extraction package by default, then stops for user confirmation before any proposal-strategy or slide stage.

## Non-Negotiables

- While this skill is active, these Singapore-only and English-only rules override conflicting language or country defaults in other CONTRL skills.
- Keep the procurement scope Singapore-only. Use `mcp__global_cliwant.global_search_bids` with `region: "SG"` before any general web search.
- Do not use Korea Nara Marketplace/KONEPS/G2B, Korea-focused `signals`, SAM.gov, or other country procurement sources unless the user explicitly changes the country.
- Write all bid summaries, extracted implications, CONTRL artifacts, HTML panels, slide text, and deck content in English.
- Search bid titles by default. Use `search_target: "DOC"` only when the user explicitly asks for full-document search or deeper evidence.
- If the global Cliwant MCP tools are unavailable, report that GeBIZ MCP access is unavailable. Do not silently switch to another country source.
- Default stage boundary: unless the user explicitly says to run every CONTRL stage end-to-end through render without pausing, stop after S0 RFP analysis/extraction and ask before starting the Strategy Interview or any later stage.

## Trigger Interpretation

Treat requests like these as a direct instruction to use this skill:

- "contrl:gebiz"
- "Find an English AI s/w bid and analyze the RFP."
- "Find a Singapore software tender and prepare the RFP analysis."
- "GeBIZ AI bid pipeline."
- "Look for an AI software opportunity and start the staged English CONTRL workflow."
- "Run everything end-to-end through render without pausing." This is an explicit all-stage override.

For shorthand such as "AI s/w bid", search for Singapore GeBIZ opportunities related to artificial intelligence, software, systems, platforms, analytics, data, cloud, SaaS, applications, automation, and digital services.

## Workflow

### 1. Search GeBIZ

Call:

```json
{
  "params": {
    "region": "SG",
    "keywords": ["AI", "artificial intelligence", "software", "system", "platform", "analytics", "data", "cloud", "digital"],
    "keyword_or_and": "OR",
    "include_finished": false,
    "search_target": "TITLE",
    "sort_by": "close_dt",
    "order": "asc",
    "page": 1,
    "page_limit": 10
  }
}
```

Use `exclude_title_keywords` only when the user gives a clear exclusion. Leave `procurement_type` unset unless the user asks for a specific type.

### 2. Discovery Results

When the user asks to find, list, shortlist, scan, or compare bids without explicitly asking to run the proposal pipeline, treat the task as discovery-only.

For discovery-only results:

1. Load detail for the strongest shortlist items with `mcp__global_cliwant.global_get_project_info`.
2. Create a structured JSON file with the search metadata and bid rows.
3. Render the English artifacts with:

```bash
python3 "<skill_dir>/scripts/render-bid-results-html.py" \
  --input "<bid_results.json>" \
  --output "<bid_results.html>" \
  --details-dir "<bid_details_dir>" \
  --markdown-output "<bid_results.md>"
```

By default, keep the shortlist in the chat response as a compact Markdown table. The final table column must be `Details`, and each `Details` link should open the corresponding detail-only HTML page in the artifact/browser area. This gives the user the chat area for scanning and the artifact area for full bid detail.

The renderer still writes a combined `bid_results.html` for archival use, but do not make that combined page the primary review surface unless the user explicitly asks for a browser-first report.

Each detail-only HTML page should include the project overview, eligibility, evaluation, submission instructions, proposal implications, attached documents, contacts, keyword evidence, project ID, source URL, posted date, closing date, notice type, and procurement type when available.

Each detail-only HTML page must also include an `Analyze RFP` action near the top. If the current artifact/browser surface cannot directly invoke Codex skills from static HTML, the action must copy and reveal an exact ready-to-send `contrl:gebiz` S0-start command for that bid. The copied command should name the project ID, title, agency, source URL, preferred project slug, source-packet path, and instruction to create the English source packet, run S0 RFP analysis/extraction only, then stop before Strategy Interview. Do not make the button copy a full-pipeline command.

Use the same restrained CONTRL decision-brief tone as go/no-go review pages: warm neutral background, compact executive table, clear status chips, and concise evidence sections. Keep all visible labels and detail copy in English.

If the user later chooses a bid and asks to proceed, continue from "Select the Opportunity".

### 3. Select the Opportunity

If the user asks to "find and run" or otherwise implies automation without an explicit all-stage override, choose the strongest open opportunity and run only the discovery-to-S0 analysis flow. Rank by:

1. Clear AI/software fit in the title.
2. Future closing date with enough response time.
3. Public-sector relevance and proposal-deck suitability.
4. Richness of available details/documents.

If the top result is weak or no open result is found, show the top candidates in English and ask for direction before starting RFP analysis.

### 4. Load Detail

For the selected result, call `mcp__global_cliwant.global_get_project_info`:

```json
{
  "params": {
    "region": "SG",
    "project_id": "<project_id from search>",
    "keywords": ["AI", "artificial intelligence", "software", "system", "platform", "analytics", "data", "cloud", "digital"]
  }
}
```

Use attached document summaries, source URL, issuing agency, posted date, closing date, procurement contact, and requirement/evaluation details when available.

### 5. Prepare CONTRL Source Packet

Create or reuse a project under `projects/{project_slug}`. Put an English source packet at:

```text
projects/{project_slug}/inputs/references/gebiz_bid.md
```

The packet must include:

- Notice title.
- Issuing agency.
- Posted and closing dates.
- Source URL.
- Procurement contact if provided.
- Summary of scope.
- Eligibility, submission, and evaluation details when provided.
- Attached document summaries and any keyword hit excerpts.
- A short "Proposal implications" section that explains what the bid likely rewards.

If downloadable attachments are directly available, save them under the same `inputs/references/` directory and include their filenames in the packet. If only summaries are available, the packet is sufficient.

### 6. Start CONTRL RFP Analysis (S0)

After the source packet exists, read and follow `skills/pipeline/SKILL.md`. By default, run only the S0 RFP analysis/extraction package:

- Initialize or reuse the project directory.
- Prepare `inputs/references/gebiz_bid.md` and any downloaded attachments.
- Create `artifacts/rfp/analysis.md`.
- Create `artifacts/rfp/rfp.json` and `artifacts/rfp/status.json`.
- Create the initial `artifacts/strategy/framework_3c.json`.
- Render the S0 result panel with `rfp-extraction/scripts/render-s0-html.py`.
- Open or preview `projects/{project_slug}/outputs/index.html#s=S0` from a static server rooted at `projects/{project_slug}/outputs/`, so the artifact/browser area shows the S0 result page after the pasted command finishes.

Then stop and ask whether the user wants to start the Strategy Interview. Do not generate Win Themes, Theme Statements, Slide Contents, Slide Plan, or Render outputs unless the user explicitly approves the next stage.

Full end-to-end automation is an exception. It is allowed only when the user uses an unmistakable all-stage instruction such as "run everything", "run all stages", "continue through render without pausing", "full pipeline end-to-end", "다 진행해줘", or "끝까지 자동으로 진행해줘".

Keep every stage in English:

- RFP extraction and `rfp.json`.
- Strategy interview questions, options, and summaries.
- Win Themes and selected theme.
- Theme Statements and requirement mapping.
- Slide Contents.
- Slide Plan, cover, TOC, slot fills, and diagnostics.
- Final `deck.pptx` and slide PNGs.

If the workflow needs a user decision, ask in concise English. After the answer, continue only with the single stage or action the user explicitly approved.

For normal staged execution, every completed stage is a user decision point. Passing a gate is not permission to start the next stage.

## Completion Criteria

For discovery-only requests, the task is complete only when:

- Singapore GeBIZ results have been searched with the requested scope.
- A shortlist has been summarized in English in the chat area.
- Detail-only HTML pages exist for the shortlisted bids.
- The chat shortlist includes a `Details` column linking to those detail pages.
- Final user-facing status includes the artifact path, search scope, and any material limitations such as title-level search or closed notices.

For GeBIZ RFP-analysis requests, the task is complete only when:

- A Singapore GeBIZ opportunity has been selected or the user has chosen one.
- The English source packet exists under `projects/{project_slug}/inputs/references/`.
- S0 RFP analysis/extraction artifacts exist and validate according to `skills/pipeline/SKILL.md`.
- Final user-facing status includes the selected bid title, source URL, project path, S0 artifacts, and the next available stage.

For explicit all-stage override requests, the task is complete only when:

- The selected opportunity and source packet are prepared.
- The CONTRL pipeline has been carried forward according to `skills/pipeline/SKILL.md` through the user-requested final stage.
- Final user-facing status includes the selected bid title, source URL, project path, and current/final pipeline artifacts.
