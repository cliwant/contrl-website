#!/usr/bin/env python3

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE_PATH = SKILL_ROOT / "templates" / "theme-statements-progress.html"

# Stage order shown as the three top-bar pills. ``generating`` (A fan-out),
# ``merging`` (barrier / 1:1 check), ``mapping`` (B requirement mapping).
# ``done`` lights every pill. Keep in sync with the coordinator's --stage arg.
STAGES = (
    ("generating", "Generate"),
    ("merging", "Merge"),
    ("mapping", "Map Requirements"),
)
STAGE_INDEX = {name: i for i, (name, _label) in enumerate(STAGES)}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Render theme-statements generation progress into a static user-facing HTML output.",
    )
    parser.add_argument("project", nargs="?", help="Project directory name under projects/.")
    parser.add_argument("--root", default=str(ROOT), help="Repo root containing projects/.")
    parser.add_argument("--progress-dir", help="Progress dir holding plan.json + group-*.json. Defaults to the project path.")
    parser.add_argument("--output", help="HTML output path. Defaults to projects/<project>/outputs/strategy/theme_statements_progress.html.")
    parser.add_argument(
        "--stage",
        choices=[name for name, _ in STAGES] + ["done"],
        help="Current pipeline stage. When omitted it is inferred from how many groups have landed.",
    )
    parser.add_argument("--no-cache", action="store_true", help="Do not read/write the default hidden snapshot cache.")
    return parser.parse_args()


def assert_project_name(project: str) -> None:
    if not project or project in {".", ".."} or "/" in project or "\\" in project:
        raise SystemExit("project name must be one directory name without path separators")


def default_progress_dir(root: Path, project: str) -> Path:
    assert_project_name(project)
    return root / "projects" / project / "outputs" / "strategy" / ".ts_progress"


def default_output(root: Path, project: str) -> Path:
    assert_project_name(project)
    return root / "projects" / project / "outputs" / "strategy" / "theme_statements_progress.html"


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise SystemExit(f"{path} must contain a JSON object")
    return value


def esc(value: object) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def _clean_ref(ref: object) -> dict | None:
    """Normalize a {kind, locator} source ref; drop anything malformed."""
    if not isinstance(ref, dict):
        return None
    locator = str(ref.get("locator", "")).strip()
    if not locator:
        return None
    kind = str(ref.get("kind", "")).strip().lower() or "rfp"
    return {"kind": kind, "locator": locator}


def extract_fields(item: dict) -> dict:
    """Pull the rich ThemeStatementArtifact fields off a partial item for the
    collapsible detail view. Tolerant of missing keys (older statement-only
    partials yield an empty dict → leaf renders without a toggle)."""
    proof_points = []
    for pp in item.get("proof_points", []) if isinstance(item.get("proof_points"), list) else []:
        if not isinstance(pp, dict):
            continue
        text = str(pp.get("text", "")).strip()
        if not text:
            continue
        proof_points.append({"text": text, "citation": _clean_ref(pp.get("citation"))})
    return {
        "hot_button": str(item.get("hot_button", "")).strip(),
        "hot_button_source_ref": _clean_ref(item.get("hot_button_source_ref")),
        "feature": str(item.get("feature", "")).strip(),
        "benefit": str(item.get("benefit", "")).strip(),
        "proof_points": proof_points,
        "quantified_benefit": str(item.get("quantified_benefit") or "").strip(),
        "discriminator": str(item.get("discriminator") or "").strip(),
    }


def assemble_state(progress_dir: Path) -> dict:
    """Pure read of the seed plan + whatever group-*.json partials exist.

    Each worker writes its own group-{group_id}.json so concurrent workers
    never write the same file (no lost-update race). The renderer is a pure
    function of (plan + present partials): a group not yet on disk simply
    renders as still running, and gets filled on the next render.
    """
    # plan.json이 아직 없으면(워크플로 진입 시 seed) 빈 상태 → "아직 준비 안됨" 패널.
    if not (progress_dir / "plan.json").exists():
        return {}
    plan = load_json(progress_dir / "plan.json")
    groups = plan.get("groups") if isinstance(plan.get("groups"), list) else []
    # Index landed group results by group_id.
    results: dict[str, dict] = {}
    for partial in sorted(progress_dir.glob("group-*.json")):
        try:
            data = load_json(partial)
        except (SystemExit, json.JSONDecodeError):
            # A partial caught mid-write by a peer renderer — skip it this
            # pass; the next render (triggered by that worker) will include it.
            continue
        gid = str(data.get("group_id", ""))
        if gid:
            results[gid] = data
    assembled_groups = []
    for group in groups:
        if not isinstance(group, dict):
            continue
        gid = str(group.get("group_id", ""))
        leaves = group.get("leaves") if isinstance(group.get("leaves"), list) else []
        result = results.get(gid)
        items_by_id: dict[str, dict] = {}
        gstatus = "wait"
        if result is not None:
            gstatus = str(result.get("status") or "done")
            for item in result.get("items", []) if isinstance(result.get("items"), list) else []:
                if isinstance(item, dict) and item.get("section_id"):
                    items_by_id[str(item["section_id"])] = item
        assembled_leaves = []
        for leaf in leaves:
            if not isinstance(leaf, dict):
                continue
            sid = str(leaf.get("section_id", ""))
            item = items_by_id.get(sid)
            assembled_leaves.append(
                {
                    "section_id": sid,
                    "title": str(leaf.get("title", "")),
                    "statement": str(item.get("statement", "")) if item else "",
                    "source": str(item.get("source", "section")) if item else "section",
                    "fields": extract_fields(item) if item else {},
                    "done": item is not None and bool(item.get("statement")),
                }
            )
        assembled_groups.append(
            {
                "group_id": gid,
                "parent_path": str(group.get("parent_path", "")),
                "status": gstatus,
                "leaves": assembled_leaves,
            }
        )
    return {
        "project": str(plan.get("project", "")),
        "win_theme_headline": str(plan.get("win_theme_headline", "")),
        "groups": assembled_groups,
    }


def leaf_signature(group_id: str, leaf: dict) -> tuple[str, str]:
    return (f"{group_id}:{leaf.get('section_id', '')}", str(leaf.get("statement", "")))


def changed_keys(previous: dict | None, current: dict) -> set[str]:
    if not previous:
        return set()
    before: dict[str, str] = {}
    for group in previous.get("groups", []):
        gid = str(group.get("group_id", ""))
        for leaf in group.get("leaves", []):
            key, sig = leaf_signature(gid, leaf)
            before[key] = sig
    out: set[str] = set()
    for group in current.get("groups", []):
        gid = str(group.get("group_id", ""))
        for leaf in group.get("leaves", []):
            if not leaf.get("done"):
                continue
            key, sig = leaf_signature(gid, leaf)
            if before.get(key) != sig:
                out.add(key)
    return out


def counts(state: dict) -> tuple[int, int, int, int]:
    groups = state.get("groups", [])
    groups_total = len(groups)
    groups_done = sum(1 for g in groups if g.get("status") == "done")
    leaves = [leaf for g in groups for leaf in g.get("leaves", [])]
    leaves_total = len(leaves)
    leaves_done = sum(1 for leaf in leaves if leaf.get("done"))
    return groups_done, groups_total, leaves_done, leaves_total


def infer_stage(state: dict) -> str:
    groups_done, groups_total, _ld, _lt = counts(state)
    if groups_total and groups_done >= groups_total:
        return "merging"
    return "generating"


def render_stage_pills(state: dict, stage: str) -> str:
    groups_done, groups_total, _ld, _lt = counts(state)
    current = STAGE_INDEX.get(stage, len(STAGES)) if stage != "done" else len(STAGES)
    pills = []
    for i, (name, label) in enumerate(STAGES):
        text = label
        if name == "generating":
            text = f"① {label} · {groups_done}/{groups_total}"
        elif name == "merging":
            text = f"② {label}"
        else:
            text = f"③ {label}"
        if stage == "done" or i < current:
            cls = "pill done"
            dot = '<span class="dot"></span>'
        elif i == current:
            cls = "pill active"
            dot = '<span class="dot pending"></span>'
        else:
            cls = "pill"
            dot = '<span class="dot wait"></span>'
        pills.append(f'<span class="{cls}">{dot}<span>{esc(text)}</span></span>')
    return "".join(pills)


def render_ref_chip(ref: dict | None) -> str:
    if not ref:
        return ""
    kind = str(ref.get("kind", "rfp"))
    locator = str(ref.get("locator", ""))
    label = f"p.{locator}" if kind == "rfp" and not locator.startswith("p.") else locator
    return f'<span class="refchip kind-{esc(kind)}">[{esc(label)}]</span>'


def render_ts_details(fields: dict) -> str:
    """Labelled field rows shown when a theme statement is expanded. Mirrors the
    app's Hot Button · Feature · Benefit · Proof Point · Discriminator ·
    Quantified Benefit layout. Only present fields render."""
    rows: list[str] = []

    def row(label: str, value_html: str) -> None:
        rows.append(
            f'<div class="tsRow"><div class="tsLabel">{label}</div>'
            f'<div class="tsVal">{value_html}</div></div>'
        )

    if fields.get("hot_button"):
        row("Hot Button", esc(fields["hot_button"]) + render_ref_chip(fields.get("hot_button_source_ref")))
    if fields.get("feature"):
        row("Feature", esc(fields["feature"]))
    if fields.get("benefit"):
        row("Benefit", esc(fields["benefit"]))
    proof = fields.get("proof_points") or []
    if proof:
        items = "".join(
            f'<li>{esc(p.get("text", ""))}{render_ref_chip(p.get("citation"))}</li>' for p in proof
        )
        row("Proof Point", f'<ul>{items}</ul>')
    if fields.get("discriminator"):
        row("Discriminator", esc(fields["discriminator"]))
    if fields.get("quantified_benefit"):
        row("Quantified Benefit", esc(fields["quantified_benefit"]))
    if not rows:
        return ""
    return "".join(rows)


def render_leaf(group_id: str, leaf: dict, changed: set[str]) -> str:
    key, _sig = leaf_signature(group_id, leaf)
    done = bool(leaf.get("done"))
    sid = esc(leaf.get("section_id", ""))
    changed_class = " changed" if key in changed else ""
    # caret은 좌측 거터 컨트롤(행 전체를 거느린다). 토글 가능한 leaf만 버튼,
    # 나머지는 같은 폭의 빈 스페이서로 제목·본문 왼쪽 기준선을 맞춘다.
    title_html = f'<div class="leafTitle">{esc(leaf.get("title", ""))}</div>'
    empty_caret = '<span class="leafCaret leafCaret--empty"></span>'
    if done:
        statement = f'<div class="leafStatement">{esc(leaf.get("statement", ""))}</div>'
        wait_class = ""
        source = str(leaf.get("source") or "section")
        chip_class = "section" if source == "section" else "req"
        chip_label = "SECTION" if source == "section" else esc(source)
        chips = f'<span class="chip {chip_class}">{chip_label}</span>'
        details_inner = render_ts_details(leaf.get("fields") or {})
        if details_inner:
            caret = (
                f'<button class="leafCaret" type="button" data-toggle="{sid}" '
                f'aria-expanded="false" aria-label="Expand/collapse details">'
                '<span class="caret">▶</span></button>'
            )
            details = f'<div class="leafDetails" data-details="{sid}" hidden>{details_inner}</div>'
        else:
            caret = empty_caret
            details = ""
    else:
        caret = empty_caret
        statement = '<div class="leafStatement placeholder">Group runner in progress - content will appear when it lands.</div>'
        details = ""
        wait_class = ""
        chips = '<span class="chip">···</span>'
    return (
        f'<div class="leaf{wait_class}{changed_class}" data-section-id="{sid}">'
        f"{caret}"
        '<div class="leafBody">'
        f"{title_html}"
        f"{statement}"
        f"{details}"
        "</div>"
        f'<div class="chips">{chips}</div>'
        "</div>"
    )


def render_group(group: dict, changed: set[str]) -> str:
    status = str(group.get("status") or "wait")
    status_label = {
        "done": "group ✓",
        "running": "group · generating",
        "failed": "group · failed",
        "wait": "group · waiting",
    }.get(status, "group · waiting")
    status_cls = {"done": "done", "running": "running", "failed": "failed"}.get(status, "wait")
    # 완료 상태는 정보량이 없어 숨긴다 — 진행 중(생성 중·대기·실패)에만 배지를 보여
    # "어느 단원이 도는 중인가"라는 라이브 신호를 유지한다.
    status_html = (
        "" if status == "done"
        else f'<div class="groupStatus {status_cls}">{esc(status_label)}</div>'
    )
    leaves_html = "".join(
        render_leaf(str(group.get("group_id", "")), leaf, changed)
        for leaf in group.get("leaves", [])
    )
    return (
        '<section class="group">'
        '<div class="groupName">'
        f'{esc(group.get("parent_path", ""))}'
        f"{status_html}"
        "</div>"
        f'<div class="groupItems">{leaves_html}</div>'
        "</section>"
    )


# --- Requirement mapping (B stage) views -------------------------------------
# rfp.json carries `requirements[]` (id/summary/category/priority) and, after B,
# `requirement_mapping = {"sections": [tree]}` with req_ids on leaf sections.

CATEGORY_LABEL = {
    "functional": "Functional", "technical": "Technical", "management": "Management",
    "administrative": "Administrative", "security": "Security", "constraint": "Constraint", "other": "Other",
}
PRIORITY_ORDER = {"H": 0, "M": 1, "L": 2}


def load_rfp_mapping(root: Path, project: str) -> tuple[list, list, bool]:
    """Return (requirements, mapping_sections, mapping_complete). Tolerant: any
    missing/partial rfp.json yields empties so the panel shows a placeholder."""
    path = root / "projects" / project / "artifacts" / "rfp" / "rfp.json"
    if not path.exists():
        return [], [], False
    try:
        rfp = load_json(path)
    except (SystemExit, json.JSONDecodeError):
        return [], [], False
    reqs = rfp.get("requirements") if isinstance(rfp.get("requirements"), list) else []
    mapping = rfp.get("requirement_mapping") if isinstance(rfp.get("requirement_mapping"), dict) else {}
    sections = mapping.get("sections") if isinstance(mapping.get("sections"), list) else []
    return reqs, sections, bool(rfp.get("mapping_complete"))


def load_rps(root: Path, project: str) -> dict:
    """Return the proposal-outline review state for View 0.

    ``present`` is False when rfp.json is absent/unreadable or has no
    ``required_proposal_structure`` key — the pre-extraction seed state.
    ``present`` True with an empty ``sections`` list is the *not-found* case
    (extraction ran but no outline was identified). Tolerant of partial files.
    """
    path = root / "projects" / project / "artifacts" / "rfp" / "rfp.json"
    empty = {"present": False, "sections": [], "page_limit": None}
    if not path.exists():
        return empty
    try:
        rfp = load_json(path)
    except (SystemExit, json.JSONDecodeError):
        return empty
    rps = rfp.get("required_proposal_structure")
    if not isinstance(rps, dict):
        return empty
    sections = rps.get("sections") if isinstance(rps.get("sections"), list) else []
    return {"present": True, "sections": sections, "page_limit": rps.get("page_limit")}


def render_outline(rps: dict) -> str:
    """View 0 body: the extracted required_proposal_structure so a
    human can confirm it before Theme Statement generation consumes it. Three
    states — pre-extraction seed, not-found, and the rendered outline."""
    if not rps.get("present"):
        return (
            '<div class="outlineEmpty">The proposal outline is not ready yet.<br>'
            "It will appear here after RFP extraction finishes.</div>"
        )
    sections = rps.get("sections") or []
    if not sections:
        return '<div class="outlineEmpty">No proposal outline was identified.</div>'
    # Single source page in the header. The proposal outline is almost always one
    # table on one RFP page, so the per-section pages collapse to one value here
    # (a range if they ever differ). Surrounding brackets are stripped for "p.N".
    seen_pages: list[str] = []
    for sec in sections:
        if isinstance(sec, dict):
            p = str(sec.get("page") or "").strip().strip("[]").strip()
            if p and p not in seen_pages:
                seen_pages.append(p)
    if not seen_pages:
        source_html = ""
    elif len(seen_pages) == 1:
        source_html = f'<span class="outlineMeta">Source: {esc(seen_pages[0])}</span>'
    else:
        source_html = f'<span class="outlineMeta">Source: {esc(seen_pages[0])}–{esc(seen_pages[-1])}</span>'
    head = (
        '<div class="outlineHead"><span class="outlineTitle">Proposal Outline</span>'
        f'{source_html}</div>'
    )
    rows: list[str] = []
    for sec in sections:
        if not isinstance(sec, dict):
            continue
        try:
            level = int(sec.get("level", 1))
        except (TypeError, ValueError):
            level = 1
        level = max(1, min(level, 4))
        title = esc(sec.get("title", ""))
        rows.append(
            f'<div class="olrow lvl-{level}"><span class="oltitle">{title}</span></div>'
        )
    return f'<div class="outline">{head}{"".join(rows)}</div>'


def iter_leaf_nodes(sections: list) -> list:
    out: list = []
    for node in sections:
        if not isinstance(node, dict):
            continue
        children = node.get("children") if isinstance(node.get("children"), list) else []
        if children:
            out.extend(iter_leaf_nodes(children))
        else:
            out.append(node)
    return out


def build_coverage(requirements: list, sections: list) -> dict:
    """req_id -> [section titles]; plus unmapped / duplicate / orphan sets."""
    placement: dict[str, list[str]] = {}
    for leaf in iter_leaf_nodes(sections):
        title = str(leaf.get("title", ""))
        reqs = leaf.get("requirements") if isinstance(leaf.get("requirements"), list) else []
        for rid in reqs:
            placement.setdefault(str(rid), []).append(title)
    req_ids = [str(r.get("id")) for r in requirements if isinstance(r, dict) and r.get("id")]
    known = set(req_ids)
    unmapped = {rid for rid in req_ids if rid not in placement}
    duplicate = {rid for rid, secs in placement.items() if len(secs) > 1}
    orphan = {rid for rid in placement if rid not in known}
    mapped = len([rid for rid in req_ids if rid in placement])
    return {
        "placement": placement, "unmapped": unmapped, "duplicate": duplicate,
        "orphan": orphan, "total": len(req_ids), "mapped": mapped,
    }


def statement_index(state: dict) -> dict:
    idx: dict[str, str] = {}
    for group in state.get("groups", []):
        for leaf in group.get("leaves", []):
            sid = str(leaf.get("section_id", ""))
            if sid and leaf.get("statement"):
                idx[sid] = str(leaf.get("statement"))
    return idx


def shorten(text: str, limit: int = 28) -> str:
    text = str(text).strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


def render_banner(cov: dict) -> str:
    unmapped = len(cov["unmapped"])
    dup = len(cov["duplicate"])
    ok = unmapped == 0 and dup == 0
    parts = [
        f'<span class="bstat"><span class="bnum">{cov["total"]}</span>Total</span>',
        f'<span class="bstat ok"><span class="bnum">{cov["mapped"]}</span>Mapped</span>',
        f'<span class="bstat {"bad" if unmapped else "ok"}"><span class="bnum">{unmapped}</span>Unmapped</span>',
        f'<span class="bstat {"warn" if dup else "ok"}"><span class="bnum">{dup}</span>Duplicates</span>',
    ]
    parts.append(
        '<span class="bflag ok">✓ Every requirement has one mapped section</span>' if ok
        else '<span class="bflag bad">⚠ Check missing or duplicate mappings</span>'
    )
    return f'<div class="banner">{"".join(parts)}</div>'


def render_req_chip(rid: str, req_by_id: dict) -> str:
    r = req_by_id.get(rid) or {}
    pri = str(r.get("priority", "")).upper()
    cat = str(r.get("category", ""))
    summary = str(r.get("summary", ""))
    pri_cls = f"pri-{pri}" if pri in PRIORITY_ORDER else ""
    cat_label = CATEGORY_LABEL.get(cat, cat)
    title_attr = esc(f"{cat_label} · {summary}" if summary else rid)
    pri_html = f'<span class="pri">{esc(pri)}</span>' if pri else ""
    sum_html = f'<span class="csum">{esc(shorten(summary))}</span>' if summary else ""
    return (
        f'<span class="reqchip {pri_cls}" title="{title_attr}" '
        f'data-priority="{esc(pri)}" data-category="{esc(cat)}">'
        f"{pri_html}<b>{esc(rid)}</b>{sum_html}</span>"
    )


def render_mapping_node(node: dict, req_by_id: dict, stmt_index: dict) -> str:
    if not isinstance(node, dict):
        return ""
    title = esc(node.get("title", ""))
    sid = str(node.get("section_id", ""))
    sid_html = f'<span class="nsid">{esc(sid)}</span>' if sid else ""
    children = node.get("children") if isinstance(node.get("children"), list) else []
    if children:
        inner = "".join(render_mapping_node(c, req_by_id, stmt_index) for c in children)
        return (
            '<div class="node">'
            f'<div class="nodeRow"><span class="ntitle">{title}</span>{sid_html}</div>'
            f'<div class="children">{inner}</div>'
            "</div>"
        )
    theme = stmt_index.get(sid, "")
    theme_html = (
        f'<span class="ntheme" title="{esc(theme)}">Theme: {esc(theme)}</span>'
        if theme else ""
    )
    reqs = node.get("requirements") if isinstance(node.get("requirements"), list) else []
    if reqs:
        chips = "".join(render_req_chip(str(rid), req_by_id) for rid in reqs)
        reqs_html = f'<div class="reqs">{chips}</div>'
    else:
        reqs_html = '<div class="noreq">No assigned requirements</div>'
    return (
        '<div class="node leaf">'
        f'<div class="nodeRow"><span class="ntitle">{title}</span>{sid_html}{theme_html}</div>'
        f"{reqs_html}"
        "</div>"
    )


def render_mapping_tree(sections: list, req_by_id: dict, stmt_idx: dict, cov: dict) -> str:
    nodes = "".join(render_mapping_node(n, req_by_id, stmt_idx) for n in sections)
    return render_banner(cov) + f'<div class="tree">{nodes}</div>'


def render_coverage_table(requirements: list, cov: dict) -> str:
    placement = cov["placement"]
    ordered = sorted(
        [r for r in requirements if isinstance(r, dict) and r.get("id")],
        key=lambda r: (PRIORITY_ORDER.get(str(r.get("priority", "")).upper(), 9), str(r.get("id"))),
    )
    rows = []
    for r in ordered:
        rid = str(r.get("id"))
        pri = str(r.get("priority", "")).upper()
        cat = str(r.get("category", ""))
        cat_label = CATEGORY_LABEL.get(cat, cat)
        secs = placement.get(rid, [])
        if rid in cov["unmapped"]:
            row_cls = "unmapped"
            sec_html = '<span class="covsec none">✗ Unmapped</span>'
            flag = '<span class="flag bad">Unmapped</span>'
        elif rid in cov["duplicate"]:
            row_cls = "dup"
            sec_html = f'<span class="covsec">{esc(" · ".join(secs))}</span>'
            flag = f'<span class="flag warn">Duplicate {len(secs)}</span>'
        else:
            row_cls = ""
            sec_html = f'<span class="covsec">{esc(secs[0]) if secs else ""}</span>'
            flag = ""
        pri_badge = f'<span class="pbadge pri-{pri}">{esc(pri)}</span>' if pri in PRIORITY_ORDER else esc(pri)
        rows.append(
            f'<tr class="{row_cls}" data-priority="{esc(pri)}" data-category="{esc(cat)}">'
            f"<td>{pri_badge}</td><td>{esc(cat_label)}</td><td><b>{esc(rid)}</b></td>"
            f"<td>{esc(r.get('summary', ''))}</td><td>{sec_html} {flag}</td></tr>"
        )
    cats = sorted({str(r.get("category", "")) for r in requirements if isinstance(r, dict) and r.get("category")})
    cat_opts = '<option value="all">All categories</option>' + "".join(
        f'<option value="{esc(c)}">{esc(CATEGORY_LABEL.get(c, c))}</option>' for c in cats
    )
    filters = (
        '<div class="filters">'
        '<select id="filterPriority"><option value="all">All priorities</option>'
        '<option value="H">H (High)</option><option value="M">M (Medium)</option><option value="L">L (Low)</option></select>'
        f'<select id="filterCategory">{cat_opts}</select></div>'
    )
    table = (
        '<table class="covtable"><thead><tr>'
        "<th>Priority</th><th>Category</th><th>ID</th><th>Requirement</th><th>Mapped Section</th>"
        f"</tr></thead><tbody>{''.join(rows)}</tbody></table>"
    )
    return render_banner(cov) + filters + table


_MAP_PLACEHOLDER = (
    '<div class="mapEmpty">Requirement mapping will be populated after Theme Statement generation<br>'
    "during step 3, Requirement Mapping.</div>"
)


def render_html(
    state: dict, stage: str, changed: set[str],
    requirements: list, mapping_sections: list, rps: dict,
) -> str:
    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    project = state.get("project", "")
    headline = state.get("win_theme_headline", "")
    groups = state.get("groups", [])
    # 패널을 "준비됨"으로 볼 조건: S3 생성 데이터가 있거나(groups), 제안서 목차 확인
    # 체크포인트가 열려 있음(rfp.json에 required_proposal_structure 존재 — 목차가
    # 비어 있는 not-found 케이스 포함). 목차만 있어도 메뉴를 켜 사용자가 View 0을
    # 열어 확인하게 한다. 패널은 스크립트 실행 시에만 다시 그려지므로, 이 확장이
    # S0b 완료만으로 메뉴를 조기에 켜지 않는다(체크포인트에서 재렌더할 때 켜진다).
    panel_ready = bool(groups) or bool(rps.get("present"))
    groups_html = (
        "".join(render_group(group, changed) for group in groups)
        if groups
        else '<div class="empty">Theme Statement generation has not started yet. Results will appear here as this stage progresses.</div>'
    )
    notice_text = ""
    notice_class = "hidden"
    if any(g.get("status") == "failed" for g in groups):
        notice_text = "Some section-group generation tasks failed. Check the coordinator return value for the failure list."
        notice_class = ""
    if mapping_sections:
        cov = build_coverage(requirements, mapping_sections)
        req_by_id = {str(r.get("id")): r for r in requirements if isinstance(r, dict) and r.get("id")}
        stmt_idx = statement_index(state)
        map_tree_html = render_mapping_tree(mapping_sections, req_by_id, stmt_idx, cov)
        map_table_html = render_coverage_table(requirements, cov)
    else:
        map_tree_html = _MAP_PLACEHOLDER
        map_table_html = _MAP_PLACEHOLDER
    win_theme_label = f"Win Theme: {headline}" if headline else ""
    replacements = {
        "TITLE": f"Theme Statements Generation - {project}",
        "HEADING": "Theme Statements Generation",
        "PROJECT_LABEL": f"Project: {project}",
        "WIN_THEME_LABEL": win_theme_label,
        "STAGE_PILLS_HTML": render_stage_pills(state, stage),
        "NOTICE_CLASS": notice_class,
        "NOTICE_TEXT": notice_text,
        "OUTLINE_HTML": render_outline(rps),
        "GROUPS_HTML": groups_html,
        "MAP_TREE_HTML": map_tree_html,
        "MAP_TABLE_HTML": map_table_html,
        "PANEL_READY": "true" if panel_ready else "false",
    }
    for key, value in replacements.items():
        template = template.replace(f"{{{{{key}}}}}", value)
    return template


def main() -> None:
    args = parse_args()
    root = Path(args.root).resolve()
    if not args.project and not args.progress_dir:
        raise SystemExit("project is required unless --progress-dir is provided")
    if args.progress_dir:
        progress_dir = Path(args.progress_dir).resolve()
        project = args.project or progress_dir.parents[2].name
    else:
        project = args.project
        progress_dir = default_progress_dir(root, project)
    output = Path(args.output).resolve() if args.output else default_output(root, project)
    cache = output.with_suffix(".snapshot.json")
    state = assemble_state(progress_dir)
    stage = args.stage or infer_stage(state)
    previous: dict | None = None
    if not args.no_cache and cache.exists():
        try:
            previous = load_json(cache)
        except (SystemExit, json.JSONDecodeError):
            previous = None
    changed = changed_keys(previous, state)
    requirements, mapping_sections, _mapping_complete = load_rfp_mapping(root, project)
    rps = load_rps(root, project)
    html_text = render_html(state, stage, changed, requirements, mapping_sections, rps)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html_text, encoding="utf-8")
    if not args.no_cache:
        cache.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
