---
name: theme-statements
description: >-
  CONTRL pipeline S3 — Theme Statements. Reduces the selected Win Theme into one theme statement per leaf section in the proposal outline and creates the requirement-to-section mapping.
  Produces theme_statements.json and rfp.json requirement_mapping. Use for Theme Statement generation, section-level messages, requirement mapping, or S3 execution. S4 Slide Contents consumes this artifact.
---

# S3 — Theme Statement 생성 (Theme Statements)

## Customer Delivery Defaults

Generate all theme statements, requirement mappings, labels, and progress-panel text in English. Translate Korean or other non-English source content into natural business English before writing artifacts.

선택된 Win Theme를 **RFP 제안 목차의 leaf 섹션마다 1개의 theme statement**로 환원한다
(섹션 1:1). 이어서 요구사항을 섹션에 매핑한다.

## 입출력 계약

- **입력:** runner가 디스크에서 읽는 것 — `projects/{name}/artifacts/rfp/rfp.json`,
  `projects/{name}/artifacts/strategy/framework_3c.json`, 그리고 거기서 파생한 `leaves`(아래 leaf 파생 규칙).
  orchestrator가 호출 인자로 주입하는 것 — `selected_win_theme` 객체(`win_themes.json`에서 resolve, `index` 필드 제거) + `win_theme_index`.
- **출력 (canonical, gate 대상):**
  - `projects/{name}/artifacts/strategy/theme_statements.json`
  - `projects/{name}/artifacts/rfp/rfp.json`의 `requirement_mapping` + `mapping_complete:true`
- **출력 (진행 표시, read-only 파생물, gate 비대상):** `projects/{name}/outputs/strategy/theme_statements_progress.html` + 작업용 `outputs/strategy/.ts_progress/`. 아래 "진행 표시(progress HTML)" 절이 단일 소스. 렌더 실패는 스테이지를 막지 않는다.

## leaf 파생 규칙 (결정론)
`required_proposal_structure.sections[]`(flat, level 1/2)에서 leaf를 도출:
- level-1 아래 level-2 자식이 있으면 → level-1은 group, level-2들이 leaf
  (`parent_path=[level-1 title]`).
- mixed-depth TOC에서 level-1에 level-2 자식이 없으면 → 합성 mirror leaf 생성:
  `section_id={parent_id}-1`, title `"1. {numbering 제거된 parent}"`.
- 전부 level-1(mixed 아님)이면 → 각 level-1이 leaf.
- level >2 무시.
각 leaf: `{section_id, title, level, page, parent_path}`.

## 절차

S3는 코디네이터(`theme-statement-runner`) 1개가 전 과정을 자기 컨텍스트 안에서 수행한다. A(생성)는 leaf 수에 따라 **level-1 그룹별 fan-out** 또는 **단일 콜**로 갈리고, A가 모두 도착한 뒤(barrier) 같은 코디네이터가 이어서 B(매핑)를 1콜로 처리한다. win theme는 orchestrator가 resolve해 주입한 `selected_win_theme` 객체 + `win_theme_index`를 소비만 한다 (win_themes.json을 열거나 index로 pull하지 않고, 선택을 새로 묻거나 기록하지 않음).

### A. Theme Statement 생성

**A-0. 그룹핑 (결정론).** 위 leaf 파생 규칙으로 leaf를 도출하고 `parent_path`(level-1)별로 묶어 그룹을 만든다. 한 그룹 = 한 level-1 단원 + 그 leaf들(자식 없는 level-1은 mirror leaf 1개짜리 그룹). `group_id`는 등장 순 `g1,g2,…`.

**A-1. 실행 전략 (fan-out vs 단일 콜).**
- **단일 콜 폴백:** 모든 그룹이 단일 leaf(예: 전부 level-1 TOC)이거나 leaf 총수 < 6이면 fan-out 이득이 없고 형제 차별화도 한 컨텍스트가 더 낫다 → 전체 leaf를 **단일 콜**로 생성한다 (`{leaf_sections_table}`=전체 leaf, `{sibling_sections_note}`=빈 값).
- **그룹 fan-out:** 그 외에는 그룹마다 `theme-statement-group-runner`를 띄운다. **동시 최대 5그룹**, 더 많으면 slot이 비는 대로 이어 실행. 각 worker는 자기 그룹 leaf의 items만 생성·반환하고 자기 partial을 디스크에 쓴 뒤 progress HTML을 재렌더한다.

**A-2. 그룹별 생성 (worker 또는 단일 콜 본체).** 시스템 프롬프트 `references/prompts/theme_statement_assembly.md`:
- `{selected_win_theme}`(JSON), `{framework_3c_markdown}`(인용 id 포함), `{rfp_json}`,
- `{leaf_sections_table}`(컬럼: section_id, level, parent_path, title) — **fan-out이면 그 그룹 leaf로 한정**,
- `{sibling_sections_note}` — fan-out이면 그 그룹 외 전체 leaf 제목 목록(차별화 가드), 단일 콜이면 빈 값,
- `{theme_statement_instructions}`(theme_statement_system.md), `{quality_checks}`.
structured-output(json_schema)으로 `ThemeStatementArtifact` 생성(아래 스키마). **그룹 내 1:1 강제:** items 개수 = 그 입력 leaf 개수, section_id 집합 일치. 불일치면 그 그룹만 재생성(최대 2회).

**A-3. barrier (코디네이터).** 그룹 결과를 모아 머지하고 **전역 1:1 강제**: items 합 개수 = 전체 leaf 개수, section_id 집합 = 전체 leaf section_id 집합. 추가로 **discriminator 중복 점검** — 여러 섹션이 WT `feature.discriminator`를 사실상 그대로 복제했으면(섹션 grain 없음) 해당 그룹을 재생성한다. 부분 실패(그룹 단위)는 silent drop 금지: 실패 그룹 목록을 반환값에 싣는다.

### B. 요구사항↔섹션 매핑 (1콜, 글로벌)
A의 barrier가 끝난 뒤 같은 코디네이터가 이어서 1콜로 수행한다. **글로벌 배정**(모든 요구사항을 전 섹션에 정확히 한 번씩)이라 그룹으로 쪼개지 않는다.
1. 시스템 프롬프트: `requirement_mapping_system.md`
2. 유저 프롬프트: `requirement_mapping_user.md`
   - `{proposal_sections}` = TOC 트리 불릿. 각 노드 `- [{section_id}] {title}`, 매칭된 leaf엔
     `Theme: {statement}` 줄 추가.
   - `{requirements}` = `- {id}: {summary} [{rfp_reference}]` 불릿.
3. structured-output으로 nested 트리 생성: TOC 깊이만큼 inline된 섹션 스키마
   `{section_id, title, requirements:[req_id], children:[...]}`.
4. `rfp.json`에 `requirement_mapping`(=결과) + `mapping_complete:true` 병합 저장.

## 진행 표시 (progress HTML) — 렌더 메커닉 단일 소스
유저가 대기 중 중간 결과를 보도록, A 진행을 디스크 고정 경로 HTML 패널로 보여준다. 시드 렌더 후 덮어쓰기로 in-place 갱신하며, 렌더 실패는 스테이지를 막지 않는다.

**작업 파일 (`outputs/strategy/.ts_progress/`).** 병렬 worker의 동시 쓰기 race를 피하려고 공유 mutable JSON을 쓰지 않고 **파일을 쪼갠다**:
- `plan.json` (코디네이터가 fan-out 전에 1회 기록 = 시드 구조):
  ```json
  {"project":"name","win_theme_headline":"...","groups":[
    {"group_id":"g1","parent_path":"Ⅰ. 사업 일반","leaves":[
      {"section_id":"sec_0001","title":"1. 사업 개요"}]}]}
  ```
- `group-{group_id}.json` (각 worker가 자기 것만 기록): `items`는 그 그룹 leaf의 ThemeStatementArtifact item을 **그대로**(생성한 full field 포함) 담는다. 패널이 `statement` 요약 아래로 각 필드(Hot Button·Feature·Benefit·Proof Point·Discriminator·Quantified Benefit)를 토글로 펼쳐 보여주기 때문이다. `source`는 진행 패널용 부가 필드(`section` 또는 `{req_id}`)다.
  ```json
  {"group_id":"g1","status":"done|failed","items":[
    {"section_id":"sec_0001","statement":"...","source":"section|{req_id}",
     "hot_button":"...","hot_button_source_ref":{"kind":"rfp|3c","locator":"..."}|null,
     "feature":"...","benefit":"...",
     "proof_points":[{"text":"...","kind":"case|metric|certification|reference|other","citation":{"kind":"rfp|3c","locator":"..."}|null}],
     "quantified_benefit":"...|null","discriminator":"...|null"}]}
  ```
  field가 빠진 item(예: 구버전 partial)도 렌더러가 허용한다 — `statement`만 있으면 토글 없이 한 줄로 그린다.
렌더러는 `plan.json` + 존재하는 `group-*.json`을 합쳐 읽는 **순수 함수** — 아직 없는 그룹은 "생성 중"으로 그려지고 다음 렌더에서 채워진다.

**렌더 명령** (CWD가 유저 레포라 상대경로 불가 → 스크립트는 `${CLAUDE_PLUGIN_ROOT}`, 출력 루트는 절대경로):
```bash
python3 "${CLAUDE_PLUGIN_ROOT}/skills/theme-statements/scripts/render-progress-html.py" \
  <project_name> --root "<projects/ 가 있는 절대경로>" [--stage generating|merging|mapping|done]
```
출력 `projects/{name}/outputs/strategy/theme_statements_progress.html`. snapshot 캐시(`*.snapshot.json`)로 직전 대비 새로 도착한 leaf를 강조. `--stage` 생략 시 그룹 완료 수로 추정.

**패널 탭 구성.** 패널은 3개 탭으로 나뉜다 — ① **Theme Statements**(A 진행/결과, progress dir 기반), ② **요구사항 매핑 · 섹션 트리**, ③ **요구사항 매핑 · 커버리지 표**. 매핑 탭 ②③은 렌더러가 `artifacts/rfp/rfp.json`의 `requirements[]` + `requirement_mapping.sections`를 함께 읽어 그린다(별도 인자 없음, project 경로로 자동 로드). B 미완(=`requirement_mapping` 없음)이면 매핑 탭은 placeholder를 보여주고, B 저장(`--stage mapping`/`done`) 후 자동으로 채워진다. 두 매핑 탭 상단에는 **커버리지 배너**(전체·매핑·미매핑·중복)가 공통 탑재되며, 표 탭은 우선순위/카테고리 필터와 미매핑(✗)·중복(⚠) 강조로 B의 "요구사항 1:1 배정" 계약을 눈으로 검증하게 한다.

**렌더 호출 시점:**
1. **시드 렌더 (코디네이터, fan-out 전 1회):** `plan.json` 기록 후 패널을 렌더한다. 단일 콜 폴백에서도 시드 렌더는 한다.
2. **worker 완료마다:** worker가 자기 `group-{id}.json` 기록 직후 렌더(덮어쓰기) → 해당 단원이 in-place로 채워진다. 동시 완료는 last-writer-wins(전체 union을 렌더하므로 최신은 항상 정합).
3. **barrier 후 코디네이터:** `--stage merging` → B 진입 시 `--stage mapping` → 저장 완료 시 `--stage done`.

## ThemeStatementArtifact 스키마
```json
{
  "items": [{
    "section_id": "sec_0003",              // leaf 섹션의 안정 id
    "statement": "유저에게 보이고 다운스트림이 재사용하는 단일 문장",
    "hot_button": "string",
    "hot_button_source_ref": {"kind":"rfp|3c","locator":"co3 또는 페이지번호"} | null,
    "feature": "string",
    "benefit": "string",
    "proof_points": [{"text":"string","kind":"case|metric|certification|reference|other",
                      "citation":{"kind":"rfp|3c","locator":"..."}|null}],
    "quantified_benefit": "string|null",   // enhancer
    "discriminator": "string|null"          // enhancer
  }]
}
```
모든 객체 `additionalProperties:false`. `win_theme_index`는 저장 단계에서 추가.

## 검증
- `items` 개수 == leaf 개수, section_id 집합 일치 (불일치 시 재생성).
- 매핑 트리의 section_id가 RFP 구조와 정합.
