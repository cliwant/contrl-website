# Quality checks (self-review before emit)

Run these on every TS item before emitting. If a TS fails, rewrite it — do not loosen the rule.

1. **1:1 coverage** — `items` count == Leaf Section List count; `section_id` values match the input set verbatim.
2. **Section grain** — a reader who reads only this TS and the section title can tell why this `hot_button` lives in THIS section and not another. Generic project slogans fail.
3. **WT reduction, no carry** — `statement` points in the WT `headline`'s direction; `feature` / `benefit` / `discriminator` are re-articulated, not verbatim copies of the WT's same-name fields.
4. **Citation tokens placed correctly** — see "Citation policy summary" above. `statement` carries no tokens; `[p.N]` never appears in any body field.
5. **Discriminator restraint** — `null` unless there's a defensible section-grain differentiator that competitors lack.
6. **`quantified_benefit`** — `null` unless a number genuinely follows from RFP / 3C / proof_points.
7. **Plain JSON, no commentary** — emit only the JSON object matching `ThemeStatementArtifact`.
