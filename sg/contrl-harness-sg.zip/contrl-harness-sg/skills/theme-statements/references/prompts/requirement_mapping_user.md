## Proposal Sections

{proposal_sections}

## Requirements

{requirements}
