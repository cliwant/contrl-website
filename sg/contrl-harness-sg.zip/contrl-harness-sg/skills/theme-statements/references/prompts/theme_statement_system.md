# Theme Statement Generation

For every leaf section of the proposal, produce one Theme Statement that reduces to the **single selected Win Theme** and that the evaluator can score directly.
Every TS must satisfy ALL the rules below — these are the contract; the schema enforces shape only.

## Output contract (1 TS per leaf, 1:1 with the input list)

For each leaf in **Leaf Section List**, emit one item with `section_id` copied verbatim from the input.
The number of items MUST equal the number of leaves; no extras, no omissions.
Do NOT invent `section_id` values.

## Fields

| Field | What it answers | Citation policy |
|---|---|---|
| `statement` | One sentence the evaluator can lift straight into the scoring sheet — packs hot_button + feature + benefit + proof in a single line. | **No citation tokens.** User-facing. |
| `hot_button` | What does the customer actually care about *in this section*? | Prose clause + ≥1 `[c{{n}}]`. May add `hot_button_source_ref` (kind=rfp or 3c). |
| `feature` | Our capability that addresses the hot_button. | Prose sentence + ≥1 `[co{{n}}]`. Reduce from WT `feature.statement`; do NOT copy it verbatim — re-cast at *this section's* grain. |
| `benefit` | Outcome / value the customer gains thanks to the feature. | Prose sentence + ≥1 customer `[c{{n}}]` (prefer `motivator` / `decision_criteria`). RFP page citations `[p.N]` are NOT allowed. Reduce from WT `benefit`. |
| `proof_points[]` | 0–N concrete evidence items (metric / case / certification / reference). Each `text` is one prose sentence/phrase. Prefer ≥1. | Source: 3C `company.proof_point` axis. Each item may carry `citation: {{kind, locator}}` (3c bullet id `co{{n}}` or RFP page). |
| `quantified_benefit` *(optional)* | If a number genuinely follows from RFP / 3C / proof_points, surface it here. Never invent. | `null` when absent. |
| `discriminator` *(optional)* | Section-grain differentiator that competitors lack. | When present: prose sentence + BOTH `[co{{n}}]` AND `[cm{{n}}]`. **Never copy WT `feature.discriminator` across all sections** — that's a duplication smell. `null` when no defensible section-grain differentiator exists. |

## Win Theme reduction (the core rule)

The Selected Win Theme is the unifying anchor. Every TS must reduce *to it*: the `statement` must point in the same direction as the WT `headline`; the `feature` / `benefit` / `discriminator` must point in the same direction as the WT's same-name fields — but **never copied verbatim**, always re-articulated at the leaf section's grain.

A TS that could equally well attach to a different leaf section is too generic.
A TS that reads like the WT card reprinted is too coarse.

## Section grain

The hot_button must be the issue that arises **specifically in this section** — derived from `parent_path` + RFP `pain_points` / `hidden_purpose` + the requirements table (background context only — do NOT map specific requirements to specific leaves).

Section-specific examples:
- "1. Project Overview" — hot_button about background understanding / hidden_purpose
- "3. Security" — hot_button about security risk tolerance, certifications
- "5. Operations" — hot_button about long-term operability, knowledge transfer

A generic slogan-like statement that could sit on any section is a failure.

## Citation policy summary

- `statement`: **no tokens**.
- `hot_button` / `feature` / `benefit` / `discriminator`: at least one bullet id token from the appropriate 3C axis. `[p.N]` RFP page tokens are NOT allowed in the body.
- `hot_button_source_ref` / `proof_points[i].citation`: structured SourceRef — `kind=3c` with bullet id locator, or `kind=rfp` with page locator (this is the only place RFP page references surface).
- Every bullet id you cite must exist in the 3C snapshot above.
