# Requirement-to-Section Mapping

You are assigning RFP requirements to their best-fit proposal sections, guided by theme statements that define the strategic narrative of each section.

## Input

You will receive:
1. A proposal TOC as a nested hierarchy. Sections with no sub-sections beneath them are leaf sections.
2. Theme statements — one per leaf section, each containing:
   - `statement`: the overall persuasion sentence for the section
3. A list of requirements extracted from the RFP, each with an ID, summary, and page reference.

## Output Format

Output the proposal TOC tree with requirement IDs placed in the `requirements` array of each **leaf** section. Preserve the exact tree structure (titles, nesting) from the input. Non-leaf sections must have an empty `requirements` array.

```json
{
  "sections": [
    {
      "title": "III. Technical and Functional Approach",
      "requirements": [],
      "children": [
        {"title": "1. Functional Requirements", "requirements": ["SFR-001", "SFR-002"], "children": []},
        {"title": "2. Security Requirements", "requirements": ["SER-001"], "children": []}
      ]
    }
  ]
}
```

Note: Requirement IDs vary per RFP (e.g., `SFR-001`, `ECR-003`, `R1`). Use the IDs from the input as-is.

Output ONLY JSON. No markdown fences. No explanation.

## Rules

1. **Use both section titles and theme statements to determine the best fit.**
   - When a requirement's subject clearly matches a section title, that is the default placement.
   - When a theme statement explicitly references a requirement **by ID**, that overrides the section-title match.
   - When neither applies clearly, use the theme statement to break the tie. Map requirements whose subject aligns with the section's overall narrative.
   - A theme statement that merely mentions a topic in passing is **not** sufficient to move a requirement away from a section whose title directly matches the requirement's subject.
2. **Section titles** must be the exact strings from the input. Do not paraphrase or abbreviate.
3. **Only map to leaf sections** — sections that have no sub-sections beneath them. Non-leaf sections must have `"requirements": []`.
4. Every requirement MUST be mapped to a leaf section. If a requirement is not referenced by any theme statement, place it in the section whose theme is the closest semantic match.
5. Every requirement ID must appear exactly once across all sections. If a requirement is referenced by multiple theme statements, place it in the section where it is most central to the theme's argument.
