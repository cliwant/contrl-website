#!/usr/bin/env python3
"""S5 flatten — slide_contents.json → ordered input_slides with ABSOLUTE index.

Faithful port of the original contrl `worker.py::run_slide_plan` flatten
(`backend/services/slide_plan/worker.py`). Deterministic, stdlib-only.

The flatten order (items in order, slides within each item in order) defines each
slide's ABSOLUTE index. That index is the per-slide pipeline's identity: every
DECISION record (`.plan/slide_{index}.json`), the floor path, and assemble all
key off it, and it maps 1:1 to a slide card — including on a selective re-plan.

`--slide-indices` re-plans only those ABSOLUTE indices (the rest are merged back
from the existing artifact downstream); the index is still assigned from the FULL
flatten so it never shifts.

Each input slide carries exactly what the per-slide steps need:
  {index, source, subtitle, section_id, blocks:[{heading, body:[...]}]}

CLI:
    python flatten.py --contents <slide_contents.json> [--slide-indices 0,3,5]
                      [--out <manifest.json>] [--split-dir <dir>]

Default: prints `{total, count, slides:[...]}` to stdout. `--out` writes that
JSON. `--split-dir DIR` additionally writes one `slide_{index}.json` per (filtered)
slide into DIR — the per-slide input a fan-out subagent / layout_fills / make_floor
consumes — and the manifest then also reports `{dir, indices}`.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def load_slide_contents(path: str | Path) -> dict[str, Any]:
    """Load + parse slide_contents.json. Fail-loud with the path."""
    p = Path(path)
    if not p.is_file():
        raise SystemExit(f"slide_contents not found: {p}")
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"slide_contents is invalid JSON at {p}: {exc}")


def flatten(slide_contents: dict[str, Any]) -> list[dict[str, Any]]:
    """`slide_contents.items` → ordered input_slides with absolute `index`.

    Order = items in order, slides within each item in order (the absolute-index
    contract). An item with no slides contributes nothing. Mirrors the original
    worker flatten field-for-field.
    """
    items = slide_contents.get("items")
    if not isinstance(items, list) or not items:
        raise SystemExit("slide_contents has no non-empty 'items' array")

    input_slides: list[dict[str, Any]] = []
    index = 0
    for item in items:
        section_id = item.get("section_id")
        for slide in item.get("slides", []) or []:
            input_slides.append({
                "index": index,
                "source": slide.get("source", "section"),
                "subtitle": slide.get("subtitle", ""),
                "section_id": section_id,
                "blocks": slide.get("blocks", []) or [],
            })
            index += 1
    if not input_slides:
        raise SystemExit("slide_contents items contain no slides")
    return input_slides


def _parse_indices(spec: str | None, total: int) -> list[int] | None:
    """`"0,3,5"` → sorted in-range absolute indices, or None for the full deck.

    Out-of-range indices are dropped (matches the worker's `0 <= i < total_all`).
    """
    if spec is None:
        return None
    out: set[int] = set()
    for tok in spec.split(","):
        tok = tok.strip()
        if not tok:
            continue
        try:
            i = int(tok)
        except ValueError:
            raise SystemExit(f"--slide-indices: not an integer: {tok!r}")
        if 0 <= i < total:
            out.add(i)
    return sorted(out)


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="S5 flatten (absolute-index input_slides)")
    p.add_argument("--contents", required=True, help="path to slide_contents.json")
    p.add_argument("--slide-indices", help="comma-separated ABSOLUTE indices for a partial re-plan")
    p.add_argument("--out", help="write the manifest JSON here (default: stdout)")
    p.add_argument("--split-dir", help="also write one slide_{index}.json per filtered slide into this dir")
    args = p.parse_args(argv)

    contents = load_slide_contents(args.contents)
    all_slides = flatten(contents)
    total = len(all_slides)

    target = _parse_indices(args.slide_indices, total)
    selected = all_slides if target is None else [all_slides[i] for i in target]

    if args.split_dir:
        d = Path(args.split_dir)
        d.mkdir(parents=True, exist_ok=True)
        for s in selected:
            (d / f"slide_{s['index']}.json").write_text(
                json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8"
            )

    manifest: dict[str, Any] = {
        "total": total,
        "count": len(selected),
        "indices": [s["index"] for s in selected],
        "slides": selected,
    }
    if args.split_dir:
        manifest["dir"] = str(Path(args.split_dir))

    payload = json.dumps(manifest, ensure_ascii=False, indent=2)
    if args.out:
        Path(args.out).write_text(payload, encoding="utf-8")
        print(f"wrote {args.out}: total={total} count={len(selected)}"
              + (f" split-dir={args.split_dir}" if args.split_dir else ""))
    else:
        print(payload)


if __name__ == "__main__":
    main()