#!/usr/bin/env python3
"""S5 assemble (finalize) — the single deterministic pass to slide_plan.json.

Faithful port of the original contrl `assemble.py::finalize_slide_plan` +
`validate_slide` (`backend/services/slide_plan/assemble.py`), adapted to the
harness: it ingests per-slide DECISION records (`.plan/slide_{index}.json`,
emitted by the per-slide agent) instead of an in-memory `section_results` dict,
and concats by ascending ABSOLUTE index (= flatten order; S4 already emits items
section-sorted). Stdlib-only; dict-based catalog.

Pipeline (mirrors the original §3.1.3 steps):
  1. Body — for every flattened input index 0..N-1: the agent's record if it is
     ok/fallback, else (failed / missing record) a deterministic floor. So every
     input slide → a real plan or a floor; **never dropped, never empty.**
  2. proposal_body — merged into the slide's layout_fills as
     {slot:"proposal_body", value:...} (the agent emits it top-level; audit §5).
  3. Pre-validation (existence / referential integrity) — a real-match slide that
     references a missing catalog id is DEMOTED to the floor; a floor slide that
     still has issues is kept + warned (matches the original).
  4. allowed-list — every component variant on a non-floor slide must be
     in that slide's intent allowed_variant_ids ∪ the catalog fallback pool ∪
     FALLBACK_VARIANT_ID. A violation FAILS LOUD before writing (the agent picked
     a variant outside its candidate set — a planning bug to fix, not to floor).
     The orchestrator gate (validate-artifacts.mjs) is the independent backstop.
  5. Cover / TOC prepend — the precomputed front matter (cover_toc.py output).
  6. Absolute slide_number 1..N over the whole deck.
  7. _meta — pipeline marker, front_matter_count, slide_count, referenced_ids,
     catalog_sha256, floored_count, fallback_count, toc_pages_resolved.

CLI:
    python assemble.py --contents <slide_contents.json> --decisions <dir>
        --front-matter <cover_toc.json> --out <slide_plan.json>
        (--catalog <catalog.json> | --project <name> [--root <abs>])
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import flatten
import loaders
from make_floor import FALLBACK_VARIANT_ID, make_fallback_floor_slide

# Marks an artifact produced by the handoff pipeline (vs the legacy in-app render
# path). Downstream restore / status code keys off this.
PIPELINE_MARKER = "compose_handoff"


def _warn(msg: str) -> None:
    print(msg, file=sys.stderr)


# ── Pre-validation slot-name helpers (dict-based) ────────────────────────────
def _layout_placeholder_names(catalog: dict[str, Any], layout_id: str) -> set[str]:
    for layout in catalog.get("layouts", []):
        if layout.get("id") == layout_id:
            return {p["name"] for p in (layout.get("placeholders") or []) if p.get("name")}
    return set()


def _variant_slot_names(catalog: dict[str, Any], vid: str) -> set[str]:
    for v in catalog.get("variants", []):
        if v.get("id") == vid:
            names: set[str] = set()
            for s in v.get("slots", []):
                if s.get("name"):
                    names.add(s["name"])
                for sub in (s.get("subslots") or []):
                    if sub.get("name"):
                        names.add(sub["name"])
            return names
    return set()


def _adornment_slot_names(catalog: dict[str, Any], aid: str) -> set[str]:
    for a in catalog.get("adornments", []):
        if a.get("id") == aid:
            return {s["name"] for s in (a.get("slots") or []) if s.get("name")}
    return set()


def validate_slide(slide: dict[str, Any], catalog: dict[str, Any]) -> list[str]:
    """Referential integrity of one slide's plan against the catalog (existence of
    intent/layout/variant/adornment ids + every fill slot). None intent/layout
    (a floor slide) is not an error — it's the explicit fallback signal."""
    issues: list[str] = []
    intent_ids = {i.get("id") for i in catalog.get("intents", [])}
    layout_ids = {layout.get("id") for layout in catalog.get("layouts", [])}
    variant_ids = {v.get("id") for v in catalog.get("variants", [])}
    adornment_ids = {a.get("id") for a in catalog.get("adornments", [])}

    intent_id = slide.get("intent_id")
    layout_id = slide.get("layout_id")
    if intent_id is not None and intent_id not in intent_ids:
        issues.append(f"missing intent_id: {intent_id}")
    if layout_id is not None:
        if layout_id not in layout_ids:
            issues.append(f"missing layout_id: {layout_id}")
        else:
            ph_names = _layout_placeholder_names(catalog, layout_id)
            for f in slide.get("layout_fills", []) or []:
                if f.get("slot") not in ph_names:
                    issues.append(f"{layout_id}.layout_fills missing slot: {f.get('slot')}")
    for b in slide.get("blocks", []) or []:
        aid = b.get("adornment_id")
        if aid:
            if aid not in adornment_ids:
                issues.append(f"missing adornment_id: {aid}")
            else:
                ad_names = _adornment_slot_names(catalog, aid)
                for f in b.get("adornment_fills", []) or []:
                    if f.get("slot") not in ad_names:
                        issues.append(f"{aid}.adornment_fills missing slot: {f.get('slot')}")
        for c in b.get("components", []) or []:
            vid = c.get("variant_id")
            if vid not in variant_ids:
                issues.append(f"missing variant_id: {vid}")
                continue
            names = _variant_slot_names(catalog, vid)
            for f in c.get("fills", []) or []:
                if f.get("slot") not in names:
                    issues.append(f"{vid}.fills missing slot: {f.get('slot')}")
            for rf in c.get("repeating_fills", []) or []:
                if rf.get("slot") not in names:
                    issues.append(f"{vid}.repeating_fills missing slot: {rf.get('slot')}")
    return issues


# ── allowed-list (mirrors validate-artifacts.mjs) ──────────────────
def _allowed_sets(catalog: dict[str, Any]) -> tuple[dict[str, set[str]], set[str]]:
    """(intent_id → allowed_variant_ids set, catalog fallback pool set)."""
    allowed_by_intent = {
        i.get("id"): set(i.get("allowed_variant_ids") or [])
        for i in catalog.get("intents", [])
    }
    pool = {v.get("id") for v in catalog.get("variants", []) if v.get("is_fallback")}
    return allowed_by_intent, pool


def allowed_list_violations(
    slide: dict[str, Any],
    allowed_by_intent: dict[str, set[str]],
    pool: set[str],
) -> list[str]:
    """Every component variant on a NON-floor slide must be in its intent's
    allowed_variant_ids ∪ fallback pool ∪ FALLBACK_VARIANT_ID. Floor slides
    (intent_id None) are exempt. Returns human-readable violations."""
    intent_id = slide.get("intent_id")
    if intent_id is None:
        return []
    out: list[str] = []
    allowed = allowed_by_intent.get(intent_id)
    if allowed is None:
        out.append(f"unknown intent_id '{intent_id}'")
        return out
    for b in slide.get("blocks", []) or []:
        for c in b.get("components", []) or []:
            vid = c.get("variant_id")
            if not vid or vid == FALLBACK_VARIANT_ID:
                continue
            if vid not in allowed and vid not in pool:
                out.append(f"variant '{vid}' not in intent '{intent_id}' allowed ∪ fallback pool")
    return out


# ── _meta ────────────────────────────────────────────────────────────────────
def _referenced_ids(slides: list[dict[str, Any]]) -> dict[str, list[str]]:
    intents: set[str] = set()
    layouts: set[str] = set()
    variants: set[str] = set()
    adornments: set[str] = set()
    for s in slides:
        if s.get("intent_id"):
            intents.add(s["intent_id"])
        if s.get("layout_id"):
            layouts.add(s["layout_id"])
        for b in s.get("blocks", []) or []:
            if b.get("adornment_id"):
                adornments.add(b["adornment_id"])
            for c in b.get("components", []) or []:
                if c.get("variant_id"):
                    variants.add(c["variant_id"])
    return {
        "intents": sorted(intents),
        "layouts": sorted(layouts),
        "variants": sorted(variants),
        "adornments": sorted(adornments),
    }


# ── Record → slide ───────────────────────────────────────────────────────────
# Block-heading dedup — VENDORED verbatim into render/scripts/_lib/plan_record.py.
# Keep both copies byte-identical, or a per-slide `--plan-slide` seed would diverge
# from this assembled slide_plan.json (seed-equivalence invariant).
def _is_headline_slot(slot: str) -> bool:
    """A component's own title/banner/header slot — the one that collides with a
    block's adornment heading. Excludes sub-headings (subtitle/subhead*) and any
    `sub…`-prefixed slot; column headers (…_header) match by name but survive the
    value guard in `_dedup_block_headings` since their text differs from the
    heading."""
    s = slot or ""
    if s.startswith("sub") or "subtitle" in s or "subhead" in s:
        return False
    return s.endswith(("title", "header", "heading")) or "banner" in s


def _dedup_block_headings(blocks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Root-fix the S5 double-heading. block_matching gives every block a
    heading-bearing adornment (which renders the block heading in its `title`
    slot), while slot_mapping independently fills the component's own headline
    slot from the same source — the two steps don't see each other, so the heading
    is planted twice. Where the adornment already carries the heading, drop it from
    the component's headline fill so it renders once: a fill that IS the heading is
    dropped; a fill that is the heading followed by an extra editorial line keeps
    only that extra line. The value guard (equal, or heading as a leading line)
    means non-duplicates — subtitles, column headers with different text, body —
    are left untouched, and adornments/components/variant_ids are never modified
    (only component `fills` values). Mechanical + deterministic; keep byte-identical
    with the vendored copy in the other skill so per-slide seeds stay equal to the
    assembled slide_plan.json."""
    for b in blocks or []:
        if not b.get("adornment_id"):
            continue
        heading = next(
            (f.get("value", "").strip()
             for f in (b.get("adornment_fills") or [])
             if f.get("slot") == "title" and (f.get("value") or "").strip()),
            "",
        )
        if not heading:
            continue
        for c in b.get("components") or []:
            fills = c.get("fills")
            if not fills:
                continue
            kept: list[dict[str, Any]] = []
            for f in fills:
                headline = _is_headline_slot(f.get("slot") or "")
                v = (f.get("value") or "").strip()
                if headline and v == heading:
                    continue  # pure duplicate of the adornment heading → drop
                if headline and v.startswith(heading) and v[len(heading):len(heading) + 1] == "\n":
                    rest = v[len(heading):].lstrip("\n").strip()
                    if rest:
                        kept.append({**f, "value": rest})
                    continue
                kept.append(f)
            c["fills"] = kept
    return blocks


def _record_to_slide(rec: dict[str, Any]) -> dict[str, Any]:
    """Build the artifact Slide dict from a DECISION record, merging the agent's
    top-level proposal_body into layout_fills (audit §5/§6)."""
    layout_fills = list(rec.get("layout_fills") or [])
    pb = (rec.get("proposal_body") or "").strip() if isinstance(rec.get("proposal_body"), str) else ""
    if pb and not any(f.get("slot") == "proposal_body" for f in layout_fills):
        layout_fills.append({"slot": "proposal_body", "value": pb})
    return {
        "slide_number": None,
        "source": rec.get("source", "section"),
        "subtitle": rec.get("subtitle", ""),
        "section_id": rec.get("section_id"),
        "intent_id": rec.get("intent_id"),
        "layout_id": rec.get("layout_id"),
        "layout_fills": layout_fills,
        "blocks": _dedup_block_headings(rec.get("blocks") or []),
    }


def _load_record(decisions_dir: Path, index: int) -> dict[str, Any] | None:
    p = decisions_dir / f"slide_{index}.json"
    if not p.is_file():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"decision record invalid JSON at {p}: {exc}")


# ── Assemble ─────────────────────────────────────────────────────────────────
def assemble(
    *,
    input_slides: list[dict[str, Any]],
    decisions_dir: Path,
    front_matter: list[dict[str, Any]],
    catalog: dict[str, Any],
    catalog_sha: str,
) -> dict[str, Any]:
    """The single deterministic finalize pass. Returns the slide_plan artifact
    dict. Raises SystemExit (fail-loud) on an allowed-list violation."""
    allowed_by_intent, pool = _allowed_sets(catalog)

    body: list[dict[str, Any]] = []
    floored_count = 0
    fallback_count = 0
    hard_violations: list[str] = []

    for sin in input_slides:
        idx = sin["index"]
        rec = _load_record(decisions_dir, idx)

        # 1. failed / missing → floor from the original input (never dropped).
        if rec is None or rec.get("status") == "failed":
            why = "missing record" if rec is None else (rec.get("error") or "failed")
            _warn(f"slide {idx}: flooring ({why})")
            body.append(make_fallback_floor_slide(sin, catalog))
            floored_count += 1
            continue

        slide = _record_to_slide(rec)
        status = rec.get("status")

        # 4. allowed-list (non-floor only) → fail loud. Checked BEFORE the
        # existence demote so a borrowed variant that also has slot mismatches can't
        # be silently floored instead of surfaced (the agent picked outside its
        # candidate set — a planning bug, consistent regardless of slot fit).
        for v in allowed_list_violations(slide, allowed_by_intent, pool):
            hard_violations.append(f"slide {idx}: {v}")

        # 3. pre-validation (existence). Real-match with issues → demote to floor.
        issues = validate_slide(slide, catalog)
        if issues:
            if slide.get("intent_id") is not None:
                _warn(f"slide {idx}: demoting to floor — {issues}")
                body.append(make_fallback_floor_slide(sin, catalog))
                floored_count += 1
                continue
            _warn(f"slide {idx}: floor slide still has issues (left as-is): {issues}")

        if status == "fallback" or slide.get("intent_id") is None:
            fallback_count += 1
        body.append(slide)

    if hard_violations:
        raise SystemExit(
            "assemble: allowed-list violation(s) — fix the agent's variant pick:\n  "
            + "\n  ".join(hard_violations)
        )

    # 5. front-matter prepend (validated, warn-only — cover_toc emits authored variants).
    for entry in front_matter:
        fi = validate_slide(entry, catalog)
        if fi:
            _warn(f"front-matter ({entry.get('intent_id')}): {fi}")

    slides = list(front_matter) + body

    # 6. absolute slide_number.
    for n, s in enumerate(slides, 1):
        s["slide_number"] = n

    meta = {
        "pipeline": PIPELINE_MARKER,
        "front_matter_count": len(front_matter),
        "slide_count": len(slides),
        "referenced_ids": _referenced_ids(slides),
        "catalog_sha256": catalog_sha,
        "floored_count": floored_count,
        "fallback_count": fallback_count,
        "toc_pages_resolved": False,
    }
    _warn(
        f"assemble: front_matter={len(front_matter)} body={len(body)} "
        f"floored={floored_count} fallback={fallback_count} total={len(slides)}"
    )
    return {"_meta": meta, "status": "ready", "master_fills": [], "slides": slides}


def _resolve_catalog_path(args: argparse.Namespace) -> Path:
    if args.catalog:
        return Path(args.catalog)
    if args.project:
        return loaders.catalog_path_for_project(args.project, args.root)
    raise SystemExit("provide --catalog <path> or --project <name>")


def _load_json(path: str, what: str) -> Any:
    p = Path(path)
    if not p.is_file():
        raise SystemExit(f"{what} not found: {p}")
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"{what} invalid JSON at {p}: {exc}")


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="S5 assemble → slide_plan.json")
    p.add_argument("--contents", required=True, help="slide_contents.json (re-flattened for the index range + floor inputs)")
    p.add_argument("--decisions", required=True, help="dir of per-slide DECISION records (slide_{index}.json)")
    p.add_argument("--front-matter", dest="front_matter", required=True, help="cover_toc.py output JSON")
    p.add_argument("--out", required=True, help="write slide_plan.json here")
    p.add_argument("--catalog", help="path to catalog.json")
    p.add_argument("--project", help="project name under projects/")
    p.add_argument("--root", default=".", help="repo root (for --project)")
    args = p.parse_args(argv)

    catalog_path = _resolve_catalog_path(args)
    catalog = loaders.load_catalog(catalog_path)
    catalog_sha = loaders.catalog_sha256(catalog_path)

    contents = _load_json(args.contents, "slide_contents")
    input_slides = flatten.flatten(contents)

    decisions_dir = Path(args.decisions)
    if not decisions_dir.is_dir():
        raise SystemExit(f"decisions dir not found: {decisions_dir}")

    fm_payload = _load_json(args.front_matter, "front_matter")
    front_matter = fm_payload.get("slides", []) if isinstance(fm_payload, dict) else list(fm_payload)

    artifact = assemble(
        input_slides=input_slides,
        decisions_dir=decisions_dir,
        front_matter=front_matter,
        catalog=catalog,
        catalog_sha=catalog_sha,
    )
    Path(args.out).write_text(json.dumps(artifact, ensure_ascii=False, indent=2), encoding="utf-8")
    m = artifact["_meta"]
    print(f"wrote {args.out}: slides={m['slide_count']} front_matter={m['front_matter_count']} "
          f"floored={m['floored_count']} fallback={m['fallback_count']} sha={catalog_sha[:16]}")


if __name__ == "__main__":
    main()
