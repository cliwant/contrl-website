#!/usr/bin/env python3
"""S5 fallback floor — the single deterministic degraded-slide definition.

Faithful port of the original contrl `section_plan.py` floor helpers
(`make_fallback_floor_slide`, `_fallback_fill_slot`, `_floor_component_dict`),
with the pydantic Slide/Block/Component models emitted as plain dicts. Stdlib-only.

The floor wraps a slide's original blocks in `FALLBACK_VARIANT_ID` with
`intent_id=None` (the render's fallback signal — there is no separate
`is_fallback` field on the slide) and `layout_id=None` (renderer uses the default
content box). **Never an empty Slide** — the body text survives in the variant's
primary text slot, so a degraded slide still carries its content.

Two callers, identical output shape:
  - the per-slide agent's null-intent path (status="fallback"), and
  - assemble-time demotion of a slide whose plan failed / failed pre-validation.
`assemble.py` imports `make_fallback_floor_slide` + `FALLBACK_VARIANT_ID` from
here so the floor has one definition.

NOTE: `FALLBACK_VARIANT_ID` ("single-bordered-bullet-box") is the degraded floor
component — distinct from the `is_fallback` *pool* (`loaders.get_variants_for_intent`)
that thin intents draw structural alternatives from. Do not conflate.

CLI:
    python make_floor.py --slide <flattened_slide.json>
        (--catalog <catalog.json> | --project <name> [--root <abs>])
        [--out <path>]

`--slide` is the flattened input slide (flatten.py output: source/subtitle/
section_id/blocks[{heading, body:[...]}]). Emits one floor Slide dict.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import loaders

# The degraded floor component. Mirrors the original models.FALLBACK_VARIANT_ID
# and the FALLBACK_VARIANT_ID hardcoded in pipeline/scripts/validate-artifacts.mjs.
FALLBACK_VARIANT_ID = "single-bordered-bullet-box"


def _fallback_fill_slot(catalog: dict[str, Any]) -> str | None:
    """Name of FALLBACK_VARIANT_ID's primary text slot, or None.

    Catalog-driven so it survives a variant slot rename; None when the
    variant/slot is absent (a catalog lacking FALLBACK_VARIANT_ID) — the floor is
    still produced, just without fills (pre-validation flags it)."""
    for v in catalog.get("variants", []):
        if v.get("id") != FALLBACK_VARIANT_ID:
            continue
        for slot in v.get("slots", []):
            if slot.get("kind") in ("richtext", "text") and slot.get("name"):
                return str(slot["name"])
        return None
    return None


def _floor_component_dict(block: dict[str, Any], fill_slot: str | None) -> dict[str, Any]:
    """The floor component for one source block: one FALLBACK_VARIANT_ID component
    whose primary slot holds the block's body text (newline-joined)."""
    body = [str(line) for line in (block.get("body") or [])]
    fills: list[dict[str, str]] = []
    if fill_slot and body:
        fills.append({"slot": fill_slot, "value": "\n".join(body)})
    return {"variant_id": FALLBACK_VARIANT_ID, "fills": fills, "repeating_fills": []}


def make_fallback_floor_slide(slide_input: dict[str, Any], catalog: dict[str, Any]) -> dict[str, Any]:
    """The fallback floor: a renderable degraded slide, never empty.

    `intent_id=None` is the render's fallback signal; `layout_id=None` → default
    content box. `slide_number` is assigned later at assemble."""
    fill_slot = _fallback_fill_slot(catalog)
    blocks: list[dict[str, Any]] = []
    for b in slide_input.get("blocks", []) or []:
        comp = _floor_component_dict(b, fill_slot)
        blocks.append({
            "heading": b.get("heading", ""),
            "adornment_id": None,
            "adornment_fills": [],
            "components": [comp],
        })
    return {
        "slide_number": None,
        "source": slide_input.get("source", "section"),
        "subtitle": slide_input.get("subtitle", ""),
        "section_id": slide_input.get("section_id"),
        "intent_id": None,
        "layout_id": None,
        "layout_fills": [],
        "blocks": blocks,
    }


def _resolve_catalog(args: argparse.Namespace) -> dict[str, Any]:
    if args.catalog:
        return loaders.load_catalog(args.catalog)
    if args.project:
        return loaders.load_catalog(loaders.catalog_path_for_project(args.project, args.root))
    raise SystemExit("provide --catalog <path> or --project <name>")


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="S5 fallback floor slide")
    p.add_argument("--slide", required=True, help="flattened input slide JSON")
    p.add_argument("--catalog", help="path to catalog.json")
    p.add_argument("--project", help="project name under projects/")
    p.add_argument("--root", default=".", help="repo root (for --project)")
    p.add_argument("--out", help="write output JSON here (default: stdout)")
    args = p.parse_args(argv)

    catalog = _resolve_catalog(args)
    sp = Path(args.slide)
    if not sp.is_file():
        raise SystemExit(f"slide not found: {sp}")
    slide_input = json.loads(sp.read_text(encoding="utf-8"))

    floor = make_fallback_floor_slide(slide_input, catalog)
    payload = json.dumps(floor, ensure_ascii=False, indent=2)
    if args.out:
        Path(args.out).write_text(payload, encoding="utf-8")
        print(f"wrote {args.out}")
    else:
        print(payload)


if __name__ == "__main__":
    main()