#!/usr/bin/env python3
"""Slide-plan (S5) candidate-variant assembly.

Faithful port of the original contrl `get_variants_for_intent`
(`backend/services/slide_plan/loaders.py`) into the harness. Deterministic,
stdlib-only (no venv, no API key) — it is pure candidate assembly and does not
depend on the unresolved S5 execution substrate.

Builds the block_matching candidate-variant list for one intent: the intent's
`allowed_variant_ids`, plus the **fallback pool** (catalog variants flagged
`is_fallback: true`) appended when the intent has
`<= _VARIANT_FALLBACK_THRESHOLD` primary variants — so thin / single-variant
intents still hand the block matcher real structural alternatives instead of a
forced single option.

Two DISTINCT fallback mechanisms — do not conflate:
  - **is_fallback pool** (this file): catalog-flagged generic variants appended
    to THIN intents' candidate sets so the matcher has alternatives.
  - **FALLBACK_VARIANT_ID** (`"single-bordered-bullet-box"`): the degraded floor
    component used when `intent_id == null`. A different mechanism, handled in
    the assemble/floor path, NOT here.

Marker convention (matches the original): pool-appended variants get a runtime
`_fallback: True`. The prompt context exposes this per-variant as `fallback`
(bool) plus a top-level `has_fallback`. The block_matching prompt must split its
"Fallback Variants" section on each variant's `fallback` flag — NOT on the
catalog `is_fallback` field (a variant can be both `is_fallback` AND an intent's
allowed primary, e.g. `three-column-titled-bullet-cards` for `scope-of-work`;
only the runtime `fallback` flag classifies it correctly for THIS intent).

CLI:
    python loaders.py candidates --catalog <catalog.json> --intent <intent_id>
    python loaders.py candidates --project <name> [--root <abs>] --intent <id>
    python loaders.py audit      --project <name> [--root <abs>]

`candidates` prints `{intent_id, has_fallback, variants:[{...variant, fallback}]}`
— exactly the block_matching prompt context. `audit` prints a per-intent summary
(allowed count, candidate count, fallback appended) for verification.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

# Append the is_fallback pool when an intent has at most this many primary
# (allowed) variants. The original uses 1 (single-variant intents only).
_VARIANT_FALLBACK_THRESHOLD = 1


def load_catalog(catalog_path: str | Path) -> dict[str, Any]:
    """Load and parse a design-system catalog.json. Fail-loud with the path."""
    p = Path(catalog_path)
    if not p.is_file():
        raise SystemExit(f"catalog not found: {p}")
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"catalog is invalid JSON at {p}: {exc}")


def catalog_path_for_project(project: str | None = None, root: str | Path = ".") -> Path:
    """Canonical catalog path: the shared design system at the repo root (`design-system/catalog.json`)"""
    return Path(root) / "design-system" / "catalog.json"


def get_intent_by_id(catalog: dict[str, Any], intent_id: str) -> dict[str, Any] | None:
    """Look up a single intent by id."""
    for i in catalog.get("intents", []):
        if i.get("id") == intent_id:
            return i
    return None


def get_variants_for_intent(catalog: dict[str, Any], intent_id: str) -> list[dict[str, Any]]:
    """Full variant entries for an intent's allowed_variant_ids, plus the
    fallback pool when the intent is thin.

    When the intent has <= ``_VARIANT_FALLBACK_THRESHOLD`` primary variants,
    catalog variants with ``is_fallback=true`` (and not already allowed) are
    appended, each marked ``_fallback: True``. Faithful port of the original.
    """
    intent = get_intent_by_id(catalog, intent_id)
    if not intent:
        return []
    allowed = set(intent.get("allowed_variant_ids", []))
    primary = [v for v in catalog.get("variants", []) if v.get("id") in allowed]
    if len(primary) <= _VARIANT_FALLBACK_THRESHOLD:
        fallback = [
            {**v, "_fallback": True}
            for v in catalog.get("variants", [])
            if v.get("is_fallback") and v.get("id") not in allowed
        ]
        return primary + fallback
    return primary


def prompt_context_for_intent(catalog: dict[str, Any], intent_id: str) -> dict[str, Any]:
    """block_matching prompt context: variants (each with a `fallback` bool) +
    `has_fallback`. Mirrors the original `_build_user_prompt` derivation:
    per-variant ``fallback = bool(_fallback marker)``, ``has_fallback = any``.
    The runtime `_fallback` marker is dropped from each variant in favor of the
    clean `fallback` field the prompt splits on.
    """
    variants = get_variants_for_intent(catalog, intent_id)
    out: list[dict[str, Any]] = []
    has_fallback = False
    for v in variants:
        fb = bool(v.get("_fallback"))
        has_fallback = has_fallback or fb
        clean = {k: val for k, val in v.items() if k != "_fallback"}
        clean["fallback"] = fb
        out.append(clean)
    return {"intent_id": intent_id, "has_fallback": has_fallback, "variants": out}


# ── Catalog query helpers (ported from the original contrl loaders.py) ───────
# Used by the deterministic S5 scripts (layout_fills / cover_toc / assemble) and
# by the per-slide subagent to build prompt context. All dict-based, stdlib-only
# — the catalog carries slots/placeholders/affinity inline, so no shapes.xml.

def get_intents_for_prompt(catalog: dict[str, Any]) -> list[dict[str, str]]:
    """intent id/name/description for the intent_matching prompt context."""
    return [
        {"id": i["id"], "name": i.get("name", i["id"]), "description": i.get("description", "")}
        for i in catalog.get("intents", [])
        if i.get("id")
    ]


def get_layout_by_id(catalog: dict[str, Any], layout_id: str) -> dict[str, Any] | None:
    """Look up a layout by id."""
    for layout in catalog.get("layouts", []):
        if layout.get("id") == layout_id:
            return layout
    return None


def get_adornments(catalog: dict[str, Any]) -> list[dict[str, Any]]:
    """All adornments (block_matching adornment candidates)."""
    return catalog.get("adornments", [])


def get_layout_affinity(catalog: dict[str, Any], intent_id: str | None) -> list[dict[str, Any]]:
    """The layout_affinity list for an intent. Empty for a null intent."""
    if not intent_id:
        return []
    intent = get_intent_by_id(catalog, intent_id)
    if not intent:
        return []
    return intent.get("layout_affinity", [])


def get_section_path(
    section_tree: list[dict[str, Any]], section_id: str,
) -> list[dict[str, Any]]:
    """The section + its ancestors from the tree, root-first.

    A slide's section_id may carry a split suffix (``sec_0001-1``) absent from the
    RFP tree (``sec_0001``); when an exact match is missing and the id contains a
    ``-``, retry against the parent id. Faithful port of the original.
    """
    level_stack: dict[int, dict[str, Any]] = {}
    for section in section_tree:
        level = section.get("level", 1)
        level_stack[level] = {
            "section_id": section["section_id"],
            "title": section["title"],
            "level": level,
        }
        for deeper in [k for k in level_stack if k > level]:
            del level_stack[deeper]

        if section["section_id"] == section_id:
            return [level_stack[lvl] for lvl in sorted(level_stack)]

    if "-" in section_id:
        return get_section_path(section_tree, section_id.rsplit("-", 1)[0])

    return []


def get_section_metadata(
    section_tree: list[dict[str, Any]], section_id: str,
) -> dict[str, str]:
    """Derive ``breadcrumb`` + ``section_path`` (leaf title) for layout fills."""
    path = get_section_path(section_tree, section_id)
    if not path:
        return {"breadcrumb": "", "section_path": ""}
    return {
        "breadcrumb": " > ".join(s["title"] for s in path[:-1]) if len(path) > 1 else "",
        "section_path": path[-1]["title"],
    }


def catalog_sha256(catalog_path: str | Path) -> str:
    """SHA-256 of the catalog.json bytes — stamped into ``slide_plan.json._meta``
    so S6's Stage-0 bundle check can abort on a catalog mismatch. ``""`` when the
    file is absent (the caller decides whether that is fatal)."""
    p = Path(catalog_path)
    if not p.is_file():
        return ""
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _resolve_catalog(args: argparse.Namespace) -> dict[str, Any]:
    if args.catalog:
        return load_catalog(args.catalog)
    if args.project:
        return load_catalog(catalog_path_for_project(args.project, args.root))
    raise SystemExit("provide --catalog <path> or --project <name>")


def _cmd_candidates(args: argparse.Namespace) -> None:
    """block_matching context for one intent: variants (with `fallback` flag) +
    has_fallback + the full adornment list — everything step 3 needs."""
    catalog = _resolve_catalog(args)
    ctx = prompt_context_for_intent(catalog, args.intent)
    ctx["adornments"] = [
        {"id": a.get("id"), "note": a.get("note", ""), "slots": a.get("slots", [])}
        for a in get_adornments(catalog)
    ]
    print(json.dumps(ctx, ensure_ascii=False, indent=2))


def _cmd_intents(args: argparse.Namespace) -> None:
    """intent_matching context: id/name/description for every catalog intent."""
    catalog = _resolve_catalog(args)
    print(json.dumps({"intents": get_intents_for_prompt(catalog)}, ensure_ascii=False, indent=2))


def _cmd_layouts(args: argparse.Namespace) -> None:
    """layout_matching context: the full layout list + (with --intent) that
    intent's layout_affinity. Subagent derives slide_type + section_path itself."""
    catalog = _resolve_catalog(args)
    layouts = [
        {
            "id": layout.get("id"),
            "note": layout.get("note", ""),
            "furniture_roles": layout.get("furniture_roles", []),
            "placeholders": [p.get("name") for p in (layout.get("placeholders") or []) if p.get("name")],
        }
        for layout in catalog.get("layouts", [])
    ]
    out: dict[str, Any] = {"layouts": layouts}
    if args.intent:
        out["layout_affinity"] = get_layout_affinity(catalog, args.intent)
    print(json.dumps(out, ensure_ascii=False, indent=2))


def _cmd_audit(args: argparse.Namespace) -> None:
    catalog = _resolve_catalog(args)
    pool = [v.get("id") for v in catalog.get("variants", []) if v.get("is_fallback")]
    print(f"fallback pool ({len(pool)}): {pool}")
    print(f"threshold (append pool when allowed primaries <= {_VARIANT_FALLBACK_THRESHOLD})")
    print(f"{'intent':30}{'allowed':>8}{'cands':>7}{'+fb':>5}{'has_fb':>8}")
    for i in catalog.get("intents", []):
        iid = i.get("id", "?")
        n_allowed = len(i.get("allowed_variant_ids", []))
        ctx = prompt_context_for_intent(catalog, iid)
        n_fb = sum(1 for v in ctx["variants"] if v["fallback"])
        print(f"{iid:30}{n_allowed:>8}{len(ctx['variants']):>7}{n_fb:>5}{str(ctx['has_fallback']):>8}")


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="S5 candidate-variant assembly")
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("candidates", "audit", "intents", "layouts"):
        sp = sub.add_parser(name)
        sp.add_argument("--catalog", help="path to catalog.json")
        sp.add_argument("--project", help="project name under projects/")
        sp.add_argument("--root", default=".", help="repo root (for --project)")
        if name == "candidates":
            sp.add_argument("--intent", required=True)
        if name == "layouts":
            sp.add_argument("--intent", help="include this intent's layout_affinity")
    args = p.parse_args(argv)
    {
        "candidates": _cmd_candidates,
        "audit": _cmd_audit,
        "intents": _cmd_intents,
        "layouts": _cmd_layouts,
    }[args.cmd](args)


if __name__ == "__main__":
    main()
