#!/usr/bin/env python3
"""S5 layout mapping — the MECHANICAL fills of step 5 (no LLM).

Faithful port of the deterministic half of the original contrl
`steps/layout_mapping.py::map_layout` (`_fill_adornments`,
`_fill_layout_mechanical`, `_get_chapter_label`, `_get_requirement`,
`_layout_has_proposal_body`). Stdlib-only; dict-based catalog.

This runs AFTER the per-slide agent has decided `layout_id` and each block's
`adornment_id` (steps 1–4). Its `--slide` input is therefore the in-progress
DECISION record — not the raw flattened slide — carrying:
    {index, source, subtitle, section_id, layout_id, blocks:[{heading, adornment_id}]}

It returns the mechanical text fills only:
    layout_fills              — page_title / chapter_label / section_breadcrumb /
                                requirement_* / title / subtitle / page_number …,
                                one per layout placeholder EXCEPT proposal_body.
    adornment_fills_by_block  — {block_index: [{slot:"title", value:heading}]} for
                                each block that has an adornment_id (heading→title).
    needs_proposal_body       — True iff the layout declares a proposal_body
                                placeholder AND the slide's section has a theme
                                statement (the LLM anchor). The agent fills the
                                proposal_body itself and merges it into layout_fills
                                as {slot:"proposal_body", value:...} (audit §5).
    theme_statement           — that section's statement text (the proposal_body
                                anchor), or "".

CLI:
    python layout_fills.py --slide <decision_so_far.json> --rfp <rfp.json>
        (--catalog <catalog.json> | --project <name> [--root <abs>])
        [--theme-statements <theme_statements.json>] [--out <path>]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import loaders


def _fill_adornments(blocks: list[dict[str, Any]]) -> dict[str, list[dict[str, str]]]:
    """Mechanical: heading → adornment `title` slot, per block that has an
    adornment. Keyed by string block index (JSON-object keys are strings)."""
    result: dict[str, list[dict[str, str]]] = {}
    for i, block in enumerate(blocks):
        if block.get("adornment_id"):
            result[str(i)] = [{"slot": "title", "value": block.get("heading", "")}]
    return result


def _get_chapter_label(section_tree: list[dict[str, Any]], section_id: str) -> str:
    """Level-1 ancestor title (e.g. 'III. 제안 내용')."""
    path = loaders.get_section_path(section_tree, section_id)
    return path[0]["title"] if path else ""


def _get_requirement(
    requirements: list[dict[str, Any]], requirement_id: str
) -> dict[str, Any] | None:
    for r in requirements:
        if r.get("id") == requirement_id:
            return r
    return None


def _fill_layout_mechanical(
    slide: dict[str, Any],
    layout_id: str | None,
    catalog: dict[str, Any],
    section_tree: list[dict[str, Any]],
    section_id: str,
    requirements: list[dict[str, Any]],
) -> list[dict[str, str]]:
    """Mechanical layout fills for the layout's text placeholders (sans
    proposal_body). One fill per declared placeholder; unknown names → ""."""
    if not layout_id:
        return []
    layout = loaders.get_layout_by_id(catalog, layout_id)
    if not layout or not layout.get("placeholders"):
        return []

    metadata = loaders.get_section_metadata(section_tree, section_id)
    chapter_label = _get_chapter_label(section_tree, section_id)

    requirement_id = slide.get("source", "")
    requirement = (
        _get_requirement(requirements, requirement_id)
        if requirement_id != "section" else None
    )

    breadcrumb = metadata.get("breadcrumb", "")
    section_path = metadata.get("section_path", "")

    value_map: dict[str, str] = {
        "page_title": slide.get("subtitle", ""),
        "chapter_label": chapter_label,
        "section_breadcrumb": f"{breadcrumb} > {section_path}" if breadcrumb else section_path,
        "requirement_name": slide.get("subtitle", "") if requirement else "",
        "requirement_detail": requirement.get("summary", "") if requirement else "",
        "rfp_requirement_ref": requirement.get("rfp_reference", "") if requirement else "",
        "title": slide.get("subtitle", ""),
        "subtitle": section_path,
        "page_number": "slidenum",
    }

    fills: list[dict[str, str]] = []
    for placeholder in layout["placeholders"]:
        name = placeholder.get("name")
        if not name or name == "proposal_body":
            continue
        fills.append({"slot": name, "value": value_map.get(name, "")})
    return fills


def _layout_has_proposal_body(layout_id: str | None, catalog: dict[str, Any]) -> bool:
    if not layout_id:
        return False
    layout = loaders.get_layout_by_id(catalog, layout_id)
    if not layout:
        return False
    return any(p.get("name") == "proposal_body" for p in layout.get("placeholders", []))


def compute_layout_fills(
    slide: dict[str, Any],
    catalog: dict[str, Any],
    rfp: dict[str, Any],
    theme_statements: dict[str, Any] | None,
) -> dict[str, Any]:
    """The deterministic step-5 output for one slide. Pure."""
    section_tree = rfp.get("required_proposal_structure", {}).get("sections", []) or []
    requirements = rfp.get("requirements", []) or []
    section_id = slide.get("section_id") or ""
    layout_id = slide.get("layout_id")
    blocks = slide.get("blocks", []) or []

    layout_fills = _fill_layout_mechanical(
        slide, layout_id, catalog, section_tree, section_id, requirements
    )
    adornment_fills_by_block = _fill_adornments(blocks)

    statement = ""
    if theme_statements:
        for item in theme_statements.get("items", []) or []:
            if item.get("section_id") == section_id:
                statement = item.get("statement", "") or ""
                break

    needs_proposal_body = _layout_has_proposal_body(layout_id, catalog) and bool(statement)

    return {
        "layout_id": layout_id,
        "layout_fills": layout_fills,
        "adornment_fills_by_block": adornment_fills_by_block,
        "needs_proposal_body": needs_proposal_body,
        "theme_statement": statement,
    }


def _resolve_catalog(args: argparse.Namespace) -> dict[str, Any]:
    if args.catalog:
        return loaders.load_catalog(args.catalog)
    if args.project:
        return loaders.load_catalog(loaders.catalog_path_for_project(args.project, args.root))
    raise SystemExit("provide --catalog <path> or --project <name>")


def _load_json(path: str, what: str) -> dict[str, Any]:
    p = Path(path)
    if not p.is_file():
        raise SystemExit(f"{what} not found: {p}")
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"{what} is invalid JSON at {p}: {exc}")


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="S5 mechanical layout/adornment fills")
    p.add_argument("--slide", required=True, help="in-progress DECISION record JSON")
    p.add_argument("--rfp", required=True, help="rfp.json (section_tree + requirements)")
    p.add_argument("--catalog", help="path to catalog.json")
    p.add_argument("--project", help="project name under projects/")
    p.add_argument("--root", default=".", help="repo root (for --project)")
    p.add_argument("--theme-statements", dest="theme_statements", help="theme_statements.json")
    p.add_argument("--out", help="write output JSON here (default: stdout)")
    args = p.parse_args(argv)

    catalog = _resolve_catalog(args)
    slide = _load_json(args.slide, "slide")
    rfp = _load_json(args.rfp, "rfp")
    ts = _load_json(args.theme_statements, "theme_statements") if args.theme_statements else None

    out = compute_layout_fills(slide, catalog, rfp, ts)
    payload = json.dumps(out, ensure_ascii=False, indent=2)
    if args.out:
        Path(args.out).write_text(payload, encoding="utf-8")
        print(f"wrote {args.out}")
    else:
        print(payload)


if __name__ == "__main__":
    main()