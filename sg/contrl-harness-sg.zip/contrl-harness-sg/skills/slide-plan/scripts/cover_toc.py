#!/usr/bin/env python3
"""S5 cover / table-of-contents as slide_plan entries — deterministic (no LLM).

Faithful port of the original contrl `cover_toc.py`
(`backend/services/slide_plan/cover_toc.py`), with the pydantic
Slide/Block/Component/SlotFill/RepeatingSlotFill models emitted as plain dicts
(the harness artifact shape). Stdlib-only; dict-based catalog.

Cover and TOC are real `Slide` plan entries (not post-compose OOXML): intent_id
pinned to `cover` / `table-of-contents`, a single block carrying the authored
variant + standard-slot fills, so the renderer treats them like any other slide.
Each may be skipped independently (no authored variant / no standard slots / no
chapters) — a cover-only, TOC-only, or neither deck is handled naturally.
`toc_pages` is resolved from the flatten order when `--input-slides` is given —
each chapter's first slide number = front_matter_count + first flatten index + 1
(the pipeline's own numbering) — and left blank otherwise (pre-pipeline behaviour).
`slide_number` is assigned later at assemble.

CLI:
    python cover_toc.py --rfp <rfp.json>
        (--catalog <catalog.json> | --project <name> [--root <abs>])
        [--project-name <str>] [--bidder <str>] [--date <str>]
        [--subtitle <str>] [--tagline <str>] [--out <path>]

Emits `{cover: bool, toc: bool, slides: [<cover?>, <toc?>]}` — the `slides`
array is what assemble prepends as front matter. `--project-name` defaults to
the RFP `project_overview.project_name`.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

import loaders


def _warn(msg: str) -> None:
    print(msg, file=sys.stderr)


# ── Standard slot vocabulary (cover-toc spec §5) ─────────────────────────────
COVER_TITLE = "cover_title"
COVER_SUBTITLE = "cover_subtitle"
COVER_TAGLINE = "cover_tagline"
COVER_BIDDER = "cover_bidder"
COVER_DATE = "cover_date"

TOC_SECTION_TITLE = "toc_section_title"
TOC_SECTION_MARKER = "toc_section_marker"
TOC_ENTRIES = "toc_entries"
TOC_PAGES = "toc_pages"

_NAV_RE = re.compile(r"^toc_nav_(\d+)$")
_COVER_TITLE_FALLBACK = "Proposal"

_STANDARD_COVER = {COVER_TITLE, COVER_SUBTITLE, COVER_TAGLINE, COVER_BIDDER, COVER_DATE}
_STANDARD_TOC_FLAT = {TOC_SECTION_TITLE, TOC_SECTION_MARKER, TOC_ENTRIES, TOC_PAGES}
_STANDARD_TOC_SUB = {TOC_SECTION_MARKER, TOC_SECTION_TITLE, TOC_ENTRIES, TOC_PAGES}

COVER_INTENT = "cover"
TOC_INTENT = "table-of-contents"

_ROMAN = [(10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]


# ── Dict builders (the harness artifact Slide shape) ─────────────────────────
def _slot_fill(slot: str, value: str) -> dict[str, str]:
    return {"slot": slot, "value": value}


def _repeating_fill(slot: str, rows: list[dict[str, str]]) -> dict[str, Any]:
    return {"slot": slot, "rows": rows}


def _component(
    variant_id: str,
    fills: list[dict[str, str]] | None = None,
    repeating_fills: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    return {
        "variant_id": variant_id,
        "fills": fills or [],
        "repeating_fills": repeating_fills or [],
    }


def _slide(*, source: str, subtitle: str, intent_id: str, layout_id: str | None,
           component: dict[str, Any]) -> dict[str, Any]:
    return {
        "slide_number": None,
        "source": source,
        "subtitle": subtitle,
        "section_id": None,
        "intent_id": intent_id,
        "layout_id": layout_id,
        "layout_fills": [],
        "blocks": [{
            "heading": "",
            "adornment_id": None,
            "adornment_fills": [],
            "components": [component],
        }],
    }


# ── Small helpers ────────────────────────────────────────────────────────────
def _roman(n: int) -> str:
    if n <= 0 or n > 39:
        return str(n)
    out, rem = [], n
    for val, sym in _ROMAN:
        while rem >= val:
            out.append(sym)
            rem -= val
    return "".join(out)


def _strip_enumerator(title: str) -> str:
    """Drop a leading number token — navigator boxes draw their own (01..)."""
    return re.sub(r"^\s*([IVXLCDM]+|\d+)\s*[.)]\s*", "", title or "").strip()


# ── Catalog (dict form) helpers ──────────────────────────────────────────────
def _intent(catalog: dict[str, Any], intent_id: str) -> dict[str, Any] | None:
    for i in catalog.get("intents", []):
        if i.get("id") == intent_id:
            return i
    return None


def _intent_pin(catalog: dict[str, Any], intent_id: str) -> tuple[list[str], str | None]:
    """(allowed_variant_ids present in catalog, layout_affinity[0].layout_id)."""
    intent = _intent(catalog, intent_id) or {}
    variant_ids = {v.get("id") for v in catalog.get("variants", [])}
    allowed = [v for v in (intent.get("allowed_variant_ids") or []) if v in variant_ids]
    affinity = intent.get("layout_affinity") or []
    layout_id = affinity[0].get("layout_id") if affinity else None
    return allowed, layout_id


def _variant_slots(catalog: dict[str, Any], vid: str) -> list[dict[str, Any]]:
    for v in catalog.get("variants", []):
        if v.get("id") == vid:
            return v.get("slots", []) or []
    return []


def _slot_names(catalog: dict[str, Any], vid: str) -> set[str]:
    return {s.get("name") for s in _variant_slots(catalog, vid)}


def _repeated_toc_slot(catalog: dict[str, Any], vid: str) -> dict[str, Any] | None:
    """A resizable repeated slot whose subslots carry standard TOC roles."""
    for s in _variant_slots(catalog, vid):
        if (s.get("cardinality") or {}).get("resizable") and s.get("subslots"):
            sub_names = {x.get("name") for x in s["subslots"]}
            if sub_names & _STANDARD_TOC_SUB:
                return s
    return None


def _has_standard_cover_slot(names: set[str]) -> bool:
    return bool(names & _STANDARD_COVER)


def _has_standard_toc_slot(catalog: dict[str, Any], vid: str) -> bool:
    names = _slot_names(catalog, vid)
    return (
        bool(names & _STANDARD_TOC_FLAT)
        or any(n and _NAV_RE.match(n) for n in names)
        or _repeated_toc_slot(catalog, vid) is not None
    )


# ── Section tree helpers ─────────────────────────────────────────────────────
def _chapters(section_tree: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Top-level chapters (level-1 sections), in tree order."""
    return [s for s in section_tree if s.get("level", 1) == 1]


# ── Cover ────────────────────────────────────────────────────────────────────
def build_cover_entry(catalog: dict[str, Any], ctx: "CoverTocContext") -> dict[str, Any] | None:
    """The cover Slide plan entry, or None (skip + warn). Only standard cover_*
    slots are filled; skipped when the intent has no authored/standard variant."""
    allowed, layout_id = _intent_pin(catalog, COVER_INTENT)
    if not allowed:
        _warn("cover intent has no authored variant; skipping cover entry")
        return None
    vid = allowed[0]
    names = _slot_names(catalog, vid)
    if not _has_standard_cover_slot(names):
        _warn(f"cover variant {vid!r} has no standard cover_* slots; skipping cover entry")
        return None

    title = (ctx.project_name or "").strip() or _COVER_TITLE_FALLBACK
    if not (ctx.project_name or "").strip():
        _warn(f"cover_title source project_name is empty; using fallback {_COVER_TITLE_FALLBACK!r}")
    candidates = {
        COVER_TITLE: title,
        COVER_SUBTITLE: ctx.subtitle,
        COVER_TAGLINE: ctx.tagline,
        COVER_BIDDER: ctx.bidder,
        COVER_DATE: ctx.date,
    }
    fills = [_slot_fill(n, v) for n, v in candidates.items() if n in names and v]
    if COVER_TITLE not in names:
        _warn(f"cover variant {vid!r} has no {COVER_TITLE} slot; title is not filled")

    return _slide(source="cover", subtitle=title, intent_id=COVER_INTENT,
                  layout_id=layout_id, component=_component(vid, fills=fills))


# ── Table of contents ────────────────────────────────────────────────────────
def _pick_toc_variant(catalog: dict[str, Any], n_chapters: int) -> tuple[str | None, str | None]:
    """Choose a TOC variant by chapter count: navigator if chapters fit its fixed
    boxes, else a list/repeated variant; never a silent cap."""
    allowed, layout_id = _intent_pin(catalog, TOC_INTENT)
    if not allowed:
        return None, None
    navs: list[tuple[str, int]] = []
    lists: list[str] = []
    for vid in allowed:
        cap = sum(1 for n in _slot_names(catalog, vid) if n and _NAV_RE.match(n))
        if cap:
            navs.append((vid, cap))
        else:
            lists.append(vid)
    for vid, cap in navs:
        if n_chapters <= cap:
            return vid, layout_id
    if lists:
        return lists[0], layout_id
    if navs:
        vid, cap = max(navs, key=lambda x: x[1])
        _warn(f"TOC chapter count {n_chapters} exceeds navigator capacity {cap}; no list variant, so {vid!r} will show only {cap} entries")
        return vid, layout_id
    return None, None


def _toc_single_fills(catalog: dict[str, Any], vid: str, chapters: list[dict[str, Any]],
                      pages: dict[str, str]) -> list[dict[str, str]]:
    """Single-value TOC slot fills (positional navigator + flat section slots).
    `pages` maps chapter section_id → resolved page number (empty when unresolved)."""
    names = _slot_names(catalog, vid)
    fills: list[dict[str, str]] = []
    nav_caps = sorted(int(_NAV_RE.match(n).group(1)) for n in names if n and _NAV_RE.match(n))
    for pos in nav_caps:
        label = _strip_enumerator(chapters[pos - 1]["title"]) if pos - 1 < len(chapters) else ""
        fills.append(_slot_fill(f"toc_nav_{pos}", label))
    if TOC_SECTION_TITLE in names and chapters:
        fills.append(_slot_fill(TOC_SECTION_TITLE, chapters[0]["title"]))
    if TOC_SECTION_MARKER in names and chapters:
        fills.append(_slot_fill(TOC_SECTION_MARKER, "01"))
    if TOC_PAGES in names and any(pages.get(c.get("section_id", "")) for c in chapters):
        fills.append(_slot_fill(TOC_PAGES, "\n".join(pages.get(c.get("section_id", ""), "") for c in chapters)))
    return fills


def _toc_repeated_rows(rep_slot: dict[str, Any], chapters: list[dict[str, Any]],
                       pages: dict[str, str]) -> list[dict[str, str]]:
    """Rows for a repeated TOC slot (one unit per chapter). `pages` maps chapter
    section_id → resolved page number; blank when unresolved (no flatten input)."""
    subs = {s.get("name") for s in (rep_slot.get("subslots") or [])}
    rows: list[dict[str, str]] = []
    for i, c in enumerate(chapters):
        title = _strip_enumerator(c["title"])
        row: dict[str, str] = {}
        if TOC_SECTION_MARKER in subs:
            row[TOC_SECTION_MARKER] = _roman(i + 1)
        if TOC_SECTION_TITLE in subs:
            row[TOC_SECTION_TITLE] = title
        if TOC_ENTRIES in subs:
            row[TOC_ENTRIES] = title
        if TOC_PAGES in subs:
            row[TOC_PAGES] = pages.get(c.get("section_id", ""), "")
        rows.append(row)
    return rows


def _resolve_chapter_pages(
    section_tree: list[dict[str, Any]],
    input_slides: list[dict[str, Any]] | None,
    front_matter_count: int,
) -> dict[str, str]:
    """chapter (level-1 section_id) → first body slide's absolute number, as a string.

    A body slide belongs to the chapter that is the level-1 ancestor of its
    `section_id` (split suffixes like `sec_0001-1` handled by
    `loaders.get_section_path`). A chapter's first slide = lowest flatten index
    among its slides; its absolute number = `front_matter_count + index + 1`
    (the same numbering the pipeline assigns). `{}` when no flatten input is given
    — then pages stay blank (the pre-pipeline behaviour)."""
    if not input_slides:
        return {}
    first_idx: dict[str, int] = {}
    for s in input_slides:
        sid, idx = s.get("section_id"), s.get("index")
        if sid is None or idx is None:
            continue
        path = loaders.get_section_path(section_tree, sid)
        if not path:
            continue
        chapter = path[0]["section_id"]
        if chapter not in first_idx or idx < first_idx[chapter]:
            first_idx[chapter] = idx
    return {ch: str(front_matter_count + i + 1) for ch, i in first_idx.items()}


def build_toc_entry(catalog: dict[str, Any], ctx: "CoverTocContext",
                    pages: dict[str, str] | None = None) -> dict[str, Any] | None:
    """The table-of-contents Slide plan entry, or None (skip + warn). Chapters =
    level-1 sections of the RFP section_tree. `pages` (chapter section_id → page)
    fills `toc_pages` when resolved up front from the flatten order; blank otherwise."""
    pages = pages or {}
    chapters = _chapters(ctx.section_tree)
    if not chapters:
        _warn("section_tree has no top-level chapters (level 1); skipping TOC entry")
        return None
    vid, layout_id = _pick_toc_variant(catalog, len(chapters))
    if not vid:
        _warn("table-of-contents intent has no authored variant; skipping TOC entry")
        return None
    if not _has_standard_toc_slot(catalog, vid):
        _warn(f"TOC variant {vid!r} has no standard toc slots; skipping TOC entry")
        return None

    rep_slot = _repeated_toc_slot(catalog, vid)
    if rep_slot is not None:
        base = (rep_slot.get("cardinality") or {}).get("base")
        if isinstance(base, int) and len(chapters) > base:
            _warn(f"TOC repeated variant {vid!r}: chapter count {len(chapters)} exceeds base {base}; extra-unit filling may be imprecise")
        rows = _toc_repeated_rows(rep_slot, chapters, pages)
        component = _component(vid, repeating_fills=[_repeating_fill(rep_slot["name"], rows)])
    else:
        fills = _toc_single_fills(catalog, vid, chapters, pages)
        names = _slot_names(catalog, vid)
        if TOC_ENTRIES in names:
            fills.append(_slot_fill(TOC_ENTRIES, "\n".join(c["title"] for c in chapters)))
        component = _component(vid, fills=fills)

    return _slide(source="table-of-contents", subtitle="Table of Contents", intent_id=TOC_INTENT,
                  layout_id=layout_id, component=component)


# ── Public entry ─────────────────────────────────────────────────────────────
class CoverTocContext:
    """Values for deterministic cover/TOC fills. project_name ← project_overview,
    bidder ← bidder company, section_tree ← RFP required_proposal_structure."""

    def __init__(self, *, project_name: str = "", bidder: str = "", subtitle: str = "",
                 tagline: str = "", date: str = "",
                 section_tree: list[dict[str, Any]] | None = None) -> None:
        self.project_name = project_name
        self.bidder = bidder
        self.subtitle = subtitle
        self.tagline = tagline
        self.date = date
        self.section_tree = section_tree or []


def build_cover_toc_entries(catalog: dict[str, Any], ctx: CoverTocContext,
                            input_slides: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """`[cover?, table-of-contents?]` Slide plan entries to prepend. When
    `input_slides` (the flatten output) is given, TOC page numbers are resolved
    up front from the flatten order + the front_matter_count this run produces."""
    entries: list[dict[str, Any]] = []
    cover = build_cover_entry(catalog, ctx)
    if cover is not None:
        entries.append(cover)
    # front_matter_count for page resolution: the cover (if any) + this TOC (1).
    fmc = (1 if cover is not None else 0) + 1
    pages = _resolve_chapter_pages(ctx.section_tree, input_slides, fmc)
    toc = build_toc_entry(catalog, ctx, pages)
    if toc is not None:
        entries.append(toc)
    return entries


def _resolve_catalog(args: argparse.Namespace) -> dict[str, Any]:
    if args.catalog:
        return loaders.load_catalog(args.catalog)
    if args.project:
        return loaders.load_catalog(loaders.catalog_path_for_project(args.project, args.root))
    raise SystemExit("provide --catalog <path> or --project <name>")


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="S5 cover/TOC front-matter entries")
    p.add_argument("--rfp", required=True, help="rfp.json (section_tree + project_overview)")
    p.add_argument("--catalog", help="path to catalog.json")
    p.add_argument("--project", help="project name under projects/")
    p.add_argument("--root", default=".", help="repo root (for --project)")
    p.add_argument("--project-name", dest="project_name", help="cover title (default: RFP project_overview.project_name)")
    p.add_argument("--bidder", default="", help="cover_bidder")
    p.add_argument("--date", default="", help="cover_date")
    p.add_argument("--subtitle", default="", help="cover_subtitle")
    p.add_argument("--tagline", default="", help="cover_tagline")
    p.add_argument("--input-slides", dest="input_slides",
                   help="flatten output JSON — when given, resolve TOC page numbers up front")
    p.add_argument("--out", help="write output JSON here (default: stdout)")
    args = p.parse_args(argv)

    catalog = _resolve_catalog(args)
    rfp_p = Path(args.rfp)
    if not rfp_p.is_file():
        raise SystemExit(f"rfp not found: {rfp_p}")
    rfp = json.loads(rfp_p.read_text(encoding="utf-8"))

    section_tree = rfp.get("required_proposal_structure", {}).get("sections", []) or []
    project_name = args.project_name
    if project_name is None:
        project_name = (rfp.get("project_overview", {}) or {}).get("project_name", "") or ""

    input_slides = None
    if args.input_slides:
        fp = Path(args.input_slides)
        if not fp.is_file():
            raise SystemExit(f"input-slides not found: {fp}")
        loaded = json.loads(fp.read_text(encoding="utf-8"))
        input_slides = loaded.get("slides") if isinstance(loaded, dict) else loaded

    ctx = CoverTocContext(
        project_name=project_name, bidder=args.bidder, subtitle=args.subtitle,
        tagline=args.tagline, date=args.date, section_tree=section_tree,
    )
    entries = build_cover_toc_entries(catalog, ctx, input_slides)
    out = {
        "cover": any(s["intent_id"] == COVER_INTENT for s in entries),
        "toc": any(s["intent_id"] == TOC_INTENT for s in entries),
        "front_matter_count": len(entries),
        "toc_pages_resolved": input_slides is not None,
        "slides": entries,
    }
    payload = json.dumps(out, ensure_ascii=False, indent=2)
    if args.out:
        Path(args.out).write_text(payload, encoding="utf-8")
        print(f"wrote {args.out}: cover={out['cover']} toc={out['toc']}")
    else:
        print(payload)


if __name__ == "__main__":
    main()
