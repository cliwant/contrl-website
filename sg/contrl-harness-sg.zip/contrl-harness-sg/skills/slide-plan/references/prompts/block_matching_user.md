{% if has_fallback %}
{% if variants | rejectattr('fallback') | list %}
## Intent Variants

These variants are designed for this slide's intent. Prefer these when they fit the content structure.

{% for variant in variants if not variant.fallback %}
### {{ variant.id }}
- Name: {{ variant.name }}
- Description: {{ variant.description }}
- Slots:
{% for slot in variant.slots %}
  - `{{ slot.name }}` ({{ slot.kind }}){% if slot.get('cardinality') %} [min:{{ slot.cardinality.min }}, max:{{ slot.cardinality.max }}]{% endif %}{% if slot.get('description') %} — {{ slot.description }}{% endif %}

{% endfor %}
{% endfor %}
{% endif %}

## Fallback Variants

Generic alternatives. Use only when the intent variants above don't match the content structure.

{% for variant in variants if variant.fallback %}
### {{ variant.id }}
- Name: {{ variant.name }}
- Description: {{ variant.description }}
- Slots:
{% for slot in variant.slots %}
  - `{{ slot.name }}` ({{ slot.kind }}){% if slot.get('cardinality') %} [min:{{ slot.cardinality.min }}, max:{{ slot.cardinality.max }}]{% endif %}{% if slot.get('description') %} — {{ slot.description }}{% endif %}

{% endfor %}
{% endfor %}
{% else %}
## Available Variants

{% for variant in variants %}
### {{ variant.id }}
- Name: {{ variant.name }}
- Description: {{ variant.description }}
- Slots:
{% for slot in variant.slots %}
  - `{{ slot.name }}` ({{ slot.kind }}){% if slot.get('cardinality') %} [min:{{ slot.cardinality.min }}, max:{{ slot.cardinality.max }}]{% endif %}{% if slot.get('description') %} — {{ slot.description }}{% endif %}

{% endfor %}
{% endfor %}
{% endif %}

## Available Adornments

{% for adornment in adornments %}
### {{ adornment.id }}
- Description: {{ adornment.note }}
- Slots: {% for s in adornment.slots %}{{ s.name }} ({{ s.kind }}){% if not loop.last %}, {% endif %}{% endfor %}

{% endfor %}

## Slide Blocks

```json
{{ blocks_json }}
```

## Output schema

For each block, assign an `adornment_id` and a `components` array. Each component has `variant_id` and `content` (bullets from the block).

```json
[
  {
    "heading": "<same as input>",
    "body": ["<same as input>"],
    "adornment_id": "<selected adornment id>",
    "components": [
      {
        "variant_id": "<selected variant id>",
        "content": ["bullet 1", "bullet 2"]
      }
    ]
  }
]
```