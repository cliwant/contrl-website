## Slide to Match

```json
{{ slide_json }}
```

## Output schema

```json
{
  "intent_id": "<best matching intent id, or null>"
}
```