## Theme Statement

{{ theme_statement }}

## Slide Content Summary

Subtitle: {{ subtitle }}

{% for block in blocks %}
### {{ block.heading }}
{% for comp in block.components %}
Variant: {{ comp.variant_id }}
{% for fill in comp.fills %}
- {{ fill.slot }}: {{ fill.value | default("(image)", true) }}
{% endfor %}
{% endfor %}
{% endfor %}

## Output schema

```json
{
  "proposal_body": "<1-2 sentence framing paragraph in English>"
}
```
