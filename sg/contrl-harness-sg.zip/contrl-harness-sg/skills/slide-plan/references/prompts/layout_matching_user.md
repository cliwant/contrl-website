## Slide Type

{{ slide_type }}

## Proposal Structure

{% for section in section_path %}
- Level {{ section.level }}: {{ section.title }}
{% endfor %}

{% if layout_affinity %}
## Layout Affinity (from design system)

{% for a in layout_affinity %}
- {{ a.layout_id }} (frequency: {{ a.frequency }})
{% endfor %}
{% endif %}

## Output schema

```json
{
  "layout_id": "<selected layout id>"
}
```