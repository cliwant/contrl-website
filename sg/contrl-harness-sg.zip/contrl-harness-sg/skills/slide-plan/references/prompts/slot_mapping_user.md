## Source Content

```json
{{ content_json }}
```

## Variant Slot Schema

```json
{{ slots_json }}
```

## Output schema

```json
{
  "fills": [
    { "slot": "<slot name or dot-path>", "value": "<adapted text>" }
  ],
  "repeating_fills": [
    {
      "slot": "<repeated/table slot name>",
      "rows": [
        { "<subslot_name>": "<value>", "<subslot_name>": "<value>" }
      ]
    }
  ]
}
```

For image slots, use:
```json
{ "slot": "<image slot name>", "value": "" }
```

For a `richtext` slot, you may add inline emphasis with `**bold**` on a few key terms (no colors); use `\n` for paragraphs:
```json
{ "slot": "<richtext slot name>", "value": "Achieved **30% performance improvement**\nExpanded into a core initiative" }
```
A richtext slot with no emphasis is perfectly normal — emphasis is optional, not the default:
```json
{ "slot": "<richtext slot name>", "value": "Ensures stable operations through a proven delivery framework" }
```
