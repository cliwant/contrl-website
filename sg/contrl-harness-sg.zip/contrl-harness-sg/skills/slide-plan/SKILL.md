---
name: slide-plan
description: >-
  CONTRL pipeline S5 — Slide Plan. Plans every slide in slide_contents.json against the design-system catalog through intent → layout → block → slot → layout-fill matching, then adds cover/TOC and fallback floor slides to produce render-ready slide_plan.json.
  Use for slide planning, intent/layout/variant matching, slide_plan.json generation, or S5 execution. S6 Render consumes this artifact.
---

# S5 — Slide Plan (슬라이드 플래닝)

## Customer Delivery Defaults

Generate all proposal-body text, slot fills, labels, cover/TOC text, and diagnostics copy in English. Translate Korean or other non-English slide content into natural business English before writing `slide_plan.json`.

`slide_contents.json`의 슬라이드 하나하나를 **자기 콘텐츠 + 공유 컨텍스트만으로**
(절대 인덱스/타 슬라이드 의존 없이) design-system catalog에 매칭한다. 섹션 단위로
격리 플래닝 가능. 결과는 렌더 준비 완료 `slide_plan.json` — **결정(decision)만 담고
소스 데이터는 담지 않는다.**

> **실행 규율 (load-bearing).** S5의 **LLM 결정 단계**(intent·layout·block_matching·proposal_body)는 슬라이드마다 그 step의 프롬프트(`references/prompts/{step}_{system,user}.md`)를 **그 슬라이드 입력에 실제로 적용해** 내린 결정이어야 한다 — block_matching의 variant·adornment는 `loaders.py candidates` 후보를 그 슬라이드 콘텐츠로 보고 고른 프롬프트 출력이다.
> **왜 중요한가.** 이 결정을 상수 표(`DECISIONS[index]`·intent당 canonical 등)·builder 스크립트·block_count/slot-shape 류 heuristic으로 대신하면 모든 슬라이드가 같은 variant로 평탄화된다(collapse) — 바로 이 스킬이 막으려는 실패 모드다. 그래서 결정은 표가 아니라 그 슬라이드에 실제 적용한 프롬프트 출력이어야 하고, variety는 그 per-slide 결정의 산물이다(반복은 수렴 결과일 때만).
> **이건 의지가 아니라 구조로 보장된다.** 결정론(non-LLM) 단계는 코드(아래 "제공 스크립트")가 대신하므로 agent가 builder를 새로 짤 일이 없고, 결정은 **슬라이드 1장만 보는 per-slide 서브에이전트**가 내리므로 cross-slide 표·batch loop를 **애초에 쓸 수 없다.**

## 입출력 계약

- **입력:**
  - `projects/{name}/artifacts/slides/slide_contents.json` (S4)
  - `projects/{name}/artifacts/rfp/rfp.json` — `required_proposal_structure.sections`, `requirements`
  - `projects/{name}/artifacts/strategy/theme_statements.json` — section_id별 theme statement
  - `design-system/catalog.json` — `variants`, `layouts`, `intents`, `adornments`
- **중간 산출 (per-slide):** `projects/{name}/artifacts/slides/.plan/slide_{index}.json` — 서브에이전트가 슬라이드별로 쓰는 DECISION 레코드. `assemble.py`가 이걸 읽어 최종 아티팩트를 만든다.
- **출력:** `projects/{name}/artifacts/slides/slide_plan.json` (`SlidePlanArtifact`)
- **제공 스크립트:** `skills/slide-plan/scripts/{loaders,flatten,layout_fills,cover_toc,make_floor,assemble}.py` — 전부 stdlib-only, venv 불필요 (`python3`로 바로 실행). dict 기반 catalog. prompts: `references/prompts/{step}_{system,user}.md`.

## 게이트

**입력 사전조건 (orchestrator):** `slide_contents.json` 존재 + `items` 비어있지 않음, catalog 파일 존재는 orchestrator(`pipeline`)의 `gate S5 before`가 검증한다. runner는 재검증하지 않는다. 어떤 catalog를 쓸지는 orchestrator가 게이트 전에 **디자인 템플릿 선택** 절차(pipeline SKILL.md — 현재 템플릿 사용 vs 유저 PPTX에서 `extract-design-system`으로 추출)로 확정한다 — runner는 선택 UI를 띄우지 않고 canonical path만 읽는다.

**design system catalog 로드·검증·SHA 스탬프 (런타임, fail-loud):** S5는 design system 없이는 의미가 없다. 제공 스크립트들이 canonical path `design-system/catalog.json`을 `loaders.load_catalog`로 로드한다 — 없거나 invalid JSON이면 path와 오류를 보고하며 **fail-loud로 중단**(빈/임의 플랜 생성 금지). SHA-256 스탬프는 `assemble.py`가 `loaders.catalog_sha256`로 계산해 `slide_plan.json._meta.catalog_sha256`에 박는다 — 렌더 단계가 자신이 읽는 catalog와 대조(불일치 시 abort)하기 위함. catalog의 `variants`/`layouts`/`intents` 키는 후보 조립·검증이 사용하므로 비어 있으면 다운스트림에서 드러난다.

## 제공 스크립트 (script ↔ agent 분담)

| 단계 | 누가 | 무엇 |
|---|---|---|
| flatten | `flatten.py` | `slide_contents.items` → 절대 인덱스 `input_slides` (+`--split-dir`로 슬라이드별 입력 파일) |
| intent·layout·block·slot·proposal_body | **per-slide 서브에이전트** (LLM) | 그 슬라이드의 진짜 결정 — 아래 5단계 |
| 후보 조립 | `loaders.py candidates` | intent별 block_matching 후보 (thin intent엔 fallback pool 부착 — 규칙: `loaders.py` docstring) |
| 기계 fill | `layout_fills.py` | layout_fills(mechanical)·adornment_fills·`needs_proposal_body` 플래그 |
| floor | `make_floor.py` | intent==null/실패 슬라이드의 degraded floor |
| cover/TOC | `cover_toc.py` | 표지·목차 front-matter 엔트리 |
| assemble | `assemble.py` | DECISION 레코드 → 본문 concat·floor·front-matter·번호·검증·`_meta`+SHA → `slide_plan.json` |

원칙: **기계 변환은 제공 스크립트, 결정은 per-slide 서브에이전트.** agent는 스크립트를 호출하고 결정 레코드를 쓸 뿐, loop·표·builder를 만들지 않는다.

## 슬라이드 평탄화 (절대 인덱스 정의) — `flatten.py`
`flatten.py --contents <slide_contents.json> [--slide-indices a,b] [--split-dir <dir>]`.
`slide_contents.items`를 순서대로 펼쳐 `input_slides` 생성 — 이 순서가 각 슬라이드의
**절대 인덱스** (출력 슬라이드와 1:1, 부분 재실행 시에도 동일). 각 input_slide =
`{index, source, subtitle, section_id, blocks}`. `--split-dir`은 fan-out용으로
`slide_{index}.json`을 슬라이드별로 쓴다. 부분 재실행: `--slide-indices`(절대 인덱스)
지정 시 그 슬라이드만 재플래닝, 나머지는 assemble이 기존 레코드에서 머지.

## 5단계 per-slide 파이프라인 (슬라이드 격리)

각 슬라이드는 **자기 입력 하나에만** 5단계를
적용해 DECISION 레코드 1개(`​.plan/slide_{index}.json`)를 쓴다. 각 step은 그 슬라이드에
실제 적용하는 LLM 결정(structured output). 프롬프트는 `references/prompts/{step}_system.md`
/ `{step}_user.md` (Jinja). catalog 데이터는 헬퍼(`loaders.py`)로 주입한다. 한 슬라이드만 보고
내린 결정이라 cross-slide 표·batch loop가 애초에 불가능하다(collapse 구조적 차단). **이 결정을 슬라이드별
서브에이전트로 fan-out 하는 디스패치(웨이브·동시성)는 runner(`slide-planner`)의 실행 전략이며 여기서 정의하지 않는다.**

### 1. intent_matching → `intent_id | null`
- system: catalog의 intents 목록 주입. user: `{subtitle, blocks}` JSON.
- 출력: `{"intent_id": "string|null"}`.
- **null은 정상 결과** — "맞는 intent 없음" → 이 슬라이드는 fallback floor로 (아래).
  단 인프라 실패(파싱/게이트웨이 오류)는 예외로 → 슬라이드 failed.

### 2. layout_matching → `layout_id` (intent 있을 때만)
- system: catalog `layouts`(미사용 제외) — id/note/furniture_roles/placeholders.
- user: `section_path`(section_tree에서 도출), `layout_affinity`(intent별), `slide_type`
  (`source!="section"`이면 `requirement-response`, 아니면 `section-overview`).
- 출력: `{"layout_id": "string"}`.

### 3. block_matching → 블록별 variant + adornment (intent 있을 때만)
- system: block_matching/system.md.
- user: intent의 variants(`id,name,description,slots,fallback`), adornments,
  `blocks_json`({heading,body}), `has_fallback`.
- 출력: 블록 배열 — 각 `{heading, adornment_id, components:[{variant_id, content[]}]}`.
- 실패 시 모든 블록을 `FALLBACK_VARIANT_ID`("single-bordered-bullet-box") 컴포넌트로 폴백.

### 4. slot_mapping → 컴포넌트 slot 채우기
- 각 컴포넌트별 1콜. system: slot_mapping/system.md. user: `content_json`, variant의 `slots_json`.
- 출력: `{"fills":[{slot,value}], "repeating_fills":[{slot,rows[]}]}`.
- `FALLBACK_VARIANT_ID` 컴포넌트는 LLM 없이 `fills:[{slot:"items", value:"\n".join(content)}]`.

### 5. layout_mapping → layout_fills + adornment_fills
- **기계적(LLM 아님) = `layout_fills.py`.** 서브에이전트가 자기 결정(layout_id +
  adornment_id 박힌 blocks)을 `layout_fills.py --slide <레코드> --rfp <rfp.json> --project <name>
  --theme-statements <ts.json>`에 넘기면 layout_fills(mechanical: `page_title`/`chapter_label`
  /`section_breadcrumb`/`requirement_*`/`title`/`subtitle`/`page_number`)·adornment_fills·
  `needs_proposal_body`·`theme_statement`를 돌려준다. **agent가 이 fill을 손으로 쓰지 않는다.**
- **proposal_body (LLM, agent 결정):** `needs_proposal_body`(= layout에 proposal_body
  placeholder 有 AND 그 섹션 theme statement 존재)일 때만, theme_statement + 채워진 컴포넌트
  값을 앵커로 proposal_body 텍스트를 생성해 레코드의 top-level `proposal_body`에 넣는다.
  `assemble.py`가 이를 layout_fills에 `{slot:"proposal_body", value}`로 병합한다.

### intent==null (fallback floor) — `make_floor.py`
서브에이전트가 intent를 null로 판단하면 5단계를 건너뛰고 `make_floor.py --slide <input>
--project <name>`로 degraded 슬라이드를 만들어 레코드에 `status:"fallback"`으로 쓴다: 각 source
블록을 `FALLBACK_VARIANT_ID`("single-bordered-bullet-box") 컴포넌트 1개로 감싸 body를 primary
text slot(`items`)에 채움. `intent_id=null`(렌더의 fallback 신호), `layout_id=null`. **절대 빈
슬라이드 금지** — "콘텐츠가 살아있는 degraded 슬라이드".

### DECISION 레코드 (`​.plan/slide_{index}.json`)
서브에이전트가 슬라이드당 1개 쓰는 산출. 코드가 아니라 데이터:
```json
{ "index": 0, "section_id": "sec_0003", "source": "section", "subtitle": "…",
  "intent_id": "string|null", "layout_id": "string|null",
  "layout_fills": [{"slot","value"}], "proposal_body": "string",
  "blocks": [{"heading", "adornment_id", "adornment_fills":[{"slot","value"}],
              "components":[{"variant_id","fills":[],"repeating_fills":[]}]}],
  "status": "ok|fallback|failed", "error": "string|null" }
```

### 에러 / 재시도
서브에이전트는 자기 작업을 transient 실패 시에만 최대 2회 재시도. 끝까지 실패면
`status:"failed"`(+`error`)로 레코드를 쓰거나(또는 레코드 없이 죽으면) — `assemble.py`가 그 index를
input에서 floor로 강등한다. **부분 실패 silent drop 금지: 모든 input_slide → plan 또는 floor.**

## cover / TOC + assemble — `cover_toc.py` → `assemble.py`
- `cover_toc.py --rfp <rfp.json> --project <name> [--project-name --bidder --date]` →
  표지·목차 front-matter 엔트리(JSON). 각각 저작 variant/표준 slot/장(章) 없으면 스킵.
- `assemble.py --contents <slide_contents.json> --decisions <.plan dir> --front-matter
  <cover_toc.json> --project <name> --out <slide_plan.json>`: 절대 인덱스 순으로 본문 concat,
  failed/누락 index는 floor 강등, front-matter prepend, `slide_number` 1..N 부여, 2단 검증(아래),
  `_meta`(pipeline·referenced_ids·catalog_sha256·floored/fallback count) 스탬프 → 저장.

## slide_plan.json 스키마 (`SlidePlanArtifact`)
```json
{
  "_meta": {                            // 산출 bookkeeping (필수 — S6가 catalog_sha256을 읽어 자기 catalog와 대조)
    "pipeline": "compose_handoff",
    "catalog_sha256": "string",         // catalog 지문
    "slide_count": 50, "front_matter_count": 2,
    "floored_count": 0, "fallback_count": 0,
    "referenced_ids": { "intents":[], "layouts":[], "variants":[], "adornments":[] },
    "toc_pages_resolved": false
  },
  "status": "ready",
  "master_fills": [{"slot":"string","value":"string"}],
  "slides": [{
    "slide_number": 1,                 // 1-based, 정보용(정체성은 배열 위치)
    "source": "section|{req_id}",
    "subtitle": "string",
    "section_id": "sec_0003|null",      // provenance (cover/TOC는 null)
    "intent_id": "string|null",          // null = fallback floor 신호
    "layout_id": "string|null",
    "layout_fills": [{"slot","value"}],
    "blocks": [{
      "heading": "string",
      "adornment_id": "string|null",
      "adornment_fills": [{"slot","value"}],
      "components": [{
        "variant_id": "string",
        "fills": [{"slot","value"}],
        "repeating_fills": [{"slot","rows":[{...}]}]
      }]
    }]
  }]
}
```
모든 객체 `additionalProperties:false`.

## 저장 상태 (durability)
- 서브에이전트가 끝나는 대로 `​.plan/slide_{index}.json`을 써 두므로, 중간에 죽어도 완료된
  슬라이드는 보존된다(부분 재실행 시 그 index만 다시 씀).
- S5 완료 = `assemble.py`가 `slide_plan.json`(`status:"ready"`)을 쓴 상태. 렌더는 S6.

## 검증 (2단, fail-loud)
1. **스크립트단 (`assemble.py`):**
   - 모든 input_slide가 plan 또는 floor로 귀결 (failed/누락이 빈 슬라이드로 남지 않음).
   - 참조 정합(`validate_slide`): 각 `variant_id`/`layout_id`/`intent_id`/`adornment_id`가
     catalog에 존재, slot 이름이 catalog slot/placeholder와 일치 (slot name = 라우팅 키).
     real-match 슬라이드가 누락 id를 참조하면 floor로 강등.
   - **allowed-list:** non-floor 컴포넌트 variant는 그 intent의
     `allowed_variant_ids` ∪ fallback pool ∪ `FALLBACK_VARIANT_ID` 안이어야 한다 — 벗어나면
     (agent가 후보 밖 variant를 고른 것) **fail-loud로 중단**(슬롯 적합 여부 무관).
2. **orchestrator 게이트 (`validate-artifacts.mjs gate … S5 after`):** 같은 allowed-list를
   독립 backstop으로 재검증.

## 캐스케이드
`slide_plan.json`은 파이프라인 말단(렌더 입력). 상위(slide_contents) 재생성 시 재실행 필요.
