#!/usr/bin/env python3
"""Deterministic S4 slide-budget allocator/checker (stdlib only).

Two subcommands, both pure functions of their input files plus the constants
below. This script is the single source for the allocation/comparison
algorithm and its tunable constants; the S4 SKILL.md documents only the call
contract and output semantics:

- ``allocate`` — split a body-slide target across 단원 groups by weight
  (leaf count + mapped-requirement count), with a per-group floor of one slide
  per leaf. Reads the progress-seed ``plan.json`` (group/section structure)
  plus ``rfp.json`` (requirement_mapping for per-section requirement counts).
  Optionally stamps the allocation back into ``plan.json`` (``--update-plan``)
  so the progress renderer can show budget vs. actual per group.
- ``compare`` — given a merged ``slide_contents.json`` whose
  ``_meta.slide_budget`` carries the allocation, count actual slides per group
  and flag deviations (per-group and total). Optionally writes the actual
  counts back into ``_meta`` (``--update-meta``).
- ``inventory`` — per-group expansion headroom for under-target diagnosis:
  mapped requirements never used as a slide ``source`` plus (when
  ``--framework`` is given) 3C bullet ids never cited in the group's slides.
  ``headroom`` counts unused requirements only — they are group-specific
  evidence; uncited 3C items are shared across groups, so they are reported
  as supplementary injection material but do not drive the diagnosis.
- ``reallocate`` — accept user-approved thin groups as they are
  (``--absorb``: budget drops to actual) and move the freed slides to groups
  with headroom, one slide per unused requirement at most. Optionally stamps
  the new budgets back into ``_meta`` (``--update-meta``).

The budget is a *target*, not a hard cap — the thresholds only catch large
deviations a human would otherwise have to fix downstream.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path

# Tunable operating constants — single source for these values.
# Every constant is also CLI-overridable.
FRONT_MATTER = 2        # cover + TOC slides S5 adds on top of the body
REQ_WEIGHT = 0.5        # weight of one mapped requirement vs. one leaf (1.0)
GROUP_DEV_ABS = 2       # group flag: |actual-budget| >= max(this, pct*budget)
GROUP_DEV_PCT = 0.2
TOTAL_DEV_PCT = 0.1     # total flag: |actual-target| > pct*target


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise SystemExit(f"{path} must contain a JSON object")
    return value


def dump_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def requirement_ids(rfp: dict) -> dict[str, list[str]]:
    """Map section_id -> mapped requirement ids from rfp.json requirement_mapping."""
    ids: dict[str, list[str]] = {}

    def walk(node: object) -> None:
        if isinstance(node, list):
            for child in node:
                walk(child)
            return
        if not isinstance(node, dict):
            return
        sid = node.get("section_id")
        reqs = node.get("requirements")
        if sid and isinstance(reqs, list):
            bucket = ids.setdefault(str(sid), [])
            for req in reqs:
                if isinstance(req, str):
                    bucket.append(req)
                elif isinstance(req, dict) and req.get("id"):
                    bucket.append(str(req["id"]))
        walk(node.get("children"))

    mapping = rfp.get("requirement_mapping") or {}
    walk(mapping.get("sections"))
    return ids


def requirement_counts(rfp: dict) -> dict[str, int]:
    """Map section_id -> mapped requirement count from rfp.json requirement_mapping."""
    return {sid: len(req_ids) for sid, req_ids in requirement_ids(rfp).items()}


def section_req_ids(section_id: str, ids: dict[str, list[str]]) -> list[str]:
    """Requirement ids for a leaf; a synthetic mirror leaf ``X-1`` falls back to its parent ``X``."""
    if section_id in ids:
        return ids[section_id]
    base, sep, _tail = section_id.rpartition("-")
    if sep and base in ids:
        return ids[base]
    return []


def section_req_count(section_id: str, counts: dict[str, int]) -> int:
    """Requirement count for a leaf; a synthetic mirror leaf ``X-1`` falls back to its parent ``X``."""
    if section_id in counts:
        return counts[section_id]
    base, sep, _tail = section_id.rpartition("-")
    if sep and base in counts:
        return counts[base]
    return 0


# 3C citation tags embedded in bullets, e.g. ``[c3]``, ``[co12]``, ``[cm4]``.
CITATION_RE = re.compile(r"\[(c\d+|co\d+|cm\d+)\]")


def budget_meta(contents: dict) -> tuple[dict, list[dict]]:
    """Return (slide_budget meta, groups) from slide_contents.json; budget mode required."""
    meta = (contents.get("_meta") or {}).get("slide_budget") or {}
    if meta.get("mode") != "budget":
        raise SystemExit("_meta.slide_budget is missing or not budget mode")
    groups = [g for g in (meta.get("groups") or []) if isinstance(g, dict)]
    if not groups:
        raise SystemExit("_meta.slide_budget has no groups")
    return meta, groups


def group_inventory(groups: list[dict], contents: dict, rfp: dict, framework: dict | None) -> list[dict]:
    """Per-group unused material: mapped-but-unused requirements, uncited 3C ids, actual slide count."""
    ids_by_section = requirement_ids(rfp)
    slides_by_section = {
        str(item.get("section_id", "")): [s for s in (item.get("slides") or []) if isinstance(s, dict)]
        for item in (contents.get("items") or [])
        if isinstance(item, dict)
    }
    framework_ids: list[str] = []
    if framework is not None:
        for axis in ("customer", "company", "competitor"):
            for bullet in framework.get(axis) or []:
                if isinstance(bullet, dict) and bullet.get("id"):
                    framework_ids.append(str(bullet["id"]))

    rows = []
    for group in groups:
        section_ids = [str(s) for s in (group.get("section_ids") or [])]
        mapped: list[str] = []
        used: set[str] = set()
        cited: set[str] = set()
        actual = 0
        for sid in section_ids:
            for rid in section_req_ids(sid, ids_by_section):
                if rid not in mapped:
                    mapped.append(rid)
            for slide in slides_by_section.get(sid, []):
                actual += 1
                source = str(slide.get("source", ""))
                if source and source != "section":
                    used.add(source)
                for block in slide.get("blocks") or []:
                    if not isinstance(block, dict):
                        continue
                    texts = [block.get("heading", "")] + [str(b) for b in (block.get("body") or [])]
                    for text in texts:
                        cited.update(CITATION_RE.findall(str(text)))
        unused = [rid for rid in mapped if rid not in used]
        row = {
            "group_id": str(group.get("group_id", "")),
            "parent_path": str(group.get("parent_path", "")),
            "actual": actual,
            "unused_requirements": unused,
            "headroom": len(unused),
        }
        if framework is not None:
            row["uncited_3c"] = [fid for fid in framework_ids if fid not in cited]
        rows.append(row)
    return rows


def plan_groups(plan: dict) -> list[dict]:
    groups = plan.get("groups")
    if not isinstance(groups, list) or not groups:
        raise SystemExit("plan.json has no groups")
    return [g for g in groups if isinstance(g, dict)]


def allocate(args: argparse.Namespace) -> dict:
    plan_path = Path(args.plan).resolve()
    plan = load_json(plan_path)
    counts = requirement_counts(load_json(Path(args.rfp).resolve()))
    target = args.page_limit - args.front_matter
    if target <= 0:
        raise SystemExit(f"page_limit {args.page_limit} leaves no body budget after front matter {args.front_matter}")

    rows = []
    for group in plan_groups(plan):
        sections = [s for s in (group.get("sections") or []) if isinstance(s, dict) and s.get("section_id")]
        section_ids = [str(s["section_id"]) for s in sections]
        leaf_count = len(section_ids)
        req_count = sum(section_req_count(sid, counts) for sid in section_ids)
        rows.append(
            {
                "group_id": str(group.get("group_id", "")),
                "parent_path": str(group.get("parent_path", "")),
                "section_ids": section_ids,
                "leaf_count": leaf_count,
                "req_count": req_count,
                "weight": leaf_count + args.req_weight * req_count,
            }
        )

    floor_total = sum(row["leaf_count"] for row in rows)
    remaining = target - floor_total
    note = None
    if remaining <= 0:
        # The floor (one slide per leaf) already meets/exceeds the target:
        # keep the floor, flag it — going below one slide per leaf is invalid.
        note = "target_below_floor"
        for row in rows:
            row["budget"] = row["leaf_count"]
    else:
        # Largest-remainder split of the surplus, proportional to weight.
        total_weight = sum(row["weight"] for row in rows) or 1.0
        shares = [remaining * row["weight"] / total_weight for row in rows]
        extras = [math.floor(s) for s in shares]
        leftover = remaining - sum(extras)
        order = sorted(range(len(rows)), key=lambda i: (-(shares[i] - extras[i]), i))
        for i in order[:leftover]:
            extras[i] += 1
        for row, extra in zip(rows, extras):
            row["budget"] = row["leaf_count"] + extra

    result = {
        "mode": "budget",
        "page_limit": args.page_limit,
        "front_matter": args.front_matter,
        "target_body": target,
        "floor_total": floor_total,
        "note": note,
        "groups": rows,
    }

    if args.update_plan:
        budgets = {row["group_id"]: row["budget"] for row in rows}
        for group in plan_groups(plan):
            gid = str(group.get("group_id", ""))
            if gid in budgets:
                group["slide_budget"] = budgets[gid]
        plan["budget"] = {
            "mode": "budget",
            "page_limit": args.page_limit,
            "front_matter": args.front_matter,
            "target_body": target,
            "note": note,
        }
        dump_json(plan_path, plan)
    return result


def compare(args: argparse.Namespace) -> dict:
    contents_path = Path(args.contents).resolve()
    contents = load_json(contents_path)
    meta = (contents.get("_meta") or {}).get("slide_budget") or {}
    if meta.get("mode") != "budget":
        return {"mode": meta.get("mode") or "free", "needs_review": False}

    target = int(meta.get("target_body") or 0)
    groups = [g for g in (meta.get("groups") or []) if isinstance(g, dict)]
    if target <= 0 or not groups:
        raise SystemExit("_meta.slide_budget is budget mode but lacks target_body/groups")

    slides_by_section = {
        str(item.get("section_id", "")): len(item.get("slides") or [])
        for item in (contents.get("items") or [])
        if isinstance(item, dict)
    }

    report_groups = []
    flagged = False
    for group in groups:
        budget = int(group.get("budget") or 0)
        actual = sum(slides_by_section.get(sid, 0) for sid in (group.get("section_ids") or []))
        delta = actual - budget
        threshold = max(args.group_dev_abs, math.ceil(args.group_dev_pct * budget))
        flag = "ok"
        if abs(delta) >= threshold:
            flag = "over" if delta > 0 else "under"
            flagged = True
        group["actual"] = actual
        report_groups.append(
            {
                "group_id": str(group.get("group_id", "")),
                "parent_path": str(group.get("parent_path", "")),
                "budget": budget,
                "actual": actual,
                "delta": delta,
                "flag": flag,
            }
        )

    actual_body = sum(slides_by_section.values())
    total_delta = actual_body - target
    total_ok = abs(total_delta) <= args.total_dev_pct * target
    # Regeneration candidates: groups contributing to the total deviation,
    # largest contribution first. Only meaningful when the total is off.
    candidates = []
    if not total_ok:
        direction = 1 if total_delta > 0 else -1
        candidates = [
            {"group_id": row["group_id"], "parent_path": row["parent_path"], "delta": row["delta"]}
            for row in sorted(report_groups, key=lambda r: -abs(r["delta"]))
            if row["delta"] * direction > 0
        ]

    if args.update_meta:
        meta["actual_body"] = actual_body
        contents.setdefault("_meta", {})["slide_budget"] = meta
        dump_json(contents_path, contents)

    return {
        "mode": "budget",
        "target_body": target,
        "actual_body": actual_body,
        "total_delta": total_delta,
        "total_ok": total_ok,
        "groups": report_groups,
        "candidates": candidates,
        "needs_review": flagged or not total_ok,
    }


def inventory(args: argparse.Namespace) -> dict:
    contents = load_json(Path(args.contents).resolve())
    _meta, groups = budget_meta(contents)
    if args.groups:
        wanted = {gid for gid in args.groups.split(",") if gid}
        unknown = wanted - {str(g.get("group_id", "")) for g in groups}
        if unknown:
            raise SystemExit(f"unknown group ids: {','.join(sorted(unknown))}")
        groups = [g for g in groups if str(g.get("group_id", "")) in wanted]
    rfp = load_json(Path(args.rfp).resolve())
    framework = load_json(Path(args.framework).resolve()) if args.framework else None
    return {"groups": group_inventory(groups, contents, rfp, framework)}


def reallocate(args: argparse.Namespace) -> dict:
    contents_path = Path(args.contents).resolve()
    contents = load_json(contents_path)
    meta, groups = budget_meta(contents)
    absorb = {gid for gid in args.absorb.split(",") if gid}
    known = {str(g.get("group_id", "")) for g in groups}
    unknown = absorb - known
    if unknown:
        raise SystemExit(f"unknown group ids: {','.join(sorted(unknown))}")

    rfp = load_json(Path(args.rfp).resolve())
    inv = {row["group_id"]: row for row in group_inventory(groups, contents, rfp, None)}

    # Free the unmet part of each absorbed group's budget (its budget drops to actual).
    rows = []
    freed = 0
    for group in groups:
        gid = str(group.get("group_id", ""))
        budget = int(group.get("budget") or 0)
        actual = inv[gid]["actual"]
        row = {
            "group_id": gid,
            "parent_path": str(group.get("parent_path", "")),
            "budget": budget,
            "actual": actual,
            "headroom": inv[gid]["headroom"],
            "unused_requirements": inv[gid]["unused_requirements"],
            "extra": 0,
        }
        if gid in absorb:
            row["role"] = "absorb"
            freed += max(0, budget - actual)
            row["new_budget"] = min(budget, actual)
        else:
            row["role"] = "hold"  # promoted to "receive" below if it gets slides
            row["new_budget"] = budget
        rows.append(row)

    # Hand the freed slides to non-absorbed groups with headroom, one slide at a
    # time to the group with the most remaining capacity (earlier group on ties);
    # a group can take at most one extra slide per unused requirement.
    remaining = freed
    receivers = [row for row in rows if row["role"] == "hold" and row["headroom"] > 0]
    while remaining > 0:
        eligible = [row for row in receivers if row["extra"] < row["headroom"]]
        if not eligible:
            break
        target = max(eligible, key=lambda row: (row["headroom"] - row["extra"], -rows.index(row)))
        target["extra"] += 1
        target["new_budget"] += 1
        target["role"] = "receive"
        remaining -= 1

    note = None
    if freed == 0:
        note = "nothing_to_reallocate"
    elif remaining > 0:
        note = "insufficient_headroom"

    if args.update_meta:
        new_budgets = {row["group_id"]: row["new_budget"] for row in rows}
        for group in groups:
            gid = str(group.get("group_id", ""))
            group["budget"] = new_budgets[gid]
        meta["reallocated"] = True
        contents.setdefault("_meta", {})["slide_budget"] = meta
        dump_json(contents_path, contents)

    return {
        "mode": "budget",
        "target_body": int(meta.get("target_body") or 0),
        "freed": freed,
        "allocated": freed - remaining,
        "leftover": remaining,
        "note": note,
        "groups": rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="S4 slide budget allocate/compare (deterministic).")
    sub = parser.add_subparsers(dest="command", required=True)

    p_alloc = sub.add_parser("allocate", help="Split the body-slide target across section groups.")
    p_alloc.add_argument("--plan", required=True, help="Progress-seed plan.json (groups + sections).")
    p_alloc.add_argument("--rfp", required=True, help="rfp.json (requirement_mapping for weights).")
    p_alloc.add_argument("--page-limit", type=int, required=True, help="RFP page_limit (integer).")
    p_alloc.add_argument("--front-matter", type=int, default=FRONT_MATTER)
    p_alloc.add_argument("--req-weight", type=float, default=REQ_WEIGHT)
    p_alloc.add_argument("--update-plan", action="store_true", help="Stamp slide_budget into plan.json groups.")

    p_cmp = sub.add_parser("compare", help="Flag deviations of merged slide_contents.json vs. the budget.")
    p_cmp.add_argument("--contents", required=True, help="slide_contents.json with _meta.slide_budget.")
    p_cmp.add_argument("--group-dev-abs", type=int, default=GROUP_DEV_ABS)
    p_cmp.add_argument("--group-dev-pct", type=float, default=GROUP_DEV_PCT)
    p_cmp.add_argument("--total-dev-pct", type=float, default=TOTAL_DEV_PCT)
    p_cmp.add_argument("--update-meta", action="store_true", help="Write actual counts back into _meta.slide_budget.")

    p_inv = sub.add_parser("inventory", help="Per-group unused material (expansion headroom) for under-target diagnosis.")
    p_inv.add_argument("--contents", required=True, help="slide_contents.json with _meta.slide_budget.")
    p_inv.add_argument("--rfp", required=True, help="rfp.json (requirement_mapping).")
    p_inv.add_argument("--framework", help="framework_3c.json — include uncited 3C ids per group.")
    p_inv.add_argument("--groups", help="Comma-separated group ids to limit the report to (default: all).")

    p_re = sub.add_parser("reallocate", help="Absorb thin groups (budget := actual) and move freed slides to groups with headroom.")
    p_re.add_argument("--contents", required=True, help="slide_contents.json with _meta.slide_budget.")
    p_re.add_argument("--rfp", required=True, help="rfp.json (requirement_mapping).")
    p_re.add_argument("--absorb", required=True, help="Comma-separated group ids whose budget drops to actual.")
    p_re.add_argument("--update-meta", action="store_true", help="Stamp new budgets back into _meta.slide_budget.")

    args = parser.parse_args()
    commands = {"allocate": allocate, "compare": compare, "inventory": inventory, "reallocate": reallocate}
    result = commands[args.command](args)
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
