#!/usr/bin/env python3
"""Render slide_contents.json as a static HTML panel for contrl-shell.

Reads `projects/<project>/artifacts/slides/slide_contents.json` and writes
`projects/<project>/outputs/slides/slide_contents.html`, laying out
section -> slide -> block(bullets) the way the deck will read. Section titles are
resolved from rfp.json (`required_proposal_structure.sections[]`); when rfp.json
is missing or a section_id is absent, the section_id itself is shown as a fallback.
"""
from __future__ import annotations

import argparse
import json
from html import escape
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE_PATH = SKILL_ROOT / "templates" / "slide-contents.html"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render slide_contents panel HTML.")
    parser.add_argument("project", help="Project name under projects/.")
    parser.add_argument("--root", required=True, help="Absolute path to the dir that contains projects/.")
    parser.add_argument("--input", help="slide_contents.json path. Defaults to the project artifact path.")
    parser.add_argument("--rfp", help="rfp.json path (for section titles). Defaults to the project artifact path.")
    parser.add_argument("--output", help="HTML output path. Defaults to the project outputs path.")
    return parser.parse_args()


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def section_titles(rfp_path: Path) -> dict[str, str]:
    """Map section_id -> title from rfp.json; empty dict if unavailable."""
    if not rfp_path.exists():
        return {}
    try:
        rfp = load_json(rfp_path)
    except (json.JSONDecodeError, OSError):
        return {}
    sections = ((rfp.get("required_proposal_structure") or {}).get("sections")) or []
    titles: dict[str, str] = {}
    for node in sections:
        sid = node.get("section_id")
        if sid and node.get("title"):
            titles[sid] = str(node["title"])
    return titles


def render_block(block: dict) -> str:
    heading = escape(str(block.get("heading") or ""))
    bullets = [b for b in (block.get("body") or []) if str(b or "").strip()]
    items = "".join(f"<li>{escape(str(b))}</li>" for b in bullets)
    head_html = f'<div class="heading">{heading}</div>' if heading else ""
    list_html = f"<ul>{items}</ul>" if items else ""
    return f'<div class="block">{head_html}{list_html}</div>'


def render_slide(slide: dict, number: int) -> str:
    subtitle = escape(str(slide.get("subtitle") or ""))
    source = str(slide.get("source") or "")
    if source == "section":
        chip = '<span class="chip section">Section</span>'
    elif source:
        chip = f'<span class="chip req">Requirement {escape(source)}</span>'
    else:
        chip = ""
    blocks = "".join(render_block(b) for b in (slide.get("blocks") or []))
    return (
        '<div class="slide">'
        f'<div class="slideHead"><span class="slideNo">#{number}</span>'
        f'<span class="subtitle">{subtitle}</span>{chip}</div>'
        f'<div class="blocks">{blocks}</div>'
        "</div>"
    )


def render_section(item: dict, titles: dict[str, str], slide_offset: int) -> tuple[str, int]:
    sid = str(item.get("section_id") or "")
    title = escape(titles.get(sid, sid) or sid)
    slides = item.get("slides") or []
    slides_html = "".join(
        render_slide(slide, slide_offset + i + 1) for i, slide in enumerate(slides)
    )
    head = (
        '<div class="sectionHead">'
        f'<span class="sectionTitle">{title}</span>'
        f'<span class="sid">{escape(sid)}</span>'
        f'<span class="slideCount">Slides {len(slides)}</span>'
        "</div>"
    )
    return f'<section class="section">{head}<div class="slides">{slides_html}</div></section>', len(slides)


def render_budget(data: dict) -> str:
    """Render the slide-budget summary strip when budget mode metadata exists."""
    meta = (data.get("_meta") or {}).get("slide_budget") or {}
    if meta.get("mode") != "budget" or not isinstance(meta.get("target_body"), int):
        return ""
    slides_by_section = {
        str(item.get("section_id", "")): len(item.get("slides") or [])
        for item in (data.get("items") or [])
        if isinstance(item, dict)
    }
    actual_body = sum(slides_by_section.values())
    target = meta["target_body"]
    total_delta = actual_body - target
    total_suffix = f" ({total_delta:+d})" if total_delta else " (matched)"
    rows = []
    for group in meta.get("groups") or []:
        if not isinstance(group, dict) or not isinstance(group.get("budget"), int):
            continue
        budget = group["budget"]
        actual = sum(slides_by_section.get(str(sid), 0) for sid in (group.get("section_ids") or []))
        delta = actual - budget
        delta_html = f'<span class="delta">{delta:+d}</span>' if delta else ""
        rows.append(
            '<div class="budgetRow">'
            f'<span class="budgetPath">{escape(str(group.get("parent_path", "")))}</span>'
            f'<span class="budgetNums">Budget {budget} · Actual {actual}{delta_html}</span>'
            "</div>"
        )
    return (
        '<section class="budget">'
        f'<div class="budgetHead">Volume (budget mode) - Body target {target} slides · Actual {actual_body} slides{escape(total_suffix)}</div>'
        f"{''.join(rows)}"
        "</section>"
    )


def render_html(data: dict, titles: dict[str, str], project: str) -> str:
    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    items = data.get("items") or []
    sections_html = ""
    total_slides = 0
    for item in items:
        html_part, count = render_section(item, titles, total_slides)
        sections_html += html_part
        total_slides += count
    if not items:
        sections_html = '<div class="empty">No slide content has been generated yet. Results will appear here as this stage progresses.</div>'
    counts = f"Sections {len(items)} · Slides {total_slides}" if items else ""
    replacements = {
        "TITLE": f"Slide Contents - {project}",
        "HEADING": "Slide Contents",
        "PROJECT_LABEL": f"Project: {escape(project)}",
        "COUNTS": counts,
        "BUDGET_HTML": render_budget(data),
        "SECTIONS_HTML": sections_html,
        "PANEL_READY": "true" if items else "false",
    }
    for key, value in replacements.items():
        template = template.replace(f"{{{{{key}}}}}", value)
    return template


def main() -> None:
    args = parse_args()
    root = Path(args.root).resolve()
    project = args.project
    base = root / "projects" / project
    input_path = Path(args.input).resolve() if args.input else base / "artifacts" / "slides" / "slide_contents.json"
    rfp_path = Path(args.rfp).resolve() if args.rfp else base / "artifacts" / "rfp" / "rfp.json"
    output = Path(args.output).resolve() if args.output else base / "outputs" / "slides" / "slide_contents.html"
    # 입력이 없으면(워크플로 진입 시 seed) 빈 데이터로 "아직 준비 안됨" 패널을 렌더한다.
    data = load_json(input_path) if input_path.exists() else {}
    titles = section_titles(rfp_path)
    html_text = render_html(data, titles, project)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html_text, encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
