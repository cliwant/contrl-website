#!/usr/bin/env python3
"""Render S4 slide-contents generation progress as a static HTML panel.

Mirrors the S3 theme-statements progress renderer: a pure read of a seed
`plan.json` plus whatever per-group `group-*.json` partials each worker has
written so far. A group not yet on disk renders as still running and gets
filled on the next render. Output is `outputs/slides/slide_contents.html` —
the same panel path the canonical renderer targets, so the live run and the
final deck share one panel slot in contrl-shell.
"""
from __future__ import annotations

import argparse
import html
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE_PATH = SKILL_ROOT / "templates" / "slide-contents-progress.html"

# Stage pills. ``generating`` (단원 fan-out), ``merging`` (머지/정렬/저장).
# ``done`` lights every pill. Keep in sync with the coordinator's --stage arg.
STAGES = (
    ("generating", "Generate"),
    ("merging", "Merge"),
)
STAGE_INDEX = {name: i for i, (name, _label) in enumerate(STAGES)}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Render slide-contents generation progress into a static user-facing HTML output.",
    )
    parser.add_argument("project", nargs="?", help="Project directory name under projects/.")
    parser.add_argument("--root", default=str(ROOT), help="Repo root containing projects/.")
    parser.add_argument("--progress-dir", help="Progress dir holding plan.json + group-*.json. Defaults to the project path.")
    parser.add_argument("--output", help="HTML output path. Defaults to projects/<project>/outputs/slides/slide_contents.html.")
    parser.add_argument(
        "--stage",
        choices=[name for name, _ in STAGES] + ["done"],
        help="Current pipeline stage. When omitted it is inferred from how many groups have landed.",
    )
    parser.add_argument("--no-cache", action="store_true", help="Do not read/write the default hidden snapshot cache.")
    return parser.parse_args()


def assert_project_name(project: str) -> None:
    if not project or project in {".", ".."} or "/" in project or "\\" in project:
        raise SystemExit("project name must be one directory name without path separators")


def default_progress_dir(root: Path, project: str) -> Path:
    assert_project_name(project)
    return root / "projects" / project / "outputs" / "slides" / ".sc_progress"


def default_output(root: Path, project: str) -> Path:
    assert_project_name(project)
    return root / "projects" / project / "outputs" / "slides" / "slide_contents.html"


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise SystemExit(f"{path} must contain a JSON object")
    return value


def esc(value: object) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def assemble_state(progress_dir: Path) -> dict:
    """Pure read of the seed plan + whatever group-*.json partials exist.

    Each worker writes its own group-{group_id}.json so concurrent workers
    never touch the same file (no lost-update race). The renderer is a pure
    function of (plan + present partials): a group not yet on disk renders as
    still running and gets filled on the next render. Each planned section
    carries its slides once its group lands; until then it shows a placeholder.
    """
    # plan.json이 아직 없으면(스테이지 진입 시 seed) 빈 상태 → "아직 준비 안됨" 패널.
    if not (progress_dir / "plan.json").exists():
        return {}
    plan = load_json(progress_dir / "plan.json")
    groups = plan.get("groups") if isinstance(plan.get("groups"), list) else []
    # Index landed group results by group_id.
    results: dict[str, dict] = {}
    for partial in sorted(progress_dir.glob("group-*.json")):
        try:
            data = load_json(partial)
        except (SystemExit, json.JSONDecodeError):
            # A partial caught mid-write by a peer renderer — skip it this
            # pass; the next render (triggered by that worker) will include it.
            continue
        gid = str(data.get("group_id", ""))
        if gid:
            results[gid] = data
    assembled_groups = []
    for group in groups:
        if not isinstance(group, dict):
            continue
        gid = str(group.get("group_id", ""))
        planned = group.get("sections") if isinstance(group.get("sections"), list) else []
        result = results.get(gid)
        slides_by_id: dict[str, list] = {}
        gstatus = "wait"
        if result is not None:
            gstatus = str(result.get("status") or "done")
            for sec in result.get("sections", []) if isinstance(result.get("sections"), list) else []:
                if isinstance(sec, dict) and sec.get("section_id"):
                    slides = sec.get("slides") if isinstance(sec.get("slides"), list) else []
                    slides_by_id[str(sec["section_id"])] = slides
        assembled_sections = []
        for sec in planned:
            if not isinstance(sec, dict):
                continue
            sid = str(sec.get("section_id", ""))
            slides = slides_by_id.get(sid)
            assembled_sections.append(
                {
                    "section_id": sid,
                    "title": str(sec.get("title", "")),
                    "slides": slides if slides is not None else [],
                    "done": slides is not None,
                }
            )
        assembled = {
            "group_id": gid,
            "parent_path": str(group.get("parent_path", "")),
            "status": gstatus,
            "sections": assembled_sections,
        }
        # budget.py allocate --update-plan이 스탬프한 그룹 예산(예산 모드에서만 존재).
        if isinstance(group.get("slide_budget"), int):
            assembled["slide_budget"] = group["slide_budget"]
        assembled_groups.append(assembled)
    state = {
        "project": str(plan.get("project", "")),
        "win_theme_headline": str(plan.get("win_theme_headline", "")),
        "groups": assembled_groups,
    }
    if isinstance(plan.get("budget"), dict):
        state["budget"] = plan["budget"]
    return state


def section_signature(group_id: str, section: dict) -> tuple[str, str]:
    slides = section.get("slides") or []
    sig = f"{len(slides)}|" + "¶".join(str(s.get("subtitle", "")) for s in slides if isinstance(s, dict))
    return (f"{group_id}:{section.get('section_id', '')}", sig)


def changed_keys(previous: dict | None, current: dict) -> set[str]:
    if not previous:
        return set()
    before: dict[str, str] = {}
    for group in previous.get("groups", []):
        gid = str(group.get("group_id", ""))
        for sec in group.get("sections", []):
            key, sig = section_signature(gid, sec)
            before[key] = sig
    out: set[str] = set()
    for group in current.get("groups", []):
        gid = str(group.get("group_id", ""))
        for sec in group.get("sections", []):
            if not sec.get("done"):
                continue
            key, sig = section_signature(gid, sec)
            if before.get(key) != sig:
                out.add(key)
    return out


def counts(state: dict) -> tuple[int, int, int, int, int]:
    groups = state.get("groups", [])
    groups_total = len(groups)
    groups_done = sum(1 for g in groups if g.get("status") == "done")
    sections = [sec for g in groups for sec in g.get("sections", [])]
    sections_total = len(sections)
    sections_done = sum(1 for sec in sections if sec.get("done"))
    slides_total = sum(len(sec.get("slides") or []) for sec in sections)
    return groups_done, groups_total, sections_done, sections_total, slides_total


def infer_stage(state: dict) -> str:
    groups_done, groups_total, *_ = counts(state)
    if groups_total and groups_done >= groups_total:
        return "merging"
    return "generating"


def render_stage_pills(state: dict, stage: str) -> str:
    groups_done, groups_total, _sd, _st, _sl = counts(state)
    current = STAGE_INDEX.get(stage, len(STAGES)) if stage != "done" else len(STAGES)
    pills = []
    for i, (name, label) in enumerate(STAGES):
        if name == "generating":
            text = f"① {label} · {groups_done}/{groups_total}"
        else:
            text = f"② {label}"
        if stage == "done" or i < current:
            cls = "pill done"
            dot = '<span class="dot"></span>'
        elif i == current:
            cls = "pill active"
            dot = '<span class="dot pending"></span>'
        else:
            cls = "pill"
            dot = '<span class="dot wait"></span>'
        pills.append(f'<span class="{cls}">{dot}<span>{esc(text)}</span></span>')
    return "".join(pills)


def render_block(block: dict) -> str:
    if not isinstance(block, dict):
        return ""
    heading = esc(block.get("heading") or "")
    bullets = [b for b in (block.get("body") or []) if str(b or "").strip()]
    items = "".join(f"<li>{esc(b)}</li>" for b in bullets)
    head_html = f'<div class="heading">{heading}</div>' if heading else ""
    list_html = f"<ul>{items}</ul>" if items else ""
    return f'<div class="block">{head_html}{list_html}</div>'


def render_slide(slide: dict, number: int) -> str:
    if not isinstance(slide, dict):
        return ""
    subtitle = esc(slide.get("subtitle") or "")
    source = str(slide.get("source") or "")
    if source == "section":
        chip = '<span class="chip section">Section</span>'
    elif source:
        chip = f'<span class="chip req">Requirement {esc(source)}</span>'
    else:
        chip = ""
    blocks = "".join(render_block(b) for b in (slide.get("blocks") or []))
    return (
        '<div class="slide">'
        f'<div class="slideHead"><span class="slideNo">#{number}</span>'
        f'<span class="subtitle">{subtitle}</span>{chip}</div>'
        f'<div class="blocks">{blocks}</div>'
        "</div>"
    )


def render_section(section: dict, changed: set[str], group_id: str) -> str:
    key, _sig = section_signature(group_id, section)
    sid = esc(section.get("section_id", ""))
    title = esc(section.get("title") or section.get("section_id", ""))
    changed_class = " changed" if key in changed else ""
    slides = section.get("slides") or []
    if section.get("done"):
        if slides:
            body = "".join(render_slide(s, i + 1) for i, s in enumerate(slides))
        else:
            body = '<div class="slide empty">No slides</div>'
        count_html = f'<span class="slideCount">Slides {len(slides)}</span>'
    else:
        body = '<div class="slide placeholder">Group runner in progress - content will appear when it lands.</div>'
        count_html = '<span class="slideCount">···</span>'
    head = (
        '<div class="sectionHead">'
        f'<span class="sectionTitle">{title}</span>'
        f'<span class="sid">{sid}</span>'
        f"{count_html}"
        "</div>"
    )
    return (
        f'<section class="section{changed_class}" data-section-id="{sid}">'
        f'{head}<div class="slides">{body}</div></section>'
    )


def group_budget_label(group: dict) -> str:
    """Budget-vs-actual label for group headers; empty outside budget mode."""
    budget = group.get("slide_budget")
    if not isinstance(budget, int):
        return ""
    if group.get("status") not in {"done", "failed"}:
        return f"Budget {budget} slides"
    actual = sum(len(sec.get("slides") or []) for sec in group.get("sections", []))
    delta = actual - budget
    suffix = f" ({delta:+d})" if delta else ""
    return f"Budget {budget} slides · Actual {actual} slides{suffix}"


def render_group(group: dict, changed: set[str]) -> str:
    status = str(group.get("status") or "wait")
    status_label = {
        "done": "group ✓",
        "running": "group · generating",
        "failed": "group · failed",
        "wait": "group · waiting",
    }.get(status, "group · waiting")
    status_cls = {"done": "done", "running": "running", "failed": "failed"}.get(status, "wait")
    gid = str(group.get("group_id", ""))
    sections_html = "".join(render_section(sec, changed, gid) for sec in group.get("sections", []))
    budget_label = group_budget_label(group)
    budget_html = f'<div class="groupBudget">{esc(budget_label)}</div>' if budget_label else ""
    return (
        '<section class="group">'
        '<div class="groupName">'
        f'{esc(group.get("parent_path", ""))}'
        f"{budget_html}"
        f'<div class="groupStatus {status_cls}">{esc(status_label)}</div>'
        "</div>"
        f'<div class="groupItems">{sections_html}</div>'
        "</section>"
    )


def render_html(state: dict, stage: str, changed: set[str]) -> str:
    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    project = state.get("project", "")
    headline = state.get("win_theme_headline", "")
    groups = state.get("groups", [])
    panel_ready = bool(groups)
    _gd, _gt, sections_done, sections_total, slides_total = counts(state)
    groups_html = (
        "".join(render_group(group, changed) for group in groups)
        if groups
        else '<div class="empty">Slide content generation has not started yet. Results will appear here as this stage progresses.</div>'
    )
    notice_text = ""
    notice_class = "hidden"
    if any(g.get("status") == "failed" for g in groups):
        notice_text = "Some section-group generation tasks failed. Check the coordinator return value for the failure list."
        notice_class = ""
    counts_text = f"Sections {sections_done}/{sections_total} · Slides {slides_total}" if groups else ""
    budget = state.get("budget") or {}
    if groups and isinstance(budget.get("target_body"), int):
        counts_text += f" · Body target {budget['target_body']} slides"
    win_theme_label = f"Win Theme: {headline}" if headline else ""
    replacements = {
        "TITLE": f"Slide Contents Generation - {project}",
        "HEADING": "Slide Contents Generation",
        "PROJECT_LABEL": f"Project: {project}",
        "WIN_THEME_LABEL": win_theme_label,
        "STAGE_PILLS_HTML": render_stage_pills(state, stage),
        "COUNTS": counts_text,
        "NOTICE_CLASS": notice_class,
        "NOTICE_TEXT": notice_text,
        "GROUPS_HTML": groups_html,
        "PANEL_READY": "true" if panel_ready else "false",
    }
    for key, value in replacements.items():
        template = template.replace(f"{{{{{key}}}}}", value)
    return template


def main() -> None:
    args = parse_args()
    root = Path(args.root).resolve()
    if not args.project and not args.progress_dir:
        raise SystemExit("project is required unless --progress-dir is provided")
    if args.progress_dir:
        progress_dir = Path(args.progress_dir).resolve()
        project = args.project or progress_dir.parents[2].name
    else:
        project = args.project
        progress_dir = default_progress_dir(root, project)
    output = Path(args.output).resolve() if args.output else default_output(root, project)
    cache = output.with_suffix(".snapshot.json")
    state = assemble_state(progress_dir)
    stage = args.stage or infer_stage(state)
    previous: dict | None = None
    if not args.no_cache and cache.exists():
        try:
            previous = load_json(cache)
        except (SystemExit, json.JSONDecodeError):
            previous = None
    changed = changed_keys(previous, state)
    html_text = render_html(state, stage, changed)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html_text, encoding="utf-8")
    if not args.no_cache:
        cache.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
