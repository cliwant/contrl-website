# S4 편차 대응 — 미달 진단·처방·재배분 계약

`budget.py compare`가 `needs_review`를 냈을 때(미달 진단), 그리고 coordinator가 `deviation_groups` 재호출을 처리할 때 읽는다.
편차 임계·튜닝 상수는 budget.py 상단에, 유저와 처방을 정하는 흐름은 pipeline "편차 처리"(orchestrator 몫)에 있다 — 이 문서는 진단·처방의 정의와 실행 계약만 담는다.

## 미사용 재료와 확장 여력 (미달 진단의 정의)

"미사용 재료"는 ① 그 단원 섹션에 매핑됐지만 기존 슬라이드 어디에도 `source`로 쓰이지 않은 요구사항, ② 그 단원 슬라이드 불릿 어디에도 인용(`[cN]`/`[coN]`/`[cmN]`)되지 않은 slim 3C 아이템이다.
발굴은 `budget.py inventory`가 결정론으로 한다(추측 금지).
인용 강제 구조에서 콘텐츠는 재료 없이 늘지 않으므로, 미달 단원의 처방은 여력(headroom)이 가른다 — 여력이 있으면 재료 재주입 재생성이 의미 있고, 여력이 없으면 입력이 같아 재생성해도 결과가 달라지지 않으니 유저 보강 입력 또는 재배분이 처방이다.
유저가 보강 내용을 자유입력으로 줬으면 어느 처방에서든 그것을 최우선 재료로 주입한다.

## 진단·재배분 명령 (budget.py)

```bash
# 여력 진단 — compare가 미달을 플래그하면 coordinator가 즉시 실행해 보고서에 싣는다.
python3 "${CLAUDE_PLUGIN_ROOT}/skills/slide-contents/scripts/budget.py" inventory \
  --contents <slide_contents.json> --rfp <rfp.json> --framework <framework_3c.json>
# 재배분 — 유저가 수용한 미달 단원(--absorb)의 예산을 실제치로 낮추고 여력 있는 단원에 옮긴다.
python3 "${CLAUDE_PLUGIN_ROOT}/skills/slide-contents/scripts/budget.py" reallocate \
  --contents <slide_contents.json> --rfp <rfp.json> --absorb <g4,g5> --update-meta
```

- **inventory:** 그룹별 미사용 재료를 산출한다 — `unused_requirements`(id 목록), `uncited_3c`(id 목록), `headroom`(=미사용 요구사항 수). headroom만 여력 판정 기준이다 — 미인용 3C는 전 그룹이 공유하는 재료라 판정에 쓰지 않고 주입 보조 재료로만 쓴다.
- **reallocate:** `--absorb` 단원의 예산을 실제치로 낮추고, 남는 분량을 headroom 있는 단원에 배분한다(그룹별 증분은 headroom 이하로 캡). 여력 총량이 모자라면 `note:"insufficient_headroom"`과 미배분 `leftover`를 낸다. `--update-meta`가 새 예산과 `reallocated:true`를 `_meta`에 스탬프해 이후 compare가 새 예산 기준으로 돈다. 받을 단원만 미리 보려면 `--update-meta` 없이 dry-run 한다.

## 편차 재생성 (처방 실행)

compare `needs_review` 후 유저가 처방을 정한 단원만 대상으로 하는 부분 재실행의 특수형이다.
대상 단원 그룹만 다시 fan-out하되, orchestrator가 그룹별로 정해 넘긴 처방대로 payload를 조정한다 —

- **재주입 (미달 · 여력 있음):** 기존 `slide_budget` 유지 + inventory가 찾은 미사용 재료를 payload `expansion`(입력 계약은 `group_content.md`)으로 주입.
- **보강 (미달 · 유저 보강 입력 수령):** 기존 `slide_budget` 유지 + 유저 보강 텍스트를 `expansion.user_input`으로 주입(그 단원 미사용 재료가 있으면 함께). 보강 입력 없이 여력 0 단원을 재생성하지 않는다 — 입력이 같으면 결과도 같다.
- **확장 (재배분 수혜 단원):** `reallocate --update-meta`가 올린 새 `slide_budget` + 그 단원 미사용 재료를 `expansion`으로 주입. absorb된 단원은 예산이 실제치로 내려갔으므로 재생성하지 않는다.
- **압축 (초과 단원):** `slide_budget`을 낮춘 값(예산치)으로 다시 주입하고 `compress:true`를 덧붙인다(계약은 `group_content.md`).

재생성 후 다시 머지 → `compare --update-meta` → 보고. 반복 여부는 orchestrator가 유저와 정한다.
