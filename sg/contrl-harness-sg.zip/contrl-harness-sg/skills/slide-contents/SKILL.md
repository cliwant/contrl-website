---
name: slide-contents
description: >-
  CONTRL pipeline S4 — Slide Contents. Uses the selected Win Theme, Theme Statements, and requirement mapping to generate content for each leaf section, split it into slides, and write slide_contents.json.
  Use for slide-content generation, section content, slide splitting, or S4 execution.
---

# S4 — Slide Contents 생성 (Slide Contents)

## Customer Delivery Defaults

Generate all slide subtitles, headings, bullets, section content, labels, and progress-panel text in English. Translate Korean or other non-English source content into natural business English before writing `slide_contents.json`.

목차 구조(단원 → section → slide)를 그대로 따라 단원(level-1) 단위 fan-out으로 실행한다. leaf 섹션을 level-1 단원별 그룹으로 묶고, 단원마다 그룹 agent를 하나씩 띄운다. 그룹 agent는 그 단원의 모든 섹션 슬라이드(경계·블록·불릿)를 **한 번의 LLM 패스로 통째로** 생성한다. 병렬은 단원 단위에서만 일어나며, 섹션·슬라이드 단위로 다시 쪼개 fan-out 하지 않는다.
이렇게 하는 이유: 단원 하나는 보통 섹션 몇 개·슬라이드 십여 장이라, fan-out·재수집 overhead(특히 worker spawn/teardown 고정 비용)보다 한 패스 생성이 비용·일관성 면에서 낫다. 또 단원 전체를 한 컨텍스트에서 보므로 섹션 간 중복까지 제거할 수 있다(leaf당 worker였을 때는 섹션 로컬 dedup만 가능했다).
```
slide-contents-runner (coordinator)              ← 단원 동시 최대 5
  └─ slide-group-runner (단원당 1개, sonnet)      ← 단원의 모든 섹션 슬라이드를 한 패스로 생성
```
이 스테이지는 `agents/slide-contents-runner.md`가 coordinator로, `agents/slide-group-runner.md`가 작업자로 실행한다.

## 입출력 계약

- **입력:** `projects/{name}/artifacts/rfp/rfp.json`,
  `projects/{name}/artifacts/strategy/framework_3c.json`,
  `projects/{name}/artifacts/strategy/win_themes.json`(+선택 index),
  `projects/{name}/artifacts/strategy/theme_statements.json`, `leaves`(S3 leaf 파생 규칙 동일)
- **출력:** `projects/{name}/artifacts/slides/slide_contents.json` (`items[]` + `_meta.slide_budget` — 아래 "분량 모드와 예산" 절)
- **출력 (패널, read-only 파생물, gate 비대상):** `projects/{name}/outputs/slides/slide_contents.html` — 생성 진행·결과를 사용자에게 보여주는 단일 contrl-shell 패널(`S4`) + 작업용 `outputs/slides/.sc_progress/`. 렌더 메커닉은 아래 "진행·결과 패널" 절을 따른다. 렌더 실패는 스테이지를 막지 않는다.

## 분량 모드와 예산 (budget.py)

S4는 두 분량 모드 중 하나로 돈다. 모드 결정(유저 질문·재실행 시 유지)은 orchestrator(`pipeline`) 책임이고, 이 절은 모드의 의미·budget.py 호출 계약·`_meta` 계약을 정의한다.

- **자유 모드 (`free`):** 분량 제약 없음. theme statement·매핑 요구사항이 슬라이드 수를 결정한다. 프롬프트에 분량 지시를 넣지 않는다.
- **예산 모드 (`budget`):** rfp.json `required_proposal_structure.page_limit`을 **목표치(target)** 로 삼는다 — 상한이 아니라 "비슷한 장수"이며, 사람이 사후 조정할 수 있으니 큰 편차만 막는다. 본문 예산 = `page_limit − front matter`(S5가 더하는 cover/TOC 몫, 기본값은 budget.py `FRONT_MATTER`).
  - **유저 지정 목표:** `page_limit`이 null이라 orchestrator가 유저에게 목표 장수 N을 받아온 경우(pipeline "S4 분량 모드 선택"), N은 **본문 목표 그대로** 쓴다(front matter를 빼지 않는다). coordinator는 allocate를 `--page-limit N --front-matter 0`으로 호출하고, `_meta.slide_budget`에 `"source":"user"`를 덧붙인다(rfp 유래면 `source` 생략). 재실행·부분 재실행 시에도 이 `_meta` 값을 그대로 이어받는다.

**예산 배분·검증은 결정론 스크립트가 한다:** `scripts/budget.py` (stdlib-only).

```bash
# 배분 — coordinator가 plan.json 기록 직후 실행. --update-plan이 그룹별 slide_budget을 plan.json에 스탬프.
python3 "${CLAUDE_PLUGIN_ROOT}/skills/slide-contents/scripts/budget.py" allocate \
  --plan <.sc_progress/plan.json> --rfp <artifacts/rfp/rfp.json> --page-limit <N> --update-plan
# 비교 — coordinator가 머지 저장 직후 실행. --update-meta가 실제치를 _meta에 기록.
python3 "${CLAUDE_PLUGIN_ROOT}/skills/slide-contents/scripts/budget.py" compare \
  --contents <artifacts/slides/slide_contents.json> --update-meta
```

- **allocate:** leaf 수·매핑 요구사항 수 기반 가중치로 본문 목표치를 그룹에 배분한다 — 그룹당 하한은 leaf당 1장, 합계 = 목표치 보장. 하한 합이 목표치 이상이면 하한 그대로 두고 `note:"target_below_floor"`.
- **compare:** 그룹·총합 편차를 플래그해 `needs_review`와 `candidates`(편차 기여가 큰 단원 순 재생성 후보)를 낸다. `needs_review`가 true면 orchestrator가 유저와 처방을 정한다.
- 가중치·배분 산식, 편차 임계식, 튜닝 상수(`FRONT_MATTER` 등)는 budget.py 상단이 단일 소스다. 상수는 전부 CLI 플래그로도 override 가능.

**편차 대응은 `references/deviation-regeneration.md`로 분리돼 있다** — compare가 `needs_review`를 내면(미달 여력 진단·`inventory`), 그리고 `deviation_groups` 재호출을 처리할 때(처방 4종·`reallocate`) 그 문서를 읽고 따른다. 편차가 없는 실행에서는 읽지 않는다.

**`_meta.slide_budget` 계약 (slide_contents.json):** 재실행 시 orchestrator가 모드를 유지·판별하는 근거이자 패널 표시의 소스다.
```json
{"_meta": {"slide_budget": {
  "mode": "budget",
  "page_limit": 30, "front_matter": 2, "target_body": 28, "note": null,
  "groups": [{"group_id": "g1", "parent_path": "...", "section_ids": ["sec_0001"],
              "leaf_count": 1, "req_count": 3, "weight": 2.5, "budget": 4, "actual": 5}],
  "actual_body": 27
}}}
```
자유 모드는 `{"_meta": {"slide_budget": {"mode": "free"}}}`만 기록한다. `groups[].budget/weight`는 allocate 출력을 coordinator가 그대로 싣고, `actual`/`actual_body`는 `compare --update-meta`가 채운다. 편차 재배분이 실행됐으면 `reallocated:true`가 덧붙고 `groups[].budget`이 새 예산으로 갱신된다.

## 진행·결과 패널 (slide_contents.html) — 렌더 메커닉 단일 소스
유저가 대기 중 중간 결과를 보도록, 단원 fan-out 진행을 디스크 고정 경로 HTML 패널로 보여준다(theme-statements S3와 동형). 시드 렌더 후 단원이 도착할 때마다 덮어쓰기로 in-place 갱신하며, 같은 패널이 `done`에서 완성 덱이 된다.

**작업 파일 (`outputs/slides/.sc_progress/`).** 병렬 worker의 동시 쓰기 race를 피하려고 공유 mutable JSON을 쓰지 않고 **파일을 쪼갠다**:
- `plan.json` (coordinator가 fan-out 전에 1회 기록 = 시드 구조). 섹션 제목은 coordinator가 rfp.json에서 resolve해 실어 둔다:
  ```json
  {"project":"name","win_theme_headline":"...","groups":[
    {"group_id":"g1","parent_path":"Ⅰ. 사업 일반","sections":[
      {"section_id":"sec_0001","title":"1. 사업 개요"}]}]}
  ```
  예산 모드면 `budget.py allocate --update-plan`이 여기에 top-level `budget`(`{mode,page_limit,front_matter,target_body,note}`)과 그룹별 `slide_budget`을 스탬프한다. 렌더러는 이 필드가 있으면 헤더에 목표/실제 총합을, 그룹 헤더에 `예산 N장 대비 실제 M장` 편차를 표시한다(없으면 자유 모드 — 분량 표시 없음).
- `group-{group_id}.json` (각 worker가 자기 것만 기록 = 그 단원의 GroupSlides + status):
  ```json
  {"group_id":"g1","status":"done|failed","sections":[
    {"section_id":"sec_0001","slides":[
      {"source":"section|{req_id}","subtitle":"...","blocks":[{"heading":"...","body":["..."]}]}]}]}
  ```
렌더러는 `plan.json` + 존재하는 `group-*.json`을 합쳐 읽는 **순수 함수** — 아직 없는 단원은 "group-runner 작업 중"으로 그려지고 다음 렌더에서 채워진다. 슬라이드 `source`는 `section`이면 "본문", 그 외는 "요구사항 {id}" 칩으로 표시한다.

**렌더 명령** (CWD가 유저 레포라 상대경로 불가 → 스크립트는 `${CLAUDE_PLUGIN_ROOT}`, 출력 루트는 절대경로):
```bash
python3 "${CLAUDE_PLUGIN_ROOT}/skills/slide-contents/scripts/render-progress-html.py" \
  <project_name> --root "<projects/ 가 있는 절대경로>" [--stage generating|merging|done]
```
출력 `projects/{name}/outputs/slides/slide_contents.html`. snapshot 캐시(`*.snapshot.json`)로 직전 대비 새로 도착한 섹션을 강조. `--stage` 생략 시 단원 완료 수로 추정.

**렌더 호출 시점:**
1. **시드 렌더 (coordinator, fan-out 전 1회):** `plan.json` 기록 후 패널을 렌더한다.
2. **worker 완료마다:** worker가 자기 `group-{id}.json` 기록 직후 렌더(덮어쓰기) → 해당 단원이 in-place로 채워진다. 동시 완료는 last-writer-wins(전체 union을 렌더하므로 최신은 항상 정합).
3. **머지 후 coordinator:** `slide_contents.json` 저장 시 `--stage done`으로 최종 렌더(완성 덱).

**canonical 폴백 렌더 (`render-contents-html.py`).** live 진행 dir이 없는 재렌더(완료된 프로젝트 재오픈 등)는 머지된 `slide_contents.json`을 직접 읽어 같은 `slide_contents.html`로 렌더한다 — `python3 "${CLAUDE_PLUGIN_ROOT}/skills/slide-contents/scripts/render-contents-html.py" <project_name> --root "<절대경로>"`. 진행 패널과 출력 경로가 동일하다.

## 게이트 (orchestrator 책임)
이 스테이지의 사전조건(위 입력 아티팩트 4개 존재, `win_theme_index >= 1`, leaf ≥ 1개)은 orchestrator(`pipeline`)가 `gate S4 before` + 선택 흐름으로 검증한다. coordinator는 게이트를 재검증하지 않고 통과된 입력을 신뢰해 바로 fan-out에 들어간다. 산출물 측 검증(섹션 스키마·정렬·머지)은 게이트가 아니라 coordinator가 유지한다.

## 단원 그룹핑 (결정론, S3 A-0와 동일)
leaf 파생 규칙으로 leaf를 도출한 뒤 `parent_path`(level-1)별로 묶어 그룹을 만든다. 한 그룹 = 한 level-1 단원 + 그 leaf들(자식 없는 level-1은 mirror leaf 1개짜리 그룹). `group_id`는 등장 순 `g1,g2,…`. 그룹이 1개여도 그대로 그룹 1개로 fan-out한다 (단원 payload가 무거워 전체를 1콜로 합치는 폴백은 두지 않는다 — truncation·직렬 decode 위험).

## 절차 (단원 단위 fan-out — 단원 동시 5)

### Layer 0 — coordinator (`slide-contents-runner`)
위 규칙으로 단원 그룹을 만들고, fan-out 전에 `.sc_progress/plan.json`(섹션 제목 포함)을 기록한다. **예산 모드면** 직후 `budget.py allocate --update-plan`(위 "분량 모드와 예산")으로 그룹별 예산을 계산해 plan.json에 스탬프하고, 각 그룹 payload에 `slide_budget`을 싣는다(자유 모드는 이 단계 전체 생략 — `slide_budget` 미주입). 이어 시드 패널을 1회 렌더한다(위 "진행·결과 패널"). 그룹마다 `slide-group-runner`를 하나씩 띄운다 — **동시 최대 5단원**, 더 많으면 slot이 비는 대로 이어서 실행한다. 각 worker에 progress dir 경로를 넘겨 worker가 자기 `group-{id}.json` 기록 + 재렌더를 하게 한다. 콘텐츠를 직접 만들지 않고, 그룹이 반환한 `sections[]`를 펼쳐 모아 `section_id` 정렬(`sec_NNNN`, `-` 서브 순) 후 `_meta.slide_budget`(allocate 출력 기반, 자유 모드는 `{"mode":"free"}`)과 함께 `slide_contents.json`에 저장·머지한다. 예산 모드면 저장 직후 `budget.py compare --update-meta`를 돌려 실제치를 `_meta`에 채우고 compare 보고서를 반환값에 싣는다 — 미달 플래그가 있으면 `budget.py inventory`도 돌려 여력 보고서를 함께 싣는다(orchestrator 진단용). 마지막으로 `--stage done`으로 최종 패널을 렌더한다.

### Layer 1 — group agent (`slide-group-runner`, 단원당 1개, leaf)
배정된 단원 그룹 하나를 맡아 그 단원의 모든 섹션 슬라이드를 한 패스로 생성한다.
1. 단원 payload 조립 (coordinator가 JSON으로 조립해 주입):
   - 단원의 각 섹션마다: theme statement (theme_statements.items 중 section_id 매칭),
     매핑된 요구사항 (rfp.json `requirement_mapping`에서 그 섹션에 배치된 req_id →
     `requirements[]`에서 본문 조회)
   - 단원 공통: 관련 3C (slim 형태), win theme 컨텍스트(선택 테마), project_overview(rfp.json), 예산 모드면 `slide_budget`(allocate가 계산한 이 단원 예산), 편차 재생성이면 `expansion` 또는 `compress`
2. **단원 슬라이드 생성 (LLM, 한 패스):**
   - 지시 문서: `references/group_content.md` 하나 — payload 입력 계약·출력 스키마·작성 규칙·인용 규칙을 모두 담는다. 템플릿 렌더링 없음: worker가 이 문서를 지시로 읽고 coordinator가 조립한 payload JSON을 입력으로 받는다.
   - 출력 **GroupSlides**: 이 단원 모든 섹션의 슬라이드 경계·블록 배분·불릿을 한 번에 결정한다 (아래 스키마). section narrative 슬라이드는 `source:"section"`, 요구사항 응답 슬라이드는 `source:"{requirement_id}"`. 한 아이디어·요구사항·근거는 이 단원 안에서 정확히 한 슬라이드/블록에만 배정한다 — 섹션 내부뿐 아니라 형제 섹션끼리도 반복 금지.
3. 생성한 GroupSlides를 스키마 자가검증 후 반환한다. canonical(`slide_contents.json`)은 쓰지 않고, 자기 `.sc_progress/group-{id}.json` partial 기록 + progress HTML 재렌더만 디스크에 한다.

부분 재실행: `section_ids` 지정 시 그 섹션들이 속한 단원만 재생성하고 기존 artifact와 머지한다. 진행 패널을 통째로 유지하려면 coordinator가 시드 `plan.json`을 전체 leaf로 기록하고, 재생성 대상이 아닌 단원의 `group-{id}.json`은 기존 artifact에서 미리 채운 뒤 대상 단원만 fan-out한다. 모드·예산은 기존 `_meta.slide_budget`을 그대로 이어받는다(재배분하지 않음).

## GroupSlides 스키마 (group agent LLM 출력, 단원당)
한 패스로 단원의 모든 섹션 슬라이드(경계·블록·불릿)를 채운, 이 단원의 완성된 슬라이드 묶음이다.
```json
{
  "group_id": "g3",
  "sections": [{
    "section_id": "sec_0007",
    "slides": [{
      "source": "section" | "{requirement_id}",
      "subtitle": "슬라이드 부제",
      "blocks": [{"heading": "블록 주제 라벨", "body": ["불릿/문장", "..."]}]
    }]
  }]
}
```

## slide_contents.json 스키마 (최종, 머지 후)
```json
{
  "_meta": {"slide_budget": {"...": "위 '분량 모드와 예산' 절의 계약"}},
  "items": [{
    "section_id": "sec_0003",
    "slides": [{
      "source": "section" | "{requirement_id}",
      "subtitle": "슬라이드 부제",
      "blocks": [{"heading": "블록 주제 라벨", "body": ["불릿/문장", "..."]}]
    }]
  }]
}
```
모든 객체 `additionalProperties:false`. 최종 `items[]`는 각 그룹 agent가 반환한 GroupSlides의 `sections[]`를 펼쳐 `section_id` 정렬해 모은 것이다.

## 검증
- 각 section_id가 leaf 집합에 속하고, 머지된 section_id 집합 = 전체 leaf 집합(개수·집합 일치).
- 그룹(단원) 전부 실패 시 `all_groups_failed` — 일부 단원 실패는 `partial`로 허용하되 실패 목록(group_id + section_id)을 보고 (silent drop 금지).
- 저장 전 section_id 정렬. 각 슬라이드에 `source`·`subtitle`이 있고 모든 block에 `heading` + 비어 있지 않은 `body`가 있는지 확인.
- `_meta.slide_budget.mode`가 기록돼 있는지 확인. 예산 모드면 `compare --update-meta` 실행 + 보고서 반환이 완료 조건이고, 미달 플래그가 있으면 `inventory` 여력 보고서 반환까지 포함이다.
