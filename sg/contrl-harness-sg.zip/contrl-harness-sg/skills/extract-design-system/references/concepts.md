# Concepts — the design-system model

A proposal deck is built from a small set of reusable visual building blocks. This skill names
them so a later *build* stage can assemble new proposals by selecting and filling them. Read this
once; the vocabulary is used throughout the pipeline.

## Vocabulary

| Term | What it is |
|---|---|
| **Intent** | The *rhetorical role* a slide plays (cover, objective, system-architecture, test-plan…). One per slide. Never a visual shape — "what the slide is *for*", not what it looks like. |
| **Layout** | The *fixed frame* a slide sits in = a **Slide Master** (deck-wide background/logo/page-number) + a **Slide Layout** (the per-section frame: header band, chapter marker, footer, and the empty body region). Stays the same as body content changes. |
| **content_box** | The empty rectangle inside a Layout where body content goes = the slide area minus the fixed frame furniture. |
| **Adornment** | A *fluid decoration* in the body — a thin header/label band (ruled subhead, triangle-bullet label, colored band) that introduces a block. Recurs across slides with different text; clustered by **visual form**, layout-agnostic. |
| **Variant** | An *atomic, reusable visual unit* of body content (a card row, a table, a diagram, a two-panel comparison…). Global and intent-agnostic — the same variant can appear under many intents. Clustered by **structure**. |
| **Slot** | A fillable region inside a Variant/Adornment (or a Layout placeholder). Has a `kind`, a `target` (the OOXML/shape anchor), and fill guidance. |
| **Block** | A runtime grouping = one Adornment header + the Components under it. Not stored — it's how a slide body is segmented. |
| **Component** | (Intent, Variant) pairing at use-time. Not a stored pool. |

**Why the separation:** the *fixed frame* (Layout), the *role* (Intent), the *reusable atoms*
(Variant), the *decorations* (Adornment), and the *fillable regions* (Slot) vary independently. Pulling
them apart is what lets the build stage recombine them for any new proposal.

## Outputs

Two files (+ per-entity disk artifacts):

- **`catalog.json`** — the reusable *selection index* (what the build stage reads). Pools:
  `intents[]`, `variants[]`, `adornments[]`, `layouts[]`, `masters[]`, plus `meta`.
- **`evidence.json`** — per-slide *observations of the source template* (the derivation record /
  reference; not read by the build). `slides[]` each with `intent_id`, `layout_id`, and
  `occurrences[]` (which variants/adornments appeared, where, with what sample values).
- **`media/`** — shared, content-addressed pool of the body icons the carved fragments embed
  (`<hash>.<ext>`, deduped). A variant/adornment that embeds icons ships a sibling
  `shapes.xml.rels` (`artifacts.rels`) mapping its `<a:blip r:embed>` rIds → `../../media/<file>`,
  so the render stage re-homes the icons instead of leaving them dangling.

### catalog.json — key fields per pool

```
meta        { source_template, slide_emu{w,h}, schema_version }
intents[]   { id, name, description, allowed_variant_ids[], layout_affinity[], cooccurs_with[] }
variants[]  { id, name, description, size_emu, slots[], used_by_intents[], artifacts{shapes,preview,rels?} }
adornments[]{ id, name, note, size_emu, slots[], artifacts{shapes,preview,rels?} }
layouts[]   { id, name, master_id, note, content_box, furniture[], placeholders[], artifacts{frame_bundle} }
masters[]   { id, name, note, placeholders[], decorations[], artifacts{frame_bundle} }
```

### Slot shape (variants/adornments and layout placeholders)

```
{ name, kind, target, description, convention?, cardinality?, subslots? }
```
- `kind` ∈ `text · richtext · image · repeated · table · composite` (closed set).
- `target` = the OOXML/shape anchor: `{shape_id}` · `{shape_ids[]}` · `{a_t_xpath}` · `{pic_index}`
  for variant/adornment slots; `{ph_type, ph_idx}` for layout placeholders. **Never edited** once set.
- `cardinality` = `{base, resizable, min, max}` — required on `repeated`/`table`. `base` is the
  observed count (mechanical fact); `resizable`/`min`/`max` is judgment.
- `subslots` — only on `repeated`/`composite` (never on `table`).
- `name` = form/role, never content (`title`/`items`/`cards`, not `team_members`). For **layout
  placeholders** the `name` is also the **join key** the build stage routes fills to, so it must be
  semantic and unique within the layout. `description` = what it is; `convention` = how to fill it.

## Principles

- **Variant atomicity** — variants are atomic, global, intent-agnostic. The catalog grows by adding
  *new atomic variants*, not mega-composites. If a body stacks [variant A] over [variant B], that's
  two variants. A repeating set (3 identical cards) is *one* variant with internal repetition.
- **Adornment ≠ content** — an adornment *names* a block (a short header/label). A band that carries
  information (multi-line text, a list, data) is *content* (a variant or part of one), not an adornment.
- **No orphans** — every content-bearing shape ends up under a slot, and decorative-only shapes are
  marked fixed/omitted.

