---
name: extract-design-system
description: Mine a single PPTX proposal template into a reusable design-system catalog — the Intents, Layouts, Adornments, Variants, and Slots a later build stage uses to assemble new proposals. Produces catalog.json (reusable selection index) + evidence.json (per-slide source observations) + per-entity artifacts. Use this whenever you need to extract or rebuild a design system from a .pptx template, turn a proposal deck into reusable building blocks, or catalog a template's layouts/components/slots — even when the user just says "extract the design system", "catalog this template", or "break this deck into reusable parts".
---

# extract-design-system

Turn **one** PPTX proposal template into a **reusable design-system catalog**. A proposal deck is
built from a small set of repeating building blocks — fixed page frames, recurring decorations,
reusable body components, and the fillable regions inside them. This skill pulls those apart and
records them so a later *build* stage can assemble brand-new proposals by selecting and filling them.

You (Claude) are the orchestrator: you read this file and drive the pipeline. The pipeline is
mostly self-explanatory once you hold the model in §Mental model — so prefer understanding *why*
each stage exists over running commands by rote. When a template breaks an assumption (no
adornments, an odd frame), reason about it rather than forcing the steps.

## Requirements

Runs **inside Claude Code / the Agent SDK** — mechanical steps are Bash scripts and judgment steps
are dispatched as **subagents (the Agent tool)**, so it needs an environment with Bash + subagent
dispatch (not the plain claude.ai chat sandbox). Runtime deps:

- **LibreOffice** — the `soffice` binary on `PATH` (renders PPTX → PNG). Install separately.
- **Fonts** covering the deck's language (e.g. a Korean font for Korean RFP decks) so renders aren't tofu.
- **Python 3** + the libs in `requirements.txt`: `pip install -r "$SK/requirements.txt"` (lxml,
  python-pptx, Pillow, markitdown).

Otherwise self-contained — the skill carries its own `scripts/_lib/` (no cross-skill imports), so the
folder can be dropped into any Claude Code project's `.claude/skills/` (or `~/.claude/skills/`).

## What it produces

Under a run directory of your choice (`<run>/` — any fresh dir; every script takes `--run`, so the
path is up to you; this repo uses `extract-design-system/outputs/<YYYY-MM-DD>_<source>[_label]/` by convention):

- **`catalog.json`** — the reusable *selection index*; the build stage reads only this. Pools:
  `intents · variants · adornments · layouts · masters` (+ `meta`).
- **`evidence.json`** — per-slide *observations of this template* (the derivation record): each slide's
  intent, layout, and the variant/adornment occurrences with their sample values.
- per-entity disk artifacts (`variants/<id>/`, `adornments/<id>/`, `frame/`) and `catalog.html` — a
  **self-contained** viewer with every slide render and preview inlined (downscaled base64), so it
  shows the same however a reviewer opens it (browser, macOS Quick Look, an editor's HTML preview).
  It must never depend on sibling-file relative paths: a sandboxed viewer blocks those and the whole
  deck silently renders blank — which defeats the gate review the viewer exists for.
- Work-in-progress intermediates live under `_work/`; the canonical files sit at the run-dir top.

## Mental model

Five things vary independently in a deck, so the pipeline extracts them as separate concerns:

- **Intent** — a slide's rhetorical role (one per slide). *What the slide is for*, not what it looks like.
- **Layout** — the fixed page frame (Slide **Master** + Slide **Layout**): header band, chapter marker,
  footer, and the empty **content_box** where body goes.
- **Adornment** — a fluid decoration in the body: a thin header/label band that introduces a block.
- **Variant** — an atomic, reusable body component (card row, table, diagram…). Global, intent-agnostic.
- **Slot** — a fillable region inside a Variant/Adornment, or a Layout placeholder.

**Read `references/concepts.md`** for the full vocabulary, the `catalog.json`/`evidence.json` schema,
and the atomicity principles. The detailed judgment rules for each LLM step live in that step's
`prompts/*.md` — consult them when you run that step, not before.

## How extraction works (the shape, and why)

Two independent readings happen first — the **frame** (Layout) and the **role** (Intent), neither of
which looks at body content. They then **converge** so the body can be decomposed into Variants +
Adornments; those get **Slots**; finally the whole thing is **validated**.

Two ideas make this robust:

- **Progressive registration.** Each stage writes its own pool straight into `catalog.json` /
  `evidence.json` (via `catalog_compile.py`). There is no big end-of-run translation step, so what
  you review at each gate is the *real* output, and a re-run of one stage updates just its pool.
- **Stage gates pause for a human.** At each stage boundary, render the current catalog and **stop** —
  a person reviews before the next stage runs. Don't auto-advance past a gate.

Resumability is free: every mechanical script is idempotent (it skips entities whose output already
exists), so a stopped run continues by re-running from where it left off.

```
1 준비 → (2 레이아웃 ∥ 2 인텐트) → ▣gate → 3 본문 추출 → ▣gate → 4 슬롯 → ▣gate → 5 검증
```

## Running it

Set up once:
```bash
SK=.claude/skills/extract-design-system   # = this skill's own folder; adjust if installed elsewhere
                                          #   (e.g. ~/.claude/skills/extract-design-system for a user-level install)
RUN=<workdir>/<YYYY-MM-DD>_<source>       # any fresh run dir — scripts take --run, not tied to a fixed path
mkdir -p "$RUN"
```
All `prompts/…` and `references/…` paths below are under `$SK` (i.e. `prompts/x.md` = `$SK/prompts/x.md`).
Below, **⚙️ = run the script (Bash)**, **🧠 = dispatch a subagent with the prompt (or, if you're the
one doing it, follow the prompt yourself)**, **▣ = render the catalog and pause for review**.

### Stage 1 — 준비 (⚙️)
Unpack the template into the raw material every later stage reads: per-slide shape XML, slide
renders, text, and a structural fingerprint of each slide.
```bash
python3 $SK/scripts/pptx-preprocess/preprocess.py --pptx "<template.pptx>" --build-dir "$RUN"
python3 $SK/scripts/fingerprint.py --run "$RUN"
python3 $SK/scripts/frame_parse.py --run "$RUN" --pptx "<template.pptx>"   # → frame.json + the frame/ bundle (original presentation·slideLayout·slideMaster·theme·media+rels + manifest.json) that layouts/masters ship as their artifact
```

### Stage 2 — 레이아웃 ∥ 인텐트 (independent — do both)
The fixed frame and the slide roles don't depend on each other; run them together.

*Layout* — collapse duplicate slide layouts into a canonical set, derive each one's `content_box`
from its real frame furniture, then give its placeholders meaning so the build stage can route
content to them:
```bash
python3 $SK/scripts/layout_build.py    --run "$RUN" --out "$RUN/_work/layout"   # dedup · content_box · placeholder skeleton
python3 $SK/scripts/render_layouts.py  --run "$RUN" || true                     # (optional) layout previews for the next step
```
🧠 `prompts/layout_placeholder_annotate.md` — re-curate each placeholder's `name` (the join key) and
add `description`/`convention`; never touch `kind`/`target`. → `$RUN/_work/layout/ph_annot.json`

> **Watch for slide-drawn frame furniture (header/breadcrumb).** Some decks draw the page header band
> (section breadcrumb + page title) as per-slide body shapes rather than in the slideLayout — so
> `frame_parse` sees no furniture and a full-slide `content_box`, and distinct page types (a bare
> full-bleed page vs a standard body page with a header) collapse into one dedup'd layout, leaking the
> repeating header into the body as an adornment. If a header strip recurs across many body pages,
> **split the layout** into a header-bearing one (with `section_breadcrumb`/`page_title` placeholders and
> a `content_box` below the band) and a bare one, remap the header slides, and keep the header out of the
> adornment pool.

*Intent* — 🧠 `prompts/intent_discover.md` — one rhetorical intent per slide, consolidated by role,
covering every slide. → `$RUN/intent_discovery.json`

Then register + gate:
```bash
python3 $SK/scripts/catalog_compile.py --run "$RUN"    # writes layouts/masters/intents into catalog.json + evidence
python3 $SK/scripts/catalog_html.py    --run "$RUN"    # → catalog.html
```
**▣ gate** — review the layout pool (placeholders now meaningful) + the intent mapping, then continue.
Checklist: (a) does every layout's `content_box` exclude the real frame furniture? (b) is a header /
breadcrumb that **repeats on every body page** captured as a layout placeholder — not left to surface
later as a body adornment (see the slide-drawn-furniture note above)? (c) are distinct page types
(full-bleed vs header-bearing) actually separate layouts, or wrongly merged by a shared empty slideLayout?

### Stage 3 — 본문 추출 (Adornments + Variants)
Decompose the body (what's inside `content_box`, frame excluded) into reusable units. A vision pass
splits each slide body into blocks of `[adornment header] + [variant region(s)]`; the regions are
then clustered two ways — variants by **structure**, adornments by **visual form** — and each
canonical entity is **carved to disk** (`shapes.xml` = the authoritative geometry the slot stage
reads; `preview.png` = the catalog thumbnail) so Stage 4 has something to tag. Carving also
**re-homes the embedded icons**: the media each fragment's `<a:blip r:embed>` references is copied
into the shared `media/` pool (deduped) and a sibling `shapes.xml.rels` is written, so the icons
resolve at render time instead of dangling (needs slide rels + media from `preprocess`).
```bash
python3 $SK/scripts/body_extract_prep.py --run "$RUN" --out "$RUN/_work/body/prep"   # per-slide body-shape inventory + render (content_box from each slide's mapped layout)
```
- 🧠 `prompts/body_extract.md` (per slide) — read `prep/slide_<n>.json` + the render; write
  `$RUN/_work/body/split/slide_<n>.json` with `units[]` (each `{bbox_emu, kind, shape_ids, label}`).
  `shape_ids` is required — the carve in `body_register` depends on it.
```bash
python3 $SK/scripts/body_crop.py --run "$RUN" --splitdir "$RUN/_work/body/split" --out "$RUN/_work/body"   # crops + contact sheets + manifest (carries shape_ids)
```
- 🧠 `prompts/body_cluster.md` — cluster the crops into canonical variant/adornment pools + name them → `$RUN/_work/body/clusters.json`.
- 🧠 `prompts/body_kind_audit.md` — re-judge each canonical adornment type; emit a verdict per type → `$RUN/_work/body/kind_audit.json`.
```bash
python3 $SK/scripts/body_register.py   --run "$RUN"   # reads clusters.json + applies kind_audit.json verdicts (content→variant), then carves <pool>/<id>/{shapes.xml,preview.png(,shapes.xml.rels)} + re-homes icons → media/ pool + _work/body/pools.json + variants.json
python3 $SK/scripts/catalog_compile.py --run "$RUN" && python3 $SK/scripts/catalog_html.py --run "$RUN"
```
- **▣ gate** — variants/adornments now carry previews + slots-to-be; the overview shows occurrence overlays.

### Stage 4 — 슬롯 (per entity)
Define the fillable regions of each Variant and Adornment. Slots attach to the *canonical entity*
(tagged once, not per occurrence), read from the entity's `shapes.xml` (not the preview, which is a
crop that can show neighbors).
```bash
python3 $SK/scripts/slot_tag_prep.py --run "$RUN"      # per-entity inventory + batches of untagged entities
```
- 🧠 `prompts/slot_tag.md` (parallel fan-out) — per-entity `slots.json`.
```bash
python3 $SK/scripts/cardinality_base.py --run "$RUN"   # base count = actual shape count (mechanical, never guessed)
python3 $SK/scripts/catalog_compile.py  --run "$RUN"   # re-assemble: merges per-entity slots.json into catalog + pushes observed values → evidence
```
- 🧠 `prompts/slot_qa.md` → ⚙️ `slot_qa_report.py` — audit slot tagging; re-tag the ones flagged major.
- **▣ gate**

### Stage 5 — 전체 검증 (⚙️)
Cross-references (`variant.used_by_intents`, `intent.allowed_variant_ids`, `intent.layout_affinity`,
`intent.cooccurs_with`) are **derived automatically inside `catalog_compile.py`** — a pure function of
the per-slide evidence, recomputed on every run (layout_affinity/cooccurs_with already fill at gate ②;
the variant↔intent maps fill once stage 3 records occurrences). So just recompile once more so the
final catalog reflects all occurrences, render the viewer, **package the run** (tuck stage
intermediates into `_work/` so the top level is exactly the deliverable set), and validate. The
audit is the single gate — beyond schema/closed-fields/completeness it now also checks the **disk**:
every `artifacts.*` path (incl. the `frame/` bundle) resolves and is non-empty, the per-entity dirs
match the pools (no orphans), and the run **surface** holds only deliverables. So the manual
"did the right files get produced / is there cruft" review is now automated here.
```bash
python3 $SK/scripts/catalog_compile.py --run "$RUN"    # refresh derived cross-refs
python3 $SK/scripts/catalog_html.py    --run "$RUN"
python3 $SK/scripts/package_run.py     --run "$RUN"    # tidy: top-level intermediates + per-entity working files (slots.json…) → _work/, leaving the clean design-system surface
python3 $SK/scripts/schema_audit.py    --run "$RUN"    # must PASS (schema + disk artifacts + clean surface)
```

## References
- `references/concepts.md` — vocabulary, `catalog.json`/`evidence.json` schema, atomicity principles.
- `prompts/*.md` — the detailed judgment rules for each 🧠 step (read when you run that step).

## Repair
- `scripts/backfill_media_rels.py --ds <design_system_dir> --source <template.pptx>` — for a design
  system extracted **before** icon re-homing (carved `shapes.xml` with dangling `<a:blip r:embed>`,
  no `media/` pool): reconstructs the `media/` pool + per-entity `shapes.xml.rels` from the source
  template and records `artifacts.rels`. Idempotent; matches each fragment to its source slide by
  shape-id + embed-id.

## Stage discipline
This is an **extract** task over one specific template, so template-specific observations are fine —
but the *code and prompts* must stay template-agnostic (no sample literals, no hard-coded slide
counts or ids). Success isn't "it ran"; it's a catalog whose pools and granularity hold up under the
gate reviews and pass `schema_audit`.
