#!/usr/bin/env python3
"""package_run: finalize a Phase-0 run by tidying the run-dir *surface*. Phase-0's deliverable is a
small set — `catalog.json` + `evidence.json` + `catalog.html` + the `frame/` bundle + the per-entity
`variants/`·`adornments/` dirs. Every other top-level entry is a stage intermediate that should live
under `_work/`, not on the deliverable surface. This step MOVES (never deletes) those intermediates
into `_work/`, so the run stays reproducible/resumable while the top level reads as the spec output.

Run it at the end of Stage 5, before the final schema_audit (the audit enforces the clean surface).
Idempotent: re-running finds nothing left to move."""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

# What legitimately sits at the run-dir top. Everything else → _work/.
DELIVERABLES = {
    "catalog.json", "evidence.json", "catalog.html",   # the contract + viewer
    "frame", "variants", "adornments",                 # frame bundle + per-entity artifacts
    "media",                                            # shared content-addressed icon pool
    "meta.json",                                        # optional run provenance
    "_work",                                            # the intermediate bin itself
}
# Inside variants/<id>/ and adornments/<id>/, only these ship — the spec disk artifacts.
# shapes.xml.rels rides along when the fragment embeds icons (maps its rIds into media/).
# Tagging working files (_inventory.txt, slots.json, slot_qa.json) get tucked into _work/entities/.
ENTITY_KEEP = {"shapes.xml", "preview.png", "shapes.xml.rels"}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    args = ap.parse_args()
    R = Path(args.run)
    work = R / "_work"
    work.mkdir(exist_ok=True)
    moved = []
    for child in sorted(R.iterdir()):
        if child.name in DELIVERABLES:
            continue
        dest = work / child.name
        if dest.exists():                 # replace a stale prior copy
            shutil.rmtree(dest) if dest.is_dir() else dest.unlink()
        shutil.move(str(child), str(dest))
        moved.append(child.name)

    # strip per-entity working files so variants/<id>/·adornments/<id>/ hold only shapes.xml+preview.png
    stripped = 0
    for pool in ("variants", "adornments"):
        pdir = R / pool
        if not pdir.is_dir():
            continue
        for ent in sorted(p for p in pdir.iterdir() if p.is_dir()):
            for f in sorted(ent.iterdir()):
                if f.name in ENTITY_KEEP:
                    continue
                dest = work / "entities" / pool / ent.name / f.name
                dest.parent.mkdir(parents=True, exist_ok=True)
                if dest.exists():
                    shutil.rmtree(dest) if dest.is_dir() else dest.unlink()
                shutil.move(str(f), str(dest))
                stripped += 1

    top = f"moved {len(moved)} top-level intermediate(s)" if moved else "surface already clean"
    ent = f", stripped {stripped} per-entity working file(s) → _work/entities/" if stripped else ""
    print(f"package_run: {top}{ent}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
