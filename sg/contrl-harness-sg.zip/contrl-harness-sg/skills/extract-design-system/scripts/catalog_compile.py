#!/usr/bin/env python3
"""catalog_compile: assemble catalog.json + evidence.json from whatever stage outputs exist
(progressive / idempotent). Each stage registers its pool; this re-derives the canonical
catalog from the intermediates present so far. At the gate-② point only layouts/masters/intents
are populated (variants/adornments empty).

Reads (all optional except frame.json):
  <run>/frame.json                         slide_emu · masters · slide_layout_map (raw)
  <run>/_work/layout/layouts.json          canonical layouts + slide_layout_map (from layout_build)
  <run>/_work/layout/ph_annot.json         {layout_id: {ph_idx: {name,description,convention}}}
  <run>/intent_discovery.json              intents[] + per-slide intent assignment
  <run>/_work/body/pools.json              {variants:[...], adornments:[...], occurrences:{n:[...]}}  (stage 3, later)
  <run>/variants.json                      {variants:[{id, rep_region_key}]}  (stage 3 — for evidence slot_values)
  <run>/<pool>/<id>/slots.json             per-entity slots (stage 4 — merged in here; current_value → evidence)
Writes:
  <run>/catalog.json · <run>/evidence.json

This is the single idempotent assembler: it (re)derives the whole catalog from the intermediates
present so far — including slots — so re-running it at any stage never drops a previously-built pool.
"""
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


def load(p, default=None):
    p = Path(p)
    return json.loads(p.read_text()) if p.exists() else default


def strip_cv(slots):
    """Drop `current_value` from catalog slots (observed content lives in evidence, not the contract)."""
    out = []
    for s in slots or []:
        s2 = {k: v for k, v in s.items() if k != "current_value"}
        if s2.get("subslots"):
            s2["subslots"] = strip_cv(s2["subslots"])
        out.append(s2)
    return out


def cv_map(slots):
    """slot name -> current_value (for evidence rep slot_values). Flat; subslot values omitted."""
    return {s["name"]: s["current_value"] for s in slots or [] if "current_value" in s}


def slide_intent_map(idoc):
    """Accept either {slide_intent:{n:id}} or {assignments:{n:{intent_id}}}."""
    if not idoc:
        return {}
    if "slide_intent" in idoc:
        return {str(k): v for k, v in idoc["slide_intent"].items()}
    out = {}
    for k, v in (idoc.get("assignments") or {}).items():
        out[str(k)] = v.get("intent_id") if isinstance(v, dict) else v
    return out


def merge_placeholders(skeleton, annot_for_layout):
    """Final placeholder = skeleton(kind,target) + annotated(name,description,convention).
    Drops working fields (bbox, prompt_text). target NEVER changes."""
    out = []
    for ph in skeleton or []:
        idx = str((ph.get("target") or {}).get("ph_idx"))
        a = (annot_for_layout or {}).get(idx, {})
        out.append({
            "name": a.get("name") or ph.get("name"),
            "kind": ph.get("kind"),
            "target": ph.get("target"),
            "description": a.get("description", ""),
            "convention": a.get("convention", ""),
        })
    return out


def derive_crossrefs(catalog, slides):
    """Populate the derived cross-reference fields from per-slide evidence (pure function of the
    occurrences recorded so far — empty at gate ②, fills in once stage 3 adds occurrences):
      variant.used_by_intents   — intents whose slides this variant appears on
      intent.allowed_variant_ids — variants appearing on this intent's slides (inverse)
      intent.layout_affinity     — [{layout_id, frequency}] over this intent's slides, desc
      intent.cooccurs_with       — other intents on an adjacent slide (n±1)
    """
    vids = {v["id"] for v in catalog.get("variants", [])}
    v_intents = defaultdict(set)       # variant_id -> {intent_id}
    i_variants = defaultdict(set)      # intent_id  -> {variant_id}
    i_layouts = defaultdict(Counter)   # intent_id  -> Counter(layout_id)
    by_n = {}                          # slide_n    -> intent_id
    for s in slides:
        iid, lid = s.get("intent_id"), s.get("layout_id")
        by_n[s["n"]] = iid
        if iid and lid:
            i_layouts[iid][lid] += 1
        if iid:
            for o in s.get("occurrences", []):
                if o.get("kind") == "variant" and o.get("id") in vids:
                    v_intents[o["id"]].add(iid)
                    i_variants[iid].add(o["id"])

    cooc = defaultdict(set)
    for n, iid in by_n.items():
        for m in (n - 1, n + 1):
            j = by_n.get(m)
            if iid and j and j != iid:
                cooc[iid].add(j)

    for it in catalog.get("intents", []):
        iid = it["id"]
        it["allowed_variant_ids"] = sorted(i_variants.get(iid, ()))
        tot = sum(i_layouts.get(iid, Counter()).values())
        it["layout_affinity"] = [{"layout_id": lid, "frequency": round(cnt / tot, 2)}
                                 for lid, cnt in i_layouts.get(iid, Counter()).most_common()] if tot else []
        it["cooccurs_with"] = sorted(cooc.get(iid, ()))
    for v in catalog.get("variants", []):
        v["used_by_intents"] = sorted(v_intents.get(v["id"], ()))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    args = ap.parse_args()
    R = Path(args.run)
    frame = load(R / "frame.json") or {}
    emu = frame.get("slide_emu", {})
    lay = load(R / "_work" / "layout" / "layouts.json", {})
    ph_annot = load(R / "_work" / "layout" / "ph_annot.json", {})
    idoc = load(R / "intent_discovery.json", {})
    body = load(R / "_work" / "body" / "pools.json", {})
    src = (R / "source.pptx.path").read_text().strip() if (R / "source.pptx.path").exists() else "?"

    # ---- layouts (canonical from layout_build) ----
    canon_layouts = lay.get("layouts", [])
    slmap = {str(k): v for k, v in (lay.get("slide_layout_map") or frame.get("slide_layout_map") or {}).items()}
    layouts = []
    for lo in canon_layouts:
        layouts.append({
            "id": lo["id"],
            "name": lo.get("name", lo["id"]),
            "master_id": lo.get("master_id"),
            "note": lo.get("note", ""),
            "content_box": lo.get("content_box"),
            "furniture": lo.get("furniture", []),
            "placeholders": merge_placeholders(lo.get("placeholders"), ph_annot.get(lo["id"], {})),
            "artifacts": {"frame_bundle": "frame/"},
        })

    # ---- masters (from frame raw masters) ----
    masters = []
    for m in frame.get("masters", []):
        masters.append({
            "id": m.get("id"), "name": m.get("name", m.get("id")), "note": m.get("note", ""),
            "placeholders": m.get("placeholders", []), "decorations": [],
            "artifacts": {"frame_bundle": "frame/"},
        })

    # ---- intents ----
    intents = []
    for it in (idoc.get("intents") or []):
        intents.append({"id": it["id"], "name": it.get("name", it["id"]),
                        "description": it.get("description", ""),
                        "allowed_variant_ids": it.get("allowed_variant_ids", []),
                        "layout_affinity": it.get("layout_affinity", []),
                        "cooccurs_with": it.get("cooccurs_with", [])})

    catalog = {
        "meta": {"source_template": Path(src).name, "slide_emu": emu, "schema_version": 6},
        "intents": intents,
        "variants": body.get("variants", []),
        "adornments": body.get("adornments", []),
        "layouts": layouts,
        "masters": masters,
    }

    # ---- slots: merge each entity's per-entity slots.json (the authoritative slot source written by
    # slot_tag + cardinality_base). Doing it HERE makes catalog_compile the single idempotent
    # assembler — re-running it (e.g. the Stage-5 cross-ref refresh) never drops slots. ----
    variants_meta = {v["id"]: v for v in (load(R / "variants.json", {}) or {}).get("variants", [])}
    rep_values = {}    # (slide, variant_id) -> observed slot_values, pushed into evidence
    ntag = 0
    for pool_name in ("variants", "adornments"):
        for ent in catalog[pool_name]:
            sj = R / pool_name / ent["id"] / "slots.json"
            if sj.exists():
                d = json.loads(sj.read_text())
                ent["slots"] = strip_cv(d.get("slots", []))
                ntag += 1
                if pool_name == "variants":
                    cvs = cv_map(d.get("slots", []))
                    rep = variants_meta.get(ent["id"], {}).get("rep_region_key", "")
                    if cvs and "_" in rep:
                        rep_values[(int(rep.split("_")[0]), ent["id"])] = cvs
            else:
                ent["slots"] = []      # spec: slots is always a list (empty until tagged)

    # ---- evidence (per slide: intent_id, layout_id, occurrences + observed slot_values) ----
    s2i = slide_intent_map(idoc)
    occ = body.get("occurrences", {})
    n_slides = max([int(k) for k in (set(slmap) | set(s2i))] or [0])
    slides = []
    for n in range(1, n_slides + 1):
        slides.append({"n": n, "intent_id": s2i.get(str(n)),
                       "layout_id": slmap.get(str(n)),
                       "occurrences": occ.get(str(n), [])})
    for s in slides:
        for o in s.get("occurrences", []):
            cvs = rep_values.get((s["n"], o.get("id")))
            if cvs:
                o["slot_values"] = cvs

    # ---- derived cross-references (from evidence; empty until stage 3 records occurrences) ----
    derive_crossrefs(catalog, slides)

    (R / "catalog.json").write_text(json.dumps(catalog, ensure_ascii=False, indent=2))
    (R / "evidence.json").write_text(json.dumps({"slides": slides}, ensure_ascii=False, indent=2))

    xref = sum(1 for it in intents if it["allowed_variant_ids"])
    print(f"catalog_compile → catalog.json + evidence.json")
    print(f"  layouts {len(layouts)} · masters {len(masters)} · intents {len(intents)} · "
          f"variants {len(catalog['variants'])} · adornments {len(catalog['adornments'])} · slides {len(slides)}")
    print(f"  cross-refs: {xref}/{len(intents)} intents have allowed_variant_ids "
          f"({sum(1 for v in catalog['variants'] if v['used_by_intents'])} variants mapped to intents)")
    nent = len(catalog["variants"]) + len(catalog["adornments"])
    print(f"  slots merged: {ntag}/{nent} entities tagged · {len(rep_values)} rep slot_values → evidence")
    annotated = sum(1 for lo in layouts for p in lo["placeholders"] if p["description"])
    print(f"  placeholders annotated: {annotated} / {sum(len(lo['placeholders']) for lo in layouts)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
