#!/usr/bin/env python3
"""schema_audit: Stage-5 conformance gate. Validates <run>/ against the catalog schema
(references/concepts.md, schema_version 6) at BOTH levels — the JSON contract AND the on-disk output format.

CANONICAL OUTPUT FORMAT (REQUIRED) — the run dir IS the design system: a clean deliverable
surface, with every build-time intermediate tucked under _work/. This is the contract; the audit
FAILS on any deviation (stray top-level entry, extra file inside an entity dir, missing artifact):

  <run>/
  ├── catalog.json       all type defs · slots · relations · meta  (the single contract Phase 1·2 read)
  ├── evidence.json      per-slide observations — top-level keys: {slides} ONLY
  ├── catalog.html       self-contained viewer (images base64-inlined; NO sibling-file deps)
  ├── frame/             Phase-2 inheritance bundle: [Content_Types].xml · manifest.json ·
  │                      ppt/{presentation.xml, slideLayouts, slideMasters, theme, media} (+ _rels)
  ├── media/             shared content-addressed body-icon pool (<hash>.<ext>, deduped)
  ├── variants/<id>/     shapes.xml + preview.png (+ shapes.xml.rels when it embeds icons)
  ├── adornments/<id>/   shapes.xml + preview.png (+ shapes.xml.rels when it embeds icons)
  └── _work/             ALL intermediates (slides·layout_previews·split·batches·entities/ …) — not a deliverable

  NOT at the top level (they are intermediates, not design-system parts): slides/, layouts/,
  frame.json, intent_discovery.json, slot_qa.*, *.json scratch, render caches → all under _work/.
  (layouts/masters carry no per-id disk dir: their artifact is the shared frame/ bundle.)

Checks: closed field-sets per pool · slot/placeholder shape · cardinality invariants · evidence
structure · cross-reference completeness · on-disk artifact existence (incl. the frame/ bundle) ·
frame/ completeness · entity-dir ↔ pool consistency · entity dirs hold only shapes.xml+preview.png ·
the clean run-dir surface above. Exit 1 (and a problem list) on any deviation."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _lib import media_rels  # noqa: E402

from lxml import etree  # noqa: E402

# closed field sets — exactly what the spec documents per pool (no more, no less)
SPEC = {
    "meta": {"source_template", "slide_emu", "schema_version"},
    "intents": {"id", "name", "description", "allowed_variant_ids", "layout_affinity", "cooccurs_with"},
    "variants": {"id", "name", "description", "size_emu", "slots", "used_by_intents", "artifacts"},
    "adornments": {"id", "name", "note", "size_emu", "slots", "artifacts"},
    "layouts": {"id", "name", "master_id", "note", "content_box", "furniture", "placeholders", "artifacts"},
    "masters": {"id", "name", "note", "placeholders", "decorations", "artifacts"},
}
PH = {"name", "kind", "target", "description", "convention"}          # layout placeholder
SLOT = {"name", "kind", "target", "description", "convention", "constraints", "cardinality", "subslots"}
SLOT_KINDS = {"text", "richtext", "image", "repeated", "table", "composite"}
OCC = {"kind", "id", "bbox_emu", "slot_values"}                      # evidence occurrence
BBOX = {"x", "y", "cx", "cy"}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    args = ap.parse_args()
    R = Path(args.run)
    cat = json.loads((R / "catalog.json").read_text())
    ev = json.loads((R / "evidence.json").read_text())
    problems = []

    # ---- meta: required + closed + schema_version is int 6 ----
    mk = set(cat.get("meta", {}))
    if SPEC["meta"] - mk:
        problems.append(f"meta: missing {sorted(SPEC['meta'] - mk)}")
    if mk - SPEC["meta"]:
        problems.append(f"meta: extra (non-spec) {sorted(mk - SPEC['meta'])}")
    if cat.get("meta", {}).get("schema_version") != 6:
        problems.append(f"meta.schema_version must be int 6, got {cat.get('meta', {}).get('schema_version')!r}")

    # ---- pools: required (when populated) + closed (always) ----
    for pool in ("intents", "variants", "adornments", "layouts", "masters"):
        items = cat.get(pool, [])
        keys = {k for it in items for k in it}
        if items and (SPEC[pool] - keys):
            problems.append(f"{pool}: missing {sorted(SPEC[pool] - keys)}")
        if keys - SPEC[pool]:
            problems.append(f"{pool}: extra (non-spec) {sorted(keys - SPEC[pool])}")

    # ---- layout placeholders: closed shape, unique join-key name, target.ph_idx present ----
    for lo in cat.get("layouts", []):
        names = [p.get("name") for p in lo.get("placeholders", [])]
        if len(names) != len(set(names)):
            problems.append(f"layout {lo['id']}: placeholder names not unique (join key) {names}")
        for p in lo.get("placeholders", []):
            if PH - set(p):
                problems.append(f"layout {lo['id']} ph {p.get('name')}: missing {sorted(PH - set(p))}")
            if set(p) - PH:
                problems.append(f"layout {lo['id']} ph {p.get('name')}: extra {sorted(set(p) - PH)}")
            ph_idx = (p.get("target") or {}).get("ph_idx")
            if not ph_idx and ph_idx != 0:
                problems.append(f"layout {lo['id']} ph {p.get('name')}: target.ph_idx empty")

    # ---- slots: kind enum, closed fields, no current_value leak, table-subslot ban, cardinality invariant ----
    def walk(vid, slots):
        for s in slots or []:
            if s.get("kind") not in SLOT_KINDS:
                problems.append(f"{vid} slot {s.get('name')}: bad kind {s.get('kind')}")
            if set(s) - SLOT:
                problems.append(f"{vid} slot {s.get('name')}: extra {sorted(set(s) - SLOT)}")
            if s.get("kind") == "table" and s.get("subslots"):
                problems.append(f"{vid} slot {s.get('name')}: table must not have subslots")
            card = s.get("cardinality") or {}
            b, lo_, hi = card.get("base"), card.get("min"), card.get("max")
            if None not in (b, lo_, hi) and not (lo_ <= b <= hi):
                problems.append(f"{vid} slot {s.get('name')}: cardinality min≤base≤max violated ({lo_},{b},{hi})")
            walk(vid, s.get("subslots"))
    for v in cat.get("variants", []) + cat.get("adornments", []):
        walk(v["id"], v.get("slots"))

    # ---- evidence: closed top-level, occurrence shape, bbox shape, cross-ref completeness ----
    if set(ev) - {"slides"}:
        problems.append(f"evidence: extra top-level {sorted(set(ev) - {'slides'})} (spec: only 'slides')")
    vids = {v["id"] for v in cat.get("variants", [])}
    aids = {a["id"] for a in cat.get("adornments", [])}
    lids = {lo["id"] for lo in cat.get("layouts", [])}
    iids = {it["id"] for it in cat.get("intents", [])}
    for s in ev.get("slides", []):
        if s.get("layout_id") and s["layout_id"] not in lids:
            problems.append(f"slide {s['n']}: layout_id {s['layout_id']} not in pool")
        if s.get("intent_id") and s["intent_id"] not in iids:
            problems.append(f"slide {s['n']}: intent_id {s['intent_id']} not in pool")
        for o in s.get("occurrences", []):
            if set(o) - OCC:
                problems.append(f"slide {s['n']} occ {o.get('id')}: extra {sorted(set(o) - OCC)}")
            b = o.get("bbox_emu")
            if isinstance(b, dict) and set(b) != BBOX:
                problems.append(f"slide {s['n']} occ {o.get('id')}: bbox_emu keys {sorted(b)} (spec: {sorted(BBOX)})")
            pool = vids if o.get("kind") == "variant" else aids
            if o.get("id") not in pool:
                problems.append(f"slide {s['n']}: occurrence {o.get('id')} not in pool")

    # ==== disk-level conformance (catalog references must resolve; surface must be the deliverable set) ====

    def _exists_nonempty(rel: str) -> bool:
        p = R / rel
        if not p.exists():
            return False
        return any(p.iterdir()) if p.is_dir() else p.stat().st_size > 0

    # ---- every artifacts.* path referenced in catalog resolves on disk (catches dangling frame_bundle) ----
    for pool in ("variants", "adornments", "layouts", "masters"):
        for it in cat.get(pool, []):
            for k, rel in (it.get("artifacts") or {}).items():
                if isinstance(rel, str) and not _exists_nonempty(rel):
                    problems.append(f"{pool} {it['id']}: artifacts.{k} → '{rel}' missing/empty on disk")

    # ---- frame/ bundle is real when layouts/masters point at it (≥1 slideLayout + ≥1 slideMaster) ----
    refs_frame = any((it.get("artifacts") or {}).get("frame_bundle")
                     for it in cat.get("layouts", []) + cat.get("masters", []))
    if refs_frame:
        fb = R / "frame"
        n_lay = len(list(fb.glob("**/slideLayout*.xml"))) if fb.exists() else 0
        n_mas = len(list(fb.glob("**/slideMaster*.xml"))) if fb.exists() else 0
        if not (n_lay and n_mas):
            problems.append(f"frame/ bundle incomplete: slideLayout={n_lay} slideMaster={n_mas} (need ≥1 each)")
        for req in ("ppt/presentation.xml", "manifest.json"):
            if not (fb / req).exists():
                problems.append(f"frame/ bundle missing {req}")

    # ---- per-entity disk dirs ↔ pool ids (no orphan dirs, no missing dirs) + only spec files inside ----
    for pool in ("variants", "adornments"):
        pool_ids = {it["id"] for it in cat.get(pool, [])}
        disk_ids = {d.name for d in (R / pool).iterdir() if d.is_dir()} if (R / pool).is_dir() else set()
        if pool_ids - disk_ids:
            problems.append(f"{pool}: catalog ids with no disk dir: {sorted(pool_ids - disk_ids)}")
        if disk_ids - pool_ids:
            problems.append(f"{pool}: orphan disk dirs not in catalog: {sorted(disk_ids - pool_ids)}")
        for d in (sorted(p for p in (R / pool).iterdir() if p.is_dir()) if (R / pool).is_dir() else []):
            extra = {f.name for f in d.iterdir()} - {"shapes.xml", "preview.png", "shapes.xml.rels"}
            if extra:
                problems.append(f"{pool}/{d.name}: non-deliverable files inside (run package_run.py): {sorted(extra)}")

    # ---- embedded icons resolve: every <a:blip r:embed> in a shapes.xml is mapped by a sibling
    # shapes.xml.rels to a media/ file that exists (otherwise the icon renders broken). ----
    for pool in ("variants", "adornments"):
        pdir = R / pool
        for d in (sorted(p for p in pdir.iterdir() if p.is_dir()) if pdir.is_dir() else []):
            sx = d / "shapes.xml"
            if not sx.exists():
                continue
            try:
                ids = media_rels.media_ref_ids(etree.parse(str(sx)).getroot())
            except etree.XMLSyntaxError as e:
                problems.append(f"{pool}/{d.name}: shapes.xml unparseable ({e})")
                continue
            if not ids:
                continue
            rels_path = d / "shapes.xml.rels"
            if not rels_path.exists():
                problems.append(f"{pool}/{d.name}: {len(ids)} embedded media ref(s) but no shapes.xml.rels")
                continue
            rels = media_rels.parse_rels(rels_path)
            for rid in ids:
                target = rels.get(rid)
                if not target:
                    problems.append(f"{pool}/{d.name}: embed {rid} not mapped in shapes.xml.rels")
                    continue
                mp = (d / target).resolve()
                if not (mp.exists() and mp.stat().st_size > 0):
                    problems.append(f"{pool}/{d.name}: embed {rid} → '{target}' missing/empty media")

    # ---- run-dir surface: only the deliverable set at top, required ones present, intermediates tucked in _work/ ----
    DELIVERABLES = {"catalog.json", "evidence.json", "catalog.html",
                    "frame", "variants", "adornments", "media", "meta.json", "_work"}
    top = {p.name for p in R.iterdir() if not p.name.startswith(".")}
    stray = top - DELIVERABLES
    if stray:
        problems.append(f"run surface: non-deliverable top-level entries (run package_run.py → _work/): {sorted(stray)}")
    for req in ("catalog.json", "evidence.json", "catalog.html", "variants", "adornments"):
        if req not in top:
            problems.append(f"run surface: required deliverable missing: {req}")
    if refs_frame and "frame" not in top:
        problems.append("run surface: frame/ bundle missing but referenced by layouts/masters")

    print(f"=== schema_audit ({R.name}) ===")
    if not problems:
        print("PASS - schema and completeness checks passed (closed field set matches)")
    else:
        print(f"❌ {len(problems)} issue(s):")
        for p in problems[:60]:
            print("  -", p)
    return 0 if not problems else 1


if __name__ == "__main__":
    raise SystemExit(main())
