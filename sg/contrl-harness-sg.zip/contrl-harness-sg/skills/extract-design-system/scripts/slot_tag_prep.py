#!/usr/bin/env python3
"""slot_tag_prep: prepare the slot-tag fan-out.

Enumerates every variant + adornment that has a shapes.xml, writes each entity's `_inventory.txt`
(so subagents just read it, no Bash needed), and batches the UNTAGGED entities (those without a
slots.json yet) into <run>/_slot_batches/batch_N.json for the fan-out. Already-tagged entities are
skipped (lazy / resumable).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from slot_inventory import build_inventory  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--batch-size", type=int, default=7)
    ap.add_argument("--include-tagged", action="store_true", help="re-tag entities that already have slots.json")
    args = ap.parse_args()
    run = Path(args.run)

    entities = []
    for kind, root in (("variant", run / "variants"), ("adornment", run / "adornments")):
        for d in sorted(root.glob("*/")):
            if not (d / "shapes.xml").exists():
                continue
            entities.append({"id": d.name, "kind": kind, "dir": f"{root.name}/{d.name}"})

    todo = []
    for e in entities:
        d = run / e["dir"]
        # always (re)write the inventory so it is fresh
        try:
            (d / "_inventory.txt").write_text(build_inventory(d))
        except Exception as exc:  # noqa: BLE001
            print(f"  [warn] inventory failed for {e['id']}: {exc}", file=sys.stderr)
        tagged = (d / "slots.json").exists()
        if args.include_tagged or not tagged:
            todo.append(e)

    bdir = run / "_slot_batches"
    if bdir.exists():
        import shutil
        shutil.rmtree(bdir)
    bdir.mkdir(parents=True)
    bs = args.batch_size
    batches = [todo[i:i + bs] for i in range(0, len(todo), bs)]
    for i, b in enumerate(batches):
        (bdir / f"batch_{i+1}.json").write_text(json.dumps(b, ensure_ascii=False, indent=1))

    n_tagged = sum(1 for e in entities if (run / e["dir"] / "slots.json").exists())
    print(f"entities: {len(entities)} ({sum(1 for e in entities if e['kind']=='variant')} variants, "
          f"{sum(1 for e in entities if e['kind']=='adornment')} adornments)")
    print(f"already tagged: {n_tagged} | to tag: {len(todo)} | batches: {len(batches)} (size {bs})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
