#!/usr/bin/env python3
"""slide-fingerprint: structural signature per slide + grouping into distinct classes.

A variant/adornment is a recurring SHAPE STRUCTURE (text swapped). So two slides with
the same arrangement of same-typed, same-sized shapes are the "same structure" — we
fingerprint that mechanically (no LLM, no image) and group slides into distinct classes
so the expensive vision step runs once per class, not per slide.

Signature ignores text content; it captures, per top-level shape (document order):
(tag, x-bucket, y-bucket, cx-bucket, cy-bucket, descendant-count-bucket).

Outputs:
  <run>/fingerprints/slide-<n>.json   {n, sig_hash, shapes:[...]}
  <run>/slide_classes.json            {distinct, classes:[...], by_slide:{n:sig_hash}}
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[0]))
from _lib.pptx_xml import (  # noqa: E402
    _local,
    descendant_shape_ids,
    iter_top_level_shapes,
    parse,
    shape_box,
    slide_size_emu,
)

BUCKET = 457_200  # 0.5 inch — coarse geometry grid


def _ndesc_bucket(k: int) -> str:
    if k == 0:
        return "0"
    if k <= 3:
        return "s"
    if k <= 10:
        return "m"
    return "l"


def signature(tree) -> list[dict]:
    sig = []
    for el in iter_top_level_shapes(tree):
        tag = _local(el.tag)
        box = shape_box(el)
        if box is None:
            sig.append({"tag": tag, "geom": None, "nd": _ndesc_bucket(len(descendant_shape_ids(el)))})
            continue
        sig.append({
            "tag": tag,
            "geom": [box.x // BUCKET, box.y // BUCKET, box.cx // BUCKET, box.cy // BUCKET],
            "nd": _ndesc_bucket(len(descendant_shape_ids(el))),
        })
    return sig


def sig_hash(sig: list[dict]) -> str:
    return hashlib.sha1(json.dumps(sig, sort_keys=True).encode()).hexdigest()[:12]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    args = ap.parse_args()
    run = Path(args.run)
    fp_dir = run / "fingerprints"
    fp_dir.mkdir(parents=True, exist_ok=True)

    slide_dirs = sorted((run / "slides").glob("*/"), key=lambda p: int(p.name) if p.name.isdigit() else 0)
    by_slide: dict[str, str] = {}
    classes: dict[str, list[int]] = {}
    for sd in slide_dirs:
        raw = sd / "raw.xml"
        if not raw.exists():
            continue
        n = int(sd.name)
        tree = parse(raw)
        sig = signature(tree)
        h = sig_hash(sig)
        (fp_dir / f"slide-{n}.json").write_text(
            json.dumps({"n": n, "sig_hash": h, "n_top": len(sig), "shapes": sig}, ensure_ascii=False, indent=2)
        )
        by_slide[str(n)] = h
        classes.setdefault(h, []).append(n)

    class_list = []
    for h, members in sorted(classes.items(), key=lambda kv: (-len(kv[1]), min(kv[1]))):
        members = sorted(members)
        class_list.append({"sig": h, "rep": members[0], "members": members, "size": len(members)})
    out = {
        "distinct": len(classes),
        "total_slides": len(by_slide),
        "classes": class_list,
        "by_slide": by_slide,
    }
    (run / "slide_classes.json").write_text(json.dumps(out, ensure_ascii=False, indent=2))
    print(f"fingerprinted {len(by_slide)} slides -> {len(classes)} distinct structures")
    for c in class_list:
        print(f"  {c['sig']}  x{c['size']:>2}  rep=slide {c['rep']}  members={c['members']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
