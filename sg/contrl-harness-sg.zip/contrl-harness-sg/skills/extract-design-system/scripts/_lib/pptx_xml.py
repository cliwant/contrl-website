"""XML helpers for PPTX OOXML processing.

Conventions:
- All coordinates are in EMU (English Metric Units). 914400 EMU = 1 inch.
- We use lxml everywhere so we can preserve namespace prefixes.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

from lxml import etree

NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
}

EMU_PER_INCH = 914_400
PX_PER_INCH = 96  # standard screen DPI for our overlays

SHAPE_TAGS = {"sp", "pic", "grpSp", "cxnSp", "graphicFrame"}


def emu_to_px(emu: int, dpi: int = PX_PER_INCH) -> float:
    return emu * dpi / EMU_PER_INCH


def parse(path: Path) -> etree._ElementTree:
    return etree.parse(str(path))


def write(tree: etree._ElementTree, path: Path) -> None:
    tree.write(str(path), xml_declaration=True, encoding="UTF-8", standalone=True)


@dataclass(frozen=True)
class ShapeBox:
    """A shape's identity and bounding box in slide-space EMU."""

    shape_id: str
    name: str
    x: int
    y: int
    cx: int
    cy: int
    tag: str  # local-name of the shape element
    text: str  # concatenated visible text

    @property
    def bbox_emu(self) -> tuple[int, int, int, int]:
        return (self.x, self.y, self.x + self.cx, self.y + self.cy)


def _local(tag) -> str:
    if not isinstance(tag, str):
        return ""
    return etree.QName(tag).localname


def _find_shape_container(tree: etree._ElementTree) -> etree._Element | None:
    """Return the element whose direct children are top-level shapes.

    Accepts either:
      - a slide XML rooted at <p:sld> (container = p:cSld/p:spTree), OR
      - a per-component fragment rooted at <components> (container = root itself).
    """
    sp_tree = tree.find(".//p:cSld/p:spTree", NS)
    if sp_tree is not None:
        return sp_tree
    root = tree.getroot()
    if _local(root.tag) == "components":
        return root
    return None


def iter_top_level_shapes(tree: etree._ElementTree) -> Iterator[etree._Element]:
    """Yield direct children of the shape container that are shape-like."""
    container = _find_shape_container(tree)
    if container is None:
        return
    for child in container:
        if _local(child.tag) in SHAPE_TAGS:
            yield child


def iter_all_shape_els(tree: etree._ElementTree) -> Iterator[etree._Element]:
    """Yield EVERY shape element in the slide, recursively descending into grpSp.

    Order: parents before children (preorder). Use this when components may
    partition the slide at grpSp-child level instead of (or in addition to)
    top-level shapes.
    """
    def _walk(parent):
        for child in parent:
            if _local(child.tag) not in SHAPE_TAGS:
                continue
            yield child
            if _local(child.tag) == "grpSp":
                yield from _walk(child)

    container = _find_shape_container(tree)
    if container is None:
        return
    yield from _walk(container)


def find_shape_by_id(tree: etree._ElementTree, sid: str) -> etree._Element | None:
    """Find a shape element by its p:cNvPr/@id, anywhere in the slide (including inside grpSp)."""
    for el in iter_all_shape_els(tree):
        if shape_id(el) == sid:
            return el
    return None


def descendant_shape_ids(el: etree._Element) -> set[str]:
    """All shape IDs strictly nested inside `el` (does not include `el` itself)."""
    out: set[str] = set()
    if _local(el.tag) != "grpSp":
        return out
    for child in el:
        if _local(child.tag) not in SHAPE_TAGS:
            continue
        sid = shape_id(child)
        if sid:
            out.add(sid)
        if _local(child.tag) == "grpSp":
            out |= descendant_shape_ids(child)
    return out


def shape_id(el: etree._Element) -> str | None:
    """Return p:cNvPr/@id for this shape (looks one level into the shape's own nv* wrapper)."""
    # Each shape type wraps cNvPr inside its own nv* element which is a direct child:
    #   sp/nvSpPr/cNvPr, pic/nvPicPr/cNvPr, grpSp/nvGrpSpPr/cNvPr,
    #   cxnSp/nvCxnSpPr/cNvPr, graphicFrame/nvGraphicFramePr/cNvPr.
    # The first p:cNvPr descendant happens to always be this shape's own.
    cnv = el.find(".//p:cNvPr", NS)
    return cnv.get("id") if cnv is not None else None


def shape_name(el: etree._Element) -> str:
    cnv = el.find(".//p:cNvPr", NS)
    return cnv.get("name", "") if cnv is not None else ""


def _xfrm_element(el: etree._Element) -> etree._Element | None:
    """Find the xfrm element for any shape type.

    Different shape tags put xfrm at different paths:
      - p:sp, p:pic, p:cxnSp        → p:spPr/a:xfrm
      - p:grpSp                     → p:grpSpPr/a:xfrm
      - p:graphicFrame              → p:xfrm  (direct child!)
    """
    xfrm = el.find("./p:spPr/a:xfrm", NS)
    if xfrm is not None:
        return xfrm
    xfrm = el.find("./p:grpSpPr/a:xfrm", NS)
    if xfrm is not None:
        return xfrm
    return el.find("./p:xfrm", NS)


def shape_xfrm(el: etree._Element) -> tuple[int, int, int, int] | None:
    """Return (x, y, cx, cy) in the SHAPE'S OWN coordinate space (not slide-space).

    For a top-level shape, that IS slide-space. For a shape nested inside one or more
    groups, this returns coords in the immediate parent group's local space. Use
    `iter_all_shapes_in_slide_space` if you need composed/slide-space coordinates.
    """
    xfrm = _xfrm_element(el)
    if xfrm is None:
        return None
    off = xfrm.find("a:off", NS)
    ext = xfrm.find("a:ext", NS)
    if off is None or ext is None:
        return None
    return (
        int(off.get("x", "0")),
        int(off.get("y", "0")),
        int(ext.get("cx", "0")),
        int(ext.get("cy", "0")),
    )


def shape_text(el: etree._Element) -> str:
    """Concatenate all a:t text under this shape."""
    parts = [t.text or "" for t in el.findall(".//a:t", NS)]
    return " ".join(p for p in parts if p).strip()


def shape_box(el: etree._Element) -> ShapeBox | None:
    """ShapeBox in the shape's own coord space (slide-space for top-level shapes)."""
    sid = shape_id(el)
    xfrm = shape_xfrm(el)
    if sid is None or xfrm is None:
        return None
    x, y, cx, cy = xfrm
    return ShapeBox(
        shape_id=sid,
        name=shape_name(el),
        x=x,
        y=y,
        cx=cx,
        cy=cy,
        tag=_local(el.tag),
        text=shape_text(el),
    )


def all_shape_boxes(tree: etree._ElementTree) -> list[ShapeBox]:
    """Top-level shapes only. For exhaustive recursion use iter_all_shapes_in_slide_space."""
    out: list[ShapeBox] = []
    for el in iter_top_level_shapes(tree):
        box = shape_box(el)
        if box is not None:
            out.append(box)
    return out


# ---------------------------------------------------------------------------
# Recursive (nested-group-aware) shape walker — composes group transforms.
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class _Transform:
    """An affine transform that maps a shape's local-space coords to slide-space.

    slide_x  = off_x + local_x * sx
    slide_y  = off_y + local_y * sy
    slide_cx = local_cx * sx
    slide_cy = local_cy * sy
    """
    off_x: float = 0.0
    off_y: float = 0.0
    sx: float = 1.0
    sy: float = 1.0

    def apply(self, x: int, y: int, cx: int, cy: int) -> tuple[int, int, int, int]:
        return (
            int(self.off_x + x * self.sx),
            int(self.off_y + y * self.sy),
            int(cx * self.sx),
            int(cy * self.sy),
        )


def _compose_through_group(t: _Transform, grp_el: etree._Element) -> _Transform:
    """Given the current transform `t` and a group element, return the transform
    that should be applied to the group's children.

    A group's xfrm has off/ext (its own position in parent space) plus chOff/chExt
    (origin and size of the children's local coordinate system). We translate the
    group's slide-space position then rescale so that children's local-space coords
    map correctly into slide-space.
    """
    xfrm = _xfrm_element(grp_el)
    if xfrm is None:
        return t
    off = xfrm.find("a:off", NS)
    ext = xfrm.find("a:ext", NS)
    ch_off = xfrm.find("a:chOff", NS)
    ch_ext = xfrm.find("a:chExt", NS)
    if off is None or ext is None:
        return t

    grp_x = int(off.get("x", "0"))
    grp_y = int(off.get("y", "0"))
    grp_cx = int(ext.get("cx", "0"))
    grp_cy = int(ext.get("cy", "0"))

    # If chOff/chExt missing, identity child space → equivalent to chOff=off, chExt=ext.
    if ch_off is not None and ch_ext is not None:
        cox = int(ch_off.get("x", "0"))
        coy = int(ch_off.get("y", "0"))
        cex = int(ch_ext.get("cx", "0"))
        cey = int(ch_ext.get("cy", "0"))
    else:
        cox, coy = grp_x, grp_y
        cex, cey = grp_cx, grp_cy

    # Group's slide-space bbox under current transform.
    slide_off_x, slide_off_y, slide_cx, slide_cy = t.apply(grp_x, grp_y, grp_cx, grp_cy)

    # Children's-local-to-slide scale.
    new_sx = (slide_cx / cex) if cex else t.sx
    new_sy = (slide_cy / cey) if cey else t.sy

    new_off_x = slide_off_x - cox * new_sx
    new_off_y = slide_off_y - coy * new_sy

    return _Transform(new_off_x, new_off_y, new_sx, new_sy)


def iter_all_shapes_in_slide_space(tree: etree._ElementTree) -> Iterator[ShapeBox]:
    """Recursively yield EVERY shape in slide-space EMU, including:
      - top-level shapes
      - shapes nested inside p:grpSp containers (transforms composed)
      - the groups themselves (their own slide-space bbox)

    This is the function visualizations + slot-tag should use when they need to
    address nested shapes. Component extraction still operates on `iter_top_level_shapes`
    because components partition top-level shapes, not nested ones.
    """
    container = _find_shape_container(tree)
    if container is None:
        return

    def _walk(parent: etree._Element, t: _Transform):
        for child in parent:
            tag = _local(child.tag)
            if tag not in SHAPE_TAGS:
                continue
            own_xfrm = shape_xfrm(child)
            if own_xfrm is None and tag != "grpSp":
                continue
            if own_xfrm is None:
                # Group with no xfrm — shouldn't happen but be defensive.
                yield from _walk(child, t)
                continue
            x, y, cx, cy = own_xfrm
            sx, sy, scx, scy = t.apply(x, y, cx, cy)
            sid = shape_id(child)
            if sid is not None:
                yield ShapeBox(
                    shape_id=sid,
                    name=shape_name(child),
                    x=sx,
                    y=sy,
                    cx=scx,
                    cy=scy,
                    tag=tag,
                    text=shape_text(child),
                )
            if tag == "grpSp":
                new_t = _compose_through_group(t, child)
                yield from _walk(child, new_t)

    yield from _walk(container, _Transform())


def slide_size_emu(presentation_xml: Path) -> tuple[int, int]:
    """Read slide width/height from ppt/presentation.xml."""
    t = parse(presentation_xml)
    sz = t.find(".//p:sldSz", NS)
    if sz is None:
        return (9_144_000, 6_858_000)
    return int(sz.get("cx")), int(sz.get("cy"))


def remove_shapes_by_id(tree: etree._ElementTree, ids_to_remove: set[str]) -> int:
    """Remove top-level shapes whose p:cNvPr/@id is in the set. Returns count removed."""
    removed = 0
    container = _find_shape_container(tree)
    if container is None:
        return 0
    for child in list(container):
        if _local(child.tag) not in SHAPE_TAGS:
            continue
        sid = shape_id(child)
        if sid in ids_to_remove:
            container.remove(child)
            removed += 1
    return removed
