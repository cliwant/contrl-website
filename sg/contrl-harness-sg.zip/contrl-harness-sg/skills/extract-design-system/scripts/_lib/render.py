"""Render PPTX slides to PNG via LibreOffice soffice (headless)."""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path


def soffice_path() -> str:
    return shutil.which("soffice") or "/Applications/LibreOffice.app/Contents/MacOS/soffice"


def render_pptx_to_pngs(pptx_path: Path, out_dir: Path, dpi: int = 144) -> list[Path]:
    """Render every slide in pptx to out_dir/slide_<n>.png. Returns sorted list of pngs.

    Implementation: soffice can convert pptx → pdf, then pdftoppm splits pdf → pngs.
    More reliable than soffice's direct png export, which only handles 1 slide.

    Safe for parallel callers: each invocation gets its own LibreOffice user-profile
    directory via -env:UserInstallation, so concurrent processes don't fight over the
    default ~/Library/Application Support/LibreOffice lockfile.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        user_dir = tmp_path / "lo_profile"
        user_dir.mkdir()
        # Step 1: pptx → pdf
        subprocess.run(
            [
                soffice_path(),
                f"-env:UserInstallation=file://{user_dir}",
                "--headless",
                "--convert-to",
                "pdf",
                "--outdir",
                str(tmp_path),
                str(pptx_path),
            ],
            check=True,
            capture_output=True,
        )
        pdf_path = tmp_path / (pptx_path.stem + ".pdf")
        if not pdf_path.exists():
            raise RuntimeError(f"soffice did not produce {pdf_path}")
        # Step 2: pdf → pngs
        subprocess.run(
            [
                "pdftoppm",
                "-png",
                "-r",
                str(dpi),
                str(pdf_path),
                str(out_dir / "slide"),
            ],
            check=True,
            capture_output=True,
        )
    pngs = sorted(out_dir.glob("slide-*.png"))
    # Normalize names: slide-1.png → slide_1.png
    normalized: list[Path] = []
    for p in pngs:
        n = int(p.stem.split("-")[-1])
        new = out_dir / f"slide_{n}.png"
        p.rename(new)
        normalized.append(new)
    return sorted(normalized, key=lambda x: int(x.stem.split("_")[-1]))


def render_single_slide_xml(
    pptx_path: Path, slide_xml: Path, slide_index_1based: int, out_png: Path, dpi: int = 144
) -> Path:
    """Re-render a single slide after we've modified its XML.

    Strategy: copy pptx to tmp, overwrite ppt/slides/slideN.xml, repack, render via soffice.
    """
    import zipfile

    out_png.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        modified_pptx = tmp_path / "modified.pptx"

        # Copy pptx as zip, replacing the one slide
        with zipfile.ZipFile(pptx_path, "r") as zin, zipfile.ZipFile(
            modified_pptx, "w", zipfile.ZIP_DEFLATED
        ) as zout:
            target_name = f"ppt/slides/slide{slide_index_1based}.xml"
            for item in zin.namelist():
                if item == target_name:
                    zout.writestr(item, slide_xml.read_bytes())
                else:
                    zout.writestr(item, zin.read(item))

        # Render the whole deck, then take the one we want
        render_dir = tmp_path / "render"
        pngs = render_pptx_to_pngs(modified_pptx, render_dir, dpi=dpi)
        if slide_index_1based - 1 >= len(pngs):
            raise RuntimeError(
                f"expected slide {slide_index_1based}, only got {len(pngs)} pngs"
            )
        src = pngs[slide_index_1based - 1]
        shutil.copy(src, out_png)
    return out_png
