"""Helpers to resolve extract/build run directories.

Extract runs live under `extract-design-system/outputs/<YYYY-MM-DD>_<source>[_<label>]/`.
Build runs live under `build-slides/outputs/<YYYY-MM-DD>_<source>[_<label>]/`.

Both are versioned — each run is fully self-contained. Defaults resolve to the
most recently modified run directory.
"""
from __future__ import annotations

import datetime
from pathlib import Path


def _runs_in(parent: Path) -> list[Path]:
    if not parent.exists():
        return []
    return [p for p in parent.iterdir() if p.is_dir()]


def latest_extract_run(repo_root: Path | None = None) -> Path | None:
    """Return the most-recently-modified extract run dir, or None."""
    root = repo_root or Path.cwd()
    runs = _runs_in(root / "extract" / "outputs")
    if not runs:
        return None
    return max(runs, key=lambda p: p.stat().st_mtime)


def latest_build_run(repo_root: Path | None = None) -> Path | None:
    root = repo_root or Path.cwd()
    runs = _runs_in(root / "build" / "outputs")
    if not runs:
        return None
    return max(runs, key=lambda p: p.stat().st_mtime)


def new_run_id(source_name: str, label: str | None = None) -> str:
    """Build a run id like '2026-05-28_sample[_label]'."""
    date = datetime.date.today().isoformat()
    parts = [date, source_name]
    if label:
        parts.append(label)
    return "_".join(parts)


def new_extract_run_dir(source_name: str, label: str | None = None,
                        repo_root: Path | None = None) -> Path:
    root = repo_root or Path.cwd()
    rid = new_run_id(source_name, label)
    d = root / "extract" / "outputs" / rid
    d.mkdir(parents=True, exist_ok=True)
    return d


def new_build_run_dir(source_name: str, label: str | None = None,
                      repo_root: Path | None = None) -> Path:
    root = repo_root or Path.cwd()
    rid = new_run_id(source_name, label)
    d = root / "build" / "outputs" / rid
    d.mkdir(parents=True, exist_ok=True)
    return d
