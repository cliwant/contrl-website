"""Render a per-component preview against a CLEAN base.

Strategy:
  1. Find which slideLayout the slide references via ppt/slides/_rels/slideN.xml.rels.
  2. Build a CLEAN slide XML: replace ppt/slides/slideN.xml with one whose
     <p:spTree> contains only the component's shapes.
  3. Build a CLEAN slideLayout XML: remove all top-level shapes that are NOT
     placeholders (no <p:ph> child) — this strips chapter marks, page numbers,
     proposal-title footer, "제안내용" tag, corporate logo, etc.
  4. Repack the temporary pptx with both modifications and render via soffice.

The slide background (set via <p:bg> in slideMaster/slideLayout) is preserved
because we only strip from <p:spTree>, not from <p:bg>.
"""
from __future__ import annotations

import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

from lxml import etree

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from _lib.pptx_xml import NS, _local, parse, shape_id  # noqa: E402
from _lib.render import render_pptx_to_pngs  # noqa: E402

SHAPE_TAGS = {"sp", "pic", "grpSp", "cxnSp", "graphicFrame"}


def _strip_slide_to_component(slide_xml_path: Path, keep_ids: set[str]) -> bytes:
    """Slide XML: keep only top-level shapes whose id is in keep_ids."""
    tree = parse(slide_xml_path)
    sp_tree = tree.find(".//p:cSld/p:spTree", NS)
    if sp_tree is None:
        raise RuntimeError("slide has no p:spTree")
    _strip_recursive(sp_tree, keep_ids)
    return etree.tostring(
        tree, xml_declaration=True, encoding="UTF-8", standalone=True
    )


def _strip_recursive(container, keep_ids: set[str]) -> bool:
    """Recursively prune `container` to only keep shapes whose id is in keep_ids,
    OR grpSp ancestors of kept shapes (so transforms apply correctly).

    Returns True if any descendant was kept (caller uses this to decide whether
    to prune the container itself when it's a grpSp).
    """
    any_kept = False
    for child in list(container):
        tag = _local(child.tag)
        if tag in {"nvGrpSpPr", "grpSpPr"}:
            continue  # wrapper element, not a shape
        if tag not in SHAPE_TAGS:
            continue
        sid = shape_id(child)
        if tag == "grpSp":
            if sid in keep_ids:
                # The grpSp itself is kept as a unit — don't prune its children.
                any_kept = True
                continue
            kept_inside = _strip_recursive(child, keep_ids)
            if kept_inside:
                any_kept = True
            else:
                container.remove(child)
        else:
            if sid in keep_ids:
                any_kept = True
            else:
                container.remove(child)
    return any_kept


def _strip_layout_to_placeholders(layout_xml_bytes: bytes) -> bytes:
    """slideLayout XML: keep only top-level shapes that ARE placeholders.

    Placeholders carry a <p:ph> element inside <p:nvSpPr><p:nvPr>. Everything else
    (chapter marks, page numbers, footer logos, "제안내용" tag, decorative geometry)
    is stripped. <p:bg> and other non-spTree decoration is left alone.
    """
    tree = etree.ElementTree(etree.fromstring(layout_xml_bytes))
    sp_tree = tree.find(".//p:cSld/p:spTree", NS)
    if sp_tree is None:
        return layout_xml_bytes
    for child in list(sp_tree):
        tag = _local(child.tag)
        if tag in {"nvGrpSpPr", "grpSpPr"}:
            continue
        if tag not in SHAPE_TAGS:
            continue
        # Has a placeholder marker?
        ph = child.find(".//p:nvSpPr/p:nvPr/p:ph", NS)
        if ph is None:
            ph = child.find(".//p:ph", NS)
        if ph is None:
            sp_tree.remove(child)
    return etree.tostring(
        tree, xml_declaration=True, encoding="UTF-8", standalone=True
    )


def _slide_layout_target(rels_bytes: bytes) -> str | None:
    """From a slideN.xml.rels, find the path to the slideLayout in the zip.

    Targets in slideN.xml.rels are relative to the slide file
    (ppt/slides/slideN.xml). A target like "../slideLayouts/slideLayout3.xml"
    resolves to "ppt/slideLayouts/slideLayout3.xml" in the zip.
    """
    root = etree.fromstring(rels_bytes)
    for rel in root:
        if rel.get("Type", "").endswith("/slideLayout"):
            target = rel.get("Target", "")
            if target.startswith("../"):
                return "ppt/" + target[3:]
            if target.startswith("/"):
                return target.lstrip("/")
            return "ppt/slides/" + target
    return None


def render_component_preview(
    pptx_path: Path,
    slide_index_1based: int,
    component_shape_ids: list[str],
    out_png: Path,
) -> Path:
    """Render the component on a CLEAN base (chrome stripped from slideLayout)."""
    keep_ids = set(component_shape_ids)
    out_png.parent.mkdir(parents=True, exist_ok=True)

    slide_name = f"ppt/slides/slide{slide_index_1based}.xml"
    rels_name = f"ppt/slides/_rels/slide{slide_index_1based}.xml.rels"

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        modified_pptx = tmp_path / "modified.pptx"

        # 1. Read original slide + rels to find the slideLayout
        with zipfile.ZipFile(pptx_path) as zin:
            original_slide_xml = zin.read(slide_name)
            rels_bytes = zin.read(rels_name)
        layout_target = _slide_layout_target(rels_bytes)

        # 2. Build cleaned slide XML
        scratch = tmp_path / "slide_orig.xml"
        scratch.write_bytes(original_slide_xml)
        clean_slide_bytes = _strip_slide_to_component(scratch, keep_ids)

        # 3. Build cleaned slideLayout XML (if found)
        clean_layout_bytes: bytes | None = None
        if layout_target:
            with zipfile.ZipFile(pptx_path) as zin:
                original_layout_xml = zin.read(layout_target)
            clean_layout_bytes = _strip_layout_to_placeholders(original_layout_xml)

        # 4. Repack
        with zipfile.ZipFile(pptx_path, "r") as zin, zipfile.ZipFile(
            modified_pptx, "w", zipfile.ZIP_DEFLATED
        ) as zout:
            for item in zin.namelist():
                if item == slide_name:
                    zout.writestr(item, clean_slide_bytes)
                elif clean_layout_bytes is not None and item == layout_target:
                    zout.writestr(item, clean_layout_bytes)
                else:
                    zout.writestr(item, zin.read(item))

        # 5. Render
        render_dir = tmp_path / "render"
        pngs = render_pptx_to_pngs(modified_pptx, render_dir)
        if slide_index_1based - 1 >= len(pngs):
            raise RuntimeError(
                f"expected slide {slide_index_1based}, only got {len(pngs)} renders"
            )
        src = pngs[slide_index_1based - 1]
        shutil.copy(src, out_png)
    return out_png
