"""Pillow-based overlay helpers — draw bounding boxes/labels on rendered slide PNGs.

Coordinates from XML are EMU; PNG is rendered at a known DPI. We scale by
(png_width_px / slide_width_emu).
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


# A small palette for component groups
COMPONENT_COLORS = [
    "#e6194B",  # red
    "#3cb44b",  # green
    "#4363d8",  # blue
    "#f58231",  # orange
    "#911eb4",  # purple
    "#46f0f0",  # cyan
    "#f032e6",  # magenta
    "#9A6324",  # brown
]

CHROME_COLOR = "#888888"
CHROME_OUTLINE = "#333333"


@dataclass
class Box:
    x_emu: int
    y_emu: int
    cx_emu: int
    cy_emu: int
    label: str
    color: str
    outline_width: int = 4


def _font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    for candidate in [
        "/System/Library/Fonts/Helvetica.ttc",
        "/Library/Fonts/Arial.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
    ]:
        try:
            return ImageFont.truetype(candidate, size)
        except OSError:
            continue
    return ImageFont.load_default()


def draw_boxes(
    base_png: Path,
    out_png: Path,
    slide_size_emu: tuple[int, int],
    boxes: list[Box],
    caption: str | None = None,
    ghost_first: bool = False,
) -> Path:
    """Draw boxes on top of base_png. Optionally prepend a caption strip.

    ghost_first=True: first dim the entire image (used for chrome-stripped viz).
    """
    img = Image.open(base_png).convert("RGBA")
    w_px, h_px = img.size
    sw_emu, sh_emu = slide_size_emu

    sx = w_px / sw_emu
    sy = h_px / sh_emu

    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    if ghost_first:
        # Lay a translucent white veil over everything; non-chrome boxes get punched through
        veil = Image.new("RGBA", img.size, (255, 255, 255, 128))
        img = Image.alpha_composite(img, veil)

    label_font = _font(18)

    for b in boxes:
        x1 = b.x_emu * sx
        y1 = b.y_emu * sy
        x2 = (b.x_emu + b.cx_emu) * sx
        y2 = (b.y_emu + b.cy_emu) * sy
        draw.rectangle((x1, y1, x2, y2), outline=b.color, width=b.outline_width)
        # Label background
        if b.label:
            text_bbox = draw.textbbox((0, 0), b.label, font=label_font)
            tw = text_bbox[2] - text_bbox[0]
            th = text_bbox[3] - text_bbox[1]
            pad = 4
            draw.rectangle(
                (x1, max(0, y1 - th - 2 * pad), x1 + tw + 2 * pad, y1),
                fill=b.color,
            )
            draw.text((x1 + pad, max(0, y1 - th - pad - 2)), b.label, fill="white", font=label_font)

    img = Image.alpha_composite(img, overlay)

    if caption:
        caption_font = _font(22)
        cap_lines = caption.split("\n")
        line_h = 30
        strip_h = line_h * len(cap_lines) + 20
        new = Image.new("RGB", (w_px, h_px + strip_h), "white")
        new.paste(img.convert("RGB"), (0, strip_h))
        d2 = ImageDraw.Draw(new)
        for i, line in enumerate(cap_lines):
            d2.text((20, 10 + i * line_h), line, fill="black", font=caption_font)
        img = new
    else:
        img = img.convert("RGB")

    out_png.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_png)
    return out_png


def crop_to_box(
    base_png: Path,
    out_png: Path,
    slide_size_emu: tuple[int, int],
    bbox_emu: tuple[int, int, int, int],
    padding_emu: int = 50_000,
) -> Path:
    """Crop the rendered slide to the union bbox of a component, with padding."""
    img = Image.open(base_png).convert("RGB")
    w_px, h_px = img.size
    sw_emu, sh_emu = slide_size_emu
    sx = w_px / sw_emu
    sy = h_px / sh_emu

    x1_e, y1_e, x2_e, y2_e = bbox_emu
    x1 = max(0, int((x1_e - padding_emu) * sx))
    y1 = max(0, int((y1_e - padding_emu) * sy))
    x2 = min(w_px, int((x2_e + padding_emu) * sx))
    y2 = min(h_px, int((y2_e + padding_emu) * sy))
    crop = img.crop((x1, y1, x2, y2))
    out_png.parent.mkdir(parents=True, exist_ok=True)
    crop.save(out_png)
    return out_png


def union_bbox(boxes: list[tuple[int, int, int, int]]) -> tuple[int, int, int, int]:
    """Union of (x, y, x+cx, y+cy) tuples."""
    xs1 = [b[0] for b in boxes]
    ys1 = [b[1] for b in boxes]
    xs2 = [b[2] for b in boxes]
    ys2 = [b[3] for b in boxes]
    return (min(xs1), min(ys1), max(xs2), max(ys2))
