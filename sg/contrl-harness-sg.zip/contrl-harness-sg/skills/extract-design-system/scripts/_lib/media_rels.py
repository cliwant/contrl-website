"""Re-home image media referenced by carved shape fragments.

A carved ``<p:spTree>`` fragment (``variants/<id>/shapes.xml``, ``adornments/<id>/shapes.xml``)
keeps the source slide's ``<a:blip r:embed="rIdN"/>`` references verbatim. Those rIds are
dangling on their own: the rId→file mapping (slide ``.rels``) and the image bytes
(``ppt/media/``) live in the source slide's package parts, not in the fragment. Rendered as-is,
every embedded icon breaks.

This module re-homes the referenced media into the design-system run so the fragment becomes
self-resolving:

  - find every embedded/linked media reference in the fragment,
  - resolve each rId against the source slide's rels,
  - copy the bytes into a shared, content-addressed pool (``<run>/media/``) deduped by sha1 —
    identical icons used across many variants are stored once,
  - emit a sibling ``<id>/shapes.xml.rels`` mapping the SAME rIds → ``../../media/<file>``.

The fragment's rIds are left unchanged: they came from one source slide, so they are already
unique within the fragment, and a sibling rels keyed by them is all a consumer (the Phase-2
renderer) needs to resolve each blip. Target paths are relative to the entity dir that holds
``shapes.xml`` (so ``../../media/<file>`` lands at ``<run>/media/<file>``).

``body_register`` calls this during live extraction; ``backfill_media_rels`` reuses it to repair
an already-promoted design system from its source template.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

from lxml import etree

R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PR_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CT_IMAGE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"
# Attributes that name an embedded/linked part. r:id (hyperlinks/slide refs) is intentionally
# excluded — rewriting those would break navigation, and they are never image media.
_REF_ATTRS = (f"{{{R_NS}}}embed", f"{{{R_NS}}}link")


def media_ref_ids(root: etree._Element) -> list[str]:
    """Ordered-unique relationship ids referenced as embedded/linked media inside `root`."""
    seen: set[str] = set()
    out: list[str] = []
    for el in root.iter():
        for attr in _REF_ATTRS:
            rid = el.get(attr)
            if rid and rid not in seen:
                seen.add(rid)
                out.append(rid)
    return out


def parse_rels(rels_path: Path) -> dict[str, str]:
    """rId → Target (e.g. ``../media/image10.png``) from a ``.rels`` file. ``{}`` if absent."""
    if not rels_path.exists():
        return {}
    out: dict[str, str] = {}
    for r in etree.parse(str(rels_path)).getroot():
        rid, target = r.get("Id"), r.get("Target")
        if rid and target:
            out[rid] = target
    return out


def _is_media_target(target: str | None) -> bool:
    """A relationship Target that points at a packaged image part (not an external link)."""
    if not target or "://" in target:
        return False
    return "media/" in target.replace("\\", "/")


def _short_hash(data: bytes) -> str:
    return hashlib.sha1(data).hexdigest()[:16]


def emit_rels_for_fragment(
    shapes_xml: Path,
    slide_rels: dict[str, str],
    media_src: Path,
    pool_dir: Path,
    *,
    pool_prefix: str = "../../media",
    overwrite: bool = False,
) -> dict:
    """Re-home one carved fragment's media.

    Copies every media part the fragment references into the shared `pool_dir` (deduped by
    content hash) and writes ``<shapes_xml>.rels`` mapping each media rId to the pooled file.
    A fragment that references no media writes nothing.

    Args:
        shapes_xml: the carved ``shapes.xml`` fragment.
        slide_rels: rId→Target from the fragment's SOURCE slide ``.rels``.
        media_src:  dir holding the source media by basename (``image10.png`` …).
        pool_dir:   shared run-level media pool (``<run>/media/``), created on demand.
        pool_prefix: rels Target prefix, relative to the entity dir.
        overwrite:  rewrite the sibling rels even if it already exists.

    Returns ``{"rels": <relname|None>, "media": [pooled filenames], "missing": [rIds]}``.
    """
    out_rels = shapes_xml.with_name(shapes_xml.name + ".rels")
    root = etree.parse(str(shapes_xml)).getroot()
    ids = media_ref_ids(root)
    if not ids:
        return {"rels": None, "media": [], "missing": []}
    if out_rels.exists() and not overwrite:
        existing = parse_rels(out_rels)
        return {"rels": out_rels.name, "media": sorted({Path(t).name for t in existing.values()}),
                "missing": [i for i in ids if i not in existing]}

    rels_root = etree.Element(f"{{{PR_NS}}}Relationships", nsmap={None: PR_NS})
    used: list[str] = []
    missing: list[str] = []
    for rid in ids:
        target = slide_rels.get(rid)
        if target is None or not _is_media_target(target):
            # external link or unresolved — not our pooled media; leave the rId out of the rels.
            if target is None:
                missing.append(rid)
            continue
        src = media_src / Path(target).name
        if not src.exists():
            missing.append(rid)
            continue
        data = src.read_bytes()
        name = _short_hash(data) + Path(src.name).suffix.lower()
        dst = pool_dir / name
        if not dst.exists():
            pool_dir.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(data)
        rel = etree.SubElement(rels_root, f"{{{PR_NS}}}Relationship")
        rel.set("Id", rid)
        rel.set("Type", CT_IMAGE)
        rel.set("Target", f"{pool_prefix}/{name}")
        used.append(name)

    if len(rels_root):
        etree.ElementTree(rels_root).write(
            str(out_rels), xml_declaration=True, encoding="UTF-8", standalone=True)
        return {"rels": out_rels.name, "media": used, "missing": missing}
    return {"rels": None, "media": [], "missing": missing}
