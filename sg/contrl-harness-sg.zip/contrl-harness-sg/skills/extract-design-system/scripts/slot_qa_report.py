#!/usr/bin/env python3
"""slot_qa_report: aggregate per-entity slot_qa.json into slot_qa_summary.json (machine-readable).

The per-entity verdicts are shown to humans inline in catalog.html (a verdict chip on each entity
card), so this step no longer emits a standalone report page — just the rolled-up summary.
"""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

RANK = {"major": 0, "minor": 1, "ok": 2}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    args = ap.parse_args()
    run = Path(args.run)

    results = []
    for kind, root in (("variant", run / "variants"), ("adornment", run / "adornments")):
        for d in sorted(root.glob("*/")):
            qf = d / "slot_qa.json"
            if qf.exists():
                try:
                    q = json.loads(qf.read_text())
                except Exception:
                    q = {"id": d.name, "verdict": "major", "issues": [{"type": "target", "detail": "invalid slot_qa.json"}], "summary": "parse error"}
                q["_kind"] = kind
                q.setdefault("id", d.name)
                results.append(q)

    results.sort(key=lambda r: (RANK.get(r.get("verdict", "major"), 0), r["id"]))
    verdicts = Counter(r.get("verdict", "?") for r in results)
    itypes = Counter(i.get("type") for r in results for i in r.get("issues", []))

    # The per-entity verdicts are surfaced inline in catalog.html (verdict chips on each entity
    # card), so this step only emits the machine-readable summary — no standalone slot_qa.html
    # (its old slots.html# links were dead anyway).
    (run / "slot_qa_summary.json").write_text(json.dumps(
        {"verdicts": dict(verdicts), "issue_types": dict(itypes),
         "flagged": [r["id"] for r in results if r.get("verdict") != "ok"]}, ensure_ascii=False, indent=1))
    print(f"slot_qa_report: {len(results)} reviewed | major {verdicts.get('major',0)} "
          f"minor {verdicts.get('minor',0)} ok {verdicts.get('ok',0)} "
          f"-> slot_qa_summary.json (verdicts shown inline in catalog.html)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
