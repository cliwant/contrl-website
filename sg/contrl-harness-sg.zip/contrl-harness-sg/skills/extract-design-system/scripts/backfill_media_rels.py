#!/usr/bin/env python3
"""backfill_media_rels: repair an already-promoted design system whose carved fragments embed
icons but ship no media/rels — i.e. every ``<a:blip r:embed>`` dangles and renders broken.

Older extract runs (before body_register re-homed media) wrote ``variants/<id>/shapes.xml`` with
the source slide's ``r:embed`` ids intact but never carried the rId→file mapping or the image
bytes. This script reconstructs them from the original template:

  - opens the source ``.pptx`` and indexes every slide's spTree + rels + media,
  - for each fragment that embeds media, finds the source slide it was carved from by matching
    its top-level shape ids AND their embed ids (a fragment is a verbatim deepcopy of one slide's
    shapes, so the match is exact; ties resolve to the lowest slide number),
  - copies the referenced media into the shared ``<ds>/media/`` pool (deduped) and writes the
    sibling ``shapes.xml.rels`` — reusing the same helper body_register uses live,
  - records ``artifacts.rels`` in ``catalog.json`` for every entity that gained one.

Idempotent: a fragment whose ``shapes.xml.rels`` already exists is left alone unless ``--force``.
The catalog round-trips byte-for-byte, so the only diff is the added ``rels`` keys.
"""
from __future__ import annotations

import argparse
import json
import sys
import tempfile
import zipfile
from pathlib import Path

from lxml import etree

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _lib import media_rels  # noqa: E402

P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
SHAPE_TAGS = {"sp", "pic", "grpSp", "cxnSp", "graphicFrame"}


def _top_shapes(container: etree._Element) -> list[etree._Element]:
    return [ch for ch in container if etree.QName(ch).localname in SHAPE_TAGS]


def _own_id(shape: etree._Element) -> str | None:
    cnv = shape.find(f".//{{{P_NS}}}cNvPr")
    return cnv.get("id") if cnv is not None else None


def _top_ids(container: etree._Element) -> set[str]:
    return {i for sh in _top_shapes(container) if (i := _own_id(sh))}


def _embed_pairs(container: etree._Element) -> dict[str, list[str]]:
    """{top-shape id: [embed/link rIds in document order]} for shapes that reference media."""
    out: dict[str, list[str]] = {}
    for sh in _top_shapes(container):
        sid = _own_id(sh)
        embeds = media_rels.media_ref_ids(sh)
        if sid and embeds:
            out[sid] = embeds
    return out


def _sptree(slide_root: etree._Element) -> etree._Element | None:
    return slide_root.find(f".//{{{P_NS}}}cSld/{{{P_NS}}}spTree")


def index_source(pptx: Path):
    """Index the template: per-slide top-ids, embed-pairs, and rels. Extract media to a temp dir."""
    z = zipfile.ZipFile(pptx)
    names = set(z.namelist())
    slides: dict[int, dict] = {}
    import re
    for nm in names:
        m = re.fullmatch(r"ppt/slides/slide(\d+)\.xml", nm)
        if not m:
            continue
        n = int(m.group(1))
        sp = _sptree(etree.fromstring(z.read(nm)))
        if sp is None:
            continue
        rels: dict[str, str] = {}
        rn = f"ppt/slides/_rels/slide{n}.xml.rels"
        if rn in names:
            rr = etree.fromstring(z.read(rn))
            rels = {r.get("Id"): r.get("Target") for r in rr if r.get("Id")}
        slides[n] = {"top_ids": _top_ids(sp), "pairs": _embed_pairs(sp), "rels": rels}

    media_dir = Path(tempfile.mkdtemp(prefix="backfill_media_"))
    for mn in [n for n in names if n.startswith("ppt/media/") and not n.endswith("/")]:
        (media_dir / Path(mn).name).write_bytes(z.read(mn))
    return slides, media_dir


def find_rep_slide(frag_root: etree._Element, slides: dict[int, dict]) -> int | None:
    """The source slide a fragment was carved from: top-ids ⊇ + per-shape embed ids match exactly
    and all resolve to media. Falls back to any candidate whose embeds resolve. Lowest n on ties."""
    tids = _top_ids(frag_root)
    pf = _embed_pairs(frag_root)
    if not tids:
        return None
    cands = [n for n, s in slides.items() if tids <= s["top_ids"]]

    def strict(n: int) -> bool:
        s = slides[n]
        for sid, embeds in pf.items():
            if s["pairs"].get(sid) != embeds:
                return False
            if not all(media_rels._is_media_target(s["rels"].get(e)) for e in embeds):
                return False
        return True

    hits = [n for n in cands if strict(n)]
    if hits:
        return min(hits)
    loose = [n for n in cands
             if all(media_rels._is_media_target(slides[n]["rels"].get(e))
                    for embeds in pf.values() for e in embeds)]
    return min(loose) if loose else None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True, help="design-system dir (holds catalog.json + variants/ …)")
    ap.add_argument("--source", required=True, type=Path, help="source template .pptx")
    ap.add_argument("--force", action="store_true", help="rewrite shapes.xml.rels even if present")
    ap.add_argument("--dry-run", action="store_true", help="report only; write nothing")
    args = ap.parse_args()

    ds = Path(args.ds)
    pool = ds / "media"
    slides, media_dir = index_source(args.source)
    print(f"indexed {len(slides)} source slides; staged media → {media_dir}")

    catalog = json.loads((ds / "catalog.json").read_text())
    by_id = {p: {e["id"]: e for e in catalog.get(p, [])} for p in ("variants", "adornments")}

    done = skipped = unmatched = 0
    unresolved: list[str] = []
    for pool_name in ("variants", "adornments"):
        pdir = ds / pool_name
        if not pdir.is_dir():
            continue
        for d in sorted(p for p in pdir.iterdir() if p.is_dir()):
            sx = d / "shapes.xml"
            if not sx.exists():
                continue
            ids = media_rels.media_ref_ids(etree.parse(str(sx)).getroot())
            if not ids:
                continue
            rels_path = d / "shapes.xml.rels"
            if rels_path.exists() and not args.force:
                skipped += 1
                ent = by_id[pool_name].get(d.name)
                if ent is not None:
                    ent.setdefault("artifacts", {})["rels"] = f"{pool_name}/{d.name}/shapes.xml.rels"
                continue
            rep = find_rep_slide(etree.parse(str(sx)).getroot(), slides)
            if rep is None:
                unmatched += 1
                unresolved.append(f"{pool_name}/{d.name} (no source slide matched {len(ids)} embeds)")
                continue
            if args.dry_run:
                done += 1
                continue
            res = media_rels.emit_rels_for_fragment(
                sx, slides[rep]["rels"], media_dir, pool, overwrite=args.force)
            if res["rels"]:
                done += 1
                ent = by_id[pool_name].get(d.name)
                if ent is not None:
                    ent.setdefault("artifacts", {})["rels"] = f"{pool_name}/{d.name}/shapes.xml.rels"
            if res["missing"]:
                unresolved.append(f"{pool_name}/{d.name} slide{rep}: unresolved {res['missing']}")

    if not args.dry_run:
        (ds / "catalog.json").write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n")

    n_media = len(list(pool.glob("*"))) if pool.is_dir() else 0
    print(f"backfill → {done} rels written, {skipped} already present, {unmatched} unmatched; "
          f"{n_media} pooled media")
    if unresolved:
        print(f"  ⚠ {len(unresolved)} with unresolved/unmatched refs:")
        for u in unresolved[:40]:
            print("   -", u)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
