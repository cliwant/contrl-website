#!/usr/bin/env python3
"""body_register (stage 3, production): turn the audited cluster assignments + crop manifest into
the canonical variant/adornment pools.

For every cluster it:
  - picks a representative occurrence (the member covering the largest slide area = most complete),
  - carves that occurrence's shapes into <run>/<pool>/<id>/shapes.xml (a <p:spTree> fragment, the
    authoritative geometry the slot-tag step reads),
  - re-homes that occurrence's embedded icons: copies the media the carved shapes reference into the
    shared <run>/media/ pool (deduped by content hash) and writes a sibling shapes.xml.rels, so each
    <a:blip r:embed> resolves at render time instead of dangling (needs slides/<n>/raw.xml.rels +
    _work/media_src/ from unpack),
  - copies that occurrence's crop to <run>/<pool>/<id>/preview.png (the catalog thumbnail),
  - records every occurrence (slide + bbox) for evidence.

Writes:
  <run>/<pool>/<id>/{shapes.xml,preview.png}     per-entity canonical artifacts
  <run>/<pool>/<id>/shapes.xml.rels              per-entity rId→pooled-media map (only when it has icons)
  <run>/media/<hash>.<ext>                        shared content-addressed media pool (deduped)
  <bodydir>/pools.json                           {variants[],adornments[],occurrences:{n:[...]}}  (catalog_compile reads this)
  <run>/variants.json                            {variants:[{id,rep_region_key,name}]}             (catalog_compile reads this for evidence slot_values)

Idempotent: an entity whose shapes.xml already exists is left alone (re-run resumes).
Template-agnostic: no sample/ground-truth input — it consumes whatever clusters exist.
"""
from __future__ import annotations

import argparse
import copy
import json
import shutil
import sys
from collections import defaultdict
from pathlib import Path

from lxml import etree

SK = Path(__file__).resolve().parents[0]
sys.path.insert(0, str(SK))
from _lib import media_rels, pptx_xml  # noqa: E402

P_NS = pptx_xml.NS["p"]


def carve_shapes(raw_xml: Path, keep_ids: set[str], out: Path) -> int:
    """Write a <p:spTree> fragment holding the top-level shapes of `raw_xml` that are (or contain)
    a kept shape id. Returns the number of shapes written."""
    tree = pptx_xml.parse(raw_xml)
    sptree = etree.Element(f"{{{P_NS}}}spTree", nsmap=pptx_xml.NS)
    n = 0
    for sh in pptx_xml.iter_top_level_shapes(tree):
        sid = pptx_xml.shape_id(sh)
        if sid in keep_ids or (pptx_xml.descendant_shape_ids(sh) & keep_ids):
            sptree.append(copy.deepcopy(sh))
            n += 1
    etree.ElementTree(sptree).write(str(out), xml_declaration=True, encoding="UTF-8", standalone=True)
    return n


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--bodydir", help="dir holding manifest.json + crops/ (default <run>/_work/body)")
    ap.add_argument("--clusters", help="clusters json (default <bodydir>/clusters.json)")
    ap.add_argument("--kind-audit", dest="kind_audit",
                    help="body-kind-audit verdicts (default <bodydir>/kind_audit.json). Adornment types "
                         "judged 'content' are reclassified into variants before carving — so no separate "
                         "audited_clusters.json step is needed.")
    args = ap.parse_args()

    R = Path(args.run)
    bodydir = Path(args.bodydir) if args.bodydir else R / "_work" / "body"
    clusters_path = Path(args.clusters) if args.clusters else bodydir / "clusters.json"
    ka_path = Path(args.kind_audit) if args.kind_audit else bodydir / "kind_audit.json"
    manifest = {m["tag"]: m for m in json.loads((bodydir / "manifest.json").read_text())}
    clusters = json.loads(clusters_path.read_text())

    # Apply body-kind-audit verdicts in-line (if present): an adornment TYPE judged "content" by the
    # audit step is reclassified into the variant pool. This is the merge that used to require a
    # hand-made audited_clusters.json — body_register now does it deterministically from the verdicts.
    if ka_path.exists():
        verdicts = {v["id"]: v["verdict"] for v in json.loads(ka_path.read_text()).get("verdicts", [])}
        moved = [a for a in clusters.get("adornments", []) if verdicts.get(a["id"]) == "content"]
        if moved:
            clusters["variants"] = clusters.get("variants", []) + moved
            clusters["adornments"] = [a for a in clusters["adornments"] if verdicts.get(a["id"]) != "content"]
            print(f"  kind-audit: reclassified {len(moved)} adornment→variant: {[a['id'] for a in moved]}")

    pools: dict = {"variants": [], "adornments": []}
    variants_index: list = []
    occ_by_slide: dict = defaultdict(list)
    carved = copied = relsed = 0
    media_src = R / "_work" / "media_src"

    for kind_sing, ckey in (("variant", "variants"), ("adornment", "adornments")):
        for c in clusters.get(ckey, []):
            eid = c["id"]
            members = [t for t in c["members"] if t in manifest]
            if not members:
                print(f"  [warn] cluster {eid}: no members in manifest, skipped", file=sys.stderr)
                continue
            rep = max(members, key=lambda t: manifest[t].get("area_frac", 0))
            rm = manifest[rep]

            edir = R / ckey / eid
            edir.mkdir(parents=True, exist_ok=True)
            sx, pv = edir / "shapes.xml", edir / "preview.png"
            if not sx.exists():
                keep = {str(s) for s in rm.get("shape_ids", [])}
                raw = R / "slides" / str(rm["slide"]) / "raw.xml"
                if keep and raw.exists():
                    carve_shapes(raw, keep, sx)
                    carved += 1
                else:
                    print(f"  [warn] {eid}: no shape_ids/raw.xml — shapes.xml not carved", file=sys.stderr)
            crop = bodydir / "crops" / f"{rep}.png"
            if crop.exists() and not pv.exists():
                shutil.copy(crop, pv)
                copied += 1

            # Re-home embedded icons: copy the rep slide's referenced media into the shared run
            # pool (<run>/media/, deduped) and write a sibling shapes.xml.rels so each
            # <a:blip r:embed> resolves at render time instead of dangling.
            has_rels = False
            if sx.exists():
                slide_rels = media_rels.parse_rels(R / "slides" / str(rm["slide"]) / "raw.xml.rels")
                res = media_rels.emit_rels_for_fragment(sx, slide_rels, media_src, R / "media")
                if res["rels"]:
                    has_rels = True
                    relsed += 1
                if res["missing"]:
                    print(f"  [warn] {eid}: {len(res['missing'])} media ref(s) unresolved "
                          f"{res['missing']}", file=sys.stderr)

            for t in members:
                mb = manifest[t]["bbox_emu"]   # manifest stores {x,y,w,h}; evidence bbox is {x,y,cx,cy}
                occ_by_slide[manifest[t]["slide"]].append({
                    "kind": kind_sing, "id": eid,
                    "bbox_emu": {"x": mb["x"], "y": mb["y"], "cx": mb["w"], "cy": mb["h"]}})
            b = rm["bbox_emu"]
            sz = {"w": b["w"], "h": b["h"]}    # variant/adornment size keeps w/h (spec §2-4/2-5)
            art = {"shapes": f"{ckey}/{eid}/shapes.xml", "preview": f"{ckey}/{eid}/preview.png"}
            if has_rels:
                art["rels"] = f"{ckey}/{eid}/shapes.xml.rels"
            if ckey == "variants":
                entry = {"id": eid, "name": c.get("name", eid), "description": c.get("description", ""),
                         "size_emu": sz, "artifacts": art}
                variants_index.append({"id": eid, "rep_region_key": f"{rm['slide']}_{rep}", "name": entry["name"]})
            else:  # adornments carry `note`, not `description` (spec §2-5)
                entry = {"id": eid, "name": c.get("name", eid), "note": c.get("description", ""),
                         "size_emu": sz, "artifacts": art}
            pools[ckey].append(entry)

    occ = {str(n): sorted(v, key=lambda o: o["bbox_emu"]["y"]) for n, v in occ_by_slide.items()}
    bodydir.mkdir(parents=True, exist_ok=True)
    (bodydir / "pools.json").write_text(json.dumps(
        {"variants": pools["variants"], "adornments": pools["adornments"], "occurrences": occ},
        ensure_ascii=False, indent=2))
    (R / "variants.json").write_text(json.dumps({"variants": variants_index}, ensure_ascii=False, indent=2))

    nv, na = len(pools["variants"]), len(pools["adornments"])
    n_media = len(list((R / "media").glob("*"))) if (R / "media").is_dir() else 0
    print(f"body_register → {nv} variants + {na} adornments "
          f"({carved} shapes.xml carved, {copied} preview.png copied, "
          f"{relsed} shapes.xml.rels written, {n_media} pooled media)")
    print(f"  occurrences over {len(occ)} slides → pools.json; variants.json index ({len(variants_index)})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
