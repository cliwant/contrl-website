#!/usr/bin/env python3
"""body_crop: crop each split unit from its slide render, build index-labeled contact-sheet
montages (one per kind) for the vision cluster step, and a manifest. stdlib + PIL only."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


def font(sz):
    for p in ("/System/Library/Fonts/Helvetica.ttc", "/System/Library/Fonts/Supplemental/Arial.ttf"):
        try:
            return ImageFont.truetype(p, sz)
        except Exception:
            pass
    return ImageFont.load_default()


def montage(cells, cols, cell_w, cell_h, pad=8):
    """cells = [(tag, PIL.Image)]; returns a labeled grid image."""
    rows = (len(cells) + cols - 1) // cols
    W, H = cols * (cell_w + pad) + pad, rows * (cell_h + pad) + pad
    sheet = Image.new("RGB", (W, H), "#e8e8ea")
    d = ImageDraw.Draw(sheet)
    f = font(26)
    for i, (tag, im) in enumerate(cells):
        r, c = divmod(i, cols)
        x0, y0 = pad + c * (cell_w + pad), pad + r * (cell_h + pad)
        sheet.paste(Image.new("RGB", (cell_w, cell_h), "white"), (x0, y0))
        im = im.copy()
        im.thumbnail((cell_w - 6, cell_h - 6))
        sheet.paste(im, (x0 + (cell_w - im.width) // 2, y0 + (cell_h - im.height) // 2))
        d.rectangle([x0, y0, x0 + 46, y0 + 30], fill="#e6194B")
        d.text((x0 + 4, y0 + 2), tag, fill="white", font=f)
    return sheet


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--splitdir", required=True)
    ap.add_argument("--sample", help="(optional) restrict to slides in this sample json; "
                                     "else every slide_*.json in --splitdir")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    run, out = Path(args.run), Path(args.out)
    (out / "crops").mkdir(parents=True, exist_ok=True)
    emu = json.loads((run / "catalog.json").read_text())["meta"]["slide_emu"]
    W, H = emu["w"], emu["h"]
    if args.sample:
        slides = [s["slide"] for s in json.loads(Path(args.sample).read_text())["slides"]]
    else:
        slides = sorted(int(p.stem.split("_")[1]) for p in Path(args.splitdir).glob("slide_*.json"))

    manifest, vcells, acells = [], [], []
    vi = ai = 0
    for n in slides:
        sp = Path(args.splitdir) / f"slide_{n}.json"
        if not sp.exists():
            continue
        img = Image.open(run / "slides" / str(n) / "viz" / "01_raw.png").convert("RGB")
        iw, ih = img.size
        for ui, u in enumerate(json.loads(sp.read_text()).get("units", [])):
            b = u["bbox_emu"]
            box = (max(0, int(b["x"] / W * iw)), max(0, int(b["y"] / H * ih)),
                   min(iw, int((b["x"] + b["w"]) / W * iw)), min(ih, int((b["y"] + b["h"]) / H * ih)))
            if box[2] <= box[0] or box[3] <= box[1]:
                continue
            crop = img.crop(box)
            kind = u.get("kind")
            tag = f"V{vi}" if kind == "variant" else f"A{ai}"
            cp = out / "crops" / f"{tag}.png"
            crop.save(cp)
            rec = {"tag": tag, "kind": kind, "slide": n, "unit": ui, "bbox_emu": b,
                   "label": u.get("label", ""), "aspect": round(b["w"] / max(1, b["h"]), 2),
                   "area_frac": round(b["w"] * b["h"] / (W * H), 3),
                   "n_shapes": len(u.get("shape_ids", [])),
                   "shape_ids": [str(s) for s in u.get("shape_ids", [])]}
            manifest.append(rec)
            if kind == "variant":
                vcells.append((tag, crop)); vi += 1
            else:
                acells.append((tag, crop)); ai += 1

    # adornments sorted by aspect so same forms sit adjacent (helps clustering)
    acells.sort(key=lambda c: c[1].size[0] / max(1, c[1].size[1]))

    def emit_sheets(cells, cols, cell_w, cell_h, prefix, pad=8, target_h=1520):
        """Paginate into legible sheets. A single tall montage (one page per kind) becomes
        unreadable once a vision model downscales it to fit — cells shrink to a few px. So cap
        each page near a one-screen height and emit numbered pages `<prefix>_01.png, _02.png…`.
        Tags stay stable across pages (drawn on each cell), so clustering still spans all pages."""
        if not cells:
            return []
        max_rows = max(1, (target_h - pad) // (cell_h + pad))
        per_page = cols * max_rows
        names = []
        for pi in range(0, len(cells), per_page):
            name = f"{prefix}_{pi // per_page + 1:02d}.png"
            montage(cells[pi:pi + per_page], cols, cell_w, cell_h, pad).save(out / name)
            names.append(name)
        return names

    vpages = emit_sheets(vcells, 6, 240, 180, "variant_sheet")
    apages = emit_sheets(acells, 4, 360, 90, "adornment_sheet")
    (out / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    print(f"crops: {vi} variant + {ai} adornment | sheets: {len(vpages)} variant page(s), {len(apages)} adornment page(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
