#!/usr/bin/env python3
"""Dump the PPTX's visible text per slide to <run_dir>/text/slides.md via MarkItDown.

MarkItDown emits `<!-- Slide number: N -->` markers between slides, which is
exactly the per-slide separator the intent-discover LLM step needs.

Exposes extract_text() for the preprocess.py entrypoint; also runnable standalone
for a cheap text-only re-dump without re-rendering.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from markitdown import MarkItDown


def extract_text(pptx: Path, build: Path) -> int:
    if not pptx.exists():
        print(f"pptx not found: {pptx}", file=sys.stderr)
        return 2

    out_dir = build / "text"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "slides.md"

    md = MarkItDown()
    result = md.convert(str(pptx))
    out_path.write_text(result.text_content, encoding="utf-8")

    # Count slide markers as a sanity check.
    n_slides = result.text_content.count("<!-- Slide number:")
    print(f"wrote {out_path} ({len(result.text_content)} chars, {n_slides} slide markers)")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pptx", required=True, type=Path)
    ap.add_argument("--build-dir", required=True, type=Path)
    args = ap.parse_args()
    return extract_text(args.pptx, args.build_dir)


if __name__ == "__main__":
    raise SystemExit(main())
