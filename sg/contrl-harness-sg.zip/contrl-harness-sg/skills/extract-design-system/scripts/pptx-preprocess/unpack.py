#!/usr/bin/env python3
"""Unpack a pptx: copy slide XML + presentation.xml, render baseline PNGs.

Exposes unpack() for the preprocess.py entrypoint; also runnable standalone for
independent re-render without the text dump.
"""
from __future__ import annotations

import argparse
import shutil
import sys
import zipfile
from pathlib import Path

# Make _lib importable when run as a script
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from _lib.render import render_pptx_to_pngs  # noqa: E402


def unpack(pptx: Path, build: Path) -> int:
    pptx = pptx.resolve()
    build = build.resolve()
    build.mkdir(parents=True, exist_ok=True)

    if not pptx.exists():
        print(f"PPTX not found: {pptx}", file=sys.stderr)
        return 2

    # Persist source path for downstream steps
    (build / "source.pptx.path").write_text(str(pptx) + "\n")

    # Copy slide XMLs (+ their .rels) and presentation.xml, and stage source media.
    # The per-slide .rels + media let body_register re-home each carved fragment's embedded
    # icons (rId→file mapping + image bytes) instead of leaving <a:blip r:embed> dangling.
    media_src = build / "_work" / "media_src"
    with zipfile.ZipFile(pptx) as z:
        names = set(z.namelist())
        with z.open("ppt/presentation.xml") as f:
            (build / "presentation.xml").write_bytes(f.read())

        slide_names = sorted(
            [n for n in names if n.startswith("ppt/slides/slide") and n.endswith(".xml")],
            key=lambda n: int(n.removeprefix("ppt/slides/slide").removesuffix(".xml")),
        )
        for slide_name in slide_names:
            n = int(slide_name.removeprefix("ppt/slides/slide").removesuffix(".xml"))
            slide_dir = build / "slides" / str(n)
            slide_dir.mkdir(parents=True, exist_ok=True)
            (slide_dir / "viz").mkdir(exist_ok=True)
            with z.open(slide_name) as f:
                (slide_dir / "raw.xml").write_bytes(f.read())
            rels_name = f"ppt/slides/_rels/slide{n}.xml.rels"
            if rels_name in names:
                with z.open(rels_name) as f:
                    (slide_dir / "raw.xml.rels").write_bytes(f.read())

        media_names = [n for n in names if n.startswith("ppt/media/") and not n.endswith("/")]
        if media_names:
            media_src.mkdir(parents=True, exist_ok=True)
            for mn in media_names:
                with z.open(mn) as f:
                    (media_src / Path(mn).name).write_bytes(f.read())

    print(f"Copied {len(slide_names)} slide XMLs to {build}/slides/ "
          f"(+ rels), staged {len(media_names)} media → {media_src}")

    # Render all slides to PNG
    render_root = build / "_render"
    if render_root.exists():
        shutil.rmtree(render_root)
    pngs = render_pptx_to_pngs(pptx, render_root)
    print(f"Rendered {len(pngs)} PNGs via soffice")

    # Distribute renders into per-slide viz/01_raw.png
    for png in pngs:
        n = int(png.stem.split("_")[-1])
        dst = build / "slides" / str(n) / "viz" / "01_raw.png"
        shutil.copy(png, dst)
        print(f"  → {dst.relative_to(build.parent) if dst.is_relative_to(build.parent) else dst}")

    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pptx", required=True, type=Path)
    ap.add_argument("--build-dir", type=Path, default=Path("build"))
    args = ap.parse_args()
    return unpack(args.pptx, args.build_dir)


if __name__ == "__main__":
    raise SystemExit(main())
