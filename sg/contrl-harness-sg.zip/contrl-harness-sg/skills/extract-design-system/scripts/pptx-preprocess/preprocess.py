#!/usr/bin/env python3
"""Step 1: preprocess a PPTX into every derived artifact the pipeline needs.

One mechanical entrypoint over the raw template. Produces both derivation paths:
  - visual/structural (for variant-extract): slides/<n>/raw.xml, slides/<n>/viz/01_raw.png
  - text (for intent-discover):              text/slides.md

Render (soffice) and text dump (markitdown) are independent. Use --skip-render or
--skip-text to re-run just one half — rendering is slow, the text dump is cheap.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Sibling modules in this skill dir.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from text_extract import extract_text  # noqa: E402
from unpack import unpack  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description="Mechanical PPTX preprocessing (unpack + text dump).")
    ap.add_argument("--pptx", required=True, type=Path)
    ap.add_argument("--build-dir", type=Path, default=Path("build"))
    ap.add_argument("--skip-render", action="store_true",
                    help="Skip unzip + soffice render (XML + 01_raw.png). Text dump still runs.")
    ap.add_argument("--skip-text", action="store_true",
                    help="Skip the markitdown text dump (text/slides.md). Unpack still runs.")
    args = ap.parse_args()

    pptx: Path = args.pptx
    build: Path = args.build_dir

    rc = 0
    if not args.skip_render:
        print("[preprocess] unpack + render")
        rc = unpack(pptx, build)
        if rc != 0:
            return rc
    else:
        print("[preprocess] --skip-render: skipping unpack + render")

    if not args.skip_text:
        print("[preprocess] text dump (markitdown)")
        rc = extract_text(pptx, build)
        if rc != 0:
            return rc
    else:
        print("[preprocess] --skip-text: skipping text dump")

    print("[preprocess] done")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
