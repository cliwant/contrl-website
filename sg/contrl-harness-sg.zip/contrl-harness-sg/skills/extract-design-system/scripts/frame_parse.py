#!/usr/bin/env python3
"""frame-parse: read slideLayouts + slideMasters straight from the pptx zip.

Layout/master are already structured XML in the file — we don't infer them from
slides, we READ them. This step extracts (mechanically): placeholders (type/idx +
geometry), every top-level shape's bbox+text (furniture candidates), the layout→master
link, the slide→layout map, and a heuristic content_box. The LLM step (frame_annotate)
names furniture roles and confirms content_box.

Output: <run>/frame.json
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
import zipfile
from pathlib import Path

from lxml import etree

A = "http://schemas.openxmlformats.org/drawingml/2006/main"
P = "http://schemas.openxmlformats.org/presentationml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS = {"a": A, "p": P, "r": R}
SHAPE_TAGS = {"sp", "pic", "grpSp", "cxnSp", "graphicFrame"}


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def _bbox(sp) -> dict | None:
    xfrm = sp.find(".//a:xfrm", NS)
    if xfrm is None:
        return None
    off = xfrm.find("a:off", NS)
    ext = xfrm.find("a:ext", NS)
    if off is None or ext is None:
        return None
    try:
        return {"x": int(off.get("x")), "y": int(off.get("y")),
                "w": int(ext.get("cx")), "h": int(ext.get("cy"))}
    except (TypeError, ValueError):
        return None


def _text(sp) -> str:
    return " ".join(t.text or "" for t in sp.findall(".//a:t", NS)).strip()


def _sptree(root):
    st = root.find(".//p:cSld/p:spTree", NS)
    return st if st is not None else []


def _parse_frame_xml(xml_bytes: bytes) -> dict:
    root = etree.fromstring(xml_bytes)
    placeholders, furniture = [], []
    for sp in _sptree(root):
        tag = _local(sp.tag)
        if tag not in SHAPE_TAGS:
            continue
        ph = sp.find(".//p:nvSpPr/p:nvPr/p:ph", NS)
        bbox = _bbox(sp)
        if ph is not None:
            placeholders.append({
                "ph_type": ph.get("type"), "ph_idx": ph.get("idx"),
                "bbox": bbox, "text": _text(sp),
            })
        else:
            furniture.append({"tag": tag, "bbox": bbox, "text": _text(sp)})
    return {"placeholders": placeholders, "furniture": furniture}


def _rel_target(zf: zipfile.ZipFile, rels_path: str, rel_type_suffix: str) -> str | None:
    if rels_path not in zf.namelist():
        return None
    root = etree.fromstring(zf.read(rels_path))
    for rel in root:
        if rel.get("Type", "").endswith(rel_type_suffix):
            return rel.get("Target")
    return None


def _norm(target: str, base_dir: str) -> str:
    # resolve '../foo' relative to base_dir (e.g. 'ppt/slides')
    parts = (base_dir + "/" + target).split("/")
    out: list[str] = []
    for p in parts:
        if p == "..":
            out.pop()
        elif p in ("", "."):
            continue
        else:
            out.append(p)
    return "/".join(out)


def _rels_for(part: str) -> str:
    d, f = part.rsplit("/", 1)
    return f"{d}/_rels/{f}.rels"


def _rel_targets(zf: zipfile.ZipFile, rels_path: str) -> list[str]:
    """All internal (non-External) relationship targets in a .rels part, archive-resolved."""
    if rels_path not in zf.namelist():
        return []
    base = rels_path.rsplit("/_rels/", 1)[0]
    out = []
    for rel in etree.fromstring(zf.read(rels_path)):
        if (rel.get("TargetMode") or "Internal") == "External":
            continue
        tgt = rel.get("Target")
        if tgt:
            out.append(_norm(tgt, base))
    return out


def _build_frame_bundle(zf: zipfile.ZipFile, run: Path, seeds: list[str]) -> int:
    """Copy the *original* frame parts (slideLayouts·slideMasters·theme·referenced media + their
    rels) into <run>/frame/, mirroring the OPC archive paths so relationships still resolve. This
    is the inheritance bundle Phase 2 grafts into an output package to render the fixed frame
    (header band, page numbers, logos). BFS the rels graph from the layout/master seeds but never
    crosses into ppt/slides/ — so we pull masters↔layouts↔theme↔media, not the whole deck."""
    names = set(zf.namelist())
    want: set[str] = set()
    # seed from masters/layouts, plus the package root presentation.xml so Phase 2 has sldSz +
    # masterId list + theme refs to graft against (its rels reach masters/theme; slides are skipped).
    queue = [s for s in seeds if s in names]
    if "ppt/presentation.xml" in names:
        queue.append("ppt/presentation.xml")
    while queue:
        part = queue.pop()
        if part in want or part.startswith("ppt/slides/"):
            continue
        want.add(part)
        rels = _rels_for(part)
        if rels in names:
            want.add(rels)
            for tgt in _rel_targets(zf, rels):
                if tgt in names and tgt not in want and not tgt.startswith("ppt/slides/"):
                    queue.append(tgt)
    if "[Content_Types].xml" in names:        # type map for the grafting step (reference)
        want.add("[Content_Types].xml")
    frame_dir = run / "frame"
    if frame_dir.exists():
        shutil.rmtree(frame_dir)
    for part in sorted(want):
        dest = frame_dir / part
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(zf.read(part))
    (frame_dir / "manifest.json").write_text(json.dumps({
        "note": "Original frame parts for Phase-2 inheritance rendering "
                "(slideMasters, slideLayouts, theme, presentation, referenced media + rels).",
        "parts": sorted(want),
    }, ensure_ascii=False, indent=1))
    return len(want)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--pptx", required=True)
    args = ap.parse_args()
    run = Path(args.run)

    # slide size
    pres = run / "presentation.xml"
    w, h = 7561250, 10693400
    if pres.exists():
        m = re.search(r'<p:sldSz[^>]*cx="(\d+)"[^>]*cy="(\d+)"', pres.read_text())
        m2 = re.search(r'<p:sldSz[^>]*cy="(\d+)"[^>]*cx="(\d+)"', pres.read_text())
        if m:
            w, h = int(m.group(1)), int(m.group(2))
        elif m2:
            h, w = int(m2.group(1)), int(m2.group(2))

    zf = zipfile.ZipFile(args.pptx)
    names = zf.namelist()

    masters = []
    for name in sorted(n for n in names if re.match(r"ppt/slideMasters/slideMaster\d+\.xml$", n)):
        mid = "master-" + re.search(r"(\d+)", Path(name).stem).group(1)
        d = _parse_frame_xml(zf.read(name))
        masters.append({"id": mid, "src": name, **d})

    layouts = []
    layout_by_src = {}
    for name in sorted(n for n in names if re.match(r"ppt/slideLayouts/slideLayout\d+\.xml$", n)):
        lid = "layout-" + re.search(r"(\d+)", Path(name).stem).group(1)
        d = _parse_frame_xml(zf.read(name))
        rels = f"ppt/slideLayouts/_rels/{Path(name).name}.rels"
        mtarget = _rel_target(zf, rels, "/slideMaster")
        master_id = None
        if mtarget:
            msrc = _norm(mtarget, "ppt/slideLayouts")
            master_id = next((m["id"] for m in masters if m["src"] == msrc), None)
        # heuristic content_box: full width, drop top 10% / bottom 8%
        top = round(h * 0.10)
        cbox = {"x": 0, "y": top, "w": w, "h": h - top - round(h * 0.08)}
        layouts.append({"id": lid, "src": name, "master_id": master_id,
                        "content_box_heuristic": cbox, **d})
        layout_by_src[name] = lid

    # slide -> layout
    slide_layout_map = {}
    for sd in sorted((run / "slides").glob("*/"), key=lambda p: int(p.name) if p.name.isdigit() else 0):
        n = sd.name
        rels = f"ppt/slides/_rels/slide{n}.xml.rels"
        ltarget = _rel_target(zf, rels, "/slideLayout")
        if ltarget:
            lsrc = _norm(ltarget, "ppt/slides")
            slide_layout_map[n] = layout_by_src.get(lsrc)

    out = {
        "slide_emu": {"w": w, "h": h},
        "masters": masters,
        "layouts": layouts,
        "slide_layout_map": slide_layout_map,
        "_note": "furniture roles + content_box are heuristic; frame_annotate (LLM) finalizes them.",
    }
    (run / "frame.json").write_text(json.dumps(out, ensure_ascii=False, indent=2))

    # frame/ bundle — original slideLayout·slideMaster·theme·media+rels for Phase 2 inheritance render
    seeds = [m["src"] for m in masters] + [lo["src"] for lo in layouts]
    n_parts = _build_frame_bundle(zf, run, seeds)
    print(f"frame: {len(masters)} master(s), {len(layouts)} layout(s) · frame/ bundle: {n_parts} part(s)")
    for lo in layouts:
        print(f"  {lo['id']} <- {lo['master_id']}  ph={len(lo['placeholders'])} furniture={len(lo['furniture'])}")
    # layout usage
    from collections import Counter
    usage = Counter(slide_layout_map.values())
    print("  slide→layout usage:", dict(usage))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
