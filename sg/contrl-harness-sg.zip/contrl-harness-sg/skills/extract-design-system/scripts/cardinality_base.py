#!/usr/bin/env python3
"""cardinality-base: fill the FACT value `base` on every repeated/table slot by counting
actual repeated shapes (mechanical — never let the LLM guess a count). Reconciles with the
LLM's resizable/min/max judgment (invariant: min <= base <= max; fixed → min=max=base).

Edits each <run>/variants/<id>/slots.json in place.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _base_for(slot: dict) -> int | None:
    tgt = slot.get("target") or {}
    if isinstance(tgt.get("shape_ids"), list):
        return len(tgt["shape_ids"])
    card = slot.get("cardinality") or {}
    if isinstance(card.get("observed"), int):
        return card["observed"]
    if isinstance(slot.get("subslots"), list) and slot.get("kind") == "table":
        return None
    return None


def _fix(slot: dict) -> bool:
    if slot.get("kind") not in ("repeated", "table"):
        return False
    base = _base_for(slot)
    if base is None:
        return False
    card = dict(slot.get("cardinality") or {})
    card["base"] = base
    resizable = card.get("resizable")
    if resizable is None:
        resizable = bool(card.get("min") is not None and card.get("max") is not None
                         and card.get("min") != card.get("max"))
        card["resizable"] = resizable
    if not resizable:
        card.setdefault("min", base)
        card.setdefault("max", base)
    # enforce invariant min <= base <= max
    if card.get("min") is None or card["min"] > base:
        card["min"] = base
    if card.get("max") is None or card["max"] < base:
        card["max"] = base
    card.pop("observed", None)
    slot["cardinality"] = card
    return True


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    args = ap.parse_args()
    run = Path(args.run)
    n_slots, n_files = 0, 0
    sj_files = sorted((run / "variants").glob("*/slots.json")) + sorted((run / "adornments").glob("*/slots.json"))
    for sj in sj_files:
        data = json.loads(sj.read_text())
        changed = False
        for slot in data.get("slots", []):
            if _fix(slot):
                n_slots += 1; changed = True
            for sub in slot.get("subslots", []) or []:
                if _fix(sub):
                    n_slots += 1; changed = True
        if changed:
            sj.write_text(json.dumps(data, ensure_ascii=False, indent=2))
            n_files += 1
    print(f"cardinality-base: set base on {n_slots} repeated/table slot(s) across {n_files} variant(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
