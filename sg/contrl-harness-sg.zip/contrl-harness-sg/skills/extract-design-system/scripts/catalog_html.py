#!/usr/bin/env python3
"""catalog_html: render <run>/catalog.html from catalog.json + evidence.json (+ slide renders &
per-entity previews if present). Works at ANY stage — the slide-by-slide Overview shows each slide's
render + its Intent + its Layout from the moment those exist (gate②), and gains variant/adornment
overlay boxes once occurrences are recorded. Pool tabs follow."""
from __future__ import annotations

import argparse
import base64
import html
import io
import json
from collections import Counter, defaultdict
from pathlib import Path

try:
    from PIL import Image
    _HAVE_PIL = True
except Exception:  # Pillow absent — fall back to inlining the raw bytes
    _HAVE_PIL = False

_MAX_EDGE = 900  # downscale the long edge of inlined previews (displayed at ≤300px) to keep the file light


def data_uri(p: Path) -> str:
    """Inline a preview as a base64 data URI so the viewer is self-contained — renders in any
    context (browser file://, macOS Quick Look, editor HTML previews) regardless of whether
    sibling files resolve. Downscaled to _MAX_EDGE and re-encoded as JPEG (slide renders are
    text/line art on white — JPEG crushes them far better than a downscaled PNG, whose
    anti-aliased edges defeat PNG compression). Returns '' when the file is absent."""
    if not p.exists():
        return ""
    raw = p.read_bytes()
    if _HAVE_PIL:
        try:
            im = Image.open(io.BytesIO(raw))
            # flatten any transparency onto white — JPEG has no alpha channel
            if im.mode in ("RGBA", "LA", "PA") or (im.mode == "P" and "transparency" in im.info):
                im = im.convert("RGBA")
                bg = Image.new("RGB", im.size, (255, 255, 255))
                bg.paste(im, mask=im.split()[-1])
                im = bg
            else:
                im = im.convert("RGB")
            w, h = im.size
            scale = _MAX_EDGE / max(w, h)
            if scale < 1:
                im = im.resize((max(1, round(w * scale)), max(1, round(h * scale))), Image.LANCZOS)
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=78, optimize=True)
            return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
        except Exception:
            pass  # any decode/resize failure → inline the original bytes as-is
    return "data:image/png;base64," + base64.b64encode(raw).decode("ascii")

KC = {"text": "#4363d8", "richtext": "#911eb4", "image": "#3cb44b",
      "repeated": "#f58231", "table": "#e6194B", "composite": "#1aa3a3"}
OVL = {"variant": "#e6194B", "adornment": "#8250df"}


def _rect_xywh(o):
    """Accept {x,y,w,h} or {rect:{x,y,w,h}} (furniture) → (x,y,w,h) ints, or None."""
    r = (o or {}).get("rect", o) if isinstance(o, dict) else None
    if not isinstance(r, dict):
        return None
    try:
        return int(r["x"]), int(r["y"]), int(r["w"]), int(r["h"])
    except (KeyError, TypeError, ValueError):
        return None


def layout_svg(lo, emu, width=260):
    """A schematic of the layout frame as faint dashed boxes: content_box (blue),
    furniture (orange), placeholders w/ bbox (green) — so the structure is legible even
    when the rendered frame is visually empty. Template-agnostic (pure catalog geometry)."""
    sw = int(emu.get("w") or 12192000) or 12192000
    sh = int(emu.get("h") or 6858000) or 6858000
    k = width / sw
    H = round(sh * k)
    def box(rect, stroke, fill, label):
        r = _rect_xywh(rect)
        if not r:
            return ""
        x, y, w, h = (round(v * k) for v in r)
        w, h = max(2, w), max(2, h)
        t = (f'<text x="{x+3}" y="{y+11}" font-size="8" fill="{stroke}" '
             f'font-family="sans-serif">{esc(label)}</text>') if label and h >= 12 else ""
        return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" '
                f'stroke="{stroke}" stroke-width="1" stroke-dasharray="3 2" rx="2"/>{t}')
    parts = [box(lo.get("content_box"), "#4a90d9", "rgba(74,144,217,.06)", "content_box")]
    for f in lo.get("furniture", []):
        parts.append(box(f, "#e08a00", "rgba(224,138,0,.10)", (f or {}).get("role", "furniture")))
    for p in lo.get("placeholders", []):
        parts.append(box(p.get("bbox"), "#3a9d5d", "rgba(58,157,93,.10)", p.get("name")))
    return (f'<svg viewBox="0 0 {width} {H}" width="{width}" height="{H}" '
            f'style="background:#fff;border:1px solid #d8dde3;border-radius:4px;display:block">'
            f'<rect x="0.5" y="0.5" width="{width-1}" height="{H-1}" fill="none" stroke="#eceff3"/>'
            + "".join(parts) + "</svg>")


def esc(x):
    return html.escape(str(x if x is not None else ""))


def tgt(t):
    return esc(json.dumps(t or {}, ensure_ascii=False))


def slot_tree(slots):
    if not slots:
        return ""
    out = ['<ul class="slots">']
    for s in slots:
        k = s.get("kind", "?")
        out.append(f'<li><b>{esc(s.get("name"))}</b> <span class="k" style="background:{KC.get(k,"#777")}">{esc(k)}</span> '
                   f'<span class="tg">{tgt(s.get("target"))}</span>'
                   + (f'<div class="d">{esc(s.get("description"))}</div>' if s.get("description") else "")
                   + (f'<div class="c">▸ {esc(s.get("convention"))}</div>' if s.get("convention") else "")
                   + slot_tree(s.get("subslots")) + '</li>')
    out.append("</ul>")
    return "".join(out)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    args = ap.parse_args()
    R = Path(args.run)
    cat = json.loads((R / "catalog.json").read_text())
    ev = json.loads((R / "evidence.json").read_text()) if (R / "evidence.json").exists() else {"slides": []}
    meta = cat.get("meta", {})
    emu = ev.get("slide_emu") or meta.get("slide_emu") or {}
    W, H = emu.get("w") or 1, emu.get("h") or 1
    iname = {i["id"]: i.get("name", i["id"]) for i in cat.get("intents", [])}
    lname = {lo["id"]: lo.get("name", lo["id"]) for lo in cat.get("layouts", [])}

    # per-entity slot-QA verdicts → inline badges on the entity cards (replaces the standalone
    # slot_qa.html + its dead slots.html# links). Entity dir before packaging, _work/entities after.
    QA_COL = {"major": "#e6194B", "minor": "#f58231", "ok": "#3cb44b"}
    qa = {}
    for pool in ("variants", "adornments"):
        for d in (R / pool, R / "_work" / "entities" / pool):
            if not d.exists():
                continue
            for ed in d.iterdir():
                qf = ed / "slot_qa.json"
                if qf.exists() and ed.name not in qa:
                    try:
                        q = json.loads(qf.read_text())
                        qa[ed.name] = {"verdict": q.get("verdict", "ok"), "issues": q.get("issues", [])}
                    except Exception:
                        pass

    def qa_badge(eid):
        q = qa.get(eid)
        if not q:
            return ""
        chip = (f'<span class="qa" style="display:inline-block;font-size:11px;color:#fff;'
                f'padding:1px 6px;border-radius:8px;background:{QA_COL.get(q["verdict"],"#777")}">'
                f'QA {esc(q["verdict"])}</span>')
        if not q["issues"]:
            return chip
        items = "".join(f'<li><b>{esc(i.get("type"))}</b>'
                        + (f' <code>{esc(i.get("slot"))}</code>' if i.get("slot") else "")
                        + f': {esc(i.get("detail"))}</li>' for i in q["issues"])
        return chip + f'<ul style="margin:4px 0 0;padding-left:16px;font-size:11px;color:#a33">{items}</ul>'

    occ_count = defaultdict(int)
    for s in ev.get("slides", []):
        for o in s.get("occurrences", []):
            occ_count[o.get("id")] += 1

    tabs = []   # (key, label, html)

    # ---- Overview: slide-by-slide (render + Intent + Layout + occurrence overlays) ----
    cards = []
    for s in ev.get("slides", []):
        n = s["n"]
        render = R / "slides" / str(n) / "viz" / "01_raw.png"
        boxes = ""
        for o in s.get("occurrences", []):
            b = o.get("bbox_emu") or {}
            if not b:
                continue
            c = OVL.get(o.get("kind"), "#777")
            boxes += (f'<div class="ovl" style="left:{b.get("x",0)/W*100:.1f}%;top:{b.get("y",0)/H*100:.1f}%;'
                      f'width:{b.get("cx",0)/W*100:.1f}%;height:{b.get("cy",0)/H*100:.1f}%;border-color:{c}">'
                      f'<span style="background:{c}">{esc(o.get("kind","")[:3])}</span></div>')
        du = data_uri(render)
        canvas = (f'<div class="canvas"><img loading="lazy" src="{du}">{boxes}</div>'
                  if du else '<div class="canvas noimg">no render</div>')
        occ_li = "".join(f'<li><span class="k" style="background:{OVL.get(o.get("kind"),"#777")}">{esc(o.get("kind"))}</span> {esc(o.get("id"))}</li>'
                         for o in s.get("occurrences", []))
        cards.append(
            f'<div class="srow">{canvas}<div class="sinfo">'
            f'<div class="sh">Slide {n}</div>'
            f'<div class="kv"><span>Intent</span> <b>{esc(iname.get(s.get("intent_id"), s.get("intent_id")))}</b> <code>{esc(s.get("intent_id"))}</code></div>'
            f'<div class="kv"><span>Layout</span> <b>{esc(lname.get(s.get("layout_id"), s.get("layout_id")))}</b> <code>{esc(s.get("layout_id"))}</code></div>'
            + (f'<div class="lbl">Body occurrences ({len(s.get("occurrences",[]))})</div><ul class="occ">{occ_li}</ul>'
               if s.get("occurrences") else '<div class="pend">Body extraction pending (no occurrences)</div>')
            + '</div></div>')
    tabs.append(("ov", f"Overview ({len(ev.get('slides',[]))} slides)", "".join(cards) or "<p>No evidence</p>"))

    # ---- Layouts ----
    rows = []
    for lo in cat.get("layouts", []):
        cb = lo.get("content_box") or {}
        phs = "".join(
            f'<li><b>{esc(p.get("name"))}</b> <span class="k" style="background:{KC.get(p.get("kind"),"#777")}">{esc(p.get("kind"))}</span> '
            f'<span class="tg">{tgt(p.get("target"))}</span>'
            + (f'<div class="d">{esc(p.get("description"))}</div>' if p.get("description") else ' <span class="warn">No semantic description</span>')
            + (f'<div class="c">▸ {esc(p.get("convention"))}</div>' if p.get("convention") else "")
            + '</li>' for p in lo.get("placeholders", []))
        emu = (cat.get("meta") or {}).get("slide_emu") or {}
        schematic = layout_svg(lo, emu)
        lo_img = data_uri(R / "_work" / "layout_previews" / lo["id"] / "preview.png")
        img = f'<img src="{lo_img}">' if lo_img else ""
        rows.append(f'<div class="card">{schematic}{img}<h4>{esc(lo.get("name"))} <code>{esc(lo["id"])}</code></h4>'
                    f'<div class="m">master {esc(lo.get("master_id"))} · content_box {esc(cb.get("x"))},{esc(cb.get("y"))} {esc(cb.get("w"))}×{esc(cb.get("h"))} · furniture {len(lo.get("furniture",[]))}</div>'
                    f'<div class="lbl">placeholders ({len(lo.get("placeholders",[]))})</div><ul class="slots">{phs}</ul></div>')
    tabs.append(("ly", f"Layouts ({len(cat.get('layouts',[]))})", f'<div class="grid">{"".join(rows)}</div>'))

    # ---- Intents & Variants (master-detail: pick an intent → filter to its variants) ----
    # The data link is variants[].used_by_intents (the inverse of intents[].allowed_variant_ids):
    # each variant card carries data-intents, and clicking an intent in the rail shows just the
    # cards tagged with it. "All variants" shows all. (Mirrors the original catalog's explorer view.)
    def vcard_body(v, pool):
        pv = data_uri(R / pool / v["id"] / "preview.png")
        img = f'<img src="{pv}">' if pv else ""
        return (f'{img}<h4>{esc(v.get("name"))} <code>{esc(v["id"])}</code> '
                f'<span class="occ-b">{occ_count.get(v["id"],0)}×</span> {qa_badge(v["id"])}</h4>'
                f'<div class="d">{esc(v.get("description") or v.get("note"))}</div>{slot_tree(v.get("slots"))}')

    variants = cat.get("variants", [])
    if variants or cat.get("intents"):
        vcards = "".join(
            f'<div class="card vcard" data-intents=" {esc(" ".join(v.get("used_by_intents", [])))} ">'
            f'{vcard_body(v, "variants")}</div>' for v in variants)
        rail = [f'<li class="active" data-intent="__all__" data-name="all variants" '
                f'onclick="SI(\'__all__\',this)">All variants <span class="vn">{len(variants)}</span></li>']
        for it in cat.get("intents", []):
            iid = it["id"]
            cnt = sum(1 for v in variants if iid in v.get("used_by_intents", []))
            rail.append(f'<li data-intent="{esc(iid)}" data-name="{esc(it.get("name",""))} {esc(iid)}" '
                        f'onclick="SI(\'{esc(iid)}\',this)" title="{esc(it.get("description"))}">'
                        f'{esc(it.get("name", iid))} <span class="vn">{cnt}</span></li>')
        iv_html = (f'<div class="mdwrap"><aside class="md-rail">'
                   f'<input class="md-search" placeholder="Search intents..." oninput="IF()">'
                   f'<ul class="md-intents">{"".join(rail)}</ul></aside>'
                   f'<div class="md-main"><div class="grid mdgrid">{vcards or "<p class=md-empty>No variants yet (body extraction pending)</p>"}</div>'
                   f'<p class="md-empty" hidden>No variants are mapped to this intent.</p></div></div>')
        tabs.append(("iv", f"Intents & Variants ({len(cat.get('intents',[]))} · {len(variants)})", iv_html))

    # ---- Adornments (own tab) ----
    if cat.get("adornments"):
        rows = []
        for v in cat["adornments"]:
            pv = data_uri(R / "adornments" / v["id"] / "preview.png")
            img = f'<img src="{pv}">' if pv else ""
            rows.append(f'<div class="card">{img}<h4>{esc(v.get("name"))} <code>{esc(v["id"])}</code> '
                        f'<span class="occ-b">{occ_count.get(v["id"],0)}×</span> {qa_badge(v["id"])}</h4>'
                        f'<div class="d">{esc(v.get("note") or v.get("description"))}</div>{slot_tree(v.get("slots"))}</div>')
        tabs.append(("ad", f"Adornments ({len(cat['adornments'])})", f'<div class="grid">{"".join(rows)}</div>'))

    qa_kpi = ""
    if qa:
        qc = Counter(q["verdict"] for q in qa.values())
        qa_kpi = (f'<div class="kpi"><b>{qc.get("major",0)}·{qc.get("minor",0)}·{qc.get("ok",0)}</b>'
                  f'QA maj·min·ok</div>')
    kpis = '<div class="kpis">' + "".join(
        f'<div class="kpi"><b>{len(cat.get(k, []))}</b>{k}</div>'
        for k in ("intents", "layouts", "masters", "variants", "adornments")) + qa_kpi + "</div>"
    nav = "".join(f'<button class="tab{" on" if i==0 else ""}" onclick="T(\'{k}\',this)">{esc(lab)}</button>'
                  for i, (k, lab, _) in enumerate(tabs))
    panes = "".join(f'<section id="p-{k}" class="pane{" on" if i==0 else ""}">{h}</section>'
                    for i, (k, _, h) in enumerate(tabs))

    doc = f"""<!doctype html><meta charset=utf-8><title>catalog — {esc(meta.get('source_template'))}</title>
<style>
body{{font-family:-apple-system,BlinkMacSystemFont,sans-serif;background:#f5f5f7;color:#1d1d1f;margin:0;padding:0 0 60px}}
.wrap{{max-width:1180px;margin:0 auto;padding:0 20px}}
header{{background:#1d1d1f;color:#fff;padding:20px}} header h1{{margin:0;font-size:19px}} header .sub{{color:#aaa;font-size:13px}}
.kpis{{display:flex;gap:10px;flex-wrap:wrap;margin:16px 0}}
.kpi{{background:#fff;border:1px solid #e3e3e6;border-radius:10px;padding:10px 16px;text-align:center}}.kpi b{{display:block;font-size:22px}}.kpi{{font-size:11px;color:#666}}
nav{{display:flex;gap:2px;border-bottom:2px solid #1d1d1f;flex-wrap:wrap;margin-top:8px}}
.tab{{border:0;background:#eee;border:1px solid #ccc;border-bottom:none;padding:9px 15px;font:inherit;font-size:13px;cursor:pointer;border-radius:6px 6px 0 0}}
.tab.on{{background:#fff;font-weight:700;border-color:#1d1d1f;margin-bottom:-2px}}
.pane{{display:none;padding-top:18px}} .pane.on{{display:block}}
.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:12px}}
.card{{background:#fff;border:1px solid #e3e3e6;border-radius:10px;padding:14px}}
.card>img{{width:100%;border:1px solid #eee;border-radius:4px;margin-bottom:6px}}
h4{{margin:0 0 4px;font-size:14px}} code{{font-family:ui-monospace,monospace;font-size:11px;color:#888;background:#f0f0f3;padding:0 4px;border-radius:3px}}
.m{{font-size:11.5px;color:#777}} .lbl{{font-size:11px;color:#999;text-transform:uppercase;margin:8px 0 4px}}
.d{{font-size:12.5px;color:#444;margin:2px 0}} .c{{font-size:11.5px;color:#999;font-style:italic}}
ul.slots{{list-style:none;padding-left:0;margin:4px 0}} ul.slots ul.slots{{margin-left:14px;border-left:2px solid #eee;padding-left:10px}}
ul.slots li{{margin:5px 0;font-size:12.5px}} .k{{color:#fff;font-size:10px;padding:1px 6px;border-radius:8px;margin-right:4px}}
.tg{{font-family:ui-monospace,monospace;font-size:10.5px;color:#999}} .warn{{color:#9a6700;font-size:11px}} .occ-b{{font-size:11px;color:#0066cc;background:#eaf3ff;padding:0 7px;border-radius:9px}}
/* overview */
.srow{{display:flex;gap:16px;background:#fff;border:1px solid #e3e3e6;border-radius:10px;padding:12px;margin-bottom:12px}}
.canvas{{position:relative;flex:0 0 300px;align-self:flex-start}} .canvas img{{width:300px;display:block;border:1px solid #eee;border-radius:4px}}
.canvas.noimg{{width:300px;height:200px;display:flex;align-items:center;justify-content:center;color:#bbb;background:#fafafa;border:1px dashed #ddd}}
.ovl{{position:absolute;border:2px solid;border-radius:2px;background:rgba(255,255,255,.04)}}
.ovl span{{position:absolute;top:-1px;left:-1px;color:#fff;font-size:9px;font-weight:700;padding:0 4px;border-radius:0 0 3px 0}}
.sinfo{{flex:1;min-width:0}} .sh{{font-weight:700;font-size:15px;margin-bottom:6px}}
.kv{{font-size:13px;margin:3px 0}} .kv span{{display:inline-block;width:54px;color:#999;font-size:11px;text-transform:uppercase}}
ul.occ{{list-style:none;padding-left:0;margin:4px 0;font-size:12px}} ul.occ li{{margin:3px 0}}
.pend{{font-size:12px;color:#aaa;font-style:italic;margin-top:8px}}
/* intents & variants master-detail */
.mdwrap{{display:flex;gap:16px;align-items:flex-start}}
.md-rail{{flex:0 0 240px;position:sticky;top:10px}}
.md-search{{width:100%;padding:7px 9px;border:1px solid #ccc;border-radius:7px;font:inherit;font-size:12.5px;margin-bottom:8px;box-sizing:border-box}}
ul.md-intents{{list-style:none;padding:0;margin:0;max-height:78vh;overflow:auto;border:1px solid #e3e3e6;border-radius:10px;background:#fff}}
ul.md-intents li{{padding:8px 11px;font-size:12.5px;cursor:pointer;border-bottom:1px solid #f0f0f3;display:flex;justify-content:space-between;gap:8px;align-items:center}}
ul.md-intents li:last-child{{border-bottom:none}} ul.md-intents li:hover{{background:#f5f5f7}}
ul.md-intents li.active{{background:#1d1d1f;color:#fff}} ul.md-intents li.active .vn{{background:rgba(255,255,255,.25);color:#fff}}
.vn{{background:#eaf3ff;color:#0066cc;font-size:11px;padding:0 7px;border-radius:9px;flex:none}}
.md-main{{flex:1;min-width:0}} .md-main .mdgrid{{grid-template-columns:repeat(auto-fill,minmax(300px,1fr))}}
.md-empty{{color:#aaa;font-style:italic;font-size:13px}}
</style>
<header><h1>Design System Catalog</h1><div class="sub">{esc(meta.get('source_template'))} · schema v{esc(meta.get('schema_version'))}</div></header>
<div class="wrap">{kpis}<nav>{nav}</nav>{panes}</div>
<script>
function T(k,b){{document.querySelectorAll('.pane').forEach(p=>p.classList.remove('on'));
document.getElementById('p-'+k).classList.add('on');
document.querySelectorAll('.tab').forEach(t=>t.classList.remove('on'));b.classList.add('on');}}
function SI(iid,el){{document.querySelectorAll('.md-intents li').forEach(li=>li.classList.toggle('active',li===el));
let shown=0;document.querySelectorAll('.vcard').forEach(c=>{{
const m=iid==='__all__'||(' '+c.dataset.intents+' ').includes(' '+iid+' ');c.hidden=!m;if(m)shown++;}});
const e=document.querySelector('.md-main .md-empty');if(e)e.hidden=shown>0;}}
function IF(){{const q=(document.querySelector('.md-search').value||'').toLowerCase().trim();
document.querySelectorAll('.md-intents li').forEach(li=>{{if(li.dataset.intent==='__all__')return;
li.hidden=q&&!li.dataset.name.toLowerCase().includes(q);}});}}
</script>"""
    (R / "catalog.html").write_text(doc)
    print(f"catalog_html → {R/'catalog.html'} ({len(doc)//1024} KB · {len(ev.get('slides',[]))} slides in overview)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
