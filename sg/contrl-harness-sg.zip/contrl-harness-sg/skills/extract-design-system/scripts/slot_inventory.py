#!/usr/bin/env python3
"""slot_inventory: list the fillable handles in a v6 entity's shapes.xml for slot-tagging.

The carved variant/adornment shapes.xml has a <p:spTree> root holding top-level shapes
(p:sp / p:grpSp / p:pic / p:cxnSp / p:graphicFrame[table]). The v1 list_runs only handled
plain sp shapes, so it returned 0 here. This walks every top-level shape, plus one level into
groups, and reports: shape id/name/tag/bbox, text runs (a:t with index), pic count, and table
rows×cols + cell text — i.e. the concrete targets (shape_id / a_t_xpath / pic_index) a slot needs.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
import xml.etree.ElementTree as ET


def lt(t):
    return t.rsplit("}", 1)[-1]


def cnvpr(el):
    for x in el:
        if lt(x.tag).startswith("nv"):  # nvSpPr / nvGrpSpPr / nvPicPr / nvGraphicFramePr
            for c in x.iter():
                if lt(c.tag) == "cNvPr":
                    return c.get("id"), c.get("name")
    return None, None


def xfrm(el):
    for x in el.iter():
        if lt(x.tag) in ("xfrm",):
            off = next((c for c in x if lt(c.tag) == "off"), None)
            ext = next((c for c in x if lt(c.tag) == "ext"), None)
            if off is not None and ext is not None:
                return (off.get("x"), off.get("y"), ext.get("cx"), ext.get("cy"))
    return None


def runs(el):
    return [(r.text or "").replace("\n", " ") for r in el.iter() if lt(r.tag) == "t"]


def describe(el, depth=0):
    tag = lt(el.tag)
    sid, name = cnvpr(el)
    bb = xfrm(el)
    pad = "  " * depth
    lines = []
    if tag == "graphicFrame":
        tbl = next((x for x in el.iter() if lt(x.tag) == "tbl"), None)
        if tbl is not None:
            cols = [c for c in tbl.iter() if lt(c.tag) == "gridCol"]
            rowels = [r for r in tbl.iter() if lt(r.tag) == "tr"]
            lines.append(f"{pad}[graphicFrame TABLE] id={sid} name={name!r} rows={len(rowels)} cols={len(cols)} bbox={bb}")
            for ri, r in enumerate(rowels):
                cells = [tc for tc in r if lt(tc.tag) == "tc"]
                celltxt = [" ".join(runs(tc)).strip()[:34] for tc in cells]
                lines.append(f"{pad}    row{ri}: {celltxt}")
            return lines
    if tag == "grpSp":
        lines.append(f"{pad}[grpSp] id={sid} name={name!r} bbox={bb}")
        for ch in el:
            if lt(ch.tag) in ("sp", "grpSp", "pic", "cxnSp", "graphicFrame"):
                lines += describe(ch, depth + 1)
        return lines
    if tag == "pic":
        lines.append(f"{pad}[pic IMAGE] id={sid} name={name!r} bbox={bb}")
        return lines
    # sp / cxnSp
    rs = runs(el)
    npic = sum(1 for x in el.iter() if lt(x.tag) == "pic")
    lines.append(f"{pad}[{tag}] id={sid} name={name!r} bbox={bb} pics={npic}")
    for i, t in enumerate(rs):
        if t.strip():
            lines.append(f"{pad}    a:t[{i}] = {t!r}")
    return lines


def build_inventory(dirpath: Path) -> str:
    sx = dirpath / "shapes.xml"
    root = ET.parse(sx).getroot()
    sptree = root if lt(root.tag) == "spTree" else next((e for e in root.iter() if lt(e.tag) == "spTree"), root)
    tops = [c for c in sptree if lt(c.tag) in ("sp", "grpSp", "pic", "cxnSp", "graphicFrame")]
    lines = [f"{len(tops)} top-level shape(s)"]
    for el in tops:
        lines += describe(el)
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True, type=Path)
    args = ap.parse_args()
    print(build_inventory(args.dir))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
