#!/usr/bin/env python3
"""
Stage-2 (레이아웃 확정 / layout canonicalization) — mechanical, deterministic.

Reads <run>/frame.json (already-parsed raw layouts + slide->raw map) and produces
a canonical layout pool by structural-signature dedup. No LLM, no vision, stdlib only.
Template-agnostic: nothing is keyed off specific slide numbers, chapter glyphs, or
layout ids — every decision is derived from the data.

Pipeline (matches the Stage-2 spec):
  2-2  Build a normalized structural signature per raw layout.
  2-3  Group raw layouts by identical signature -> canonical pool.
  2-4  Map each slide -> canonical layout (slide->raw->canonical).
  2-5  Derive a real content_box per canonical from header/footer furniture bands.
  2-6  Derive placeholders per canonical from the representative raw layout.
  2-7  Emit <out>/layouts.json.

Run:
  python3 layout_build.py --run <run_dir> --out <run_dir>/_stage2_test
"""

import argparse
import hashlib
import json
import os
import re
from collections import defaultdict


# ----------------------------------------------------------------------------
# Tunable constants (top-of-file, documented).
# ----------------------------------------------------------------------------

# Coordinate rounding tolerance, in EMU. Two layouts that differ only by sub-tolerance
# jitter in placeholder/furniture geometry should collapse to the same signature.
# Chosen as slide_w / 200 (computed at runtime). For this portrait deck slide_w ~= 7.78M
# EMU, so the bucket is ~38_878 EMU ~= 0.04 inch (914_400 EMU = 1 inch) ~= 1 mm. That is
# below the visual-distinction threshold yet large enough to absorb the few-EMU rounding
# noise seen in the source (e.g. x=-3264 vs x=1, y=-1619). Kept as a fraction of slide
# width so the heuristic travels to landscape/other-sized templates unchanged.
TOLERANCE_DENOM = 200  # bucket = round(coord / (slide_w / TOLERANCE_DENOM))

# A furniture rect counts as a full-width "edge band" (header/footer candidate) when its
# width exceeds this fraction of the slide width. Edge bands are the fixed frame chrome
# (top color bar, bottom footer strip) that bound the usable content region.
FULLWIDTH_FRAC = 0.5

# A furniture rect counts as a full-height "side band" when its height exceeds this
# fraction of the slide height (rare; insets the content box left/right when present).
FULLHEIGHT_FRAC = 0.5

# Region windows: a header band must sit within the top REGION_FRAC of the slide; a footer
# band within the bottom REGION_FRAC. Bands straddling the middle are ignored as content.
REGION_FRAC = 0.30

# A slide-layout placeholder may serialize with no explicit ph_type (ph_type == null) when
# its type is inherited rather than re-declared. When True, a null ph_type is treated as a
# wildcard that adopts the *unique* non-null type observed at the same (master, ph_idx,
# rounded-geometry) across the whole template; if there is no such type, or the type is
# ambiguous, the null stays a distinct sentinel. This folds cosmetically-identical layouts
# (same idx + same box, one declaring `body`/`pic`, its twin leaving it null) into one
# canonical layout instead of over-splitting. Two *distinct* non-null types never fold.
INFER_NULL_PH_TYPE = True
_NULL_PH_SENTINEL = "__ANY__"


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------

def _round_to(value, bucket):
    """Round an EMU coordinate to the nearest tolerance bucket. Deterministic."""
    if bucket <= 0:
        return int(value)
    return int(round(value / bucket)) * bucket


def _norm_text(text):
    """Collapse internal whitespace and trim. Furniture text is identity-bearing
    (e.g. the chapter marker 'Ⅰ/Ⅱ/Ⅲ') so it is kept, just normalized."""
    if not text:
        return ""
    return re.sub(r"\s+", " ", text).strip()


def _bbox_tuple(bbox, bucket):
    """Return rounded (x, y, w, h) or None when the rect is absent."""
    if not bbox:
        return None
    return (
        _round_to(bbox.get("x", 0), bucket),
        _round_to(bbox.get("y", 0), bucket),
        _round_to(bbox.get("w", 0), bucket),
        _round_to(bbox.get("h", 0), bucket),
    )


# ----------------------------------------------------------------------------
# 2-2  Structural signature per raw layout
# ----------------------------------------------------------------------------

def build_ph_type_index(raw_layouts, bucket):
    """Map (master_id, ph_idx, rounded-geom) -> set of non-null ph_types seen anywhere.

    Used to resolve a null ph_type to its unambiguous typed twin (see INFER_NULL_PH_TYPE).
    Built once over the whole template so resolution is global and deterministic.
    """
    index = defaultdict(set)
    for layout in raw_layouts:
        master = layout.get("master_id")
        for ph in layout.get("placeholders", []):
            ptype = ph.get("ph_type")
            if ptype is None:
                continue
            idx = None if ph.get("ph_idx") is None else str(ph.get("ph_idx"))
            geom = _bbox_tuple(ph.get("bbox"), bucket)
            index[(master, idx, geom)].add(ptype)
    return index


def _resolve_ph_type(layout, ph, geom, ph_type_index):
    """Return the effective ph_type for the signature, applying null-type inference."""
    ptype = ph.get("ph_type")
    if ptype is not None or not INFER_NULL_PH_TYPE:
        return ptype
    idx = None if ph.get("ph_idx") is None else str(ph.get("ph_idx"))
    candidates = ph_type_index.get((layout.get("master_id"), idx, geom))
    if candidates and len(candidates) == 1:
        return next(iter(candidates))
    return _NULL_PH_SENTINEL


def layout_signature(layout, bucket, ph_type_index):
    """Build a canonical, hashable signature tuple for one raw layout.

    - placeholders: sorted set of (effective_ph_type, ph_idx, rx, ry, rw, rh). Placeholder
      *text* is deliberately excluded (boilerplate prompt text like "마스터 제목
      스타일 편집" — no discriminative value). A missing bbox contributes a None geom.
      effective_ph_type applies null-type inference (see INFER_NULL_PH_TYPE).
    - furniture: sorted set of (tag, rx, ry, rw, rh, normalized_text). Furniture text
      IS included — the chapter marker glyph is fixed identity and must separate
      otherwise-identical chapter-variant layouts.
    - master_id.
    """
    ph_sig = []
    for ph in layout.get("placeholders", []):
        geom = _bbox_tuple(ph.get("bbox"), bucket)
        ph_sig.append((
            _resolve_ph_type(layout, ph, geom, ph_type_index),
            # normalize ph_idx to str so None / "1" / 1 compare consistently
            None if ph.get("ph_idx") is None else str(ph.get("ph_idx")),
            geom,
        ))
    ph_sig = tuple(sorted(ph_sig, key=lambda t: json.dumps(t, sort_keys=True, default=str)))

    fur_sig = []
    for fu in layout.get("furniture", []):
        geom = _bbox_tuple(fu.get("bbox"), bucket)
        fur_sig.append((
            fu.get("tag"),
            geom,
            _norm_text(fu.get("text", "")),
        ))
    fur_sig = tuple(sorted(fur_sig, key=lambda t: json.dumps(t, sort_keys=True, default=str)))

    sig = {
        "master_id": layout.get("master_id"),
        "placeholders": ph_sig,
        "furniture": fur_sig,
    }
    blob = json.dumps(sig, sort_keys=True, default=str, ensure_ascii=False)
    return hashlib.sha1(blob.encode("utf-8")).hexdigest()


# ----------------------------------------------------------------------------
# 2-5  content_box from real furniture bands
# ----------------------------------------------------------------------------

def derive_content_box(layout, slide_w, slide_h):
    """Compute the usable content rect from header/footer/side furniture bands.

    Rule:
      - Start from the full slide rect.
      - "Edge bands" = furniture whose width > FULLWIDTH_FRAC * slide_w.
      - Header band = full-width edge band whose bottom edge (y+h) lies within the top
        REGION_FRAC of the slide. content_box top = the LOWEST such bottom edge (i.e.
        the band that pushes content furthest down).
      - Footer band = full-width edge band whose top edge (y) lies within the bottom
        REGION_FRAC of the slide. content_box bottom = the HIGHEST such top edge.
      - Side bands = furniture whose height > FULLHEIGHT_FRAC * slide_h; their inner
        edges inset left/right. (Rare; absent in this template.)
      - No furniture -> full slide.
    All comparisons use raw EMU (no rounding) so the box reflects the true geometry.
    """
    top = 0
    bottom = slide_h
    left = 0
    right = slide_w

    top_region_limit = slide_h * REGION_FRAC
    bottom_region_start = slide_h * (1.0 - REGION_FRAC)

    for fu in layout.get("furniture", []):
        bbox = fu.get("bbox")
        if not bbox:
            continue
        x = bbox.get("x", 0)
        y = bbox.get("y", 0)
        w = bbox.get("w", 0)
        h = bbox.get("h", 0)
        is_fullwidth = w > FULLWIDTH_FRAC * slide_w
        is_fullheight = h > FULLHEIGHT_FRAC * slide_h

        if is_fullwidth:
            band_bottom = y + h
            band_top = y
            # header candidate: lives in the top region
            if band_bottom <= top_region_limit:
                top = max(top, band_bottom)
            # footer candidate: lives in the bottom region
            elif band_top >= bottom_region_start:
                bottom = min(bottom, band_top)
        elif is_fullheight:
            # side band: inset whichever side it hugs
            band_right = x + w
            if x <= slide_w * 0.5:  # left-hugging
                left = max(left, band_right)
            else:  # right-hugging
                right = min(right, x)

    # Guard against degenerate boxes (shouldn't happen, but stay deterministic/sane).
    if bottom <= top:
        top, bottom = 0, slide_h
    if right <= left:
        left, right = 0, slide_w

    return {"x": int(left), "y": int(top), "w": int(right - left), "h": int(bottom - top)}


# ----------------------------------------------------------------------------
# 2-6  placeholders per canonical
# ----------------------------------------------------------------------------

_NAME_MAP = {
    "title": "title",
    "ctrTitle": "title",
    "subTitle": "subtitle",
    "body": "body",
    "sldNum": "page_number",
    "ftr": "footer",
    "dt": "date",
    "pic": "image",
}


def derive_placeholders(layout):
    """Mechanically derive placeholder descriptors from the representative raw layout.

    name  := mechanical map of ph_type (fallback = ph_type itself); duplicate names
             within a layout get _2, _3 ... suffixes (in document order).
    kind  := "richtext" when ph_type == "body" else "text".
    target:= {ph_type, ph_idx}.
    """
    out = []
    name_counts = defaultdict(int)
    for ph in layout.get("placeholders", []):
        ptype = ph.get("ph_type")
        base = _NAME_MAP.get(ptype, ptype)
        name_counts[base] += 1
        name = base if name_counts[base] == 1 else f"{base}_{name_counts[base]}"
        out.append({
            "name": name,  # provisional (OOXML-ordinal); re-curated by layout_placeholder_annotate
            "kind": "richtext" if ptype == "body" else "text",
            "target": {"ph_type": ptype, "ph_idx": ph.get("ph_idx")},
            "bbox": ph.get("bbox"),          # working field for the annotate step
            "prompt_text": (ph.get("text") or "")[:60],  # layout's prompt text, a weak hint
        })
    return out


# ----------------------------------------------------------------------------
# Driver
# ----------------------------------------------------------------------------

def build(run_dir, out_dir):
    with open(os.path.join(run_dir, "frame.json"), encoding="utf-8") as fh:
        frame = json.load(fh)

    slide_emu = frame["slide_emu"]
    slide_w = slide_emu["w"]
    slide_h = slide_emu["h"]
    bucket = max(1, int(round(slide_w / TOLERANCE_DENOM)))

    raw_layouts = frame["layouts"]
    by_id = {L["id"]: L for L in raw_layouts}
    slide_layout_map = frame["slide_layout_map"]  # slide(str) -> raw layout id

    # Slide usage count per raw layout (for representative selection).
    raw_use_count = defaultdict(int)
    for _slide, raw_id in slide_layout_map.items():
        raw_use_count[raw_id] += 1

    # 2-2 + 2-3: group raw layouts by signature.
    ph_type_index = build_ph_type_index(raw_layouts, bucket)
    groups = defaultdict(list)  # signature -> [raw_id, ...]
    for L in raw_layouts:
        sig = layout_signature(L, bucket, ph_type_index)
        groups[sig].append(L["id"])

    def numeric_suffix(layout_id):
        m = re.search(r"(\d+)$", layout_id)
        return int(m.group(1)) if m else 0

    canonical_layouts = []
    raw_to_canonical = {}
    for sig, members in groups.items():
        # Representative = raw used by MOST slides; tiebreak = smallest numeric suffix.
        rep = sorted(
            members,
            key=lambda rid: (-raw_use_count.get(rid, 0), numeric_suffix(rid)),
        )[0]
        canon_id = rep
        members_sorted = sorted(members, key=numeric_suffix)
        for rid in members_sorted:
            raw_to_canonical[rid] = canon_id

        rep_layout = by_id[rep]
        canonical_layouts.append({
            "id": canon_id,
            "master_id": rep_layout.get("master_id"),
            "content_box": derive_content_box(rep_layout, slide_w, slide_h),
            "placeholders": derive_placeholders(rep_layout),
            "group_size": len(members_sorted),
            "raw_ids": members_sorted,
        })

    # Stable output order: largest group first, then by numeric suffix of canonical id.
    canonical_layouts.sort(key=lambda c: (-c["group_size"], numeric_suffix(c["id"])))

    # 2-4: slide -> canonical.
    slide_canonical = {}
    for slide, raw_id in slide_layout_map.items():
        slide_canonical[slide] = raw_to_canonical[raw_id]

    out = {
        "layouts": canonical_layouts,
        "slide_layout_map": slide_canonical,
    }

    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "layouts.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)

    return out, {"bucket": bucket, "slide_w": slide_w, "slide_h": slide_h}


def main():
    ap = argparse.ArgumentParser(description="Stage-2 layout canonicalization (mechanical).")
    ap.add_argument("--run", required=True, help="run dir containing frame.json")
    ap.add_argument("--out", required=True, help="output dir (e.g. <run>/_stage2_test)")
    args = ap.parse_args()

    out, info = build(args.run, args.out)
    print(f"bucket(EMU)={info['bucket']}  slide={info['slide_w']}x{info['slide_h']}")
    print(f"canonical layouts: {len(out['layouts'])}  | slides mapped: {len(out['slide_layout_map'])}")
    print(f"wrote {os.path.join(args.out, 'layouts.json')}")


if __name__ == "__main__":
    main()
