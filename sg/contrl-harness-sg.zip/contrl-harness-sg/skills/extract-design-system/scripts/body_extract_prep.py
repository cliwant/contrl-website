#!/usr/bin/env python3
"""body_extract_prep: build per-slide inputs for the stage-3 vision split.

For each slide: top-level body shapes (those centered inside the slide's content_box) with
absolute bbox + text, plus the render path + content_box. The vision agent reads the
render + this inventory and splits the body into adornment/variant units.

content_box comes from the slide's mapped layout (catalog.json layouts + evidence slide→layout) —
no ground truth needed. A `--sample` json may still be passed to restrict/override (back-compat).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

SK = Path(__file__).resolve().parent
sys.path.insert(0, str(SK))          # .claude/skills
from _lib.pptx_xml import all_shape_boxes, parse  # noqa: E402


def center_in(b, cb):
    cx, cy = b["x"] + b["w"] / 2, b["y"] + b["h"] / 2
    return cb["x"] <= cx <= cb["x"] + cb["w"] and cb["y"] <= cy <= cb["y"] + cb["h"]


def slides_from_catalog(run):
    """Each slide + the content_box of its mapped layout (catalog.json + evidence.json)."""
    cat = json.loads((run / "catalog.json").read_text())
    ev = json.loads((run / "evidence.json").read_text())
    lcb = {lo["id"]: lo.get("content_box") for lo in cat.get("layouts", [])}
    out = []
    for s in ev.get("slides", []):
        cb = lcb.get(s.get("layout_id"))
        if cb:
            out.append({"slide": s["n"], "content_box": cb})
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--sample", help="(optional) sample json with slides[].content_box; "
                                     "else derived from catalog layouts + evidence")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    run, out = Path(args.run), Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    spec = json.loads(Path(args.sample).read_text())["slides"] if args.sample else slides_from_catalog(run)
    emu = json.loads((run / "catalog.json").read_text())["meta"]["slide_emu"]

    for s in spec:
        n = s["slide"]
        cb = s["content_box"]
        tree = parse(run / "slides" / str(n) / "raw.xml")
        shapes = []
        for sb in all_shape_boxes(tree):
            b = {"x": sb.x, "y": sb.y, "w": sb.cx, "h": sb.cy}
            if not center_in(b, cb):
                continue
            shapes.append({"id": sb.shape_id, "tag": sb.tag, "bbox": b,
                           "text": (sb.text or "")[:80]})
        rec = {"slide": n, "slide_emu": emu, "content_box": cb,
               "render": f"slides/{n}/viz/01_raw.png", "shapes": shapes}
        (out / f"slide_{n}.json").write_text(json.dumps(rec, ensure_ascii=False, indent=2))
        print(f"slide {n}: {len(shapes)} body shapes (in content_box)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
