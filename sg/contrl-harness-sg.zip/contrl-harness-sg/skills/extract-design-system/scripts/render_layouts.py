#!/usr/bin/env python3
"""render_layouts: render each slideLayout as an EMPTY frame (no body content) to
layouts/<id>/preview.png.

How: open the source template, remove every real slide, then add one empty slide per
slideLayout with all placeholder shapes stripped — so each rendered page shows only the
inherited master + layout graphics (header band, logos, footer), i.e. the bare frame.
Pages render in add-order; we map each page back to its layout id via the layout part name
matched against frame.json's `src`.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from pptx import Presentation
from pptx.oxml.ns import qn
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[0]))
from _lib.render import render_pptx_to_pngs  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--dpi", type=int, default=110)
    ap.add_argument("--width", type=int, default=560, help="downscale preview width px")
    args = ap.parse_args()
    run = Path(args.run)
    src_pptx = Path((run / "source.pptx.path").read_text().strip())
    frame = json.loads((run / "frame.json").read_text())
    # src part name -> our layout id
    src_to_id = {lo["src"].lstrip("/"): lo["id"] for lo in frame["layouts"] if lo.get("src")}

    prs = Presentation(str(src_pptx))
    # 1) remove all existing slides — drop the relationship (so the part is unreferenced and not
    #    re-serialized, freeing slideN.xml names) AND the sldId entry
    sldIdLst = prs.slides._sldIdLst
    for sldId in list(sldIdLst):
        rId = sldId.get(qn("r:id"))
        if rId:
            prs.part.drop_rel(rId)
        sldIdLst.remove(sldId)

    # 2) one empty slide per layout (strip placeholders so only inherited frame renders)
    order = []  # page-order list of layout ids
    for master in prs.slide_masters:
        for layout in master.slide_layouts:
            partname = str(layout.part.partname).lstrip("/")
            lid = src_to_id.get(partname)
            slide = prs.slides.add_slide(layout)
            spTree = slide.shapes._spTree
            for shp in list(slide.shapes):
                spTree.remove(shp._element)
            order.append(lid or partname)

    tmp_pptx = run / "_layouts_empty.pptx"
    prs.save(str(tmp_pptx))
    print(f"built empty deck: {len(order)} layout slides -> {tmp_pptx.name}")

    render_dir = run / "_layouts_render"
    pngs = render_pptx_to_pngs(tmp_pptx, render_dir, dpi=args.dpi)
    if len(pngs) != len(order):
        print(f"  [warn] rendered {len(pngs)} pages but expected {len(order)}", file=sys.stderr)

    n_ok = 0
    for i, lid in enumerate(order):
        if i >= len(pngs) or not lid:
            continue
        # layout previews are a gate-review aid, not a Phase-0 deliverable (layouts ship via the
        # frame/ bundle) — keep them under _work/ so the run-dir surface stays clean.
        d = run / "_work" / "layout_previews" / lid
        d.mkdir(parents=True, exist_ok=True)
        im = Image.open(pngs[i]).convert("RGB")
        if im.width > args.width:
            im = im.resize((args.width, round(im.height * args.width / im.width)))
        im.save(d / "preview.png")
        n_ok += 1

    # cleanup heavy temporaries
    tmp_pptx.unlink(missing_ok=True)
    for p in render_dir.glob("*.png"):
        p.unlink()
    render_dir.rmdir()
    print(f"render_layouts: wrote {n_ok} layout previews -> _work/layout_previews/<id>/preview.png")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
