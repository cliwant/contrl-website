# slot-QA (v6, per-entity) — vision audit of slot tagging

You AUDIT existing slot tagging for design-system entities. You do NOT fix — you verify and flag.
You handle a BATCH; do each entity independently.

## Input
A batch file (JSON array of `{id, kind, dir}`). For EACH entity, read under `<run>/<dir>/`:
- `preview.png`  (the rendered crop — your visual ground truth)
- `_inventory.txt`  (every shape: id / tag / bbox / text-runs / table dims)
- `slots.json`  (the tagging to audit: slots[] + fixed[])

## What to check (judge the IMAGE against the tagging)
1. **Coverage / no orphan** — every content-bearing shape in the inventory (visible text run, content image)
   is either under a slot or listed in `fixed`. Flag any content shape that is neither (orphan), and any
   genuinely decorative shape wrongly exposed as a slot.
2. **fixed correctness** — `fixed` shapes really are decorative/geometry (backgrounds, connectors, arrows),
   not content. Flag content shapes hidden in `fixed`.
3. **kind correctness** — `text`/`richtext`/`image`/`repeated`/`table`/`composite` fits what's shown.
   Common errors: a typed/richtext-cell table tagged as `table` instead of `repeated` rows; subslots on a
   `table` (illegal); an image tagged `text`; a single item tagged `repeated`.
4. **grouping / split** — repeating structures collapsed into ONE `repeated` slot (not N slots), and NOT
   over-merged (two visually different groups merged into one). Cardinality `base` should match the count of
   repeated units you can SEE; `resizable`/`min`/`max` should be sane (fixed grid → resizable:false).
5. **name = form/role only** — no content-bearing slot names (e.g. `tool_logo`, `team_members`). Flag leaks.
6. **target sanity** — target shape ids appear in the inventory; repeated targets list the per-unit shapes.
7. **preview-vs-content** — if the preview shows content NOT in the inventory (a neighboring band/title), it
   is correctly EXCLUDED; do not flag its absence (that is expected, not an error).

## Output
Write `<run>/<dir>/slot_qa.json`:
`{"id":"<id>", "verdict":"ok"|"minor"|"major", "issues":[{"type":"orphan|fixed|kind|grouping|cardinality|name|target", "detail":"<=25 words", "slot":"<slot name if applicable>"}], "summary":"<=20 words"}`
- `ok` = tagging is correct. `minor` = small fixable nits (a name, a cardinality range). `major` = wrong
  kind / missed content / bad grouping that would break Phase-2 fill.
- If correct, `issues` = [] and verdict `ok`.

## Return
One line per entity: `<id>: <verdict> (<n issues>)`. Final message = just those lines.
