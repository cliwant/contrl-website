# slot-tag (v6, per-entity) — fan-out instruction

Define the fillable **slots** of carved design-system entities (variants and adornments) so Phase 2
can fill them with new content. You handle a BATCH of entities; do each independently.

## Input
A batch file (JSON array) at the path given to you. Each item: `{id, kind, dir}` where `kind` is
`"variant"` or `"adornment"` and `dir` is the entity's directory (relative to the run dir given to you).
For EACH entity, read three things under `<run>/<dir>/`:
- `preview.png` — the rendered crop (use the Read tool; this is your visual).
- `_inventory.txt` — every shape's id / tag / bbox / text-runs / table dims (your concrete handles).
- `shapes.xml` — the raw OOXML (consult for exact targets / xpath when needed).

## Output
Write `<run>/<dir>/slots.json`:
`{"slots":[ {name, kind, target, description, convention?, constraints?, cardinality?, subslots?, current_value?} ], "fixed":[ {shape_id, reason} ]}`

## Rules (READ — these encode hard-won pilot lessons)
1. **Tag ONLY shapes that are in `shapes.xml`/`_inventory.txt`.** The `preview.png` is a bbox crop, so it
   may show *neighboring* content (a section title, an adjacent band) that is NOT part of this entity.
   If text is visible in the preview but absent from the inventory, it belongs to another entity — do not
   invent a slot for it.
2. **`name` = form/role only, never content.** Test: *"if this variant served a totally different intent,
   does the name still fit?"* — `title`/`items`/`primary_image`/`rows`/`cards` ✅ · `tool_logo`/`team_members`/
   `procurement_rows` ❌. Put content-specific guidance in `convention`, not the name.
   - **Carve-out for special slides (cover / table-of-contents): use the STANDARD vocabulary below, not free names.** See "Special slides" section. (These slides are filled deterministically by slot *name*, so the name must match the standard role across every template.)
3. **`kind` is a closed enum**: `text` · `richtext` · `image` · `repeated` · `table` · `composite`.
   - `subslots` belong ONLY to `repeated`/`composite` — **never put subslots on a `table` slot.**
   - `table` = a flat row×column grid of strings (value = list[list[str]]). If the rows have *typed
     columns* (a label column + richtext detail columns) or rich cells, model it as **`repeated` rows**
     with per-column `subslots` instead of `table`.
4. **target modes**: `{"shape_id":"X"}` · `{"shape_ids":[...]}` · `{"a_t_xpath":".//a:t"}` (a text run inside
   each repeated shape) · `{"pic_index":0}`. Prefer flat absolute `shape_ids`. For a repeated row of
   single-text items: `target.shape_ids = [the item shapes]`, and one subslot `{name:"label", kind:"text",
   target:{"a_t_xpath":".//a:t"}}`. For cards with label+body, give each subslot its own absolute
   `shape_ids` (one per card, parallel order).
5. **Detect repetition → ONE `repeated` slot** (not N slots). On every `repeated`/`table` slot you MUST give
   `cardinality: {"observed": N, "resizable": true|false, "min": m, "max": M}` — the count is mechanical but
   **you must judge resizable + min/max** (omitting them locks it to fixed). Fixed grid → resizable:false,
   min=max=N. Flexible list → resizable:true with a sensible min/max.
6. **`fixed[]`** = every shape carrying no fillable content (backgrounds, connectors, decorative arrows,
   tab graphics) with a one-line reason. **No orphan content**: every text run + content image must be
   under a slot OR in `fixed`.
7. **`current_value`** (optional) = the observed text/content of THIS exemplar for that slot — a light
   capture for evidence. For `image` slots, omit.
8. **Image slots**: `kind:image`, target `shape_id` (or `pic_index`), and a `convention` describing the
   image's *content role* ("a real screenshot of the tool in the brief", "structural diagram of the
   subject"), so Phase 2 can decide whether to replace it. Keep the name form/role (`primary_image`).
9. **Adornments** are usually one `title` text slot (the band's section title). Keep it minimal.

## Special slides (cover / table-of-contents) — STANDARD slot vocabulary

Cover and table-of-contents slides are generated **deterministically (no LLM) by routing on the slot
`name`**, so a fixed vocabulary must be used — the same `name` across every template — or Phase 2 can't
find the slot. This **overrides** the free form/role naming of rule 2, for these two intents only.
(There is no `role` field — the closed slot schema is `{name, kind, target, description, convention?, …}`;
the standard `name` *is* the routing key. Put any per-template nuance in `description`/`convention` as usual.)

Apply when the entity is a **cover** or **table-of-contents** variant — i.e. its `used_by_intents`
includes `cover`/`table-of-contents` (if the batch item carries it), OR the preview is unmistakably a
proposal **cover** (full-slide title page) or **contents/agenda** page. Body variants keep rule 2.

Name the fillable slots/subslots from this set (expose only the roles this template actually shows; a
template has whatever subset fits its design):

| standard `name`      | kind              |
| -------------------- | ----------------- |
| `cover_title`        | richtext/text     |
| `cover_subtitle`     | richtext/text     |
| `cover_tagline`      | richtext/text     |
| `cover_bidder`       | text              |
| `cover_date`         | text              |
| `toc_section_marker` | text              |
| `toc_section_title`  | text              |
| `toc_entries`        | richtext/repeated |
| `toc_pages`          | richtext          |

- **Fixed-geometry navigator** (hand-placed numbered boxes that can't be cloned): expose each box's title
  as a positional slot `toc_nav_1` … `toc_nav_N` (a fixed-geometry form of `toc_section_title`).
- **Repeated-row TOC** (one resizable unit per section): ONE `repeated` slot (any form name, e.g. `sections`)
  with **standard subslots** `toc_section_marker` / `toc_section_title` / `toc_entries` / `toc_pages`.
- On-slide chrome of a special slide (header/navigator/decoration) is part of the variant — keep it in
  `fixed[]` (don't drop it as "chrome"); only chrome that the layout/master provides by inheritance is left out.

## Return
One line per entity: `<id>: <slot names+kinds>` (e.g. `radial-hub: hub(text), spokes(repeated x4)`).
Your final message = just those lines.
