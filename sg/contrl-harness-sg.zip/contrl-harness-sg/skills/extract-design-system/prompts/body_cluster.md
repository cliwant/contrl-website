# body-cluster — merge split units into canonical variants + adornments (vision)

The stage-3 split produced many per-slide **occurrences**. Now merge them into the set of
**canonical types** that recur across the deck. Contact-sheet images show every occurrence as an
index-labeled thumbnail.

**Why granularity matters here:** a canonical variant's fillable slots are tagged later from ONE
representative member. So if you merge structurally-different occurrences into one variant, its slot
schema fits only that one member and every other member breaks at build-stage fill time. Cluster by
**fill-relevant structure**, not by loose visual family. (A past run collapsed swimlanes + timelines +
cyclic loops into one `process-flow`, and column-header tables + key-value grids into one `wide-table`
by aspect ratio — exactly the failure to avoid.)

## Inputs (under the test dir)
- `variant_sheet_01.png, variant_sheet_02.png, …` — every **variant** occurrence, each cell labeled
  `V0, V1, …`. The sheets are **paginated** (a single tall montage downscales to unreadable cells);
  **Read every `variant_sheet_*.png` page in numeric order** — together they cover all variants.
- `adornment_sheet_01.png, …` — every **adornment** occurrence, each cell labeled `A0, A1, …`.
  Paginated the same way; **Read every `adornment_sheet_*.png` page.** (Cells are aspect-sorted, so
  the same form sits adjacent even across a page break — cluster by the tag label, not by page.)
- `manifest.json` — per tag: `{kind, slide, label, aspect, area_frac, n_shapes}`. Use `label`/features
  to disambiguate, but **the image is the primary signal** — Read all the sheet pages.

## How to cluster variants — same SKELETON, judged on distinguishing axes

Two occurrences are the **same variant only if they match on ALL the structural axes the build stage
would fill differently.** Belonging to the same broad family (both tables, both "flows") is NOT enough.
Ignore the specific words/photos; judge the arrangement. Differ on **any** axis → **different** variant.

- **Tables** — distinguish by HEADER STRUCTURE, **never by aspect ratio or size**:
  `column-header data table` · `row-label (left-header) matrix` · `key-value spec grid` ·
  `category-grouped table` · `comparison / AS-IS·TO-BE table`. A 17-row and a 5-row column-header table
  are the **same** variant; a column-header table and a key-value grid are **different**. Aspect ratio
  (wide/square/tall) is NOT a structure — never cluster or name by it.
- **Flows / diagrams** — distinguish by TOPOLOGY: `linear pipeline` · `lane/swimlane (actors × phases)` ·
  `cyclic loop` · `decision / branch tree` · `chevron step sequence` · `timeline / gantt` ·
  `radial hub-and-spokes` · `layered stack` · `node-and-connector relationship`. Different topology →
  different variant. Do **not** lump them into one generic flow/diagram bucket.
- **Cards / panels** — distinguish by per-cell TEMPLATE: `icon+caption card` · `text bullet panel` ·
  `label+screenshot` · `numbered step card` · `quadrant matrix`. Column **count** is captured later as
  cardinality, so 3-col vs 4-col of the *same* card template = same variant; an icon-card row vs a
  text-panel row = different variants.
- **Text blocks** — `single lead/intro paragraph` · `bulleted outline panel` · `titled definition block`.

## Procedure (do this to avoid scale-induced over-merging)
With hundreds of occurrences it is tempting to settle on a few mega-buckets. Resist it:
1. Pass 1 — bin every tag into a coarse family (table / flow-diagram / cards-panels / text / other).
2. Pass 2 — **inside each family, enumerate the distinct skeletons** you actually see (by the axes
   above) and make one cluster per skeleton. This is where the real work is — most families hold
   several skeletons, not one.
3. Assign every tag to exactly one skeleton cluster.

## Naming — descriptive skeleton, not a broad category
- `id` = **3–5 kebab words naming the structural skeleton**, form/role only and intent-agnostic
  (cross-intent test: would the name still fit if a different intent used it?). Never content-derived.
- **Forbidden:** broad one/two-word category names (`process-flow`, `column-cards`, `diagram`, `table`)
  and any size/aspect name (`wide-table`, `square-table`, `tall-table`).
- **Good:** `column-header-data-table`, `key-value-spec-table`, `comparison-matrix-table`,
  `swimlane-phase-flow`, `chevron-step-flow`, `cyclic-process-loop`, `radial-hub-and-spokes`,
  `layered-stack-diagram`, `icon-caption-card-row`, `numbered-step-card-row`, `lead-paragraph`,
  `bulleted-outline-panel`, `before-after-comparison`.
- `name`: short human label. `description`: one line on the skeleton (the distinguishing axes),
  intent-independent.

## Guard against BOTH failure modes
- **Don't over-merge (the common failure).** If a cluster's members span different topologies / header
  structures / cell templates, SPLIT it. If a variant cluster exceeds **~12 members**, re-examine it for
  hidden sub-skeletons before keeping it — the only exception is a genuinely *pure repeat* (e.g. the
  identical one-line intro paragraph) that really is the same skeleton every time.
- **Don't over-split / leave twins.** If two clusters share the SAME skeleton and the SAME cell template
  (differing only in row/column count or content), MERGE them. Never emit `id-2` / `id-3`
  near-duplicates of one skeleton.
- A singleton cluster is fine for a genuinely unique skeleton. Make **as many distinct skeletons as
  truly exist** — there is **no target count** and no "small set" to shrink to; build-stage fill fidelity
  is the goal, not a compact pool.

## How to cluster adornments — same visual FORM
Adornment sameness = the *style* of the thin label/band (ruled line with tick marks, triangle/chevron
bullet, solid color band, gradient band, pill-on-rule). **Ignore the text.** Adornments collapse hard —
expect only a **handful of forms** total.

## Output
Write `<test_dir>/clusters.json`:
```json
{ "variants": [
    { "id": "kebab-skeleton", "name": "Human Label", "description": "one line on the structure",
      "members": ["V0","V7"] }, ... ],
  "adornments": [
    { "id": "kebab-slug", "name": "Form Name", "description": "the band/label style",
      "members": ["A0","A3","A9"] }, ... ] }
```
Rules: every tag appears in exactly one cluster. `id` = structural skeleton slug (NOT content-derived).
Return after writing the file, with a one-line summary: variant-cluster count, adornment-cluster count,
and the largest few variant clusters by member count.
