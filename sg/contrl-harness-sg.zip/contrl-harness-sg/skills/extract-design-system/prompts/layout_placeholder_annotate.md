# layout-placeholder-annotate — give layout placeholders meaning (vision)

Layout placeholders come out of dedup with OOXML-ordinal names (`body`, `body_2`, …) and no
semantics. The Phase-1 plan-builder routes content into them **by `name`**, so each placeholder
needs a meaningful name + `description` + `convention` — mirroring variant slots' core.

You handle a BATCH of canonical layouts; do each independently.

## Input
A batch file (JSON array). Each item: `{id, dir, placeholders}` where `placeholders` is the
mechanical skeleton from `layout_build` — each `{name(provisional), kind, target:{ph_type,ph_idx},
bbox, prompt_text}`. For EACH layout, **Read the frame render `<run>/layouts/<id>/preview.png` if it
exists** (empty frame: header band, placeholder boxes, footer) and use `bbox` to map each placeholder
to its spot. **If the render is absent**, reason from `bbox`(position) + `ph_type` + `prompt_text`
alone — enough to assign roles in a standard RFP frame.

## Output
Write `<run>/_work/layout/ph_annot.json`, accumulating:
```json
{ "<layout_id>": { "<ph_idx>": { "name": "...", "description": "...", "convention": "..." }, ... }, ... }
```
Key each annotation by its placeholder's `ph_idx` (a string) so it merges back onto the skeleton.

## Rules
1. **`name` = the placeholder's ROLE in the frame, semantic — never content.** Look at WHERE it sits
   and what it is: top breadcrumb strip → `section_breadcrumb`; the page title line → `page_title`;
   a lead/intro paragraph under the title → `lead_paragraph`; the main body region → `body`; a
   footer text → `footer_text`; page number → `page_number`. Form/role, not the sample text.
2. **Unique within the layout** — `name` is the join key; no two placeholders in one layout share a name.
3. **Do NOT touch `kind` or `target`.** `target` (`ph_type`+`ph_idx`) is the OOXML anchor — the merge
   keeps it verbatim. You only supply `name`/`description`/`convention`.
4. **`description`** = what the region is (visual/structural/positional) — "헤더 띠 상단의 브레드크럼".
5. **`convention`** = how Phase 1/2 fills it: format, length, tone, relation to sibling placeholders —
   "한 줄, '챕터 > 섹션' 경로; 슬라이드 목차 위치를 반영".
6. **No `cardinality`/`subslots`** — placeholders are fixed `<p:ph>` slots, not resizable composites.
7. If `prompt_text`/position is ambiguous, infer the most likely role from layout convention
   (Korean RFP decks: top band = breadcrumb + chapter title; large center = body).

## Return
One line per layout: `<id>: <ph_idx→name list>`. Final message = just those lines.
