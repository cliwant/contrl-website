# intent-discover — assign a rhetorical intent to every slide (vision/text, one global pass)

An **intent** is the *rhetorical role* a slide plays in the proposal (e.g. "objective & approach",
"system architecture overview", "test plan") — never a visual shape. Done once for the whole deck
from the text, so the role vocabulary stays consistent (per-slide guessing causes name drift).

## Input
`<run>/text/slides.md` — the deck's text, slides separated by `<!-- Slide number: N -->` markers.
Read it and note how many slides the deck has (cover them ALL).

## Rules
- **One slide → exactly one intent.** Never split a slide across intents.
- **Intent = rhetorical role, NOT visual.** No `diagram`/`table`/`timeline` names — those describe
  variants, not roles. Ask "what is this slide *for*?", not "what does it look like?".
- **Consolidate by role across the deck.** Don't mint a unique intent per slide. Seed candidates
  from the section/subsection headers, then merge slides that play the same role into one intent.
- `id`: snake-case, role-only (`system_architecture_overview`). `name`: short human label.
  `description`: one sentence on the role — later used to judge "is my content this role?".
- **Cover every slide**, including cover/TOC/divider pages (give them a role like `cover`, `toc`,
  `section_divider`).

## Output
Write `<run>/intent_discovery.json` directly:
```json
{ "intents": [ {"id": "...", "name": "...", "description": "..."}, ... ],
  "slide_intent": { "1": "<intent_id>", "2": "<intent_id>", ... } }
```
`slide_intent` must have an entry for every slide number in the deck, and every value must be an
`id` present in `intents`. (Downstream `catalog_compile.py` reads exactly this shape.)

## Return
One line: number of intents + confirmation that all N slides are assigned.
