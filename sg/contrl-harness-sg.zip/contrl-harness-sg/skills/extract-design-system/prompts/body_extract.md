# body-extract — split a slide body into adornment + variant units (vision)

You are given ONE slide. Split its **body** (the content area, layout frame already excluded)
into atomic **units**. Each unit is exactly one of:

- **adornment** — a thin decorative header/label: a sub-heading strip, ruled label, colored
  band, or pill that holds a single short title line. Usually sits at the top of a block.
- **variant** — a reusable **content block**: a card row, a table, a diagram, bullet panels,
  a screenshot, etc. This is the substantive content under/around the adornments.

## Inputs (per slide, under the input json)
- `render` — path to the rendered slide PNG. **Read it** — this is your primary signal.
- `content_box` — the body region in EMU; only split what's inside it.
- `shapes[]` — top-level body shapes with `{id, tag, bbox(EMU), text}`. Use these to set
  precise unit bounds and to know what text each region holds.
- `slide_emu` — slide {w,h} in EMU.

## How to split — atomicity rules (this is the whole game)

**Granularity target: COARSE. One variant = one whole content block** — everything that sits
under one section header — *including* its internal columns, side-by-side panels, sub-headers,
footnotes, legends, and captions. Err toward FEWER, LARGER variants. When unsure whether to
split, **don't**.

1. **A variant = ONE content block.** A 3-column card row is **one** variant. A table is one.
   A diagram is one.
2. **Side-by-side panels — merge vs split by FORM:**
   - **Merge into one variant** when the side-by-side regions are a **uniform repeating set**
     (N same-template columns/cards) OR **two views of one thing under one shared header**
     (e.g. a donut + a bar chart both showing "the 17 staff" under one "보유현황" header).
   - **Keep separate** when each side-by-side region is its own **self-contained block of a
     DIFFERENT structure** (e.g. a checklist column | a node-chain diagram | a data table sitting
     in three columns — that's **three** variants, not one).
3. **Fold internal furniture INTO the variant**: its own sub-headers ("기술 등급별"), footnotes,
   legends, captions, totals — these are part of the variant, not separate units.
4. **Stacked blocks = separate variants** when they are independent content (a card row, then a
   clearly separate table below).
5. **Adornment = a block's HEADER/LABEL — judged by ROLE, not style.** An adornment is a SHORT
   title (usually one line, a few words) that **names** the block below it. The visual style
   (rule, pill, band, triangle marker) is secondary.
   **Test: does it *name* the block (→ adornment) or *convey information* (→ content)?**
   A band is **NOT** an adornment if it carries **content** — multiple text lines, a list, data
   values, or full sentences — *even if it is a colored/gradient band*. That is content (a variant
   or part of one). (e.g. a gradient strip listing "Data format: Shapefile, GeoJSON…" = content.)
6. **Images: capture content photos, omit only tiny decorations.**
   - **Content image → capture as a `variant` image unit** (`shape_ids` = the picture). This covers any sizable photo/illustration (rule of thumb: `area_frac ≳ 0.06` of the slide) — a side/hero photo beside text, an example image, a photo set, a screenshot. These change per proposal, so they are **fillable image regions**, not chrome. Don't drop them just because they carry no text.
   - **Full-bleed background photo** (spans ~the whole slide, with text laid over it) → capture as its **own** image `variant` (a background-image unit), separate from the text block on top of it.
   - **Genuine decoration → omit**: only text-less *and* small/structural ornaments — background swooshes, connector lines, divider rules, corner accents, tiny bullet glyphs/badges.
7. **A block is typically [one adornment header] + [one variant content]**; some blocks have only
   content. Don't invent adornments for sub-headers that belong inside a variant (rule 3), and
   don't tag a content/data band as an adornment (rule 5).
8. A unit's `bbox_emu` = the tight bounds of the shapes that make it up (snap to `shapes[]`).

**Sanity check before writing:** a typical body slide has **1–3 variants**. If you produced 5+,
you are almost certainly over-splitting — merge side-by-side panels and fold sub-headers/callouts.

## Output
Write `<out_dir>/slide_<n>.json`:
```json
{ "slide": <n>,
  "units": [
    { "kind": "adornment", "bbox_emu": {"x":..,"y":..,"w":..,"h":..}, "shape_ids": [".."], "label": "short" },
    { "kind": "variant",   "bbox_emu": {"x":..,"y":..,"w":..,"h":..}, "shape_ids": ["..",".."], "label": "short" }
  ] }
```
Order units top-to-bottom. `label` = a few words describing the unit (for human reading).
Return only after writing the file.
