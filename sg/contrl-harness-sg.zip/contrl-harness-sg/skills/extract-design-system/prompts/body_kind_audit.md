# body-kind-audit — re-check each canonical ADORNMENT type (catch split misclassification)

The split step labels each unit adornment/variant; clustering trusts that label. A split error
(e.g. a content band mislabeled as an adornment) therefore survives. This step is the second net:
**re-judge each canonical adornment TYPE by role, and reclassify content as variant.**

## Inputs (test dir)
- `clusters.json` — has `adornments[]`, each `{id, name, description, members:[tags]}`.
- crops: `crops/<tag>.png`. For each adornment type, **Read the representative crop** = its first member tag.

## The test (role, not style)
For each adornment type, decide:
- **adornment (keep)** — it's a block's HEADER/LABEL: a SHORT title (one line, a few words) that
  *names* the block. Thin strip with a rule / triangle bullet / pill / colored band + short label.
- **content (reclassify → variant)** — it carries **information**: multiple text lines, a list,
  data values, full sentences — even if it's a colored/gradient band. It is NOT a header.

Test: does the type *name* a block (→ keep adornment) or *convey information* (→ content)?

## Output
Write `<test_dir>/kind_audit.json`:
```json
{ "verdicts": [
    { "id": "<adornment id>", "verdict": "adornment" | "content", "reason": "one line" }, ... ] }
```
Judge every adornment type in clusters.json. Read each type's representative crop before deciding.
Return a brief summary: which types kept, which reclassified to content, and why.
