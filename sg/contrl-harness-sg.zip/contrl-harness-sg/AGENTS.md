# Rule

- Avoid meaningless line breaks. Break lines only at sentence boundaries.
- Use bold (`**`) sparingly. Emphasize only one or two truly important points in a paragraph; when everything is emphasized, nothing is.
- If one-off validation needs Node packages such as Playwright, create the temporary Node project under `/tmp` rather than adding `package.json` or `node_modules` at the repo root.

# Customer Delivery Defaults

- For this branch, all user-facing CONTRL outputs and artifacts must be in English.
- Translate or summarize non-English source material into natural business English before writing JSON artifacts, Markdown analysis, HTML panels, slide text, speaker-facing copy, or deck content.
- For procurement pre-research and bid-signal lookup, use Singapore public procurement by default. Prefer Cliwant global MCP GeBIZ tools (`mcp__global_cliwant.global_search_bids` with `region: "SG"`) before general web search.
- Do not use Korea Nara Marketplace/KONEPS/G2B, Korea-focused `signals` procurement routes, or US/SAM.gov unless the user explicitly asks for that country context.

# Repo Context

- This repository is the harness-engineering layer that grew out of the original `contrl` repo's LLM API and GUI-based behavior.
- Some traces of the legacy app runtime, GUI, API, logs, and worker implementation may remain. When reviewing changes, distinguish the harness skill contract from historical app implementation details.

# Agent Authoring Rules

Conventions for writing or editing `agents/*.md` subagent definitions. These are authoring principles, not runtime instructions.

## Three-Layer Responsibility Split

- **skill (`skills/*/SKILL.md`)** — the single domain source: prompts, schemas, algorithms, citation rules, IO paths, and stage-specific selection specs.
- **agent (`agents/*-runner.md`)** — the execution shell: which skill to read, call signature, return shape, and stage-specific execution strategy such as fan-out or catalog stamping.
- **orchestrator (`skills/pipeline`)** — cross-stage behavior: ordering, gates, cascades, parallelism, and user selection flows.

Principle: **each fact lives in one layer only. Other layers reference it instead of restating it.**

Injection mechanism: an agent file body becomes the spawned agent's own system prompt, while only the frontmatter `description` is automatically exposed to the caller.
Therefore, caller-visible information such as call signatures and return shapes is not communicated merely by writing it inside the agent body.

## Runner Rules (All `*-runner` Files)

Stage runner agent files do not restate the following rules. They assume this contract and document only their stage-specific behavior.

1. **The skill is the single domain source.** A runner reads the matching skill first and follows its contract exactly: prompts, schemas, IO paths, citations, and algorithms. Do not restate IO paths, schemas, or citation rules in the agent file.
2. **Gates belong to the orchestrator.** Preconditions such as prior artifacts are checked by `gate <stage> before` in the orchestrator. The runner trusts gated input, while still validating its own outputs for schema, count, and consistency.
3. **Cascades belong only to the orchestrator.** Neither runners nor skills delete downstream artifacts. The orchestrator performs that work under the `pipeline` cascade rules before regeneration or selection changes.
4. **Retry once, then report.** A runner retries its own work at most once unless the skill states a different count. On repeated failure, stop and include the reason in the return value. The orchestrator decides whether the next stage may proceed. Partial failures must not be silently dropped; include a failure list in the return value.
5. **Pass data through the contract.** Input and output artifacts follow the skill IO contract. The orchestrator receives a return value containing success status, absolute paths written, validation summary, and failure code/reason when applicable. Stage-specific return fields are defined by each agent file.
