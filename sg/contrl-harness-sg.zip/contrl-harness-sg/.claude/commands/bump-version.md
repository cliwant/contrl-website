# Plugin Version Bump

`.claude-plugin/plugin.json` 의 버전을 올리고 커밋한다.

## 실행 순서

### 1. 현재 버전 읽기

`Read` 도구로 `.claude-plugin/plugin.json` 을 읽어 `version` 필드를 파싱한다.

### 2. 버전 종류 선택 — AskUserQuestion 호출

아래 형식으로 `AskUserQuestion` 을 호출한다.

- `patch` — 세 번째 자리(X.Y.Z). 버그 수정·문서 업데이트·소규모 조정처럼 내부만 바뀌었을 때. **(추천)**
- `minor` — 두 번째 자리(X.Y.0). 신규 기능·스킬·에이전트 추가처럼 공개 인터페이스가 늘었을 때.
`major` update는 breaking change가 있을 때만 사용하므로 특별한 상황이 아니라면 사용하지 않는다.

현재 버전과 bump 후 결과를 옵션 description에 보여준다.
예: `patch → 1.1.5 → 1.1.6`

### 3. 버전 계산

선택에 따라 버전을 계산한다.

- `patch`: `Z += 1`
- `minor`: `Y += 1`, `Z = 0`

### 4. plugin.json 업데이트

`Edit` 도구로 `version` 값만 교체한다.

### 5. CHANGELOG.md 작성

마지막 릴리즈 태그/버전 이후 `git log`, `git diff` 로 변경 내역을 파악해 `CHANGELOG.md` 최상단에 새 버전 섹션을 추가한다.
기존 항목들의 톤·포맷(버전 헤더 + 날짜, 이어서 요약 문단, 사용자 관점 bullet 목록)을 그대로 따른다. PR 링크는 이 시점엔 아직 없으므로 생략한다.

### 6. 커밋

`.claude-plugin/plugin.json` 과 `CHANGELOG.md` 를 스테이징해 커밋한다.
커밋 메시지 형식: `chore(plugin): bump version to {new_version}`
push는 user에게 확인 후 진행한다.

### 7. PR 생성 & 머지

push 후 `gh pr create` 로 PR을 생성한다 (base: `main`). 제목은 커밋 메시지와 동일하게, 본문에는 이번 CHANGELOG 항목을 요약해 넣는다.
머지는 반드시 user에게 확인받은 후에만 `gh pr merge` 로 진행한다. 확인 없이 임의로 머지하지 않는다.

### 8. Slack 알림 (merge 완료 시)

PR이 머지되면, slack 메시지 전송이 가능한 skill/MCP(예: `slack` 계열 skill, `mcp__*slack*` 도구)가 이 세션에서 사용 가능한지 먼저 확인한다.

- 사용 가능하면 `AskUserQuestion` 으로 "#proj-contrl 채널에 이번 업데이트 changelog와 업데이트 방법을 함께 보낼까요?" 를 물어본다.
- 사용자가 승인하면 `#proj-contrl` 채널에 다음을 포함해 메시지를 보낸다.
  - 이번 버전의 CHANGELOG 항목 (5번에서 작성한 내용)
  - 업데이트 방법 안내: "CONTRL 플러그인을 최신 버전으로 업데이트해서, Claude Code App 재시작 후에 새 버전이 적용되도록 확인해줘."
- slack 관련 skill/MCP가 인증되지 않았거나 사용 불가능하면, 그 사실을 user에게 알리고 이 단계는 건너뛴다 (임의로 다른 방식으로 대체 전송하지 않는다).

### 9. 완료 보고

커밋 해시, 새 버전, PR URL, 머지 여부, Slack 전송 여부를 한 줄로 출력한다.
