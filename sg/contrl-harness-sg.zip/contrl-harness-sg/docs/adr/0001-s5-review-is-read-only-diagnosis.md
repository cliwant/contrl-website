# S5 human review is read-only diagnosis, not intent editing

The S5 human-in-the-loop was first designed as intent correction — a human overrides a slide's intent and the slide re-plans, backed by a separate overlay store (`section_id` + content-hash anchor), approved/override markers, a write-capable localhost server, and a stale-set coordination loop.

We reframed it to read-only diagnosis. The feature now surfaces each slide's plan decision (intent/layout/variant as catalog previews) beside its render, plus a deck-level distribution, so a human can judge quality and localize a fault to the plan (S5) or the render/fit (S6). In v1 there is no write-back, no store, no anchor, and no re-plan — the whole `overrides.json` / coordination-loop machinery is dropped. Correction is out of scope and left to the render-feedback re-fit path that already exists.

Chosen because the highest-leverage gap is legibility — a wrong-but-plausible intent is invisible in ids/logs and only shows once you can compare the render against the catalog piece it was planned from — not another editing channel competing with the branch's render-feedback loop. Correction (intent override → re-plan) remains designed-for but deferred.
