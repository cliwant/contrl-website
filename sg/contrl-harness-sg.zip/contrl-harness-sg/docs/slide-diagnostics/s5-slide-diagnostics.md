# Slide diagnostics — S5 Slide Plan을 사람이 검수하는 read-only 진단

> **Slide Plan 단계**(파이프라인 S5 — slide_contents를 design-system catalog에 매칭해 렌더 준비가 끝난 `slide_plan.json`을 만드는 단계)가 제대로 동작했는지 사람이 눈으로 확인하는 기능의 설계 문서.
> 산문은 한국어, 도메인/기술 용어는 영어로 유지한다. 관련 결정은 [ADR 0001](../adr/0001-s5-review-is-read-only-diagnosis.md)·[ADR 0002](../adr/0002-converge-slide-diagnostics-replacing-render-review.md), 용어는 [CONTEXT.md](../../CONTEXT.md) 참조.

## TL;DR

Slide Plan의 매칭은 "지금 쓰려는 내용이 design system에 비슷하게 표현된 적이 있다"는 숨은 가정 위에서 돈다. 가정이 깨지면 슬라이드가 잘못 조립되는데, 가장 흔하고 까다로운 실패는 *intent가 붙긴 했지만 틀린* 경우다 — ID·로그만 봐선 정상처럼 보여 render preview로만 드러난다. 이 기능은 사람이 그걸 **진단**하게 한다: 각 슬라이드의 render를 그 plan 결정(catalog 조각)과 나란히 놓아, 이상이 plan(S5) 결함인지 render/fit(S6) 결함인지 localize한다. v1은 **진단만** 한다 — 편집·re-plan은 하지 않는다(ADR 0001). 표면은 별개 패널이 아니라 render-review를 대체하는 단일 read-only 뷰다(ADR 0002).

## 1. 문제 — 무엇이 실패하나

Slide Plan의 matching 로직은 위 숨은 가정 위에서 동작한다. 가정이 깨질 때 세 가지 failure class가 나타나고, 가장 까다로운 건 첫 번째다 — ID·로그만 봐선 정상처럼 보인다.

### Failure Class 1 — Wrong intent matched (`intent_id` ≠ null, 부적절) · 가장 흔함 · 핵심
intent가 매칭되긴 했지만 내용에 안 맞는 게 붙는다. floor도 fallback도 아니라 ID·로그론 정상처럼 보이고, render preview로만 "골격이 내용과 안 맞는다"가 드러난다. 기계가 못 잡는 유일한 class라 사람 판단이 실제로 필요한 지점이다.

### Failure Class 2 — Floor (`intent_id = null`) · 심각
맞는 intent를 전혀 못 찾아 degraded floor로 강등된다. 결과가 가장 크게 망가지지만 **기계가 안다**(`intent_id = null`).

### Failure Class 3 — Fallback variant · 부분 실패
intent는 찾았지만 일부 block이 맞는 variant를 못 만나 generic fallback으로 떨어진다. 골격은 맞고 살이 일부 빠진 상태로, 이것도 **기계가 안다**(fallback variant 플래그).

정리하면 Class 2·3은 기계가 degraded임을 아니 *표시*하면 되고, Class 1은 기계가 못 잡으니 *사람이 본다*. 더 근본 문제는 정보의 부재였다 — AI 결정이 왜 그렇게 났는지, 슬라이드가 실제로 어떻게 렌더됐는지 나란히 볼 surface가 없었다. 이 기능이 그 surface다.

## 2. 정체성 — read-only 진단이지 편집이 아니다 (ADR 0001)

이 기능은 한때 intent 교정으로 설계됐다: 사람이 intent를 override하면 그 슬라이드를 re-plan하고, 그 흔적을 별도 overlay store(`section_id`+hash anchor)·approved/override 마커·write 서버·stale-set coordination loop로 관리한다. 그 척추를 전부 **드러냈다.**

지금은 진단만 한다. 산출물은 저장 아티팩트가 아니라 *이해*다 — 사람이 각 슬라이드를 render + plan 결정으로 판정하고 결함을 S5/S6로 localize하면 목적 달성이다. v1엔 write-back·store·anchor·re-plan이 없다. 교정(intent override → re-plan)은 여전히 설계 대상이나 **defer**하고, render 층의 자연어 피드백 → re-fit 경로가 이미 편집을 담당한다. 이유: 가장 큰 레버는 또 하나의 편집 통로가 아니라, ID·로그로 안 보이는 Class 1을 *드러내는 가시성*이다.

**핵심 통찰(진단에도 유효):** intent는 dependency tree의 뿌리다 — `allowed_variant_ids`·`layout_affinity`·adornment가 전부 intent에서 파생된다. 그래서 진단도 intent를 축으로 읽고, variant가 그 intent의 allowed에서 벗어났는지(`allowed ✓/✗`)를 신호로 쓴다. 단 Slide Plan은 slide-isolated 설계라(다른 슬라이드·절대 인덱스 의존 없음) 한 슬라이드의 오류가 옆 슬라이드를 오염시키지 않으므로, "한 장씩 멈춰 승인받는" gate를 강제할 도메인 이유는 없다 — 진단은 advisory다.

## 3. 표면 — 수렴, render-review를 대체 (ADR 0002)

`render_review`(S6, `after.png` 2열 그리드 정독 + 일시정지 re-fit 피드백의 표시 화면)와 이 plan 진단은 겹친다 — 진단이 상위집합(render + plan 조각 + 분포)이라, 별개 두 패널로 두지 않고 **하나의 read-only per-slide 표면으로 수렴**해 render-review를 대체한다. render-review가 물려 있던 re-fit 피드백 루프는 파이프라인(orchestrator) 행동이라 유지되고, 그 루프가 새로고침하는 화면만 이 진단으로 바뀐다 — 패널 자체는 read-only. 대가로 이 표면은 S5↔S6 스테이지 소유를 가로지른다(plan record·catalog preview = S5, render 산출 = S6)이며, co-located localization을 위해 수용한다. `render_review.py`/`render-review.html`을 확장할지 새 리더로 갈아끼울지는 구현 세부다.

## 4. 뷰 구조 — overview-first + focused overlay

진단의 본령은 "많은 슬라이드에서 문제를 빠르게 짚기"라 균일 카드 나열이 아니라 overview 우선으로 간다.

- **Overview 그리드(주 화면).** 전 슬라이드의 render 썸네일을 그리드로 펼쳐 한눈에 스캔한다. floor/fallback은 상태 색으로 튀고, 정상은 물러난다. render-review와의 시각 일관성을 위해 2열을 기본으로 한다(슬라이드 사이 여백). 그리드 셀 aspect는 실제 slide 치수에서 온다(§6, orientation-aware).
- **Focused overlay(선택 시).** 슬라이드를 클릭하면 뷰포트 대부분을 쓰는 상세로 확대된다 — RENDER를 크게(plan을 스크롤해도 계속 보이게 고정), 옆(portrait) 또는 아래(landscape)에 SLIDE PLAN의 catalog 조각을 **큼직하게**: layout·variant·adornment의 `preview.png` 썸네일. plan pane은 intent를 뿌리로 위계를 세운다 — 최상단에 intent 카드(이름·설명, Class 1 진단의 주어), 그 아래 Layout·Block 단위로 경계가 명시된 섹션. variant마다 `slots · used_by · allowed ✓/✗` 메타를 붙여 "이 variant가 이 intent에 허용되나"를 바로 보인다. prev/next·키보드로 이웃 슬라이드 이동, 썸네일 클릭 시 전체화면 확대. localization은 여기서 완성된다 — render(실제)와 catalog 조각(이상형)을 대면해, 모양이 다르면 fit 결함, 조각 자체가 내용에 안 맞으면 plan 결함.
- **Option(비선택 후보 — 용어는 [CONTEXT.md](../../CONTEXT.md)).** 각 결정 지점에서 고를 수 있었지만 선택되지 않은 catalog entity를, 그 domain의 위계 안에 접힌 목록으로 함께 보여준다: intent 카드 안의 다른 intent(catalog 전체, 텍스트), Layout 섹션 안의 다른 layout(`layout_affinity` 미선택분), 블록들 뒤의 다른 variant(그 intent의 `allowed_variant_ids` 중 그 슬라이드 미사용분). "이 내용이면 저 intent/variant가 맞지 않았나"라는 Class 1 판단에 비교 대상을 준다. adornment는 intent에 종속되지 않는 전역 pool이라 option 집합이 정의되지 않아 제외한다. option은 보기 전용이다 — 선택·적용은 defer(§7). 비용은 catalog 크기에 비례하고 덱 크기와 무관하다(twin 샘플 기준 패널 +0.7MB).
- **색 문법.** 채도 있는 색 = 이상 신호 전용(floor 빨강 · fallback 노랑 · `allowed ✗` 보라). 위계 강조(intent 카드·섹션 헤더)는 크기·타이포·무채색 경계로만 한다 — 정상 슬라이드가 경보처럼 읽히지 않게.
- **Deck distribution(슬림).** 상단에 intent·layout·variant 분포를 슬림하게 두고, `분포 상세` 토글로 펼친다. 막대 클릭 = 그 엔티티로 그리드 필터(집계 ↔ 인스턴스 연결). 활성 필터는 제거 가능한 칩으로 표시.

## 5. 신호 처리 — 경보와 힌트를 구분한다

- **floor / fallback = 경보(색).** 기계가 degraded임을 확실히 아니 색 플래그로 주의를 끈다.
- **분포 쏠림 = 힌트(경보 아님).** 제안서는 같은 골격을 반복하는 문서라 "한 intent에 여러 장"이 정상일 수 있다 — 기계는 정상 반복과 오매칭 뭉침을 구별 못 한다. 그래서 쏠림은 색으로 판정하지 않고 분포에서 정렬·필터로 *보이게*만 해서, "여긴 comparison이어야 하는데 다 kpi로 갔네" 같은 판단을 사람에게 맡긴다.
- **`allowed ✗` = 진단 신호.** variant가 그 슬라이드 intent의 `allowed_variant_ids`에서 벗어나면 overlay에서 ✗로 떠, plan/validation 이상을 눈으로 잡게 한다.

## 6. 데이터 · 타이밍

- **결과(outcome)만으로 그린다.** DECISION 레코드/`slide_plan.json`은 선택된 intent·layout·블록별 variant·status만 담고, `_meta`가 `floored_count`·`fallback_count`·`referenced_ids`를 이미 집계한다 — 분포·플래그는 여기서 새 인프라 없이 계산된다. "왜 이 intent를 골랐나"(candidate·score·near-miss)는 레코드에 없다(§7 defer).
- **시각 조각은 catalog가 이미 가진 것을 재사용.** `variants/<id>/preview.png`·`_work/layout_previews/<id>/preview.png`·adornment preview. catalog.html이 이미 base64 인라인하는 것과 같은 결이다.
- **Orientation-aware.** slide 치수(`catalog.meta.slide_emu`)로 portrait/landscape를 판정해 그리드 aspect와 overlay 레이아웃(portrait=render 왼/plan 오, landscape=render 위/plan 아래)을 분기한다.
- **스트리밍 = 기존 메커니즘.** render-review처럼 슬라이드가 `fit_done` 될 때마다 스크립트가 HTML을 다시 뽑아 덮어쓰고 shell iframe이 주기적으로 reload한다. plan 조각은 plan-time에 먼저 뜨고 render는 완료되는 대로 채워진다. **단독 S5 실행**(after.png 없음)이면 render 자리는 "렌더 대기" placeholder로 두고 plan+분포만 보여주는 plan-only degrade가 공짜로 나온다.

## 7. v1 경계

**In scope:** overview 그리드(orientation-aware, 상태 색, 2열) + focused overlay(고정 render | intent 카드 + 경계 명시 섹션의 catalog 조각 layout·variant·adornment + `slots·used_by·allowed`) + domain별 Option 표시(다른 intent 전체 · 미선택 layout · 미사용 allowed variant — adornment 제외) + 슬림 deck distribution(막대 클릭 필터) + floor/fallback 경보 · 쏠림 힌트, read-only(store·write 없음), render-review 대체(수렴), 스트리밍 + 단독 S5 degrade.

**Designed-for but deferred:** intent override → re-plan(편집 경로 전체 — overlay store·anchor·coordination loop) — Option 표시(위)는 그 읽기 절반이고 선택·적용(다른 intent 하위요소 탐색, [적용하기] → re-plan/re-render)이 이 defer에 남는다, candidate intelligence(왜 이 intent · score · near-miss), variant·adornment leaf edit, 여러 덱에 걸친 시스템 집계(실패율·오매칭 패턴), Class 3 자동 교정.
