<!-- Default target branch: dev -->
<!--
## Title guide

Use this format for the PR title:

`type(scope): user-facing outcome`
-->

### `scope` 작성 기준

- 이 PR의 중심 변경 책임이 있는 기능, 플로우, 또는 서브시스템 이름을 짧게 작성합니다.
- 파일명 대신 리뷰어가 바로 이해할 수 있는 개념 단위를 사용합니다.
- 여러 영역을 수정했더라도 가장 핵심이 되는 한 단위를 선택합니다.
- 가능하면 사용자 기능 단위를 우선하고, 내부 개선 PR이면 서브시스템 단위를 사용합니다.

Examples:

- `fix(windows-runtime): guard startup failure banner during shutdown`
- `feat(projects): persist project template selection in workspace`

## 1. What problem is this PR solving?

- [기획 관점에서 해결하려는 문제를 자세히 작성]
- [사용자, 운영, 제품 흐름에서 어떤 불편 또는 리스크가 있었는지 작성]
- [버그 수정이 아니라 기능 추가라면, 이 변경이 사용자에게 어떤 가치나 개선을 주는지 작성]
- [이 변경이 적용되면 무엇이 어떻게 달라지는지 한두 문장으로 작성]

## 2. Implementation plan

### 핵심 아이디어

- [어떤 방식으로 문제를 풀었는지 한두 문장으로 작성]

### 변경 사항

| 파일/영역 | 변경 내용 |
|----------|----------|
| `path/to/file` | [이 파일에서 무엇을 변경했는지 한 줄 요약] |

### 설계 결정

- [고려했던 다른 선택지가 있었다면 무엇이었는지, 왜 이번 방식을 선택했는지 작성]
- [이번 구현에서 감수한 trade-off가 있다면 무엇인지 작성]
- [이번 PR에서 의도적으로 포함하지 않은 범위나 후속 작업이 있다면 작성]

## 3. Validation and testing

- [실행한 테스트나 검증 절차 작성]
- [예: `uv run python -m pytest ...`, `make test`, `cd electron && npx playwright test ...`]
- [수동 검증을 했다면 시나리오를 간단히 작성]
- [테스트를 못 했다면 이유와 남은 리스크를 작성]
- [자동 테스트로 커버되지 않은 부분이나 아직 남아 있는 리스크가 있다면 작성]

## Optional

- [Acceptance criteria, linked tickets, follow-up tasks, or rollout notes가 있으면 추가]
