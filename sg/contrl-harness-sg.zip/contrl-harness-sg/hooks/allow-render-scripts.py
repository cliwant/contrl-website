#!/usr/bin/env python3
"""PreToolUse hook (contrl plugin) — auto-approve the plugin's OWN render venv python.

Why this exists: S6 (render) runs its Python scripts via a venv at
`<plugin_root>/skills/render/scripts/.venv/bin/python3`. Sub-agents (the fit
agents fit.md dispatches per intent group) cannot answer interactive permission
prompts, so any command that isn't pre-approved is effectively denied for them.

A static permission rule can't express this for plugin installs because the
plugin root differs per machine and permission rules do NOT expand variables.
Hooks DO expand ${CLAUDE_PLUGIN_ROOT} at runtime, so this hook approves exactly
the plugin's own render venv python — wherever the plugin happens to be
installed — and stays silent for everything else (normal permission flow).

Scope is deliberately narrow: only commands invoking this plugin's render venv
python are allowed; no other binary, no system python, no other path.
"""
import sys
import json
import os


def main():
    try:
        data = json.load(sys.stdin)
    except Exception:
        return  # malformed input → emit no decision, fall through to normal flow

    if data.get("tool_name") != "Bash":
        return

    cmd = (data.get("tool_input") or {}).get("command", "") or ""
    root = os.environ.get("CLAUDE_PLUGIN_ROOT", "")
    if not root:
        return

    venv_py = os.path.join(root, "skills", "render", "scripts", ".venv", "bin", "python3")
    if venv_py in cmd:
        print(json.dumps({
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "allow",
                "permissionDecisionReason": "contrl: plugin-owned render venv python pre-approved (S6 render scripts, sub-agent safe)"
            }
        }))


if __name__ == "__main__":
    main()
