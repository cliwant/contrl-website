---
name: slide-planner
model: sonnet
description: >-
  CONTRL 파이프라인 S5 Slide Plan을 실행하는 에이전트. flatten·후보·기계 fill·floor·cover/TOC·assemble 제공 스크립트를 호출하고, 슬라이드마다 서브에이전트 1개를 띄워 매칭 결정을 내려 렌더 준비 완료 slide_plan.json을 만든다.
---

# CONTRL Slide Planner

## 핵심 역할
S5를 전담하는 **thin launcher**다 — 결정론 단계는 제공 스크립트가, 진짜 결정은 슬라이드별 서브에이전트가 한다. 스킬 `slide-plan`이 도메인 단일 출처(스크립트 시그니처·프롬프트·스키마·IO 경로·인용·검증). 이 파일은 재서술하지 않고 스테이지 고유 실행 전략만 적는다.

## 호출 시그니처
- **입력:** `project_name` + (선택) `slide_indices`(부분 재플래닝 → 해당 인덱스만 다시 쓰고 assemble이 머지).
- **반환:** 성공 여부, 슬라이드 수, ok/fallback/floored/failed 집계, assemble 검증 요약(catalog 정합·slot 일치·allowed-list), 쓴 아티팩트 절대경로(`slide_plan.json`).

## 스테이지 고유 (실행 전략)

1. **스킬이 단일 출처.** 먼저 `slide-plan` SKILL을 읽고 그 "제공 스크립트(script↔agent 분담)"·5단계 프롬프트·DECISION 레코드·검증 계약을 그대로 따른다. IO 경로·스키마·인용을 여기 다시 적지 않는다.

2. **흐름:** `flatten.py --split-dir`로 절대 인덱스 input_slides 생성 → 슬라이드마다 서브에이전트 1개(**≤4 동시, 연속 top-up** — 상한까지 채워 두고 하나가 끝나는 즉시 다음 슬라이드를 띄운다; 웨이브가 다 끝나길 기다렸다가 다음 웨이브를 띄우지 않는다)가 `​.plan/slide_{index}.json` 레코드 1개 작성 → 누락/failed는 `make_floor.py`로 floor → `cover_toc.py`로 front-matter → `assemble.py`로 최종 `slide_plan.json`. 기계 단계(flatten·layout_fills·cover_toc·make_floor·assemble)는 **제공 스크립트를 호출**할 뿐 직접 짜지 않는다.

3. **결정은 per-slide 서브에이전트 추론 — 상수 표·builder·heuristic 금지 (SKILL '실행 규율').** 각 서브에이전트는 자기 슬라이드 1장에만 5단계(intent→layout→block→slot→proposal_body)를 적용한다. block_matching의 variant·adornment 후보는 반드시 `slide-plan` skill의 **`loaders.py candidates --project <name> --intent <intent_id>`**(또는 `loaders.get_variants_for_intent` import) 출력에서 고른다 — `DECISIONS[index]`·intent별 canonical 같은 표나 batch builder에 인코딩하지 않고, block_count·slot-shape류 heuristic으로 프롬프트를 대체하지 않는다. 한 서브에이전트는 한 슬라이드만 보므로 cross-slide loop·표가 애초에 불가능하다.

4. **intent==null = 정상.** 서브에이전트가 `make_floor.py`로 degraded floor(콘텐츠 살아있는)를 만들어 `status:"fallback"`으로 쓴다. **절대 빈 슬라이드 금지** — 인프라 실패만 `status:"failed"`.

5. **검증은 assemble.py(2단) + orchestrator 게이트.** assemble이 참조 정합(누락 id real-match → floor 강등) + allowed-list(후보 밖 variant → **fail-loud**)를 돌린다. 사전조건 게이트는 orchestrator 몫이라 재검증하지 않지만, 산출물 검증 실패는 반환값에 싣는다.

6. **에러는 1회(서브에이전트는 transient 최대 2회) 재시도 후 보고.** 끝까지 실패한 슬라이드는 `status:"failed"`로 두어 assemble이 floor로 강등한다. **부분 실패 silent drop 금지** — 실패 인덱스 목록을 반환값에 명시한다.
