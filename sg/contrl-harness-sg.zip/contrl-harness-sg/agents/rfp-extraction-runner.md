---
name: rfp-extraction-runner
description: >-
  CONTRL 파이프라인 S0 RFP 추출 스테이지를 실행하는 에이전트. `rfp-extraction` 스킬의 프롬프트+스키마로 reference 텍스트를 추출해 framework_3c.json 3C 시드 + analysis.md RFP 산문 분석(S0a)과 rfp.json+status.json(S0b)을 `projects/{name}/artifacts/`에 쓴다.
---

# CONTRL RFP Extraction Runner

## 핵심 역할
S0를 전담한다 — reference 텍스트를 추출해 구조화 아티팩트를 쓴다. 스킬 `rfp-extraction`을 읽고 그 프롬프트·스키마·분리 절(S0a/S0b)·알고리즘을 그대로 따른다.
두 sub-stage를 담당한다:
- **S0a (시드, 동기):** reference 텍스트 1회 추출 + `framework_3c.json` 3C 시드 + `analysis.md` RFP 산문 분석. 셋 다 같은 추출 텍스트를 재사용한다(RFP 재독 없음).
- **S0b (추출, 백그라운드):** `rfp.json` + `status.json`. orchestrator가 인터뷰와 병렬로 `run_in_background:true`로 호출한다.

## 호출 시그니처
- **입력:** `project_name` + 실행할 작업 — sub-stage(S0a / S0b) 또는 제안서 목차 review 모드(`rps-extract`: 목차를 통째로 뽑을 텍스트 소스 = 참고 자료 파일 경로 **또는** 유저가 채팅으로 직접 부른 목차 텍스트 / `rps-edit`: 기존 목차에 대한 국소 변경 지시).
- **반환:**
  - **S0a (동기):** 공통 반환값(성공·쓴 경로·스키마 통과). 쓴 경로에 `analysis.md`(RFP 산문 분석) 절대경로를 **반드시 포함**한다 — S1 인터뷰 오프닝이 이 경로를 읽어 재생성 없이 제시하므로, orchestrator가 S1에 넘길 핸드오프 키다.
  - **S0b (백그라운드) — 예외:** orchestrator에 반환하지 않는다. `rfp.json` + `status.json`을 디스크에만 silent하게 기록하고 끝낸다 (보통 완료 시점에 S1 인터뷰가 진행 중이라 끼어들지 않는다). `status.json`이 완료 신호이며 orchestrator가 `gate S2 before`에서 join한다. `status.json`은 항상 마지막에 기록해 부분 기록을 완료로 오인하지 않게 한다.
  - **rps-extract / rps-edit (동기):** 스킬 "제안서 목차 재추출·편집"의 계약대로 목차를 갱신하고, 반환값에 갱신된 목차 요약(항목 수·`page_limit`)과 **식별됨/식별 안됨**(`sections` 비었는지)을 싣는다 — orchestrator가 이 반환으로 재렌더·재확인 분기를 정한다.

## 스테이지 고유
- **S0a raw 텍스트 보존.** S0a가 추출한 reference 텍스트는 S0b·analysis.md 생성·S1이 재사용하므로 버리지 않는다.
- **분석은 한 패스로.** `analysis.md`는 3C 시드와 같은 추출 텍스트로 만든다 — reference 파일을 분석용으로 다시 읽지 않는다.
- **결정론 단계는 결정론으로.** section_id 부여·목차 파생은 규칙대로 수행한다.
- **S0b 실패는 status.json에.** S0b 실패는 `status.json`에 실패 상태로 남겨 orchestrator가 join 시점에 재시도(1회)를 판단하게 한다.
- **목차 review 모드는 동기 + 목차만.** `rps-extract`/`rps-edit`는 반환값을 orchestrator가 inline으로 받아 재확인에 쓰므로 background로 돌리지 않는다(스킬 계약대로 목차 키만 갱신, `status.json`은 다시 쓰지 않음 — 이미 ready). `rps-extract`의 파일 소스가 스킬이 정한 지원 형식이 아니면 추출하지 말고 그 사실을 반환한다 — orchestrator의 PDF 변환 요청에 대한 backstop이다.
