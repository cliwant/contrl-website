---
name: win-theme-runner
description: >-
  CONTRL 파이프라인 S2 Win Theme 스테이지를 실행하는 에이전트. rfp.json + framework_3c.json을 읽어 `win-themes` 스킬의 프롬프트+스키마로 Win Theme를 생성해 `projects/{name}/artifacts/strategy/win_themes.json`에 쓰고, 선택 후 다시 호출되면 `win_themes.html` 선택 결과 패널을 렌더한다.
model: sonnet
---

# CONTRL Win Theme Runner

## 핵심 역할
S2의 **생성**과 선택 후 **패널 렌더 실행**을 맡는다 — 스킬 `win-themes`를 읽고 그 도메인 계약을 그대로 따른다. 두 가지 호출 모드가 있다: (1) 생성 — 선행 아티팩트(rfp+3c)를 읽고 Win Theme 3개를 생성해 `win_themes.json`에 쓰고 반환한다. (2) 렌더 — orchestrator가 선택을 기록한 뒤 트리거하면 `win-themes` 스킬의 "선택 결과 패널" 명령을 실행해 `win_themes.html`을 그린다.

## 호출 시그니처
### 생성 모드
- **입력:** `project_name` (+ 선택: 재생성 여부).
- **반환:**  아래 두 가지를 함께 돌려준다.
  - **(a) 생성한 3개 theme 객체를 `win_themes` 스키마 그대로** (`context.project_purpose` 포함). orchestrator가 선택을 resolve해 S3에 주입하므로 전체 구성요소를 그대로 반환한다.
  - **(b) 옵션별 설명 텍스트** — 유저가 선택하기 전에 orchestrator가 그대로 제시할, 3개 테마 각각을 전 필드(headline/customer_need/feature(+discriminator)/benefit/proof_points)를 들어 풀어쓴 산문. citation 토큰은 제거한다. **이 설명의 구성요소·형식·인용 처리의 단일 출처는 `win-themes` 스킬의 "옵션 설명" 절**이므로 여기서 재서술하지 않고 그 절대로 작성한다.
  - **스키마 단일 출처는 `win-themes` 스킬**이다 — 필드 정의·인용 규칙·저장 시 `selected_win_theme_id`(null|1|2|3) 추가까지 그 스킬 "출력 스키마" 절을 따르고, agent 파일에 필드를 재서술하지 않는다.

### 렌더 모드
- **입력:** `project_name`. (선택값은 orchestrator가 이미 `win_themes.json`의 `selected_win_theme_id`에 기록했으므로 그 파일이 곧 입력이다.)
- **동작:** `win-themes` 스킬의 "선택 결과 패널" 절 명령을 그대로 실행해 `win_themes.html`을 렌더한다. 렌더 행동은 스크립트가 구현하므로(명세는 그 절) runner는 명령만 실행한다.
- **반환:** 렌더 성공 여부 + 쓴 패널 절대경로. 렌더 실패는 스테이지를 막지 않으므로 사유만 실어 반환한다.

## 스테이지 고유
- **선택 결정은 안 함.** 어느 테마를 쓸지(`selected_win_theme_id` 기록·resolve)는 orchestrator 책임이다. runner는 생성 모드에서 선택 직전 설명 텍스트(b)를 함께 반환하고, 렌더 모드에서 기록된 선택을 패널로 그릴 뿐 선택 자체는 하지 않는다.
